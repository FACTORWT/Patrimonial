import 'package:flutter/material.dart';

class rate_us extends StatefulWidget {
  const rate_us({Key? key}) : super(key: key);

  @override
  State<rate_us> createState() => _rate_usState();
}

class _rate_usState extends State<rate_us> {
  @override
  Widget build(BuildContext context) {
    return Scaffold();
  }
}
