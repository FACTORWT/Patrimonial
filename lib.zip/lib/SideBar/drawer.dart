import 'dart:convert';
import 'dart:developer';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter_share/flutter_share.dart';
import 'package:get/get.dart';
import 'package:urwealthpal/BottomBar/bottombar.dart';
import 'package:urwealthpal/Constant/ApiBaseHelper.dart';
import 'package:urwealthpal/Constant/Dividers.dart';
import 'package:urwealthpal/Constant/Images.dart';
import 'package:urwealthpal/Constant/colors.dart';
import 'package:urwealthpal/Environment/Environment.dart';
import 'package:urwealthpal/Screens/About/about_us.dart';
import 'package:urwealthpal/Screens/Contact_Us/contact_us.dart';
import 'package:urwealthpal/Screens/MPIN/change_MPIN.dart';
import 'package:urwealthpal/Screens/PrivacyAndPolicy/privacyAndPolicy.dart';
import 'package:urwealthpal/Screens/PurchasePlan/mySubscriptions.dart';
import 'package:urwealthpal/Screens/PurchasePlan/purchase_plan.dart';
import 'package:urwealthpal/Screens/TermsAndConditions/termsAndcondition.dart';
import 'package:urwealthpal/Screens/FAQ/faq.dart';
import 'package:urwealthpal/main.dart';
import '../Screens/SecurityQuestions/change_Answers.dart';

class drawer extends StatefulWidget {
  const drawer({Key? key}) : super(key: key);

  @override
  State<drawer> createState() => _drawerState();
}

class _drawerState extends State<drawer> {

  var jsondata = json.decode(sp!.getString("loginresponse").toString());
  var image,name,mobile,email;

  var setting_json_data;
var perentId;
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    perentId = Environment.parentID;
    print("perentId--->>"+perentId.toString());
    print("perentId1--->>"+perentID.toString());
    setting_json_data = json.decode(sp!.getString("setting").toString());
    image = (sp!.getString("imagee").toString());
    name = (sp!.getString("namee").toString());
    mobile =(sp!.getString("mobilenum").toString());
    email = (sp!.getString("email").toString());
    log("data response------------->"+jsondata.toString());
    log("data response------------->"+email.toString());
    log("data response------------->"+name.toString());
    log("data response------------->"+mobile.toString());
    log("data response------------->"+image.toString());
  }

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Container(
      width: size.width * 0.8,
      child: Drawer(
        backgroundColor: sidebarcontainerColor,
        child: ListView(
            padding: EdgeInsets.zero, children: [
          Container(
            height: 150,
            decoration:  BoxDecoration(
              color: sidebarcontainerColor,
                image:  DecorationImage(
                  image:  AssetImage("assets/images/box.png"),
                  fit: BoxFit.cover,
                )),
            child: Padding(
              padding: EdgeInsets.only(top: 10,left: 20),
              child: Row(children: [
                // homeProfileImage,
                Container(
                    height: 90,
                    width: 90,
                    decoration: BoxDecoration(
                        color: appPrimaryColor,
                        border: Border.all(width: 5,
                          color: buttonColor,
                        ),
                        borderRadius: BorderRadius.all(Radius.circular(90))
                    ),
                    child: ClipOval(
                        child: image.toString()==""?Icon(Icons.person):CachedNetworkImage(
                          imageUrl: image,
                          fit: BoxFit.fill,
                        )
                    )
                ),
                Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Padding(
                      padding: EdgeInsets.only(left: 5),
                      child: Text(name.toString(),
                        style: TextStyle(color: whiteColor, fontSize: 18),
                      ),
                    ),
                    Padding(
                      padding: EdgeInsets.only(top: 10),
                      child: Row(
                        children: [
                          Padding(
                            padding: EdgeInsets.only(left: 5),
                            child: profileCallIcon,
                          ),
                          Padding(
                            padding: EdgeInsets.only(left: 5),
                            child: Text( mobile.toString(),
                              style: TextStyle(
                                  color: whiteColor, fontSize: 12),
                            ),
                          ),
                        ],
                      ),
                    ),
                    Padding(
                      padding: EdgeInsets.only(top: 10,left: 4),
                      child: Row(
                        children: [
                          profilEmailIcon,
                          Padding(
                            padding: EdgeInsets.only(left: 5),
                            child: Container(
                              width: 150,
                              child: Text(
                                email.toString(),
                                style: TextStyle(
                                    color: whiteColor, fontSize: 12,
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ]),
            ),
            // child: Stack(
            //   children: [
            //     ClipRRect(
            //         borderRadius: BorderRadius.all(Radius.circular(15)),
            //         child: profileTopImage
            //     ),
            //     Padding(
            //       padding: EdgeInsets.only(left: 10, top: 10),
            //       child: Row(children: [
            //         profileImage,
            //         Column(
            //           mainAxisAlignment: MainAxisAlignment.center,
            //           crossAxisAlignment: CrossAxisAlignment.start,
            //           children: [
            //             // Text(sp!.getString("name").toString(),
            //             // style: TextStyle(color: Colors.white, fontSize: 18),),
            //             Text(jsondata['data']['user']['name'],
            //               style: TextStyle(color: whiteColor, fontSize: 18),
            //             ),
            //             Padding(
            //               padding: EdgeInsets.only(top: 10),
            //               child: Row(
            //                 children: [
            //                   profileCallIcon,
            //                   Padding(
            //                     padding: EdgeInsets.only(left: 5),
            //                     // child:
            //                     // Text(sp!.getString("mobile").toString(),
            //                     //   style: TextStyle(color: Colors.white, fontSize: 10),
            //                    child: Text( jsondata['data']['user']['mobile'],
            //                       style: TextStyle(
            //                           color: whiteColor, fontSize: 10),
            //                     ),
            //                   ),
            //                 ],
            //               ),
            //             ),
            //             Padding(
            //               padding: EdgeInsets.only(top: 10),
            //               child: Row(
            //                 children: [
            //                   profilEmailIcon,
            //                   Padding(
            //                     padding: EdgeInsets.only(left: 5),
            //                     child:
            //                     // Text(sp!.getString("email").toString(),
            //                     //   style: TextStyle(color: Colors.white, fontSize: 10),
            //                     Text( jsondata['data']['user']['email'],
            //                       style: TextStyle(
            //                           color: whiteColor, fontSize: 10),
            //                     ),
            //                   ),
            //                 ],
            //               ),
            //             ),
            //           ],
            //         ),
            //       ]),
            //     ),
            //     Positioned(
            //       right: 0,
            //       bottom: 1,
            //
            //       child: ClipRRect(
            //           borderRadius: BorderRadius.all(Radius.circular(5)),
            //           child: profileBottomImage),
            //     ),
            //   ],
            // ),
          ),
          Column(
            children: [
              ListTile(
                dense: true,
                visualDensity: VisualDensity(horizontal: 0, vertical: -2),
                leading: homeIcon,
                title: Text(
                  "hometxt".tr,
                  textAlign: TextAlign.left,
                  style: TextStyle(
                    fontSize: 15,
                    color: whiteColor,
                  ),
                ),
                onTap: () {
                  Navigator.pushReplacement(
                      context, MaterialPageRoute(
                    builder: (context) => bottombar(bottom: 2),)
                  );
                },
              ),
              ListTile(
                dense: true,
                visualDensity: VisualDensity(horizontal: 0, vertical: -2),
                leading: ProfileIcon,
                title: Text(
                  "profiletext".tr,
                  textAlign: TextAlign.left,
                  style: TextStyle(fontSize: 15, color: whiteColor),
                ),
                onTap: () {
                  Navigator.pushReplacement(context, MaterialPageRoute(
                      builder: (context) => bottombar(bottom: 4,)));
                },
              ),
              ListTile(
                dense: true,
                visualDensity: VisualDensity(horizontal: 0, vertical: -2),
                leading: Image.asset("assets/images/assets.png",scale: 2.6,color: ContainerColor,),
                title: Text(
                  "assetstxt".tr,
                  textAlign: TextAlign.left,
                  style: TextStyle(fontSize: 15, color: whiteColor),
                ),
                onTap: () {
                  Navigator.pushReplacement(context, MaterialPageRoute(
                      builder: (context) => bottombar(bottom: 0,)));
                },
              ),
              // ListTile(
              //   dense: true,
              //   visualDensity: VisualDensity(horizontal: 0, vertical: -2),
              //   leading: ManageAssets_Icon,
              //   title: Text(
              //     "mangAsstxt".tr,
              //     textAlign: TextAlign.left,
              //     style: TextStyle(fontSize: 15, color: whiteColor),
              //   ),
              //   onTap: () {
              //     Navigator.push(context, MaterialPageRoute(
              //         builder: (context) => manage_assets()));
              //   },
              // ),
              // ListTile(
              //   dense: true,
              //   visualDensity: VisualDensity(horizontal: 0, vertical: -2),
              //   leading: ShareAssets_Icon,
              //   title: Text(
              //     "shareAssetstxt".tr,
              //     textAlign: TextAlign.left,
              //     style: TextStyle(fontSize: 15, color: whiteColor),
              //   ),
              //   onTap: () {
              //     Navigator.pushReplacement(context, MaterialPageRoute(
              //         builder: (context) => bottombar(bottom: 3,)));
              //   },
              //
              // ),
              // ListTile(
              //   dense: true,
              //   visualDensity: VisualDensity(horizontal: 0, vertical: -2),
              //   leading: ShareAssets_Icon,
              //   title: Text("family_member_txt".tr,
              //     textAlign: TextAlign.left,
              //     style: TextStyle(fontSize: 15, color: whiteColor),
              //   ),
              //   onTap: () {
              //     Navigator.push(context, MaterialPageRoute(
              //         builder:(context) => shareAssets());
              //   },
              // ),
              // ListTile(
              //   dense: true,
              //   visualDensity: VisualDensity(horizontal: 0, vertical: -2),
              //   leading: TicketIcon,
              //   title: Text(
              //     "ticket_txt".tr,
              //     textAlign: TextAlign.left,
              //     style: TextStyle(fontSize: 15, color: whiteColor),
              //   ),
              //   onTap: () {
              //     Navigator.push(context, MaterialPageRoute(
              //         builder:(context) => ticket()));
              //   },
              // ),
              ListTile(
                dense: true,
                visualDensity: VisualDensity(horizontal: 0, vertical: -2),
                leading: Libaility_Image,
                title: Text(
                  "Liabilities_txt".tr,
                  textAlign: TextAlign.left,
                  style: TextStyle(fontSize: 15, color: whiteColor),
                ),
                onTap: () {
                  Navigator.pushReplacement(context, MaterialPageRoute(
                      builder:(context) => bottombar(bottom: 1,)));
                },
              ),

              // ListTile(
              //   dense: true,
              //   visualDensity: VisualDensity(horizontal: 0, vertical: -2),
              //   leading: Libaility_Image,
              //   title: Text(
              //     "In App Purchase",
              //     textAlign: TextAlign.left,
              //     style: TextStyle(fontSize: 15, color: whiteColor),
              //   ),
              //   onTap: () {
              //     Navigator.push(context, MaterialPageRoute(
              //         builder:(context) => InAppPurchases()));
              //   },
              // ),

              perentId.toString() == "0" ?
              ListTile(
                dense: true,
                visualDensity: VisualDensity(horizontal: 0, vertical: -2),
                leading: PurchasePlan_Icon,
                title: Text(
                  "purchasePlantxt".tr,
                  textAlign: TextAlign.left,
                  style: TextStyle(fontSize: 15, color: whiteColor),
                ),
                onTap: () {
                  Navigator.push(context, MaterialPageRoute(
                      builder: (context)=> purchase_plan()));
                },
              ):Container(),

              ListTile(
                dense: true,
                visualDensity: VisualDensity(horizontal: 0, vertical: -2),
                leading: PurchasePlan_Icon,
                title: Text(
                  "Subscription_txt".tr,
                  textAlign: TextAlign.left,
                  style: TextStyle(fontSize: 15, color: whiteColor),
                ),
                onTap: () {
                  Navigator.push(context, MaterialPageRoute(
                      builder: (context)=> MySubscription()));
                },
              ),

              ListTile(
                dense: true,
                visualDensity: VisualDensity(horizontal: 0, vertical: -2),
                leading: Password_Icon,
                title: Text(
                  "change_MPIN_txt".tr,
                  textAlign: TextAlign.left,
                  style: TextStyle(fontSize: 15, color: whiteColor),
                ),
                onTap: () {
                  Navigator.push(context, MaterialPageRoute(
                      builder: (context)=> change_MPIN()));
                },
              ),

              ListTile(
                dense: true,
                visualDensity: VisualDensity(horizontal: 0, vertical: -2),
                leading: Password_Icon,
                title: Text(
                  "change_ans".tr,
                  textAlign: TextAlign.left,
                  style: TextStyle(fontSize: 15, color: whiteColor),
                ),
                onTap: () {
                  Navigator.push(context, MaterialPageRoute(
                      builder: (context)=> Change_Answers()));
                },
              ),

              lineDivider,

              perentId.toString() == "0" ?
              ListTile(
                dense: true,
                visualDensity: VisualDensity(horizontal: 0, vertical: -2),
                leading: ContactUs_Icon,
                title: Text(
                  "contactUstxt".tr,
                  textAlign: TextAlign.left,
                  style: TextStyle(fontSize: 15, color: whiteColor),
                ),
                onTap: () {
                  Navigator.push(context, MaterialPageRoute(
                      builder: (context) => perentId.toString() == "0" ? contact_us():bottombar(bottom: 3,)));
                },
              )
              :Container(),

              ListTile(
                dense: true,
                visualDensity: VisualDensity(horizontal: 0, vertical: -2),
                leading: AboutUs_Icon,
                title: Text(
                  "aboutUstxt".tr,
                  textAlign: TextAlign.left,
                  style: TextStyle(fontSize: 15, color: whiteColor),
                ),
                onTap: () {
                  Navigator.push(context, MaterialPageRoute(
                      builder: (context) => about_us()));
                },
              ),
              // ListTile(
              //   leading: RateUs_Icon,
              //   title: Text(
              //     rateUstxt,
              //     textAlign: TextAlign.left,
              //     style: TextStyle(fontSize: 15, color: Colors.white),
              //   ),
              //   onTap: () {
              //     Navigator.push(context, MaterialPageRoute(
              //         builder: (context) => rate_us()));
              //   },
              // ),

              ListTile(
                dense: true,
                visualDensity: VisualDensity(horizontal: 0, vertical: -2),
                leading: ShareApp_Icon,
                title: Text(
                  "shareApptxt".tr,
                  textAlign: TextAlign.left,
                  style: TextStyle(fontSize: 15, color: whiteColor),
                ),
                onTap: () {
                  // "${category['image'].toString()}"
                  FlutterShare.share(title: "Patrimonial",
                      linkUrl: "Patrimonial\n\t ${setting_json_data['data']['app_url'].toString()}");

                  // StoreRedirect.redirect(
                  //   androidAppId: "com.iyaffle.rangoli",
                  //   iOSAppId: "585027354",
                  // );
                },
              ),

              lineDivider,
              ListTile(
                dense: true,
                visualDensity: VisualDensity(horizontal: 0, vertical: -2),
                leading: FAQ_Icon,
                title: Text(
                  "faq_txt".tr,
                  textAlign: TextAlign.left,
                  style: TextStyle(fontSize: 15, color: whiteColor),
                ),
                onTap: () {
                  Navigator.push(context, MaterialPageRoute(
                      builder: (context) => faq()));
                },
              ),
              ListTile(
                dense: true,
                visualDensity: VisualDensity(horizontal: 0, vertical: -2),
                leading: TermC_Icon,
                title: Text(
                  "term_Conditiontxt".tr,
                  textAlign: TextAlign.left,
                  style: TextStyle(fontSize: 15, color: whiteColor),
                ),
                onTap: () {
                  Navigator.push(context, MaterialPageRoute(
                      builder: (context) => termsAndcondition()));
                },
              ),
              ListTile(
                dense: true,
                visualDensity: VisualDensity(horizontal: 0, vertical: -2),
                leading: PrivacyP_Icon,
                title: Text(
                  "privacyPolicytxt".tr,
                  textAlign: TextAlign.left,
                  style: TextStyle(fontSize: 15, color: whiteColor),
                ),
                onTap: () {
                  Navigator.push(context, MaterialPageRoute(
                      builder: (context) => privacyAndpolicy()));
                },
              ),
              ListTile(
                dense: true,
                visualDensity: VisualDensity(horizontal: 0, vertical: -2),
                leading: Logout_Icon,
                title: Text(
                  "logout_txt".tr,
                  textAlign: TextAlign.left,
                  style: TextStyle(fontSize: 15, color: whiteColor),
                ),
                onTap: () {
                  showDialog(context: context, builder: (context){
                    return Container(
                      child: AlertDialog(
                        title: Text("conLogout_txt".tr),
                        content: Text("sureToLogout_txt".tr),
                        actions: [
                          TextButton(onPressed: () {
                         //   prefs.setBool("login", false);
                            ApiBaseHelper(). AppLogout();
                          },
                              child: Text("logout_txt".tr,style: TextStyle(
                                  color: appPrimaryColor,
                                  fontWeight: FontWeight.bold
                              ),)),

                          TextButton(onPressed: (){
                            Navigator.pushReplacement(context, MaterialPageRoute(
                              builder: (context) => bottombar(bottom: 2),));
                          },
                              child: Text("cancel_txt".tr,style: TextStyle(
                                  color: appPrimaryColor,
                                  fontWeight: FontWeight.bold
                              ),))
                        ],
                      ),
                    );
                  });
                },
              ),
            ],
          ),
        ]),
      ),
    );
  }
}