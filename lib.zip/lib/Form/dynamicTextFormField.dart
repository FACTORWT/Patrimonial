import 'dart:convert';
import 'dart:developer';
import 'dart:io';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:urwealthpal/Constant/Api.dart';
import 'package:urwealthpal/Constant/ApiBaseHelper.dart';
import 'package:urwealthpal/Constant/Spacing.dart';
import 'package:urwealthpal/Constant/colors.dart';
import 'package:urwealthpal/Constant/number.dart';
import 'package:urwealthpal/Environment/Environment.dart';
import 'package:urwealthpal/Screens/Assets/Controllers/Post_Categories_Controller.dart';
import 'package:urwealthpal/main.dart';


class DynamicTextFormPage extends StatefulWidget {
  var catid;
  var formName;
   DynamicTextFormPage({this.catid,this.formName});

  @override
  State<DynamicTextFormPage> createState() => _DynamicTextFormPageState();
}

class _DynamicTextFormPageState extends State<DynamicTextFormPage> {


  DynamicController dynamicController = Get.put(DynamicController());

  List<TextEditingController> controllers = [];
  String formattedAmount = '';
  List<dynamic> selectedDropdownValues = [];
  List selectedDropdownValuesCheck = [];

  // Function to format amount with thousand separators
  String formatAmount(String value) {
    final formatter = NumberFormat('#,####,000', 'en_US');
    double parsedValue = double.tryParse(value.replaceAll(',', '')) ?? 0.0;
    return formatter.format(parsedValue);
  }

  int _fieldCount = 10;


  @override
  void initState() {
    super.initState();
    callApi();
  }
  callApi() async {

     var url = Uri.parse(dynamicField_url);
     log('dynamicField_url==>'+url.toString());
     var parameter = {
       "category_id" : widget.catid.toString(),
     };
    await dynamicController.GetDynamicField(url, parameter);
     for (var i = 0; i < dynamicController.fieldData[0]['fields'].length; i++) {
       controllers.add(TextEditingController());
       selectedDropdownValues.add('');
     }
    var data= await getvalidations("2");
     log("data : $data");
  }
  final _formKey = new GlobalKey<FormState>();

  String getvalidations(String vaulee){
  var res;
  var setting_json_data = json.decode(sp!.getString("setting").toString());
  print("setting_json_data...."+setting_json_data['data']['field_validation'].toString());
  setting_json_data['data']['field_validation'][0].forEach((k,v){
    log("Key : $k");
    log("Value : $v");
    if(k.toString()==vaulee){
      res  = v['php'];

    }

  });
  log("Value res: $res");
  return res.toString() ;

}

  String capitalizeEachWord(String input) {
    return input.split(' ').map((word) {
      if (word.isNotEmpty) {
        return word[0].toUpperCase() + word.substring(1).toLowerCase();
      }
      return word;
    }).join(' ');
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: ContainerColor,
        elevation: 0,
        titleSpacing: 0,
        title: Text(capitalizeEachWord(widget.formName.toString())+" Form".tr)
        // title: Text('Dynamic Form'),
      ),
      body: GetBuilder<DynamicController>(
        builder: (dynamicController) {
          if(dynamicController.fieldLoading.value){
            return Center(child: CircularProgressIndicator());
          }else{
            return SingleChildScrollView(
              child: Form(
                key: _formKey,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    ListView.builder(
                      shrinkWrap: true,
                      physics: NeverScrollableScrollPhysics(),
                      itemCount: dynamicController.fieldData[0]['fields'].length,
                      itemBuilder: (BuildContext context, int index) {
                        return buildFieldWidget(dynamicController.fieldData[0]['fields'][index],index);
                      },
                    ),
                    SizedBox(height: 20),
                    Center(
                      child: ElevatedButton(
                        style: ButtonStyle(
                          backgroundColor: MaterialStatePropertyAll(buttonColor),
                        ),
                        onPressed:dynamicController.addfieldLoading.value?null:() async {
                          if(_formKey.currentState!.validate()){
                            // // Access the entered text using controllers
                            // for (var i = 0; i < controllers.length; i++) {
                            //   print('Field ${i + 1}: ${controllers[i].text}');
                            //   print('Selected Dropdown ${i + 1}: ${selectedDropdownValues[i]}');
                            //   print("selectedDropdownValues--"+selectedDropdownValues[i].toString());
                            //   selectedDropdownValues[i] = controllers[i].text;
                            // }
                            // var body = {};
                            // await dynamicController.AddDynamicField(Uri.parse(adddynamicField_url),body);
                            if (_formKey.currentState!.validate()) {
                              // Create a Map to store form data
                              var formData = {
                                "category_id" : widget.catid.toString(),
                              };
                              List<MultipartBody> filekeyName=[] ;
                              // Iterate through controllers and add values to the formData Map
                              for (var i = 0; i < controllers.length; i++) {
                                String keyName = dynamicController.fieldData[0]['fields'][i]['key_name'];

                                String fieldType = dynamicController.fieldData[0]['fields'][i]['type'].toString();
                                log('type==>'+dynamicController.fieldData[0]['fields'][i]['type'].toString());
                                switch (fieldType) {
                                  case '1':
                                  formData[keyName] = controllers[i].text;
                                  break;// Text field
                                  case '2':
                                  formData[keyName] = controllers[i].text.replaceAll(',', '');
                                  break;// Number field
                                  case '3':
                                  formData[keyName] = controllers[i].text;
                                  break;// Email field
                                  case '4':
                                  formData[keyName] = controllers[i].text;
                                  break;// Date field
                                  case '5':
                                  formData[keyName] = controllers[i].text;
                                  break;// Time field
                                  case '9': // Textarea field
                                  formData[keyName] = controllers[i].text;
                                  break;

                                  case '6': // Dropdown field
                                  formData[keyName] = selectedDropdownValues[i];
                                  break;

                                  case '7':
                                  formData[keyName] = selectedDropdownValues[i];
                                  break;// Radio field
                                  case '8': // Checkbox field
                                  log("check --> "+selectedDropdownValues[i].toString());
                                  formData[keyName] = selectedDropdownValues[i].toString();
                                  break;

                                  case '10': // File field
                                  // Handle file field accordingly, e.g., you might want to upload the file and provide the file URL in the formData

                                    //
                                    if(selectedDropdownValues[i]==""){

                                    }else{
                                      filekeyName.add(selectedDropdownValues[i]) ;
                                    }
                                  break;

                                  default:
                                  // Handle other field types if needed
                                  break;
                                }
                              }

                              // Now formData contains all the data from the form
                              log("Send data To Api Body : "+formData.toString());
                              log("Send image To Api files : "+filekeyName.toString());
                              log("Send image To widget.catid : "+widget.catid.toString());

                              // Call your API with formData
                              var body = formData;
                              await dynamicController.AddDynamicField(Uri.parse(adddynamicField_url), body,filekeyName,widget.catid);
                            }
                          }
                        },
                        child: Text(dynamicController.addfieldLoading.value?"wait_txt".tr:"sub_txt".tr,
                          style: TextStyle(color: whiteColor),),
                      ),
                    ),

                  ],
                ),
              ),
            );
          }
        }
      ),
    );
  }
  Widget buildFieldWidget(Map<String, dynamic> field,int index) {
    log('field>>'+field['type'].toString());
    log('field>>'+field['name'].toString());
    switch (field['type']) {
      case 1:
        return Padding(
          padding:  EdgeInsets.only(left: 10,right: 10,top: 10,bottom: 5),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(field['name'],
                style: TextStyle(
                  fontWeight: FontWeight.w500,
                  fontSize: 15,
                ),),
              sizebox_height_5,
              TextFormField(
                controller: controllers[index],
                validator: (value) {
                  if (field['is_required'] == 1 && (value == null || value.isEmpty)) {
                    return 'notBlank_txt'.tr;
                  }
                  return null;
                  // final RegExp regex = RegExp(getvalidations(field['validation_id'].toString()));
                  //
                  // // Check if the value matches the pattern
                  // if (!regex.hasMatch(value!)) {
                  //   return 'Field must be correct';
                  // }

                  // Return null if the input is valid
                  // return null;
                },
                decoration: InputDecoration(
                  labelText: field['name'],
                  hintText: field['placeholder'],
                    filled: true,
                    fillColor: whiteColor,
                    contentPadding: EdgeInsets.only(top: 5,left: 10),
                    constraints: const BoxConstraints(
                        minWidth: 30, maxHeight: 70),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10),
                    ),
                    enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10),
                        borderSide: BorderSide(
                            width: 1, color: Namecolors)),
                    focusedBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10),
                        borderSide: BorderSide(
                            width: 1, color: appPrimaryColor)),
                    focusedErrorBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10),
                        borderSide: BorderSide(
                            width: 1, color: Colors.redAccent)),
                    ),
                // Add other text field properties and validations
              ),
            ],
          ),
        );
      case 2:
        return Padding(
          padding:  EdgeInsets.symmetric(horizontal: 10,vertical: 8),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(field['name'],
                style: TextStyle(
                  fontWeight: FontWeight.w500,
                  fontSize: 15,
                ),),
              sizebox_height_5,
              TextFormField(
                controller: controllers[index],
                keyboardType: TextInputType.number,
                inputFormatters: [
                  NumberInputFormatter(),
                ],
                // onChanged: (value){
                //   setState(() {
                //     formattedAmount = formatAmount(value);
                //      controllers[index].text = formattedAmount;
                //
                //     // _formattedAmount = _formatAmount(value);
                //   });
                // },

                decoration: InputDecoration(
                  labelText: field['name'],
                  hintText: field['placeholder'],
                  filled: true,
                  fillColor: whiteColor,
                  contentPadding: EdgeInsets.only(top: 5,left: 10),
                  constraints: BoxConstraints(
                      minWidth: 30, maxHeight: 70),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(10),
                  ),
                  enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10),
                      borderSide: BorderSide(
                          width: 1, color: Namecolors)),
                  focusedBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10),
                      borderSide: BorderSide(
                          width: 1, color: appPrimaryColor)),
                  focusedErrorBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10),
                      borderSide: BorderSide(
                          width: 1, color: Colors.redAccent)),
                ),
                validator: (value) {
                  // final RegExp regex = RegExp(getvalidations(field['validation_id'].toString()));
                  //
                  // // Check if the value matches the pattern
                  // if (!regex.hasMatch(value!)) {
                  //   return 'Field cant be empty';
                  // }
                  if (field['is_required'] == 1 && (value == null || value.isEmpty)) {
                    return 'notBlank_txt'.tr;
                  }
                  return null;
                },
              ),
            ],
          ),
        );
      case 3:
        return Padding(
          padding:  EdgeInsets.symmetric(horizontal: 10,vertical: 8),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(field['name'],
                style: TextStyle(
                  fontWeight: FontWeight.w500,
                  fontSize: 15,
                ),),
              sizebox_height_5,
              TextFormField(
                controller: controllers[index],
                keyboardType: TextInputType.emailAddress,
                decoration: InputDecoration(
                  labelText: field['name'],
                  hintText: field['placeholder'],
                  filled: true,
                  fillColor: whiteColor,
                  contentPadding: EdgeInsets.only(top: 5,left: 10),
                  constraints: BoxConstraints(
                      minWidth: 30, maxHeight: 70),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(10),
                  ),
                  enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10),
                      borderSide: BorderSide(
                          width: 1, color: Namecolors)),
                  focusedBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10),
                      borderSide: BorderSide(
                          width: 1, color: appPrimaryColor)),
                  focusedErrorBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10),
                      borderSide: BorderSide(
                          width: 1, color: Colors.redAccent)),
                ),
                validator: (value) {
                  if (field['is_required'] == 1 && (value == null || value.isEmpty)) {
                    return 'notBlank_txt'.tr;
                  }
                  return null;
                  // final RegExp regex = RegExp(getvalidations(field['validation_id'].toString()));
                  //
                  // // Check if the value matches the pattern
                  // if (!regex.hasMatch(value!)) {
                  //   return 'Not Correct Email';
                  // }
                  // Return null if the input is valid
                  // return null;
                },
              ),
            ],
          ),
        );

      case 4:
        return Padding(
          padding: EdgeInsets.symmetric(horizontal: 10,vertical: 8),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(field['name'],
                style: TextStyle(
                  fontWeight: FontWeight.w500,
                  fontSize: 15,
                ),),
              sizebox_height_5,
              TextFormField(
                onTap: () {
                  showDatePicker(
                    context: context,
                    initialDate: DateTime.now(),
                    firstDate: DateTime(1950),
                    lastDate: DateTime(2100),
                  ).then((pickedDate) {
                    if (pickedDate != null) {
                      String formattedDate = "${pickedDate.day}-${pickedDate.month}-${pickedDate.year}";
                      controllers[index].text = formattedDate;
                    }
                  });
                },
                controller: controllers[index],
                readOnly: true,
                decoration: InputDecoration(
                  labelText: field['name'],
                  hintText: field['placeholder'],
                  filled: true,
                  fillColor: whiteColor,
                  contentPadding: EdgeInsets.only(top: 5,left: 10),
                  constraints: BoxConstraints(
                      minWidth: 30, maxHeight: 70),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(10),
                  ),
                  enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10),
                      borderSide: BorderSide(
                          width: 1, color: Namecolors)),
                  focusedBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10),
                      borderSide: BorderSide(
                          width: 1, color: appPrimaryColor)),
                  focusedErrorBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10),
                      borderSide: BorderSide(
                          width: 1, color: Colors.redAccent)),
                ),
                validator: (value) {
                  if (field['is_required'] == 1 && (value == null || value.isEmpty)) {
                    return 'notBlank_txt'.tr;
                  }
                  return null;
                },
              ),

             Text(field['is_reminder']==1?"This field require for reminder" : "",
                style: TextStyle(
                  fontWeight: FontWeight.w500,
                  fontSize: 15,
                ),),

            ],
          ),
        );

      case 5:
        return Padding(
          padding:  EdgeInsets.symmetric(horizontal: 10,vertical: 8),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(field['name'],
                style: TextStyle(
                  fontWeight: FontWeight.w500,
                  fontSize: 15,
                ),),
              sizebox_height_5,
              TextFormField(
                onTap: () {
                  showTimePicker(
                    context: context,
                    initialTime: TimeOfDay.now(),
                  ).then((pickedTime) {
                    if (pickedTime != null) {
                      controllers[index].text = pickedTime.format(context);
                    }
                  });
                },
                readOnly: true,
                controller: controllers[index],
                decoration: InputDecoration(
                  labelText: field['name'],
                  hintText: field['placeholder'],
                  filled: true,
                  fillColor: whiteColor,
                  contentPadding: EdgeInsets.only(top: 5,left: 10),
                  constraints: BoxConstraints(
                      minWidth: 30, maxHeight: 70),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(10),
                  ),
                  enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10),
                      borderSide: BorderSide(
                          width: 1, color: Namecolors)),
                  focusedBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10),
                      borderSide: BorderSide(
                          width: 1, color: appPrimaryColor)),
                  focusedErrorBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10),
                      borderSide: BorderSide(
                          width: 1, color: Colors.redAccent)),
                ),
                validator: (value) {
                  if (field['is_required'] == 1 && (value == null || value.isEmpty)) {
                    return 'notBlank_txt'.tr;
                  }
                  return null;
                },
              ),
            ],
          ),
        );

      case 6:
        return Padding(
          padding:  EdgeInsets.symmetric(horizontal: 10,vertical: 8),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(field['name'],
                style: TextStyle(
                  fontWeight: FontWeight.w500,
                  fontSize: 15,
                ),),
              sizebox_height_5,
              DecoratedBox(

                decoration: BoxDecoration(

                  color:Colors.white, //background color of dropdown button
                  border: Border.all(color: Colors.black38, width:0.5), //border of dropdown button
                  borderRadius: BorderRadius.circular(5),

                ),
                child: DropdownButton<dynamic>(
                  isExpanded: true, //make true to take width of parent widget
                  underline: Container(), //empty line
                  // style: TextStyle(fontSize: 18, color: Colors.black),
                  hint: Padding(
                    padding:  EdgeInsets.only(left: 8.0),
                    child: Text(field['placeholder']),
                  ),

                  iconEnabledColor: appPrimaryColor, //Icon color
                  value: selectedDropdownValues[index]==""?null:selectedDropdownValues[index],
                  // Add the value property
                  items: field['options'].asMap().entries.map<DropdownMenuItem<dynamic>>((entry) {
                    int valueIndex = entry.key;
                    dynamic value = entry.value;

                    return DropdownMenuItem<dynamic>(
                      value: value, // Making the value unique

                      child: Padding(
                        padding:  EdgeInsets.only(left: 10.0),
                        child: Text(value.toString()),
                      ),
                    );
                  }).toList(),
                  onChanged: (dynamic newValue) {
                    setState(() {

                      selectedDropdownValues[index] = newValue;

                      print("fffafafaf--->" + newValue.toString());
                    });
                  },
                ),
              ),
            ],
          ),
        );


      case 7:
        List<String> radioOptions = List<String>.from(field['options']);
        return Padding(
          padding: EdgeInsets.symmetric(horizontal: 10,vertical: 0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              sizebox_height_5,
              Text("${field['name']}",  style: TextStyle(
                fontWeight: FontWeight.w500,
                fontSize: 15,
              ),),

              ...radioOptions.map((option) => RadioListTile(
                title: Text(option),
                value: option,
                groupValue: selectedDropdownValues[index],

                onChanged: (value) {
                  setState(() {
                    selectedDropdownValues[index] = value;
                  });
                },
              )),
              SizedBox(height: 10,)
            ],
          ),
        );

      case 8:
        List<String> checkboxOptions = List<String>.from(field['options']);
        return Padding(
          padding:  EdgeInsets.only(left: 8.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(field['name'],
              style: TextStyle(
                fontWeight: FontWeight.w500,
                fontSize: 15,
              ),),

              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: checkboxOptions.map((option) => CheckboxListTile(
                  title: Text(option,style: TextStyle(
                    fontSize: 14,
                  ),),
                  value: selectedDropdownValues[index]?.contains(option) ?? false,

                  onChanged: (value) {
                    log("slelect : "+value.toString());
                    log("selectedDropdownValues==> "+selectedDropdownValues.toString());
                    setState(() {
                      if (value != null) {
                        log("slelect 1: "+value.toString());

                        if (selectedDropdownValues[index] == "") {
                          log("slelect 2: "+value.toString());
                          selectedDropdownValues[index] = []; // Initialize the list if it's null
                        }
                        if (value) {
                          log("slelect 3: "+value.toString());
                          selectedDropdownValues[index]!.add(option);
                        } else {
                          log("slelect 4: "+value.toString());
                          selectedDropdownValues[index]!.remove(option);
                        }
                      }
                    });
                  },
                )).toList(),
              ),
            ],
          ),
        );

      case 9:
        return Padding(
          padding: EdgeInsets.symmetric(horizontal: 10,vertical: 4),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(field['name'],
                style: TextStyle(
                  fontWeight: FontWeight.w500,
                  fontSize: 15,
                ),),
              sizebox_height_5,
              TextFormField(
                maxLines: 5,
                controller: controllers[index],
                decoration: InputDecoration(
                  labelText: field['name'],
                  hintText: field['placeholder'],
                  filled: true,
                  fillColor: whiteColor,
                  contentPadding: EdgeInsets.only(top: 20,left: 10),
                  constraints: BoxConstraints(
                      minWidth: 30, maxHeight: 70),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(10),
                  ),
                  enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10),
                      borderSide: BorderSide(
                          width: 1, color: Namecolors)),
                  focusedBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10),
                      borderSide: BorderSide(
                          width: 1, color: appPrimaryColor)),
                  focusedErrorBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10),
                      borderSide: BorderSide(
                          width: 1, color: Colors.redAccent)),
                ),
                validator: (value) {
                  if (field['is_required'] == 1 && (value == null || value.isEmpty)) {
                    return 'notBlank_txt'.tr;
                  }
                  return null;
                },
              ),
            ],
          ),
        );

      case 10:
      // Display file picker
      // Implement file picker widget
        return Padding(
          padding: EdgeInsets.symmetric(horizontal: 10,vertical: 4),
          child:Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(field['name'],
                style: TextStyle(
                  fontWeight: FontWeight.w500,
                  fontSize: 15,
                ),),
              sizebox_height_5,
              TextFormField(
                onTap: () async {
                  if(Environment.askMPIN=="1"){
                    sp!.setString("ask_mpin","0");
                    log('askMPIN==>'+Environment.askMPIN.toString());
                    FilePickerResult? result = await FilePicker.platform.pickFiles();
                    log('result==>'+result.toString());
                    if (result != null) {
                      sp!.setString("ask_mpin","1");
                      log('askMPIN==>'+Environment.askMPIN.toString());
                      // String filePath = result.files.single.path!;
                      controllers[index].text=result.files.single.name.toString();
                      selectedDropdownValues[index] = MultipartBody(field['key_name'], result);
                      log('key_name==>'+selectedDropdownValues[index]);
                      setState(() {

                      });
                    }}else{
                      FilePickerResult? result = await FilePicker.platform.pickFiles();
                      log('result==>'+result.toString());
                      if (result != null) {
                        log('askMPIN==>'+Environment.askMPIN.toString());
                        // String filePath = result.files.single.path!;
                        controllers[index].text=result.files.single.name.toString();
                        selectedDropdownValues[index] = MultipartBody(field['key_name'], result);
                        log('key_name==>'+selectedDropdownValues[index]);
                        setState(() {});
                      }
                    }
                  },
                readOnly: true,
                controller: controllers[index],
                decoration: InputDecoration(
                  labelText: field['name'],
                  hintText: field['placeholder'],
                suffixIcon: Icon(Icons.attach_file),
                  filled: true,
                  fillColor: whiteColor,
                  contentPadding: EdgeInsets.only(top: 5,left: 10),
                  constraints: BoxConstraints(
                      minWidth: 30, maxHeight: 70),
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(10),
                  ),
                  enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10),
                      borderSide: BorderSide(
                          width: 1, color: Namecolors)),
                  focusedBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10),
                      borderSide: BorderSide(
                          width: 1, color: appPrimaryColor)),
                  focusedErrorBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10),
                      borderSide: BorderSide(
                          width: 1, color: Colors.redAccent)),
                ),
                validator: (value) {
                  if (field['is_required'] == 1 && (controllers[index].text.isEmpty || value!.isEmpty)) {
                    return 'notBlank_txt'.tr;
                  }
                  return null;
                },
              ),
            ],
          ),
          // ElevatedButton(
          //   onPressed: () async {
          //     FilePickerResult? result = await FilePicker.platform.pickFiles();
          //
          //     if (result != null) {
          //       String filePath = result.files.single.path!;
          //       controllers[index].text = filePath;
          //     }
          //   },
          //   child: Text('Select File'),
          // ),
        );



      default:
      // Display a default widget or handle unknown type
        return Container();
    }
  }

}

class DynamicController extends GetxController{

  @override
  void onReady() {
    // TODO: implement onReady
    super.onReady();
  }
  @override
  void onClose() {
    // TODO: implement onClose
    super.onClose();
  }
  var fieldLoading = false.obs;
  var fieldData = [];

  GetDynamicField(url,parameter) async {
    fieldLoading(true);
    update();
    try{
      var response = await ApiBaseHelper().postAPICall(url,parameter, true);
      if(response.statusCode==200){
        var responsedata = jsonDecode(response.body);
        fieldData.clear();
        fieldData.add(responsedata['data']);
        fieldData = responsedata['message'];
        var msg = fieldData.toString();
        toastMsg(msg, true);
        fieldLoading(false);
        refresh();
        update();
      }
      // else if(response.statusCode==422){
      //   fieldData = responsedata['message'];
      //   var msg = fieldData.toString();
      //   toastMsg(msg, true);
      //   fieldLoading(false);
      //   refresh();
      //   update();
      // }
      else if(response.statusCode==500){
        toastMsg("Server Error", true);
        fieldLoading(true);
        refresh();
        update();
      }else{
        var responsedata = jsonDecode(response.body);
        toastMsg(responsedata["message"], true);
        fieldLoading(false);
        refresh();
        update();
      }
    }
    catch(e){
      log("Error in Catch $e");
      fieldLoading(false);
      update();

    }
  }

  var addfieldLoading = false.obs;
  var addfieldData;
  AddDynamicField(url,parameter,multipartBody,catId) async {
    addfieldLoading(true);
    update();
    try{
      log("body..$multipartBody");
      log("parameter..$parameter");
      var response = await ApiBaseHelper().multipartAPICalls(url,parameter,multipartBody, true);
      if(response.statusCode==200){
        var responsedata = jsonDecode(response.body);
        print("responsedata-----"+responsedata.toString());
        toastMsg(responsedata['message'], true);
        addfieldData =responsedata['data'];
        Map<String, String> body = {
          que_search :"",
          'category_id':catId.toString(),
        };
        await Get.find<PostCategoriesController>().CategoriestApiCalling(PostCategory_url,body);
        Get.back();

        addfieldLoading(false);
        refresh();
        update();
      }else if(response.statusCode==500){
        toastMsg("Server Error", true);
        addfieldLoading(false);
        refresh();
        update();
      }else if(response.statusCode==403){
        var responsedata = jsonDecode(response.body);
        responsedata['error'].forEach((k,v){
          log("Key :$k");
          log("Value :${v.join(" ")}");
          toastMsg("${v.join(" ")}", false);
        });
        addfieldLoading(false);
        refresh();
        update();
      }else{
        var responsedata = jsonDecode(response.body);
        toastMsg(responsedata["message"], true);
        addfieldLoading(false);
        refresh();
        update();
      }

    }
    catch(e){
      log("Error in Catch $e");
      addfieldLoading(false);
      update();

    }
  }
}