// To parse this JSON data, do
//
//     final loginmodel = loginmodelFromJson(jsonString);

import 'dart:convert';

Loginmodel loginmodelFromJson(String str) => Loginmodel.fromJson(json.decode(str));

String loginmodelToJson(Loginmodel data) => json.encode(data.toJson());

class Loginmodel {
  bool? status;
  String? message;
  Data? data;

  Loginmodel({
    this.status,
    this.message,
    this.data,
  });

  factory Loginmodel.fromJson(Map<String, dynamic> json) => Loginmodel(
    status: json["status"],
    message: json["message"],
    data: json["data"] == null ? null : Data.fromJson(json["data"]),
  );

  Map<String, dynamic> toJson() => {
    "status": status,
    "message": message,
    "data": data?.toJson(),
  };
}

class Data {
  User? user;
  String? accessToken;
  int? setMpin;
  int? askMpin;
  int? askQuestion;
  int? hasSubscription;

  Data({
    this.user,
    this.accessToken,
    this.setMpin,
    this.askMpin,
    this.askQuestion,
    this.hasSubscription,
  });

  factory Data.fromJson(Map<String, dynamic> json) => Data(
    user: json["user"] == null ? null : User.fromJson(json["user"]),
    accessToken: json["access_token"],
    setMpin: json["set_mpin"],
    askMpin: json["ask_mpin"],
    askQuestion: json["ask_question"],
    hasSubscription: json["has_subscription"],
  );

  Map<String, dynamic> toJson() => {
    "user": user?.toJson(),
    "access_token": accessToken,
    "set_mpin": setMpin,
    "ask_mpin": askMpin,
    "ask_question": askQuestion,
    "has_subscription": hasSubscription,
  };
}

class User {
  int? id;
  String? slug;
  String? name;
  dynamic relation;
  String? email;
  String? mobile;
  String? image;
  dynamic dob;
  DateTime? emailVerifiedAt;
  String? token;
  dynamic deviceId;
  String? fcmId;
  String? address;
  int? countryId;
  dynamic stateId;
  dynamic cityId;
  dynamic pincode;
  String? timezone;
  String? language;
  DateTime? lastLogin;
  int? reminderCounter;
  int? securityQuestionStatus;
  int? mpinStatus;
  String? mpin;
  int? isSubadmin;
  dynamic parentId;
  dynamic deletedAt;
  DateTime? createdAt;
  DateTime? updatedAt;

  User({
    this.id,
    this.slug,
    this.name,
    this.relation,
    this.email,
    this.mobile,
    this.image,
    this.dob,
    this.emailVerifiedAt,
    this.token,
    this.deviceId,
    this.fcmId,
    this.address,
    this.countryId,
    this.stateId,
    this.cityId,
    this.pincode,
    this.timezone,
    this.language,
    this.lastLogin,
    this.reminderCounter,
    this.securityQuestionStatus,
    this.mpinStatus,
    this.mpin,
    this.isSubadmin,
    this.parentId,
    this.deletedAt,
    this.createdAt,
    this.updatedAt,
  });

  factory User.fromJson(Map<String, dynamic> json) => User(
    id: json["id"],
    slug: json["slug"],
    name: json["name"],
    relation: json["relation"],
    email: json["email"],
    mobile: json["mobile"],
    image: json["image"],
    dob: json["dob"],
    emailVerifiedAt: json["email_verified_at"] == null ? null : DateTime.parse(json["email_verified_at"]),
    token: json["token"],
    deviceId: json["device_id"],
    fcmId: json["fcm_id"],
    address: json["address"],
    countryId: json["country_id"],
    stateId: json["state_id"],
    cityId: json["city_id"],
    pincode: json["pincode"],
    timezone: json["timezone"],
    language: json["language"],
    lastLogin: json["last_login"] == null ? null : DateTime.parse(json["last_login"]),
    reminderCounter: json["reminder_counter"],
    securityQuestionStatus: json["security_question_status"],
    mpinStatus: json["mpin_status"],
    mpin: json["mpin"],
    isSubadmin: json["is_subadmin"],
    parentId: json["parent_id"],
    deletedAt: json["deleted_at"],
    createdAt: json["created_at"] == null ? null : DateTime.parse(json["created_at"]),
    updatedAt: json["updated_at"] == null ? null : DateTime.parse(json["updated_at"]),
  );

  Map<String, dynamic> toJson() => {
    "id": id,
    "slug": slug,
    "name": name,
    "relation": relation,
    "email": email,
    "mobile": mobile,
    "image": image,
    "dob": dob,
    "email_verified_at": emailVerifiedAt?.toIso8601String(),
    "token": token,
    "device_id": deviceId,
    "fcm_id": fcmId,
    "address": address,
    "country_id": countryId,
    "state_id": stateId,
    "city_id": cityId,
    "pincode": pincode,
    "timezone": timezone,
    "language": language,
    "last_login": lastLogin?.toIso8601String(),
    "reminder_counter": reminderCounter,
    "security_question_status": securityQuestionStatus,
    "mpin_status": mpinStatus,
    "mpin": mpin,
    "is_subadmin": isSubadmin,
    "parent_id": parentId,
    "deleted_at": deletedAt,
    "created_at": createdAt?.toIso8601String(),
    "updated_at": updatedAt?.toIso8601String(),
  };
}
