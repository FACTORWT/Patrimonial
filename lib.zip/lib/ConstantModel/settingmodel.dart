// To parse this JSON data, do
//
//     final settingmodel = settingmodelFromJson(jsonString);

import 'dart:convert';

Settingmodel settingmodelFromJson(String str) => Settingmodel.fromJson(json.decode(str));

String settingmodelToJson(Settingmodel data) => json.encode(data.toJson());

class Settingmodel {
  bool? status;
  String? message;
  Data? data;

  Settingmodel({
    this.status,
    this.message,
    this.data,
  });

  factory Settingmodel.fromJson(Map<String, dynamic> json) => Settingmodel(
    status: json["status"],
    message: json["message"],
    data: json["data"] == null ? null : Data.fromJson(json["data"]),
  );

  Map<String, dynamic> toJson() => {
    "status": status,
    "message": message,
    "data": data?.toJson(),
  };
}

class Data {
  String? favicon;
  String? adminLogo;
  String? applicationName;
  String? currency;
  String? address;
  String? email;
  String? phone;
  String? facebookLink;
  String? twitterLink;
  String? linkedinLink;
  String? frontLogo;
  String? googleLocation;
  String? metaTitle;
  String? metaKeyword;
  String? metaDescription;
  String? appUrl;
  String? appUpdateMsg;
  String? appMaintenanceMsg;
  String? appMaintenanceUpdate;
  String? appForceUpdate;
  String? appVersion;
  String? loginType;
  String? instagramLink;
  String? footerText;
  String? copyright;
  String? playstoreUrl;
  String? appstoreUrl;
  String? appVideo;
  String? welcomeImage;
  String? welomeTitle;
  String? welomeText;
  String? welcomeVideo;
  String? welcomeVideoShow;
  List<TicketPriority>? ticketPriorities;
  List<TicketStatus>? ticketStatus;
  List<Map<String, AllowedFile>>? allowedFiles;
  List<Map<String, String>>? customFieldTypes;
  List<Map<String, FieldValidation>>? fieldValidation;

  Data({
    this.favicon,
    this.adminLogo,
    this.applicationName,
    this.currency,
    this.address,
    this.email,
    this.phone,
    this.facebookLink,
    this.twitterLink,
    this.linkedinLink,
    this.frontLogo,
    this.googleLocation,
    this.metaTitle,
    this.metaKeyword,
    this.metaDescription,
    this.appUrl,
    this.appUpdateMsg,
    this.appMaintenanceMsg,
    this.appMaintenanceUpdate,
    this.appForceUpdate,
    this.appVersion,
    this.loginType,
    this.instagramLink,
    this.footerText,
    this.copyright,
    this.playstoreUrl,
    this.appstoreUrl,
    this.appVideo,
    this.welcomeImage,
    this.welomeTitle,
    this.welomeText,
    this.welcomeVideo,
    this.welcomeVideoShow,
    this.ticketPriorities,
    this.ticketStatus,
    this.allowedFiles,
    this.customFieldTypes,
    this.fieldValidation,
  });

  factory Data.fromJson(Map<String, dynamic> json) => Data(
    favicon: json["favicon"],
    adminLogo: json["admin_logo"],
    applicationName: json["application_name"],
    currency: json["currency"],
    address: json["address"],
    email: json["email"],
    phone: json["phone"],
    facebookLink: json["facebook_link"],
    twitterLink: json["twitter_link"],
    linkedinLink: json["linkedin_link"],
    frontLogo: json["front_logo"],
    googleLocation: json["google_location"],
    metaTitle: json["meta_title"],
    metaKeyword: json["meta_keyword"],
    metaDescription: json["meta_description"],
    appUrl: json["app_url"],
    appUpdateMsg: json["app_update_msg"],
    appMaintenanceMsg: json["app_maintenance_msg"],
    appMaintenanceUpdate: json["app_maintenance_update"],
    appForceUpdate: json["app_force_update"],
    appVersion: json["app_version"],
    loginType: json["login_type"],
    instagramLink: json["instagram_link"],
    footerText: json["footer_text"],
    copyright: json["copyright"],
    playstoreUrl: json["playstore_url"],
    appstoreUrl: json["appstore_url"],
    appVideo: json["app_video"],
    welcomeImage: json["welcome_image"],
    welomeTitle: json["welome_title"],
    welomeText: json["welome_text"],
    welcomeVideo: json["welcome_video"],
    welcomeVideoShow: json["welcome_video_show"],
    ticketPriorities: json["ticket_priorities"] == null ? [] : List<TicketPriority>.from(json["ticket_priorities"]!.map((x) => TicketPriority.fromJson(x))),
    ticketStatus: json["ticket_status"] == null ? [] : List<TicketStatus>.from(json["ticket_status"]!.map((x) => TicketStatus.fromJson(x))),
    allowedFiles: json["allowed_files"] == null ? [] : List<Map<String, AllowedFile>>.from(json["allowed_files"]!.map((x) => Map.from(x).map((k, v) => MapEntry<String, AllowedFile>(k, AllowedFile.fromJson(v))))),
    customFieldTypes: json["custom_field_types"] == null ? [] : List<Map<String, String>>.from(json["custom_field_types"]!.map((x) => Map.from(x).map((k, v) => MapEntry<String, String>(k, v)))),
    fieldValidation: json["field_validation"] == null ? [] : List<Map<String, FieldValidation>>.from(json["field_validation"]!.map((x) => Map.from(x).map((k, v) => MapEntry<String, FieldValidation>(k, FieldValidation.fromJson(v))))),
  );

  Map<String, dynamic> toJson() => {
    "favicon": favicon,
    "admin_logo": adminLogo,
    "application_name": applicationName,
    "currency": currency,
    "address": address,
    "email": email,
    "phone": phone,
    "facebook_link": facebookLink,
    "twitter_link": twitterLink,
    "linkedin_link": linkedinLink,
    "front_logo": frontLogo,
    "google_location": googleLocation,
    "meta_title": metaTitle,
    "meta_keyword": metaKeyword,
    "meta_description": metaDescription,
    "app_url": appUrl,
    "app_update_msg": appUpdateMsg,
    "app_maintenance_msg": appMaintenanceMsg,
    "app_maintenance_update": appMaintenanceUpdate,
    "app_force_update": appForceUpdate,
    "app_version": appVersion,
    "login_type": loginType,
    "instagram_link": instagramLink,
    "footer_text": footerText,
    "copyright": copyright,
    "playstore_url": playstoreUrl,
    "appstore_url": appstoreUrl,
    "app_video": appVideo,
    "welcome_image": welcomeImage,
    "welome_title": welomeTitle,
    "welome_text": welomeText,
    "welcome_video": welcomeVideo,
    "welcome_video_show": welcomeVideoShow,
    "ticket_priorities": ticketPriorities == null ? [] : List<dynamic>.from(ticketPriorities!.map((x) => x.toJson())),
    "ticket_status": ticketStatus == null ? [] : List<dynamic>.from(ticketStatus!.map((x) => x.toJson())),
    "allowed_files": allowedFiles == null ? [] : List<dynamic>.from(allowedFiles!.map((x) => Map.from(x).map((k, v) => MapEntry<String, dynamic>(k, v.toJson())))),
    "custom_field_types": customFieldTypes == null ? [] : List<dynamic>.from(customFieldTypes!.map((x) => Map.from(x).map((k, v) => MapEntry<String, dynamic>(k, v)))),
    "field_validation": fieldValidation == null ? [] : List<dynamic>.from(fieldValidation!.map((x) => Map.from(x).map((k, v) => MapEntry<String, dynamic>(k, v.toJson())))),
  };
}

class AllowedFile {
  String? name;
  String? type;

  AllowedFile({
    this.name,
    this.type,
  });

  factory AllowedFile.fromJson(Map<String, dynamic> json) => AllowedFile(
    name: json["name"],
    type: json["type"],
  );

  Map<String, dynamic> toJson() => {
    "name": name,
    "type": type,
  };
}

class FieldValidation {
  String? name;
  String? php;
  String? js;
  String? flutter;

  FieldValidation({
    this.name,
    this.php,
    this.js,
    this.flutter,
  });

  factory FieldValidation.fromJson(Map<String, dynamic> json) => FieldValidation(
    name: json["name"],
    php: json["php"],
    js: json["js"],
    flutter: json["flutter"],
  );

  Map<String, dynamic> toJson() => {
    "name": name,
    "php": php,
    "js": js,
    "flutter": flutter,
  };
}

class TicketPriority {
  String? low;
  String? medium;
  String? high;
  String? critical;

  TicketPriority({
    this.low,
    this.medium,
    this.high,
    this.critical,
  });

  factory TicketPriority.fromJson(Map<String, dynamic> json) => TicketPriority(
    low: json["low"],
    medium: json["medium"],
    high: json["high"],
    critical: json["critical"],
  );

  Map<String, dynamic> toJson() => {
    "low": low,
    "medium": medium,
    "high": high,
    "critical": critical,
  };
}

class TicketStatus {
  String? pending;
  String? opened;
  String? resolved;
  String? closed;
  String? reopen;

  TicketStatus({
    this.pending,
    this.opened,
    this.resolved,
    this.closed,
    this.reopen,
  });

  factory TicketStatus.fromJson(Map<String, dynamic> json) => TicketStatus(
    pending: json["pending"],
    opened: json["opened"],
    resolved: json["resolved"],
    closed: json["closed"],
    reopen: json["reopen"],
  );

  Map<String, dynamic> toJson() => {
    "pending": pending,
    "opened": opened,
    "resolved": resolved,
    "closed": closed,
    "reopen": reopen,
  };
}
