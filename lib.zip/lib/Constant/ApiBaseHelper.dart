import 'dart:async';
import 'dart:convert';
import 'dart:developer';
import 'dart:io';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:file_picker/file_picker.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';
import 'package:http/http.dart' as http;
import 'package:local_auth/local_auth.dart';
import 'package:urwealthpal/BottomBar/bottombar.dart';
import 'package:urwealthpal/ConstantModel/loginmodel.dart';
import 'package:urwealthpal/ConstantModel/registermodel.dart';
import 'package:urwealthpal/ConstantModel/settingmodel.dart';
import 'package:urwealthpal/Environment/Environment.dart';
import 'package:urwealthpal/Screens/Login/loginNewScreen.dart';
import 'package:urwealthpal/Screens/MPIN/Create_MPIN.dart';
import 'package:urwealthpal/Screens/MPIN/MPIN.dart';
import 'package:urwealthpal/Screens/PurchasePlan/purchase_plan.dart';
import 'package:urwealthpal/Screens/SecurityQuestions/Security_Question.dart';
import 'package:urwealthpal/main.dart';

import '../Screens/PurchasePlan/purchasecontroller.dart';
import 'Api.dart';

// var currentdate= DateFormat('yyyy-MM-dd').format(DateTime.now());
var jsondata;
var perentID;
class ApiBaseHelper {
  // var _mainHeaders;
  // var _headers;
  late Map<String,String> subheaders;
  late Map<String,String> _mainHeaders;
  PurchaseController _purchaseController = Get.put(PurchaseController());

  getPlandetails() async {
 await   _purchaseController.callpurchaseplanHistory_list(Get_MySubscriptionPlan_url);

  }
  Future<void> getPrefance() async {
    var is_login = sp!.getBool("loggedin") ?? false;
  //   print("is_login : " + is_login.toString());
  }

  Future<void> logindata(login) async {
    log("logindata");
    var JWTmodel = Loginmodel.fromJson(login);
    sp!.setString("loginresponse", json.encode(JWTmodel).toString());
    jsondata = json.decode(sp!.getString("loginresponse").toString());
    sp!.setString("imagee", jsondata['data']['user']['image']);
    log("login image------>>>>"+jsondata['data']['user']['image']);
    sp!.setString("namee", jsondata['data']['user']['name']);
    sp!.setString("mobilenum",  jsondata['data']['user']['mobile']);
    sp!.setString("email",  jsondata['data']['user']['email']);
    perentID =jsondata['data']['user']['parent_id'].toString();
    sp!.setString("parent_id",  jsondata['data']['user']['parent_id'].toString());
    // print("jsondata login token "+jsondata['data']['access_token']);
    log("parent_id parent_id---"+jsondata['data']['user']['parent_id'].toString());
    log("perentId 0.--->>--${sp!.getString("parent_id").toString()}");
    // updateHeader(jsondata['data']['access_token']);
  }

  Future<void> registerdata(login) async {
    var JWTmodel = Registermodel.fromJson(login);
    sp!.setString("loginresponse", json.encode(JWTmodel).toString());
    jsondata = json.decode(sp!.getString("loginresponse").toString());
    print("object...........${jsondata.toString()}");
    jsondata['data']['user']['image']==null? sp!.setString("imagee", ""):sp!.setString("imagee", jsondata['data']['user']['image']);
    sp!.setString("namee", jsondata['data']['user']['name']);
    sp!.setString("mobilenum",  jsondata['data']['user']['mobile']);
    sp!.setString("email",  jsondata['data']['user']['email']);
    perentID =jsondata['data']['user']['parent_id'].toString();
    sp!.setString("parent_id",  jsondata['data']['user']['parent_id'].toString());
    print("object...........${sp!.getString("namee").toString()}");
    print("object3...........${sp!.getString("mobilenum").toString()}");
    print("object2...........${sp!.getString("email").toString()}");
    print("object.4..........${sp!.getString("imagee").toString()}");
    log("access_token---"+jsondata['data']['access_token'].toString());
    log("parent_id---"+perentID.toString());
    // updateHeader(jsondata['data']['access_token']);
  }

  Future getId() async {
    var deviceInfo = DeviceInfoPlugin();
    if (Platform.isIOS) { // import 'dart:io'
      var iosDeviceInfo = await deviceInfo.iosInfo;
      return iosDeviceInfo.identifierForVendor; // unique ID on iOS
    } else if(Platform.isAndroid) {
      var androidDeviceInfo = await deviceInfo.androidInfo;
      return androidDeviceInfo.id; // unique ID on Android
    }
  }

  Future  getToken() async {
    var fcm_token = await FirebaseMessaging.instance.getToken();
    sp!.setString("token", fcm_token!);
    FirebaseMessaging.instance.onTokenRefresh.listen((token) {
      fcm_token = token;
    });
    print("FCM 1 : $fcm_token");
    return fcm_token;

    // print("deviceId ----- : $deviceId");
  }


  var setting_json_data;
  settingdata(response) {
    var JWTmodel = Settingmodel.fromJson(response);

    sp!.setString("setting", json.encode(JWTmodel).toString());
    setting_json_data = json.decode(sp!.getString("setting").toString());
    print("setting_json_data...."+setting_json_data['data']['login_type'].toString());
    // log("urlgdf------->${setting_json_data['data']['app_version'].toString()}");
  }

  var App_version_server ;
  double app_version = 1.1;
  var Force_update ;
  var App_force_updateNo = "1";
  var App_app_url_server ;
  var Maitaince ;
  var App_Maintaince_updateNo = "1";
  var Maitaince_text ;
  final LocalAuthentication auth = LocalAuthentication();

  Future<void> authenticate() async {
    bool isAuthenticated = false;
    log("message authenticate");
    isAuthenticated = await auth.authenticate(
      localizedReason: 'Please authenticate to access',
      options: const AuthenticationOptions(
          biometricOnly: true, // Allow only biometric authentication
          sensitiveTransaction: true,useErrorDialogs: true,
          stickyAuth: true),
    );
    if (isAuthenticated) {
      // showDialog(
      //   context: context,
      //   builder: (_) => AlertDialog(
      //     title: Text('Authenticated'),
      //     content: Text('You have been authenticated successfully!'),
      //   ),
      // );
      Fluttertoast.showToast(msg: "You have been authenticated successfully!",gravity: ToastGravity.CENTER);
      Get.off(bottombar(bottom: 2,));
    }else{
      Get.to(MPIN());
    }
    // try {
    //
    // } catch (e) {
    //   print('Error during authentication: $e');
    // }
  }  @override

  manageroute(){
    // log("urlgdf------->");
    // log("setting_json_data------->${setting_json_data.toString()}");
    setting_json_data = json.decode(sp!.getString("setting").toString());
    log("setting_json_data------->${setting_json_data['data']['app_version'].toString()}");
    if (double.parse(setting_json_data['data']['app_version'].toString()) > app_version) {
    // print("force update here 1");
    // var body = {
    //   "forceupdate" : setting_json_data['data']['app_force_update'].toString(),
    //   "applogo" : setting_json_data['data']['admin_logo'].toString(),
    //   "appname" : setting_json_data['data']['application_name'].toString(),
    //   "appurl" : setting_json_data['data']['app_url'].toString(),
    //   // "forceupdate": settingController.Force_update,
    //   // "applogo":  settingController.settingData['data']['general_settings']['logo'].toString(),
    //   // "appname":  settingController.settingData['data']['general_settings']['application_name'].toString(),
    //   // "appurl": settingController.settingData['data']['general_settings']['playstore_link'].toString() ,
    // };
    // print("force update here 1"+body.toString());
    // Get.dialog(
    //     ForceUpdatePage(
    //       forceupdate: setting_json_data['data']['app_force_update'].toString(),
    //       applogo:  setting_json_data['data']['admin_logo'].toString(),
    //       appname:  setting_json_data['data']['application_name'].toString(),
    //       appurl: setting_json_data['data']['app_url'].toString(),
    //
    //       // forceupdate: settingController.Force_update,
    //       // applogo:  settingController.settingData['data']['general_settings']['logo'].toString(),
    //       // appname:  settingController.settingData['data']['general_settings']['application_name'].toString(),
    //       // appurl: settingController.settingData['data']['general_settings']['playstore_link'].toString() ,
    //     )
    // );
    // showDialog(
    //     context: context,
    //     barrierDismissible:
    //     Force_update == App_force_updateNo.toString() ? false : true,
    //     builder: (_) => ForceUpdatePage(forceupdate: Force_update,
    //       applogo: jsonGetSetting['data']['front_logo'].toString(),
    //       appname: jsonGetSetting['data']['application_name'].toString(),
    //       appurl:jsonGetSetting['data']['app_url'].toString() ,
    //     )
    //
    // );
  }
  // else if (setting_json_data.Maitaince == App_Maintaince_updateNo)
  // {
  //   print("force update here 2");
  //   Get.to(MaitainceScreen(
  //     Maitaince_text: setting_json_data.Maitaince_text,
  //     applogo:  setting_json_data['data']['admin_logo'].toString(),
  //     appname:  setting_json_data['data']['application_name'].toString(),
  //     appurl: setting_json_data['data']['app_url'].toString(),
  //   ));
  // }
  //
  else{
    if(Environment.appuserlog==true){
      if (Environment.checkpaymentstatus==true){
        if(Environment.setMPIN.toString()== "1"){
          print("check mpin condition=> setmpin");
          Get.to(CreateMpinScreen());
        }else if (Environment.askQuestion.toString()== "1"){
          print("check mpin askQuestion=> askmpin");
          Get.to(Security_Question());
        }else if (Environment.askMPIN.toString()== "1"){
          print("check mpin condition=> askmpin");
          // Get.to(MPIN());
          authenticate();
        } else{
          log("check mpin condition=> no mpin");

          Get.offAll(bottombar(bottom: 2));
          // Get.offAll(VideoScreen(setting_json_data['data']["app_video"].toString()));
        }
      }
      else{
        // purchase_plan
        Get.offAll(purchase_plan());
      }
    }
    else{
      // Get.to(login());
      Get.to(NewLoginScreen());
    }
  }
}

  // managerouteassets(id){
  //
  //   if(Environment.appuserlog==true){
  //     // if (Environment.checkpaymentstatus==true){
  //       if(Environment.setMPIN.toString()== "1"){
  //         print("check mpin condition=> setmpin");
  //         Get.to(CreateMpinScreen());
  //       }
  //       else if (Environment.askMPIN.toString()== "1"){
  //         print("check mpin condition=> askmpin");
  //         Get.to(AssetsMPIN(),arguments: "${id}");
  //       }
  //       else{
  //         print("check mpin condition=> no mpin");
  //
  //
  //         Get.offAll(bottombar(bottom: 2));
  //       }
  //     // }
  //     // else{
  //     //   // purchase_plan
  //     //   Get.offAll(purchase_plan());
  //     // }
  //   }
  //   else{
  //     Timer(
  //         Duration(seconds: 3),
  //             () =>Get.offAll(login()));
  //   }
  // }

  Future<void> AppLogout() async {
    sp!.remove("imagee");
    sp!.remove("namee");
    sp!.remove("mobilenum");
    sp!.remove("email");
    sp!.setBool("loggedin", false);
    print("loggedin---------->");
    // Navigator.pushReplacement(context, MaterialPageRoute(
    //   builder: (context) => login(),));
    // sp!.clear();

  // await   Get.offAll(login());

    await Get.offAll(NewLoginScreen());
  }

    Future<http.Response> postAPICall(Uri url, parameter, header) async {
    print("post url : $url");
    print("post parameter : $parameter");
    var token;
    if(header ==true){
      var jsondata = json.decode(sp!.getString("loginresponse").toString());
      log("jsondata api calling: "+jsondata.toString());
      token =jsondata['data']['access_token'].toString();
      log("token for post api calling: "+token.toString());
      _mainHeaders = {
        // 'Content-Type': 'application/json',
        Environment.appxapikey.toString(): Environment.appxapivalue.toString(),
        'Authorization': 'Bearer $token'
      };
      print("_mainHeaders for post api calling: "+token.toString());
    }else{
      subheaders = {
        // 'Content-Type': 'application/json',
        Environment.appxapikey.toString(): Environment.appxapivalue.toString(),
      };
      print("subheaders for post api calling: "+subheaders.toString());
    }

    try {
      final response = await http.post(
        url,
        body: parameter,
        headers: header == true ? _mainHeaders : subheaders,
      ).timeout(
        Duration(
          seconds: int.parse(Environment.apptimeout.toString()),
        ),
      );

      print("post statusCode : ${response.statusCode.toString()}");
      log("post response : ${response.body.toString()}");
      return _response(response);
    } on SocketException {
      throw FetchDataException('No Internet connection');
    } on TimeoutException {
      throw FetchDataException('Something went wrong, try again later');
    }
  }


  Future<http.Response> getAPICall(Uri url, bool header) async {
    print("get url 1: $url");
    print("get header 1: $header");

    Map<String, String> _mainHeaders = {};
    Map<String, String> subheaders = {};

    if (header == true) {
      var jsondata = json.decode(sp!.getString("loginresponse").toString());
      print("data: $jsondata");
      var token = jsondata['data']['access_token'];

      _mainHeaders = {
        'Content-Type': 'application/json',
        Environment.appxapikey.toString(): Environment.appxapivalue.toString(),
        'Authorization': 'Bearer $token',
      };
    } else {
      subheaders = {
        'Content-Type': 'application/json',
        'Accept': 'application/json',
        Environment.appxapikey.toString(): Environment.appxapivalue.toString(),
      };
    }

    log("get headers: ${header ? _mainHeaders : subheaders}");

    try {
      final response = await http.get(
        url,
        headers: header ? _mainHeaders : subheaders,
      ).timeout(
        Duration(seconds: int.parse(Environment.apptimeout.toString())),
      );

      print("get statusCode : ${response.statusCode}");
      print("get response : ${response.body}");

      return _response(response); // assuming you handle parsing here
    } on SocketException {
      throw FetchDataException('No Internet connection');
    } on TimeoutException {
      throw FetchDataException('Something went wrong, try again later');
    }
  }


  // Future<http.Response> getAPICall(Uri url, header) async {
  //   print("get url 1: $url");
  //   print("get header 1: $header");
  //
  //   var token;
  //   if(header ==true){
  //     var jsondata = json.decode(sp!.getString("loginresponse").toString());
  //     print("data: "+jsondata.toString());
  //     token =jsondata['data']['access_token'];
  //     _mainHeaders = {
  //       'Content-Type': 'application/json',
  //       Environment.appxapikey.toString(): Environment.appxapivalue.toString(),
  //       'Authorization': 'Bearer $token'
  //     };
  //   }else{
  //     subheaders = {
  //       'Content-Type': 'application/json',
  //       'Accept': 'application/json',
  //       Environment.appxapikey.toString(): Environment.appxapivalue.toString(),
  //     };
  //   }
  //
  //   log("get _mainHeaders 1: ${header==true?_mainHeaders:subheaders}");
  //   try {
  //     final request = http.MultipartRequest('GET', url);
  //     request.headers.addAll(header==true?_mainHeaders:subheaders);
  //     http.StreamedResponse responses = await request.send();
  //
  //     var response = await http.Response.fromStream(responses);
  //
  //     // final response = await http
  //     //     .get(
  //     //       url,
  //     //       headers: header == true ? _mainHeaders : subheaders,
  //     //     )
  //     //     .timeout(
  //     //       Duration(
  //     //         seconds: int.parse(Environment.apptimeout.toString()),
  //     //       ),
  //     //     );
  //
  //     print("get statusCode : ${response.statusCode.toString()}");
  //     print("get response : ${response.body.toString()}");
  //     return _response(response);
  //   } on SocketException {
  //     throw FetchDataException('No Internet connection');
  //   } on TimeoutException {
  //     throw FetchDataException('Something went wrong, try again later');
  //   }
  // }









  Future<http.Response> getAPIQCall(Uri url, bool header, Map<String, String> parameter) async {
    print("get url 1: $url");
    print("get header 1: $header");
    print("get params 1: $parameter");

    Map<String, String> _mainHeaders = {};
    Map<String, String> subheaders = {};

    try {
      if (header == true) {
        var jsondata = json.decode(sp!.getString("loginresponse").toString());
        print("data: $jsondata");

        var token = jsondata['data']['access_token'];

        _mainHeaders = {
          'Content-Type': 'application/json',
          Environment.appxapikey.toString(): Environment.appxapivalue.toString(),
          'Authorization': 'Bearer $token'
        };
      } else {
        subheaders = {
          Environment.appxapikey.toString(): Environment.appxapivalue.toString(),
        };
      }

      // attach parameters in URL
      final finalUrl = url.replace(queryParameters: parameter);

      final response = await http
          .get(
        finalUrl,
        headers: header == true ? _mainHeaders : subheaders,
      )
          .timeout(
        Duration(seconds: int.parse(Environment.apptimeout.toString())),
      );

      print("get statusCode : ${response.statusCode}");
      print("get response : ${response.body}");

      return _response(response);
    } on SocketException {
      throw FetchDataException('No Internet connection');
    } on TimeoutException {
      throw FetchDataException('Something went wrong, try again later');
    }
  }

 // use this function for dynamic text form
  Future<http.Response> multipartAPICalls(url, parameter,List<MultipartBody> multipartBody, header) async {
    log("multipart url : $url");
    log("multipart parameter : $parameter");
    log("multipart header : $header");
    log("multipart multipartBody : ${multipartBody.length}");
    Map<String, String> headers;
    log("${header} ");
    var token;
    if (header != null) {
      var jsondata = json.decode(sp!.getString("loginresponse").toString());
      token = jsondata['data']['access_token'];
      log("post if ");
      headers = {
        'Content-Type': 'application/json',
        Environment.appxapikey.toString(): Environment.appxapivalue.toString(),
        'Authorization': 'Bearer $token'
      };
    }
    else {
      log("post else ");
      headers = {
        // 'Content-Type': 'application/json; charset=UTF-8',
        Environment.appxapikey.toString(): Environment.appxapivalue.toString(),
      };
    }
    try {
      log("in post try");
      var request = http.MultipartRequest('POST', url);
      log("in post try5");
      request.fields.addAll(parameter);
      log("in post try1");
      if (multipartBody.length!= 0) {
        log("in post try2");
        for(MultipartBody multipart in multipartBody) {

          request.files.add(await http.MultipartFile.fromPath(multipart.key.toString(),multipart.file.files.single.path.toString()));
        }

      } else {
        log("dddd");
      }
      request.headers.addAll(headers);

      http.StreamedResponse responses = await request.send();

      var responsedata = await http.Response.fromStream(responses);

      log("multipart statusCode : ${responsedata.statusCode.toString()}");
      log("multipart response : ${responsedata.body.toString()}");

      return _response(responsedata);


    } on SocketException {
      throw FetchDataException('No Internet connection');
    } on TimeoutException {
      throw FetchDataException('Something went wrong, try again later');
    }
  }

  Future<http.Response> multipartAPIForProfile(url, parameter,List<MultipartBody2> multipartBody, header)
  async {
    log("multipart url : $url");
    log("multipart parameter : $parameter");
    log("multipart header : $header");
    log("multipart multipartBody : ${multipartBody.length}");
    Map<String, String> headers;
    log("${header} ");
    var token;
    if (header != null) {
      var jsondata = json.decode(sp!.getString("loginresponse").toString());
      token = jsondata['data']['access_token'];
      log("post if ");
      headers = {
        'Content-Type': 'application/json',
        Environment.appxapikey.toString(): Environment.appxapivalue.toString(),
        'Authorization': 'Bearer $token'
      };
    }
    else {
      log("post else ");
      headers = {
        // 'Content-Type': 'application/json; charset=UTF-8',
        Environment.appxapikey.toString(): Environment.appxapivalue.toString(),
      };
    }
    try {
      log("in post try");
      var request = http.MultipartRequest('POST', url);
      log("in post try5");
      request.fields.addAll(parameter);
      log("in post try1");
      if (multipartBody.length!= 0) {
        log("in post try2");
        for(MultipartBody2 multipart in multipartBody) {

          request.files.add(await http.MultipartFile.fromPath(multipart.key.toString(), multipart.file.path.toString()));
        }

      } else {
        log("dddd");
      }
      request.headers.addAll(headers);

      http.StreamedResponse responses = await request.send();

      var responsedata = await http.Response.fromStream(responses);

      log("multipart statusCode : ${responsedata.statusCode.toString()}");
      log("multipart response : ${responsedata.body.toString()}");

      return _response(responsedata);


    } on SocketException {
      throw FetchDataException('No Internet connection');
    } on TimeoutException {
      throw FetchDataException('Something went wrong, try again later');
    }
  }

  http.Response _response(http.Response response) {
    switch (response.statusCode) {
      case 200:
        return response;
      case 201:
        return response;
      case 400:
      // toastMsg(jsonDecode(response.body)['messages'][0], true);
        return response;
    // toastMsg(jsonDecode(response.body)['messages'][0], true);
    // throw BadRequestException(response.body.toString());
      case 404:
      // toastMsg(jsonDecode(response.body)['messages'][0], true);
      // throw BadRequestException(response.body.toString());
        return response;
      case 401:
      // toastMsg(jsonDecode(response.body)['messages'][0], true);
        return response;
    //
    // throw BadRequestException(response.body.toString());
      case 422:
      //criditional
      //   toastMsg(jsonDecode(response.body)['message'], false);
        return response;
      case 403:
      //validation
      //   jsonDecode(response.body)['error'].forEach((k,v){
      //     toastMsg(v.toString(), false);
      //   });

        // throw UnauthorisedException(response.body.toString());
        return response;
      case 500:
        return response;
      default:
      // toastMsg(jsonDecode(response.body)['messages'][0], true);
        throw FetchDataException(
            'Error occurred while Communication with Server with StatusCode:${response.statusCode}');
    }
  }
}

class CustomException implements Exception {
  final _message;
  final _prefix;

  CustomException([this._message, this._prefix]);

  String toString() {
    return "$_prefix$_message";
  }
}

class FetchDataException extends CustomException {
  FetchDataException([message])
      : super(message, "Error During Communication: ");
}

class BadRequestException extends CustomException {
  BadRequestException([message]) : super(message, "Invalid Request: ");
}

class UnauthorisedException extends CustomException {
  UnauthorisedException([message]) : super(message, "Unauthorised: ");
}

class InvalidInputException extends CustomException {
  InvalidInputException([message]) : super(message, "Invalid Input: ");
}
class MultipartBody {
  String key;
  FilePickerResult file;

  MultipartBody(this.key, this.file);
}

class MultipartBody2 {
  String key;
  File file;

  MultipartBody2(this.key, this.file);
}
