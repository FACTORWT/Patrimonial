import 'package:flutter/services.dart';
import 'package:intl/intl.dart';

class NumberInputFormatter extends TextInputFormatter {
  final NumberFormat _formatter = NumberFormat('#,###');

  @override
  TextEditingValue formatEditUpdate(TextEditingValue oldValue, TextEditingValue newValue) {
    // Remove commas from the current text
    String newText = newValue.text.replaceAll(',', '');

    // Check if the new text is empty
    if (newText.isEmpty) {
      return newValue.copyWith(text: '', selection: newValue.selection);
    }

    // Convert to an integer and format it
    int? number = int.tryParse(newText);
    if (number != null) {
      String formattedText = _formatter.format(number);
      return newValue.copyWith(
        text: formattedText,
        selection: TextSelection.collapsed(offset: formattedText.length),
      );
    }

    // Return the original value if parsing fails
    return newValue;
  }
}
