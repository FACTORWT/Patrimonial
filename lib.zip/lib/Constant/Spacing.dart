import 'package:flutter/material.dart';

final sizebox_height_2  = SizedBox(height: 2,);
final sizebox_height_5  = SizedBox(height: 5,);
final sizebox_height_7  = SizedBox(height: 7,);
final sizebox_height_10  = SizedBox(height: 10,);
final sizebox_height_15  = SizedBox(height: 15,);
final sizebox_height_20 = SizedBox(height: 20,);
final sizebox_height_25 = SizedBox(height: 25,);
final sizebox_height_30 = SizedBox(height: 30,);
final sizebox_height_35 = SizedBox(height: 35,);
final sizebox_height_40 = SizedBox(height: 40,);
final sizebox_height_50 = SizedBox(height: 50,);

final sizebox_width_2 = SizedBox(width: 2,);
final sizebox_width_5 = SizedBox(width: 5,);
final sizebox_width_10 = SizedBox(width: 10,);
final sizebox_width_15 = SizedBox(width: 15,);
final sizebox_width_18 = SizedBox(width: 18,);
final sizebox_width_20 = SizedBox(width: 20,);
final sizebox_width_30 = SizedBox(width: 30,);
final sizebox_width_35 = SizedBox(width: 35,);
final sizebox_width_40 = SizedBox(width: 40,);
final sizebox_width_45 = SizedBox(width: 45,);
final sizebox_width_50 = SizedBox(width: 50,);
final sizebox_width_55 = SizedBox(width: 55,);
final sizebox_width_60 = SizedBox(width: 60,);
final sizebox_width_70 = SizedBox(width: 70,);
final sizebox_width_80 = SizedBox(width: 80,);
final sizebox_width_90 = SizedBox(width: 90,);
final sizebox_width_100 = SizedBox(width: 100,);
final sizebox_width_110 = SizedBox(width: 110,);
final sizebox_width_120 = SizedBox(width: 120,);
final sizebox_width_130 = SizedBox(width: 130,);
final sizebox_width_140 = SizedBox(width: 140,);
final sizebox_width_150 = SizedBox(width: 150,);

final main_axis_start= MainAxisAlignment.start;
final main_axis_end= MainAxisAlignment.end;
final main_axis_center= MainAxisAlignment.center;
final main_axis_spaceBetween= MainAxisAlignment.spaceBetween;

final cross_axis_start = CrossAxisAlignment.start;
final cross_axis_end = CrossAxisAlignment.end;
final cross_axis_center = CrossAxisAlignment.center;

final padding_all_5 = EdgeInsets.all(5);

// final lineDivider = Divider(
//   color: line_color,
//   height: 1,
//   thickness: 1,
//   indent: 0,
//   endIndent: 0,
// );
//
// final lDivider = Divider(
//   color: textcolor2,
//   height: 1,
//   thickness: 1,
//   indent: 0,
//   endIndent: 0,
// );
//
// final lDivide = Divider(
//   color: textcolor2,
//   height: 1,
//   thickness: 1,
// );