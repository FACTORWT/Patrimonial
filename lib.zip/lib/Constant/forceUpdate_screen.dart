import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:store_redirect/store_redirect.dart';
import 'package:urwealthpal/Constant/ApiBaseHelper.dart';
import 'package:urwealthpal/Constant/colors.dart';


class ForceUpdatePage extends StatefulWidget {
  var forceupdate,appurl,appname,applogo,updateText;
  ForceUpdatePage({this.forceupdate,this.applogo,this.appname,this.appurl,this.updateText}) ;

  @override
  State<ForceUpdatePage> createState() => _ForceUpdatePageState();
}

class _ForceUpdatePageState extends State<ForceUpdatePage> {
  bool LogedIn = false;
  bool CmpLogedIn = false;
  bool CmpSubLogedIn = false;

  @override
  Widget build(BuildContext context) {
    return      WillPopScope(
      onWillPop: () async {


        // if(widget.forceupdate != App_force_updateNo.toString()) {
        //
        //   Navigator.pushReplacement(
        //     context,
        //     MaterialPageRoute(
        //         builder: (context) =>
        //         preferences.getBool('LoggedIn') == true
        //             ? BottomBar(
        //           bottom: 2,
        //         ) :
        //         LoginScreen()),
        //   );
        //
        // }else{
        //   print("hejdkk");
        // }
        return false;

      },
      child:
      Dialog(
        child: Card(
          shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(10)),
          child: Container(
            height: 300,
            width: 400,
            color: Colors.white,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: <Widget>[
                Column(
                  children: [
                    SizedBox(
                      height: 10,
                    ),
                    Text(widget.appname.toString(),
                      style: TextStyle(fontSize: 20.5,fontWeight: FontWeight.w600,letterSpacing: 0.2),),

                    SizedBox(
                      height: 20,
                    ),
                    Container(

                      decoration: BoxDecoration(
                          color: ContainerColor,
                        borderRadius: BorderRadius.circular(10)
                      ),
                      child: CachedNetworkImage(
                        imageUrl: widget.applogo.toString(),height: 60,width: 150,),
                    ),
                    SizedBox(
                      height: 10,
                    ),
                    Container(
                      alignment: Alignment.topLeft,
                      padding: EdgeInsets.only(left: 10,right: 10),
                      child: Text(widget.updateText.toString(),
                        style: TextStyle(fontSize: 14.5,fontWeight: FontWeight.w400,letterSpacing: 0.2),textAlign: TextAlign.start,
                        maxLines: 4,),
                    ),
                  ],
                ),

                Row(
                  mainAxisAlignment: widget.forceupdate.toString()=="1"?MainAxisAlignment.center:MainAxisAlignment.spaceEvenly,
                  children: [
                    ElevatedButton(
                        onPressed: () {
                          StoreRedirect.redirect(
                              androidAppId: widget.appurl.toString());
                        },
                        style: ElevatedButton.styleFrom(
                          backgroundColor: ContainerColor,
                        ),
                        child: Text("Go To Play Store")
                    ),
                    widget.forceupdate.toString()=="1"?Container():
                    ElevatedButton(
                        onPressed: () {
                          // welcomeController.stopVideo();
                          ApiBaseHelper().manageroute();
                        },
                        style: ElevatedButton.styleFrom(
                          backgroundColor: ContainerColor,
                        ),
                        child: Text("Continue")
                    ),
                  ],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}