import 'package:flutter/material.dart';


class MaitainceScreen extends StatefulWidget {
  var appurl,appname,applogo;
  var Maitaince_text,maintainceupdate;
  MaitainceScreen({Key ? key, this.Maitaince_text,this.applogo,this.appname,this.appurl,this.maintainceupdate}) : super(key: key);

  @override
  State<MaitainceScreen> createState() => _MaitainceScreenState();
}

class _MaitainceScreenState extends State<MaitainceScreen> {
  bool LogedIn = false;
  bool CmpLogedIn = false;
  bool CmpSubLogedIn = false;


  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () async {


        // if(widget.maintainceupdate != App_Maintaince_updateNo.toString()) {
        //
        //   Navigator.pushReplacement(
        //     context,
        //     MaterialPageRoute(
        //         builder: (context) =>
        //         preferences.getBool('LoggedIn') == true
        //             ? BottomBar(
        //           bottom: 2,
        //         ) :
        //         LoginScreen()),
        //   );
        //
        // }else{
        //   print("hejdkk");
        // }
        return true;

      },
      child: Dialog(
        child: Container(
          height: 300,
          width: 400,

          decoration: BoxDecoration(
            // color: Colors.white,
            borderRadius: BorderRadius.circular(10),
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: <Widget>[

              Column(
                children: [
                  SizedBox(
                    height: 10,
                  ),
                  Text(widget.appname.toString(),
                    style: TextStyle(fontSize: 20.5,fontWeight: FontWeight.w600,letterSpacing: 0.2),),

                  SizedBox(
                    height: 20,
                  ),
                  Image.network(
                    widget.applogo.toString(),height: 50,width: 125,),
                  SizedBox(
                    height: 10,
                  ),
                  Container(
                    alignment: Alignment.topLeft,
                    padding:  EdgeInsets.only(left: 10,right: 10),
                    child: Text(widget.Maitaince_text.toString(),
                      style: TextStyle(fontSize: 14.5,fontWeight: FontWeight.w400,letterSpacing: 0.2),textAlign: TextAlign.start,
                      maxLines: 4,),
                  ),
                ],
              ),


            ],
          ),
        ),
      ),
    );
  }
}
