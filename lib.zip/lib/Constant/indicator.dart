import 'package:auto_size_text/auto_size_text.dart';
import 'package:flutter/material.dart';

class Indicator extends StatelessWidget {
  const Indicator({
    super.key,
    required this.color,
    required this.text,
    required this.isSquare,
     this.size,
     this.textwidth,
    this.textColor,
  });
  final Color color;
  final String text;
  final bool isSquare;
  final double? size;
  final double? textwidth;
  final Color? textColor;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: size,
      // height: size,
      child: Row(
        children: <Widget>[
          CircleAvatar(
            radius: 5,backgroundColor: color,
          ),

           SizedBox(
            width: 4,
          ),
          Container(
            width:textwidth,
            child: AutoSizeText(
              text,maxLines: 2,
              // overflow: TextOverflow.ellipsis,
              style: TextStyle(
                fontSize: 12,
                fontWeight: FontWeight.bold,
                color: textColor,
              ),
            ),
          )
        ],
      ),
    );
  }
}