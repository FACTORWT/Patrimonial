import 'package:flutter/material.dart';
import 'package:urwealthpal/Constant/colors.dart';


final lineDivider = Divider(
 color: sidebarcontainerColor,
  height: 1,
  thickness: 1,
  indent: 0,
  endIndent: 0,
);


final lineDivider2 = Divider(
  color: DividerColor,
  height: 1,
  thickness: 1,
  indent: 0,
  endIndent: 0,
);


final lineDivider3 = Divider(
  color: Colors.white,
  height: 1,
  thickness: 1,
  indent: 0,
  endIndent: 0,
);

