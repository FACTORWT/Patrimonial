import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:urwealthpal/Constant/colors.dart';
// final splashBackImage = Image.asset("assets/images/splash_background.png",scale: 3.0);
//final splashNewBackImage = Image.asset("assets/images/logo(1).png",scale: 1.7);
final splashNewBackImage = Image.asset("assets/images/patrimonial_loggo22.png",scale: 5);
final splashImage = Image.asset("assets/images/splash_image.png",scale: 3.0);
// final splashLogoImage = Image.asset("assets/images/splash_logo.png",scale: 3.0);
final LogoImage = Image.asset("assets/images/splash_logo.png",scale: 8.0,height: 15,width: 15,);
final loginImage = Image.asset("assets/images/login.png",scale: 3.0);
final PhoneIcon = Image.asset("assets/images/phoneIcon.png",scale: 3,width: 15,);
final PasswordIcon = Image.asset("assets/images/passIcon.png", scale: 3,width: 20,);
final OTPImage = Image.asset("assets/images/otp.png",scale: 3.0);
final full_Background_Image = Image.asset("assets/images/full_background.png");
final Main_Image = Image.asset("assets/images/main_image.png");
final signUpImage = Image.asset("assets/images/sing_up.png",scale: 3.0);
final userIcon = Image.asset("assets/images/user.png",scale: 3);
final emailIcon = Image.asset("assets/images/email (1).png",scale: 3);
final MPINImage = Image.asset("assets/images/MPIN.png",scale: 3.0);
final securityImage = Image.asset("assets/images/security.png",scale: 3.0);
final profileImage = Image.asset("assets/images/profile_image.png",scale: 4,);
final homeProfileImage = Image.asset("assets/images/profile_image.png",scale: 2.9,);
final profileTopImage = Image.asset("assets/images/profile_top_back.png",scale: 3,);
final profileBottomImage = Image.asset("assets/images/profile_bottom_back.png",scale: 2.0,);
final profileCallIcon = Image.asset("assets/images/call_icon.png",scale: 1.8,);
final profilEmailIcon = Image.asset("assets/images/mail_icon.png",scale: 1.8,);
final homeManageImage = Image.asset("assets/images/home_manage.png",scale: 3,);
final moneyImage = Image.asset("assets/images/money.png",scale: 3,);
final cashImage = Image.asset("assets/images/cash.png",scale: 3,);
final BankImage = Image.asset("assets/images/piggyBank.png",scale: 3,);
final InvestmentImage = Image.asset("assets/images/investment.png",scale: 2.5,);
final MutualFundsImage = Image.asset("assets/images/mutual_funds.png",scale: 2.5,);
final OtherImage = Image.asset("assets/images/others.png",scale: 2.5,);
final add_assets_bacgrount_image = Image.asset("assets/images/add_assets_background.png",scale: 3.2,);
final addIcon = Image.asset("assets/images/add.png",scale: 3,);

//App/Bottom Bar
final bottomImage = Image.asset("assets/images/bottom.png");
//final homeLogo = Image.asset("assets/images/homeLogo.png",height: 80,width: 80,);
final homeLogo = Image.asset("assets/images/patrimonial_logo_22.png",scale: 8,);
final indiaFlag = Image.asset("assets/images/english falg.png",height: 25,width: 25,);
final spanishFlag = Image.asset("assets/images/spanish_flag.png",height: 25,width: 25,);
final AssetsImage = Image.asset("assets/images/assets.png",scale: 2.6);
final LibailityImage = Image.asset("assets/images/libaility.png",scale:2);
final HomeImage = Image.asset("assets/images/homepage.png",scale: 2, height: 22, width: 40,);
final AssetsShareImage = Image.asset("assets/images/assetsShare.png",scale: 2.6);
final ProfileImage = Image.asset("assets/images/homeProfile.png",scale: 2.6);
final SearchIcon = Image.asset("assets/images/search_icon.png",scale: 3);

//SideBar
final homeIcon = Image.asset("assets/images/home.png",scale: 3,color: ContainerColor,);
final ProfileIcon = Image.asset("assets/images/profile.png",scale: 3,color: ContainerColor);
final ManageAssets_Icon = Image.asset("assets/images/manage.png",scale: 3);
final ShareAssets_Icon = Image.asset("assets/images/share.png",scale: 3);
final TicketIcon = Image.asset("assets/images/ticket.png",scale: 3);
final PurchasePlan_Icon = Image.asset("assets/images/purchase.png",scale: 3,color: ContainerColor);
final Libaility_Image = Image.asset("assets/images/libaility.png",scale:2,color: ContainerColor);
final Password_Icon = Image.asset("assets/images/passIcon.png", scale: 3,color: ContainerColor,);
final ContactUs_Icon = Image.asset("assets/images/contact.png",scale: 3,color: ContainerColor);
final ContactUsbottom_Icon = Image.asset("assets/images/contact.png",scale: 3,color: Colors.white,);
final AboutUs_Icon = Image.asset("assets/images/about.png",scale: 3,color: ContainerColor);
final RateUs_Icon = Image.asset("assets/images/rate.png",scale: 3);
final ShareApp_Icon = Image.asset("assets/images/shareApp.png",scale: 3,color: ContainerColor);
final FAQ_Icon = Image.asset("assets/images/faq.png",scale: 3,color: ContainerColor);
final TermC_Icon = Image.asset("assets/images/t&c.png",scale: 3,color: ContainerColor);
final PrivacyP_Icon = Image.asset("assets/images/privacyP.png",scale: 3,color: ContainerColor);
final Logout_Icon = Image.asset("assets/images/logout.png",scale: 3,color: ContainerColor);

//Assets Page
final FinancialAssets_Image = Image.asset("assets/images/Financial_Assets.png",
    height: 60,
    width: 70,
    );
final FixedAssets_Image = Image.asset("assets/images/Fixed_Assets.png",scale: 1.8);
final Bussines_Image = Image.asset("assets/images/business.png",scale: 1.8);

//Share Assets Page
final shareAss_Profile_image = Image.asset("assets/images/shareAss_Profile_image.png");

//Manage Assets page
final manAss_Profile_image = Image.asset("assets/images/shareAss_Profile_image.png",scale: 3,);

//Ticket Page
final OpenTicket = Image.asset("assets/images/openTicket.png",scale: 3);
final CloseTicket = Image.asset("assets/images/closeTicket.png",scale: 3);
final Calender = Image.asset("assets/images/calender.png",scale: 3,);

//Contact Us Page
final ContactUsLogo = Image.asset("assets/images/splash_logo.png",scale:5.0);
final FaceBookIcon = Image.asset("assets/images/facebook_icon.png",height: 50);
final InstagramIcon = Image.asset("assets/images/insta.png",height: 35);
final LinkdInIcon = Image.asset("assets/images/linkdin.png",height: 50);
final TwitterIcon = Image.asset("assets/images/twitter_icon.png",height: 50);
final GoogleIcon = Image.asset("assets/images/google_icon.png",height: 50);

//Profile Page
final profilePageImage = Image.asset("assets/images/profile_image.png",);
final cityIcon = Image.asset("assets/images/cityIcon.png",);
final boxImage = Image.asset("assets/images/box.png",);