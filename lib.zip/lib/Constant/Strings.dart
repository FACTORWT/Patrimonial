import 'package:get/get.dart';

var appname = "Patrimonial";
var appversion = 1;

class Strings extends Translations {
  @override
  // TODO: implement keys
  Map<String, Map<String, String>> get keys => {
        //ENGLISH LANGUAGE
        'en_US': {
          //Login Page
          'userlogin' : 'User',
          'getAccount' : 'Get Account',
          'loginn':'Login',
          'validMobileNo':'Please enter mobile Number.',
          'correctMobileNo':'Please enter 10 digits valid mobile number',
          'validPassword':'Please enter the password',
          'correctPassword':'Password size must be 8',
          'hintPassword':"Password",
          'forgotPasstxt':"Forgot password",
          'signIn':"SIGN IN",
          'accounttxt':"Don\'t have account create",
          'registertxt':"\t\tRegister",
          'send_OTP_txt':"Send OTP",

          //Video Page
          'video_txt':"Video Player",

          //OTP Page
          'otp':"OTP",
          'otptxt':"Please enter OTP.",
          'validotptxt':"Please enter valid OTP",
          'hintOTP':"OTP",
          'submitBtn':"SUBMIT",
          'finishBtn':"FINISH",

          //SingUp Page
          'signUp':"SIGN UP",
          'username':"Please enter name",
          'hintUserName':"User Name",
          'email':"Please enter Email",
          'validEmail':"Please enter valid email address",
          'hintEmail':"Email Id",
          'hintMobileNo':"Mobile No.",
          'reEnterPasswrod':"Please re-enter new password",
          'reEnterPasswrodNotMatch':"Password is not matched",
          'hintConfirmPassword':"Confirm password",
          'account_login_txt':"Already have an account?",
          'login_txt':"\t\tLogin",

          //MPIN Page
          'mpin':"PIN",
          'create_mpin':"CREATE PIN",
          'validMPIN':"Enter your PIN",
          'forgotMPIN':"Forgot PIN",
          'forgotSecurityAns':"Forgot Security Answer",
          'your_PIN':"Your PIN",

          //Security Page
          'security':"Security question",
          'askQue':"AskQuestion",
          'Your_AskQue':"Your AskQue",
          'enter_ans':"Please enter answer",
          'Ans...':"Ans.",
          'securityQuestion':"Q.1 What is your first school name ?",
          'answer':"Please enter answer",
          'validAnswer':"Please enter valid answer",
          'hintAns':"Ans.",
          'change_ans':"Change Answers",
          'update_ans':"Update Answers",
          'old_ans':"Old Answers",
          'new_ans':"New Answers",

          //Home page
          'totalAss':"Total Assets",
          'noOfAssets':"06",
          'totalValueOfAssets':"Total Liabilities",
          'slash':"\$",
          'totalValue':"2000",
          'financial_assets':"Financial Assets\n\t\t\t\t45% Assets",
          'cash':"Cash",
          'bank':"Banks",
          'investment':"Investment",
          'mutualFunds':"Mutual Funds",
          'barchartlib':"Last 3 Months Liabilities",
          'barchartAsst':"Last 3 Months Assets",
          'collectable':"Collectables",
          'liabilitie':"Liabilities",
          'liabilitie_detail':"Liabilities Details",
          'retirement':"Retirement accounts",
          'business':"Business Ownership",
          'fixed':"Fixed Assets",
          'financial':"Financial Assets",
          'coming':"Coming Soon.....",

          //Notification Page
          'notifications':"Notification",
          'DataFound':"No Data Found",

          //AppBar
          'search':"Search",

          //BottomBar
          'Back':"Press again Back Button exit",
          'sure':"Are you want to exit ?",
          'options':"Choose your option",
          'yes':"Yes",
          'ok':"OK",
          'no':"No",
          'assetstxt':"Assets",
          'plan_txt':"Plan",
          'Liabilities_txt':"Liabilities",
          'assetShare_txt':"Assets Share",

          //Purchase Plan
          'Subscription_txt' : 'Subscription History',
          'VoucherNo_txt' : 'Voucher No',
          'SubscriptionName_txt' : 'Subscription Name',
          'PlanPrice_txt' : 'Plan Price',
          'PlanDuration_txt' : 'Plan Duration',
          'PurchaseDate_txt' : 'Purchase Date',
          'Plan_Total_txt' : 'Plan Total',
          'ViewInvoice_txt' : 'View Invoice',
          'start_date' : 'Start Date',
          'ExpireDate_txt' : 'Expire Date',
          'InvoiceView_txt' : "Invoice View",

          //SideBar
          'hometxt':"Home",
          'profiletext':"Profile",
          'mangAsstxt':"Manage Assets",
          'shareAssetstxt':"Share Assets",
          'ticket_txt':"Ticket",
          'purchasePlantxt':"Purchase Plan",
          'Purchased_txt' : 'Purchased',
          'ChoosePlant_txt' : "Choose Plan",
          'contactUstxt':"Contact us",
          'aboutUstxt':"About Us",
          'rateUstxt':"Rate Us",
          'shareApptxt':"Share App",
          'faq_txt':"FAQ",
          'term_Conditiontxt':"Terms & Conditions",
          'privacyPolicytxt':"Privacy Policy",
          'logout_txt':"Logout",
          'conLogout_txt':"Confrim logout",
          'sureToLogout_txt':"Are you sure you want to logout?",
          "cancel_txt":"Cancel",

          //Assets Page
          'financialAssetstxt':"Financial\nAssets",
          'moduletxt':'Modules',
          'fixedAssetstxt':'Fixed\nAssets',
          'businessOwnershiptxt':'Business\nOwnership',

          //AssetsDetail Page
          'assetsDetailtxt':'Assets Detail',
          'balancetxt':'Balance',
          'storedPlacetxt':'Stored Place',
          'instructiontxt':'Instruction',
          'amount':'25,000/-',
          'blank':'-',
          'bankName_txt':'Bank Name',
          'accountType_txt':'Account Type',
          'branch_txt':'Branch',
          'accountNumber_txt':'Account Number',
          'backSpain_txt':'Back of Spain',
          'saving_txt':'Saving',
          'mi_txt':'MI Main Road',
          'accountNumber':'XXXXX-25360',
          'investmentName_txt':'Name of investment',
          'stockType_txt':'Type such as stocks',
          'investmentDate_txt':'Investment date',
          'totalInvestment_txt':"Total investment amount",
          'amounts':"12,5000/-",
          'investmentsName':"Bajaj Stock",
          'stockTypeName':"Small Clip",
          'investmentDate':"12/01/2023",
          'amt': "50,000",

          //Assets List Page
          'assetList_txt':"Assets List",
          'others_txt':"Others",

          //Add Assets Page
          'addAssets_text': "Add Assets",
          'balance_text': "Balance",
          'valid_balance':"Please enter balance",
          'correct_balance':"Please enter correct balance amount",
          'hintBankName':"Bank Name",
          'validBankName':"Please enter bank name",
          'correct_BankName':"Please enter correct bank name",
          'hintAccountType':"Account Type",
          'validAccount_type':"Please enter account type",
          'correctAccount_type':"Please enter correct account type",
          'hintBranch':"Branch",
          'validBranch':"Please enter branch",
          'correctBranch':"Please enter correct branch",
          'hintAccountNumber':"Account Number",
          'validAccount_Number':"Please enter account number",
          'correctAccount_Number':"Please enter correct account number",
          'success_txt':"Successfully submitted !!!",
          'sec':"Security question",

          //Share Assets Page
          'permission_txt':"Access Permission",

//Ticket Page
          'ticket_tx': "Tickets",
          'openTicket_txt':"Open Tickets\n     10",
          'closeTicket_txt':"Close Tickets\n   20",
          'categories_txt':"Categories",

//Ticket Status Page
          'ticketStatus_txt':"Ticket Status",
          'raise_txt':"Raise Ticket",

//Raise Ticket
          'subject_txt':"Subject",
          'answer':"Please enter answer",
          'hintans':"Ans.",
          'hintSubject_txt':"Enter Subject",
          'priority_txt':"Priority ",
          'valid_priority_txt':"Please Select Priority ",
          'select_priority_txt':"Select Priority ",
          'category_id_txt':"Category",
          'select_category_txt':"Select Category",
          'valid_sub':"Please enter subject",

          //Manage Assets Page
          'manageAss_tx':"Manage Permission",
          'manProfile_txt':"David Joha",
          'manContact_txt':"+06-123456-789",
          'manEmail_txt':"john@gmail.com",

//Chat Page
          'chatHint_txt':"Enter your text",
          'send_txt':"Send",

//Contact Us Page
          'contactUs_txt':"Contact Us",
          'phone':"Phone Number",
          'Email':"E Mail",
          'address':"Address",

//Profile Page
          'edit_txt':"Edit ",
          'validUserName_txt':"Please enter name",
          'validLength_UserName_txt':"Please enter valid name",
          'userName_txt':"Full name",
          'valid_Mobile_No_txt':"Please enter mobile number.",
          'validLengthMobile_No_txt':"Please enter 10 digits valid mobile number",
          'mobileNo_txt':"Mobile no.",
          'valid_Email_txt':"Please enter email",
          'validLength_Email_txt':"Please enter valid email address",
          'emailId_txt':"Email",
          'change_MPIN_txt':"Change PIN",
          'old_MPIN_txt':"Old PIN",
          'new_MPIN_txt':"New PIN",
          'set_MPIN_txt':"Set PIN",
//Edit Profile Page
          'editProfile_txt':"Edit Profile",
          'save_txt':"SAVE",

//About Us Page
          'about_us_txt':"About Us",

//Terms And Conditions Page
          'terms_Condition_txt':"Terms & Conditions",

//Privacy Policy Page
          'privacy_policy_txt':"Privacy & Policy",

//Reset Password Page
          'reset_txt':"Reset Password",
          'fillPin':"Please Fill Pin First",
          'valid_password_txt':"Please enter the new password",
          'new_password_correct_txt':"New password size must be 8",
          'hint_newPassword':"New password",
          'valid_confirm_txt':"Enter confirm password",
          'confirm_password_txt':"Please enter correct confirm password",
          'hintConfimPassword':"Confirm password",

//Change Password
          'ChangePassword':"Change password",
          'valid_old_password_txt':"Please enter the old password",
          'old_password_txt':"Old password size must be 8",
          'hintoldPassword':"Old password",
          'valid_new_password_txt':"Please enter the new password",
          'old_password_tx':"New password size must be 8",
          'hintoldPass':"New password",
          'valid_cofirm_password_txt':"Enter confirm password",
          'confirm_password_tx':"Please enter correct confirm password",
          'hint_confrim_Password':"Confirm password",

          //Family Member Page
          'SelectCountry':"Please select country ",
          'ValidCountry':"Please enter valid country name ",
          'hintCountry_txt':"Select country",
          'SelectState':"Please select state",
          'ValidState':"Please enter valid state name",
          'hintState_txt':"Select State",
          'SelectCity': "Please select city ",
          'hintCity_txt':"Select city",
          'no_family_txt':"No Family Member Found",
          'addfamily_txt': "Add Family Members",
          'relation_txt': "Relation",
          'validrelation_txt': "Please enter valid relation",
          'pinCode_txt': " Please enter your Pincode No.",
          'vaidPinCode': "Please enter valid Pincode No.",
          'hintpin_txt': "Pincode",
          'dob_txt': " Enter date of birth",
          'hint_dob_txt': "Enter your birth date",
          'print_dob': "Date is not selected",
          'address_txt': " Please enter your address",
          'valid_address_txt': "Please enter valid address",
          'hint_address': "Address",
          'family_member_txt': "Family Members",
          'family_txt': "Family",
          'update_txt': "Update Members",
          'sure_title_txt': "Are you sure?",
          'delete': "Do you want to Delete this Member.",
          'deleteForm': "Do you want to Delete this Form.",
          'delete_member': "Delete Members",
          'update_member_title': "Update Family Member",
          'askQue': "Ask Question",
          'reset_title_txt' : 'Reset 2-Factor Authentication',
          'reset_txt' : 'Useres 2-Factor Authentication has been cleared Successfully!!!',

          //Dynamic Form
         'wait_txt':"Please Wait.....",
          'sub_txt': "Submit",
          'notBlank_txt' : "Field cannot be blank",
          'selectBank_txt' : "Select Bank Name",


          " Form":" Form",
          "View":"View",
          "EnterMPIN":"Enter Your New PIN Code",
          'Unit of Measurement':'Unit of Measurement',

        },

    //SPANISH LANGUAGE
    'es_ES': {
      //Login Page
      'userlogin' : 'Usuario',
      'getAccountgetAccount' : 'Get Account',
      'loginn':'Inicio de sesión',
      'validMobileNo':'Por favor, introduzca el número de móvil.',
      'correctMobileNo':'Introduzca un número de móvil válido de 10 dígitos',
      'validPassword':'Introduzca la contraseña',
      'correctPassword':'El tamaño de la contraseña debe ser 8',
      'hintPassword':"Contraseña",
      'forgotPasstxt':"Contraseña olvidada",
      'signIn':"INSCRIBIRSE",
      'accounttxt':"No tener cuenta crear",
      'registertxt':"\t\tRegístrese en",
      'send_OTP_txt':"Enviar OTP",
      'ChoosePlant_txt' : "Elige Plan",

      //Video Page
      'video_txt':"Reproductor de vídeo",

      //OTP Page
      'otp':"OTP",
      'otptxt':"Por favor, introduzca OTP.",
      'validotptxt':"Por favor, introduzca un OTP válido",
      'hintOTP':"OTP",
      'submitBtn':"ENVIAR",
      'finishBtn':"ACABADO",

      //SingUp Page
      'signUp':"INSCRÍBETE",
      'username':"Por favor, introduzca su nombre",
      'hintUserName':"Nombre de usuario",
      'email':"Introduzca la dirección de correo electrónico",
      'validEmail':"Introduzca una dirección de correo electrónico válida",
      'hintEmail':"Dirección de correo electrónico",
      'hintMobileNo':"Nº de móvil",
      'reEnterPasswrod':"Vuelva a introducir la nueva contraseña",
      'reEnterPasswrodNotMatch':"La contraseña no coincide",
      'hintConfirmPassword':"Confirmar contraseña",
      'account_login_txt':"¿Ya tiene una cuenta?",
      'login_txt':"\t\tInicio de sesión",

      //MPIN Page
      'mpin':"PIN",
      'create_mpin':"CREAR PIN",
      'validMPIN':"Introduzca su PIN",
      'forgotMPIN':"Olvidé el PIN",
      'forgotSecurityAns':"¿Ha olvidado la respuesta de seguridad?",
      'your_PIN':"Su PIN",

      //Security Page
      'security':"Cuestión de seguridad",
      'askQue':"Pregunta",
      'Your_AskQue':"Tu AskQue",
      'enter_ans':"Por favor, introduzca la respuesta",
      'Ans...':"Ans.",
      'securityQuestion':"P.1 ¿Cuál es el nombre de su primer colegio?",
      'answer':"Por favor, introduzca la respuesta",
      'validAnswer':"Por favor, introduzca una respuesta válida",
      'hintAns':"Ans.",
      'change_ans':"Cambiar Respuestas",
      'update_ans':"Actualizar respuestas",
      'old_ans':"Respuestas antiguas",
      'new_ans':"Nuevas respuestas",

      //Home page
      'totalAss':"Activos totales",
      'noOfAssets':"06",
      'totalValueOfAssets':"Pasivo total",
      'slash':"\$",
      'totalValue':"2000",
      'financial_assets':"Activos financieros\n\t\t\t45% Activos",
      'cash':"Efectivo",
      'bank':"Bancos",
      'investment':"Inversión",
      'mutualFunds':"Fondos de inversión",
      'barchartlib':"Últimos 3 meses Pasivo",
      'barchartAsst':"Últimos 3 meses Activos",
      'collectable':"Coleccionables",
      'liabilitie':"Pasivo",
      'liabilitie_detail':"Detalles del pasivo",
      'retirement':"Cuentas de jubilación",
      'business':"Propiedad de la empresa",
      'fixed':"Activos fijos",
      'financial':"Activos financieros",
      'coming':"Próximamente.....",

      //Notification Page
      'notifications':"Notificación",
      'DataFound':"No se han encontrado datos",

      //AppBar
      'search':"Buscar en",

      //BottomBar
      'Back':"Pulsar de nuevo Botón Atrás salir",
      'sure':"¿Quieres salir?",
      'options':"Elija su opción",
      'yes':"Sí",
      'ok':"OK",
      'no':"No",
      'assetstxt':"Activos",
      'plan_txt':"Plan",
      'Liabilities_txt':"Pasivo",
      'assetShare_txt':"Activos Parte",

      //SideBar
      'hometxt':"Inicio",
      'profiletext':"Perfil",
      'mangAsstxt':"Gestionar activos",
      'shareAssetstxt':"Compartir activos",
      'ticket_txt':"Billete",
      'purchasePlantxt':"Plan de compra",
      'Purchased_txt' : 'Comprado',
      'contactUstxt':"Póngase en contacto con nosotros",
      'aboutUstxt':"Quiénes somos",
      'rateUstxt':"Valóranos",
      'shareApptxt':"Compartir aplicación",
      'faq_txt':"PREGUNTAS FRECUENTES",
      'term_Conditiontxt':"Condiciones generales",
      'privacyPolicytxt':"Política de privacidad",
      'logout_txt':"Cierre de sesión",
      'conLogout_txt':"Confrim logout",
      'sureToLogout_txt':"¿Seguro que quieres cerrar la sesión?",
      "cancel_txt":"Cancelar",

      //Assets Page
      'financialAssetstxt':"Activos financieros",
      'moduletxt':'Módulos',
      'fixedAssetstxt':'Activos fijos',
      'businessOwnershiptxt':'Empresa/Propiedad',

      //AssetsDetail Page
      'assetsDetailtxt':'Detalle del activo',
      'balancetxt':'Saldo',
      'storedPlacetxt':'Lugar de almacenamiento',
      'instructiontxt':'Instrucciones',
      'amount':'25,000/-',
      'blank':'-',
      'bankName_txt':'Nombre del banco',
      'accountType_txt':'Tipo de cuenta',
      'branch_txt':'Rama',
      'accountNumber_txt':'Número de cuenta',
      'backSpain_txt':'Volver a España',
      'saving_txt':'Guardar',
      'mi_txt':'MI Carretera principal',
      'accountNumber':'XXXXX-25360',
      'investmentName_txt':'Nombre de la inversión',
      'stockType_txt':'Tipo como acciones',
      'investmentDate_txt':'Fecha de inversión',
      'totalInvestment_txt':"Importe total de la inversión",
      'amounts':"12,5000/-",
      'investmentsName':"Bajaj Stock",
      'stockTypeName':"Clip pequeño",
      'investmentDate':"12/01/2023",
      'amt': "50,000",

      //Assets List Page
      'assetList_txt':"Lista de activos",
      'others_txt':"Otros",

      //Add Assets Page
      'addAssets_text': "Añadir activos",
      'balance_text': "Saldo",
      'valid_balance':"Por favor, introduzca el saldo",
      'correct_balance':"Introduzca el importe correcto del saldo",
      'hintBankName':"Nombre del banco",
      'validBankName':"Introduzca el nombre del banco",
      'correct_BankName':"Introduzca el nombre correcto del banco",
      'hintAccountType':"Tipo de cuenta",
      'validAccount_type':"Introduzca el tipo de cuenta",
      'correctAccount_type':"Please enter correct account type",
      'hintBranch':"Rama",
      'validBranch':"Por favor, introduzca la sucursal",
      'correctBranch':"Por favor, introduzca la sucursal correcta",
      'hintAccountNumber':"Número de cuenta",
      'validAccount_Number':"Introduzca el número de cuenta",
      'correctAccount_Number':"Please enter correct account number",
      'success_txt':"¡¡¡Enviado con éxito !!!",
      'sec':"Cuestión de seguridad",

      //Share Assets Page
      'permission_txt':"Permiso de acceso",

//Ticket Page
      'ticket_tx': "Entradas",
      'openTicket_txt':"Entradas abiertas\n 10",
      'closeTicket_txt':"Cerrar Entradas\n 20",
      'categories_txt':"Categorías",

//Ticket Status Page
      'ticketStatus_txt':"Estado del billete",
      'raise_txt':"Subir billete",

//Raise Ticket
      'subject_txt':"Asunto",
      'answer':"Por favor, introduzca la respuesta",
      'hintSubject_txt':"Introducir asunto",
      'priority_txt':"Prioridad ",
      'valid_priority_txt':"Seleccione la prioridad ",
      'select_priority_txt':"Seleccionar prioridad ",
      'category_id_txt':"Categoría",
      'select_category_txt':"Seleccionar categoría",
      'valid_sub':"Introduzca el asunto",

      //Manage Assets Page
      'manageAss_tx':"Gestionar permisos",
      'manProfile_txt':"David Joha",
      'manContact_txt':"+06-123456-789",
      'manEmail_txt':"john@gmail.com",

//Chat Page
      'chatHint_txt':"Introduzca su texto",
      'send_txt':"Enviar",

//Contact Us Page
      'contactUs_txt':"Contacte con nosotros",
      'phone':"Número de teléfono",
      'Email':"Correo electrónico",
      'address':"Dirección",

      //Profile Page
      'edit_txt':"Editar",
      'validUserName_txt':"Por favor, introduzca su nombre",
      'validLength_UserName_txt':"Introduzca un nombre válido",
      'userName_txt':"Nombre y apellidos",
      'valid_Mobile_No_txt':"Por favor, introduzca su número de móvil.",
      'validLengthMobile_No_txt':"Introduzca un número de móvil válido de 10 dígitos",
      'mobileNo_txt':"Nº de móvil",
      'valid_Email_txt':"Introduzca su dirección de correo electrónico",
      'validLength_Email_txt':"Introduzca una dirección de correo electrónico válida",
      'emailId_txt':"Correo electrónico",
      'change_MPIN_txt':"Cambiar PIN",
      'old_MPIN_txt':"PIN antiguo",
      'new_MPIN_txt':"Nuevo PIN",
      'set_MPIN_txt':"Establecer PIN",

//Edit Profile Page
      'editProfile_txt':"Editar perfil",
      'save_txt':"GUARDAR",

//About Us Page
      'about_us_txt':"Quiénes somos",

//Terms And Conditions Page
      'terms_Condition_txt':"Condiciones generales",

//Privacy Policy Page
      'privacy_policy_txt':"Política de privacidad",

      //Reset Password Page
      'reset_txt':"Restablecer contraseña",
      'fillPin':"Rellene primero el pin",
      'valid_password_txt':"Introduzca la nueva contraseña",
      'new_password_correct_txt':"El tamaño de la nueva contraseña debe ser 8",
      'hint_newPassword':"Nueva contraseña",
      'valid_confirm_txt':"Confirmar contraseña",
      'confirm_password_txt':"Por favor, introduzca la contraseña correcta",
      'hintConfimPassword':"Confirmar contraseña",

//Change Password
      'ChangePassword':"Cambiar contraseña",
      'valid_old_password_txt':"Por favor, introduzca la contraseña antigua",
      'old_password_txt':"El tamaño de la contraseña antigua debe ser 8",
      'hintoldPassword':"Contraseña antigua",
      'valid_new_password_txt':"Introduzca la nueva contraseña",
      'old_password_tx':"El tamaño de la nueva contraseña debe ser 8",
      'hintoldPass':"Nueva contraseña",
      'valid_cofirm_password_txt':"Confirmar contraseña",
      'confirm_password_tx':"Por favor, introduzca la contraseña correcta",
      'hint_confrim_Password':"Confirmar contraseña",

      //Family Member Page
      'SelectCountry':"Seleccione un país",
      'ValidCountry':"Introduzca un nombre de país válido",
      'hintCountry_txt':"Seleccione un país",
      'SelectState':"Seleccione un Estado",
      'ValidState':"Introduzca un nombre de estado válido",
      'hintState_txt':"Seleccionar Estado",
      'SelectCity': "Seleccione una ciudad",
      'hintCity_txt':"Seleccione una ciudad",
      'no_family_txt':"No se ha encontrado a ningún familiar",
      'addfamily_txt': "Añadir miembros de la familia",
      'relation_txt': "Relación",
      'validrelation_txt': "Introduzca una relación válida",
      'pinCode_txt': "Por favor, introduzca su Pincode No.",
      'vaidPinCode': "Introduzca un número de código PIN válido.",
      'hintpin_txt': "Código postal",
      'dob_txt': "Introduzca la fecha de nacimiento",
      'hint_dob_txt': "Introduzca su fecha de nacimiento",
      'print_dob': "Fecha no seleccionada",
      'address_txt': "Introduzca su dirección",
      'valid_address_txt': "Introduzca una dirección válida",
      'hint_address': "Dirección",
      'family_member_txt': "Miembros de la familia",
      'family_txt': "Familia",
      'update_txt': "Actualización Miembros",
      'sure_title_txt': "¿Seguro?",
      'delete': "¿Desea eliminar a este miembro?",
      'deleteForm': "¿Desea eliminar este formulario?",
      'delete_member': "Suprimir miembros",
      'update_member_title': "Actualizar miembro de la familia",
      'askQue': "Pregunta",

      //Dynamic Form
      'wait_txt':"Espere por favor.....",
      'sub_txt': "Enviar",
      'notBlank_txt' : "El campo no puede estar vacío",
      'selectBank_txt' : "Selecciona el tipo de propiedad”",

      //Purchase Plan
      'Subscription_txt' : 'Historial de suscripciones',
      'VoucherNo_txt' : 'Número de vale',
      'SubscriptionName_txt' : 'Nombre de la suscripción',
      'PlanPrice_txt' : 'Precio del plan',
      'PlanDuration_txt' : 'Duración del plan',
      'PurchaseDate_txt' : 'Fecha de compra',
      'Plan_Total_txt' : 'Plan Total',
      'ViewInvoice_txt' : 'Ver factura',
      'start_date' : 'Fecha de inicio',
      'ExpireDate_txt' : 'Fecha de expiración',
      'InvoiceView_txt' : "Vista de facturas",


      " Form":" Forma",
      "View":"Vista",
      "EnterMPIN":"Ingrese su nuevo código PIN",
      'Unit of Measurement':'Unidad de medida'

    }
      };
}
