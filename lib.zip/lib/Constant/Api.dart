import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:urwealthpal/Environment/Environment.dart';
//constant//
var que_search= "search";
var dynamicField_url ="${Environment.apibaseurl}" +"get-form";

var editDynamicField_url ="${Environment.apibaseurl}" +"edit-asset";
var updateDynamicField_url ="${Environment.apibaseurl}" +"update-asset";


var adddynamicField_url ="${Environment.apibaseurl}" +"add-asset";

var settings_url ="${Environment.apibaseurl}" +"settings";
var cms_url ="${Environment.apibaseurl}" +"cms/";
var login_url ="${Environment.apibaseurl}" +"login";
var getAccountsList_url ="${Environment.apibaseurl}" +"get-accounts";
var sendOTP_url ="${Environment.apibaseurl}" +"send-otp";
var login_OTP_url ="${Environment.apibaseurl}" +"otp-login";
var forgot_password_url ="${Environment.apibaseurl}" +"forgotpassword";
var reset_password_url ="${Environment.apibaseurl}" +"resetpassword";
var notification_url ="${Environment.apibaseurl}" +"notifications";
var register_url ="${Environment.apibaseurl}" +"register";
var Get_profile_url ="${Environment.apibaseurl}" +"profile";
var update_profile_url ="${Environment.apibaseurl}" +"updateprofile";
var check_MPIN_url ="${Environment.apibaseurl}" +"check-mpin";
var Get_forgotMPIN_url ="${Environment.apibaseurl}" +"forgot-mpin";
var reset_MPIN_url ="${Environment.apibaseurl}" +"reset-mpin";
var toggle_MPIN_url ="${Environment.apibaseurl}" +"toggle-mpin";
var change_MPIN_url ="${Environment.apibaseurl}" +"change-mpin";
var set_MPIN_url ="${Environment.apibaseurl}" +"set-mpin";
var change_password_url ="${Environment.apibaseurl}" +"updatepassword";
var Get_SubscriptionPlan_url ="${Environment.apibaseurl}" +"subscriptions";
var Save_SubscriptionPlan_url ="${Environment.apibaseurl}" +"save-subscription";
var Get_MySubscriptionPlan_url ="${Environment.apibaseurl}" +"my-subscriptions";
var Get_Invoice_url ="${Environment.apibaseurl}" +"download-invoice/";
var Post_Ticket_url ="${Environment.apibaseurl}" +"tickets";
var Raise_Ticket_url ="${Environment.apibaseurl}" +"raise-ticket";
var Ticket_Categories_url ="${Environment.apibaseurl}" +"ticket-categories";
var Get_Ticket_url ="${Environment.apibaseurl}" +"get-ticket?ticket_id=11";
var Home_url ="${Environment.apibaseurl}" +"home";
var Setup_Question_url ="${Environment.apibaseurl}" +"setup-questions";
var Toggle_Security_Question_url ="${Environment.apibaseurl}" +"toggle-security-question";
var Get_Question_url ="${Environment.apibaseurl}" +"get-question";
var Verify_AnswerQuestion_url ="${Environment.apibaseurl}" +"verify-answer";
var GetUser_Question_url ="${Environment.apibaseurl}" +"get-user-questions";
var Save_Question_url ="${Environment.apibaseurl}" +"save-questions";
var Update_answer_url ="${Environment.apibaseurl}" +"update-answer";
var ForgotSecAns_url ="${Environment.apibaseurl}" +"forgot-security-answers";
var ResetSecAns_url ="${Environment.apibaseurl}" +"reset-security-answers";
var Country_url ="${Environment.apibaseurl}" +"getcountry";
var State_url ="${Environment.apibaseurl}" +"getstate/";
var City_url ="${Environment.apibaseurl}" +"getcity/";
var Category_url ="${Environment.apibaseurl}" +"category";
var PostCategory_url ="${Environment.apibaseurl}" +"category-detail";
var Get_Family_Members_url ="${Environment.apibaseurl}" +"get-family-members";
var Rest_Family_Members_url ="${Environment.apibaseurl}" +"reset-family-member/";
var Get_Family_Member_url ="${Environment.apibaseurl}" +"get-family-member/";
var Update_familyMember_url ="${Environment.apibaseurl}" +"update-family-member";
var Delete_familyMember_url ="${Environment.apibaseurl}" +"delete-family-member/";
var Add_familyMember_url ="${Environment.apibaseurl}" +"add-family-member";
var Langauges_url ="${Environment.apibaseurl}" +"languages";
var ChangeLangauges_url ="${Environment.apibaseurl}" +"change-language";
var GetFamilyPermission_url ="${Environment.apibaseurl}" +"get-permission";
var UpdateFamilyPermission_url ="${Environment.apibaseurl}" +"update-permission";
var DeleteAssets_url ="${Environment.apibaseurl}" +"delete-asset";
var FAQ_url ="${Environment.apibaseurl}" +"faqs";

double appversion = 20.0;
double iosversion = 1.1;
var maintainversion = "1";
String App_forces_updateNo="1";

Future<void> toastMsg(var msg,bool iserrorr){
  var Msg = Fluttertoast.showToast(
      msg: msg,
      toastLength: Toast.LENGTH_SHORT,
      gravity: ToastGravity.SNACKBAR,
      timeInSecForIosWeb: 1,
      backgroundColor: iserrorr == false ? Colors.red: Color (0xFF0041A1),
      textColor: Colors.white,
      fontSize: 16.0
  );
  return Msg;
}