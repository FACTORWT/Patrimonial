// import 'package:flutter/material.dart';
// import 'package:order_tracker/order_tracker.dart';
//
// class Tracking extends StatefulWidget {
//   const Tracking({Key? key}) : super(key: key);
//
//   @override
//   State<Tracking> createState() => _TrackingState();
// }
//
// class _TrackingState extends State<Tracking> {
//   ///this TextDto present in a package add data in this dto and set in a list.
//
//   List<TextDto> orderList = [
//     TextDto("Your order has been placed", "Fri, 25th Mar '22 - 10:47pm"),
//     TextDto("Seller ha processed your order", "Sun, 27th Mar '22 - 10:19am"),
//     TextDto("Your item has been picked up by courier partner.",
//         "Tue, 29th Mar '22 - 5:00pm"),
//   ];
//
//   List<TextDto> shippedList = [
//     TextDto("Your order has been shipped", "Tue, 29th Mar '22 - 5:04pm"),
//     TextDto("Your item has been received in the nearest hub to you.", null),
//   ];
//
//   List<TextDto> outOfDeliveryList = [
//     TextDto("Your order is out for delivery", "Thu, 31th Mar '22 - 2:27pm"),
//   ];
//
//   List<TextDto> deliveredList = [
//     TextDto("Your order has been delivered", "Thu, 31th Mar '22 - 3:58pm"),
//   ];
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       appBar: AppBar(
//         title: const Text("Order Tracker Demo"),
//       ),
//       body: Padding(
//         padding: const EdgeInsets.all(20),
//         child: OrderTracker(
//           status: Status.delivered,
//           activeColor: Colors.green,
//           inActiveColor: Colors.grey[300],
//           orderTitleAndDateList: orderList,
//           shippedTitleAndDateList: shippedList,
//           outOfDeliveryTitleAndDateList: outOfDeliveryList,
//           deliveredTitleAndDateList: deliveredList,
//         ),
//       ),
//     );
//   }
// }


// import 'package:flutter/material.dart';
// import 'package:urwealthpal/Constant/colors.dart';
//
// class Tracking extends StatefulWidget {
//   const Tracking({Key? key}) : super(key: key);
//
//   @override
//   State<Tracking> createState() => _TrackingState();
// }
//
// class _TrackingState extends State<Tracking> {
//   @override
//   Widget build(BuildContext context) {
//     Size size = MediaQuery.of(context).size;
//     return Scaffold(
//       appBar: AppBar(
//         elevation: 0,
//         title: Text("Order Tracking"),
//         backgroundColor: ContainerColor,
//       ),
//       body: Padding(
//         padding:  EdgeInsets.all(50),
//         child: Column(
//           children: [
//             Row(
//               children: [
//                 Container(
//                   height: 15,
//                   width: 15,
//                   decoration: BoxDecoration(
//                       color:  Colors.green,
//                       borderRadius: BorderRadius.circular(50)),
//                 ),
//                 SizedBox(
//                   width: 20,
//                 ),
//                 Text.rich(
//                   TextSpan(
//                     children: [
//                       TextSpan(
//                           text: "Order Placed ",
//                           style:  TextStyle(
//                               fontSize: 16, fontWeight: FontWeight.bold)
//                       ),
//                       TextSpan(
//                         text: "Fri, 25th Mar '22",
//                         style:
//                         TextStyle(fontSize: 16, color: Colors.grey),
//                       ),
//                     ],
//                   ),
//                 ),
//               ],
//             ),
//             Row(
//               children: [
//                 Container(
//                   height: 15,
//                   width: 15,
//                   decoration: BoxDecoration(
//                       color:  Colors.green,
//                       borderRadius: BorderRadius.circular(50)),
//                 ),
//                 SizedBox(
//                   width: 20,
//                 ),
//                 Text.rich(
//                   TextSpan(
//                     children: [
//                       TextSpan(
//                           text: "Order Placed ",
//                           style:  TextStyle(
//                               fontSize: 16, fontWeight: FontWeight.bold)
//                       ),
//                       TextSpan(
//                         text: "Fri, 25th Mar '22",
//                         style:
//                         TextStyle(fontSize: 16, color: Colors.grey),
//                       ),
//                     ],
//                   ),
//                 ),
//               ],
//             ),
//             Row(
//               children: [
//                 Container(
//                   height: 15,
//                   width: 15,
//                   decoration: BoxDecoration(
//                       color:  Colors.green,
//                       borderRadius: BorderRadius.circular(50)),
//                 ),
//                 SizedBox(
//                   width: 20,
//                 ),
//                 Text.rich(
//                   TextSpan(
//                     children: [
//                       TextSpan(
//                           text: "Order Placed ",
//                           style:  TextStyle(
//                               fontSize: 16, fontWeight: FontWeight.bold)
//                       ),
//                       TextSpan(
//                         text: "Fri, 25th Mar '22",
//                         style:
//                         TextStyle(fontSize: 16, color: Colors.grey),
//                       ),
//                     ],
//                   ),
//                 ),
//               ],
//             ),
//             Row(
//               children: [
//                 Container(
//                   height: 15,
//                   width: 15,
//                   decoration: BoxDecoration(
//                       color:  Colors.green,
//                       borderRadius: BorderRadius.circular(50)),
//                 ),
//                 SizedBox(
//                   width: 20,
//                 ),
//                 Text.rich(
//                   TextSpan(
//                     children: [
//                       TextSpan(
//                           text: "Order Placed ",
//                           style:  TextStyle(
//                               fontSize: 16, fontWeight: FontWeight.bold)
//                       ),
//                       TextSpan(
//                         text: "Fri, 25th Mar '22",
//                         style:
//                         TextStyle(fontSize: 16, color: Colors.grey),
//                       ),
//                     ],
//                   ),
//                 ),
//               ],
//             ),
//           ],
//         ),
//       ),
//     );
//   }
// }
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:order_tracker/order_tracker.dart';
// import 'package:order_tracker/order_tracker.dart';
import 'package:urwealthpal/Constant/colors.dart';

class Tracking extends StatefulWidget {
  const Tracking({Key? key}) : super(key: key);

  @override
  State<Tracking> createState() => _TrackingState();
}

class _TrackingState extends State<Tracking> {

  List<TextDto> InitialOrderDataList = [
    TextDto("Your order has been placed", ""),
  ];

  List<TextDto> OrderShippedDataList = [
    TextDto("Your order has been shipped",""),
  ];

  List<TextDto>  OrderOutOfDeliveryDataList   = [
    TextDto("Your order is out for delivery",""),
  ];

  List<TextDto> OrderDeviveredDataList  = [
    TextDto("Your order has been delivered",""),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        elevation: 0,
        titleSpacing: 0,
        title: Text("Order Tracking"),
        backgroundColor: ContainerColor,
      ),
      body: Padding(
        padding: EdgeInsets.all(30),
        child: OrderTracker(
          status: Status.delivered,
          activeColor: Colors.blue,
          inActiveColor: Colors.grey[300],
          orderTitleAndDateList: InitialOrderDataList,
          shippedTitleAndDateList: OrderShippedDataList,
          outOfDeliveryTitleAndDateList: OrderOutOfDeliveryDataList,
          deliveredTitleAndDateList: OrderDeviveredDataList,
        ),
      ),
    );
  }
}