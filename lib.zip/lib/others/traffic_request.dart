import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:urwealthpal/Constant/colors.dart';

class traffic_request extends StatefulWidget {
  const traffic_request({Key? key}) : super(key: key);

  @override
  State<traffic_request> createState() => _traffic_requestState();
}

class _traffic_requestState extends State<traffic_request> {

  TextEditingController dateInput = TextEditingController();

  // DateTime dateTime = DateTime(2023, 12, 24, 5, 30);

  var _value = "-1";

  void initState(){
    dateInput.text = "";
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    // final hours = dateTime.hour.toString().padLeft(2, '0');
    // final mintues = dateTime.minute.toString().padLeft(2, '0');

    return Scaffold(
      resizeToAvoidBottomInset: false,
      appBar: AppBar(
        backgroundColor: primaryColor,
        title: Text(
          "Traffic Request :: Add",
        ),
        titleSpacing: 0,
        elevation: 0,
        // backgroundColor: ,
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                Container(
                  margin: EdgeInsets.only(left: 20,top: 20),
                  width: 100,
                    child: Text("Date Time",
                    style: TextStyle(
                      color: Colors.black,
                      fontSize: 15,
                      fontWeight: FontWeight.bold
                    ),)),
              ],
            ),
            Padding(
              padding: EdgeInsets.fromLTRB(20, 10, 20, 0),
              child: TextFormField(
                scrollPadding: EdgeInsets.only(
                    bottom: MediaQuery.of(context).viewInsets.bottom + 25*4),
                controller: dateInput,
                validator: (value) {
                  if (value!.isEmpty) {
                    return " Enter Date Time";
                  } else
                    return null;
                },
                decoration: InputDecoration(
                  hintText: "Enter Date Time",
                  filled: true,
                  fillColor: Colors.white,
                  contentPadding: EdgeInsets.only(top: 5,left: 10),
                  constraints: BoxConstraints(
                      minWidth: 30, maxHeight: 70),
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10),
                      borderSide: BorderSide(width: 1, color: primaryColor)),
                  enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10),
                      borderSide: BorderSide(width: 1, color: Colors.black)),
                  focusedBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10),
                      borderSide: BorderSide(width: 1, color: primaryColor)),
                ),
                onTap: () async {
                  DateTime? pickedDate = await showDatePicker(
                      context: context,
                      initialDate: DateTime.now(),
                      firstDate: DateTime(1950),
                      lastDate: DateTime(2100));
                  if (pickedDate != null) {
                    print(pickedDate);
                    String formattedDate =
                        DateFormat('MM-dd-yyyy').format(pickedDate);
                    print(formattedDate);
                    setState(() {
                      dateInput.text = formattedDate;
                    });
                  } else {
                    print('Date is not selected');
                  }
                },
              ),
            ),
            SizedBox(
              height: 20,
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                Container(
                    margin: EdgeInsets.only(left: 20),
                    width: 100,
                    child: Text("Request Type",
                      style: TextStyle(
                          color: Colors.black,
                          fontSize: 15,
                          fontWeight: FontWeight.bold
                      ),
                    )
                ),
              ],
            ),
            Padding(
              padding: EdgeInsets.fromLTRB(20, 10, 20, 0),
              child: DropdownButtonFormField(
                validator: ((value){
                  if (value == null){
                    return "Please Select Type";
                  }
                }),
                  decoration: InputDecoration(
                    border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10),
                        borderSide: BorderSide(width: 1, color: primaryColor)),
                    enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10),
                        borderSide: BorderSide(width: 1, color: Colors.black)),
                    focusedBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10),
                        borderSide: BorderSide(width: 1, color: primaryColor)),
                    filled: true,
                    contentPadding: EdgeInsets.only(top: 5,left: 10),
                    constraints: BoxConstraints(
                        minWidth: 30, maxHeight: 70),
                    hintStyle: TextStyle(color: Colors.grey),
                    hintText: "Select Type",
                    fillColor: Colors.white,
                  ),
                  items: [
                   DropdownMenuItem(
                     child: Text("Check In"),
                     value: "-1",
                   ),
                    DropdownMenuItem(
                      child: Text("Check Out"),
                      value: "1",
                    ),
                    // DropdownMenuItem(
                    //   child: Text(""),
                    //   value: "2",
                    // ),
                  ],
                  onChanged: (v){}),
            ),

            Row(
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                Container(
                    margin: EdgeInsets.only(left: 20,top: 20),
                    width: 100,
                    child: Text("Reason",
                      style: TextStyle(
                          color: Colors.black,
                          fontSize: 15,
                          fontWeight: FontWeight.bold
                      ),)),
              ],
            ),
            Padding(
              padding: EdgeInsets.fromLTRB(20, 10, 20, 0),
              child: TextFormField(
                maxLines: 10,
                scrollPadding: EdgeInsets.only(
                    bottom: MediaQuery.of(context).viewInsets.bottom + 25*4),
                decoration: InputDecoration(
                  hintText: "Enter Reason",
                  filled: true,
                  fillColor: Colors.white,
                  border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10),
                      borderSide: BorderSide(width: 1, color: primaryColor)),
                  enabledBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10),
                      borderSide: BorderSide(width: 1, color: Colors.black)),
                  focusedBorder: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10),
                      borderSide: BorderSide(width: 1, color: primaryColor)),
                ),
              ),
            ),
            SizedBox(
              height: 40,
            ),
            Container(
              width: 90,
              height: 40,
              margin: EdgeInsets.symmetric(horizontal: 10),
              decoration: BoxDecoration(
                  color: primaryColor,
                  border: Border.all(
                    color: primaryColor,
                  ),
                  borderRadius: BorderRadius.all(Radius.circular(8))
              ),
              child: Center(
                child: Text("Add",
                  // textAlign: TextAlign.center,
                  style: TextStyle(
                      fontSize: 18
                  ),),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
