import 'dart:async';
import 'package:flutter/material.dart';
import 'package:in_app_purchase/in_app_purchase.dart';
import 'package:urwealthpal/Constant/colors.dart';

InAppPurchase _appPurchase = InAppPurchase.instance;
late StreamSubscription<dynamic> _streamSubscription;
List<ProductDetails> _products = [];
const _variant = {"amplifyabhj", "amplifyabhj pro"};

class Google_pay extends StatefulWidget {
  const Google_pay({Key? key}) : super(key: key);

  @override
  State<Google_pay> createState() => _Google_payState();
}

class _Google_payState extends State<Google_pay> {

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    Stream purchaseUpdated = InAppPurchase.instance.purchaseStream;

    _streamSubscription = purchaseUpdated.listen((purchaseList) {
      _listenToPurchase(purchaseList, context);
    }, onDone: (){
      _streamSubscription.cancel();
    }, onError: (){
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("Error")));
    }
    );

    initStore();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Google Pay"),
        elevation: 0,
        titleSpacing: 0,
        backgroundColor: ContainerColor,
      ),
      body: Center(
        child: TextButton(
          onPressed: (){
            _buy();
          },
          child: Text(" Pay "),
        ),),
    );
  }

  initStore() async{
    ProductDetailsResponse productDetailsResponse =
    await _appPurchase.queryProductDetails(_variant);

    if(productDetailsResponse.error == null){
      setState(() {
        _products = productDetailsResponse.productDetails;
      });
    }
  }

   _listenToPurchase(List<PurchaseDetails> purchaseDetailsList, BuildContext context) {
    purchaseDetailsList.forEach((PurchaseDetails purchaseDetails) async{
      if(purchaseDetails.status ==PurchaseStatus.pending){
        ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text("Pending")));
      }else{
        if(purchaseDetails.status == PurchaseStatus.error){
          ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(content: Text("Error")));
        }else if(purchaseDetails.status == PurchaseStatus.purchased){
          ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(content: Text("Purchased")));
        }
      }
    });
  }

  _buy(){
    final PurchaseParam param = PurchaseParam(productDetails: _products[0]);
    _appPurchase.buyConsumable(purchaseParam: param);
  }
}

