// import 'package:fl_chart/fl_chart.dart';
// import 'package:flutter/material.dart';
//
//
// class homepage extends StatefulWidget {
//   const homepage({Key? key}) : super(key: key);
//
//   @override
//   State<homepage> createState() => _homepageState();
//
// }
// class _homepageState extends State<homepage> {
//
//   bool login;
//   get homepagekey => null;
//   void initState() {
//     //TODO: implement initState
//     getdata();
//     super.initState();
//     GlobalKey<ScaffoldState> homepagekey = GlobalKey<ScaffoldState>();
//   }
//   getdata() async {
//     SharedPreferences prefs = await SharedPreferences.getInstance();
//     // login=  prefs.getBool("login");
//     print("loginhome----${login}");
//   }
//
//
//   @override
//   Widget build(BuildContext context) {
//     Size size = MediaQuery
//         .of(context)
//         .size;
//     return Scaffold(
//         drawer: drawerpage(),
//         key: homepagekey,
//         appBar: AppBar(
//             backgroundColor: Color(0xFF302E79),
//             toolbarHeight: 60,
//             title: Image.asset(
//                 "assets/images/masterkhatalogo.png", height: 40, width: 75)
//         ),
//         body: SingleChildScrollView(
//           child: Column(
//               mainAxisAlignment: MainAxisAlignment.start,
//               crossAxisAlignment: CrossAxisAlignment.start,
//               children: [
//                 Row(
//                     mainAxisAlignment: MainAxisAlignment.spaceBetween,
//                     crossAxisAlignment: CrossAxisAlignment.start,
//                     children: [
//                       Container(
//                         margin: EdgeInsets.only(left: 10, top: 20),
//                         height: size.height * 0.10,
//                         width: size.width * 0.45,
//                         decoration: BoxDecoration(
//                           border: Border.all(color: Colors.grey),
//                           borderRadius: BorderRadius.circular(8),
//                         ),
//                         child: Row(
//                           mainAxisAlignment: MainAxisAlignment.start,
//                           crossAxisAlignment: CrossAxisAlignment.start,
//                           children: [
//                             Column(
//                               children: [
//                                 Container(
//                                   margin: EdgeInsets.only(left: 10, top: 15),
//                                   child: Image.asset("assets/images/4444.png",
//                                     height: 45, width: 45,
//                                   ),
//                                 ),
//                               ],
//                             ),
//                             Column(
//                               children: [
//                                 Container(
//                                   margin: EdgeInsets.only(top: 15, left: 25),
//                                   child: Text("Staff",
//                                     style: TextStyle(fontSize: 15,
//                                       fontWeight: FontWeight.w500,
//                                       color: Color(0xff072356),),
//                                   ),
//                                 ),
//                               ],
//                             ),
//                             Center(
//                               child: Container(
//                                 margin: EdgeInsets.only(top: 10, right: 20),
//                                 child: Text("25",
//                                   style: TextStyle(fontSize: 22,
//                                     fontWeight: FontWeight.w800,
//                                     color: Colors.grey,),
//                                 ),
//                               ),
//                             ),
//                           ],
//                         ),
//                       ),
//                       Container(
//                         margin: EdgeInsets.only(right: 10, top: 20),
//                         height: size.height * 0.10,
//                         width: size.width * 0.45,
//                         decoration: BoxDecoration(
//                           border: Border.all(color: Colors.grey),
//                           borderRadius: BorderRadius.circular(8),
//                         ),
//                         child: Row(
//                           mainAxisAlignment: MainAxisAlignment.start,
//                           crossAxisAlignment: CrossAxisAlignment.start,
//                           children: [
//                             Column(
//                               children: [
//                                 Container(
//                                   margin: EdgeInsets.only(left: 10, top: 15),
//                                   child: Image.asset("assets/images/2222.png",
//                                     height: 45, width: 45,
//                                   ),
//                                 ),
//                               ],
//                             ),
//                             Column(
//                               children: [
//                                 Container(
//                                   margin: EdgeInsets.only(top: 15, left: 13),
//                                   child: Text("Active Loan",
//                                     style: TextStyle(fontSize: 15,
//                                       fontWeight: FontWeight.w500,
//                                       color: Color(0xff072356),),
//                                   ),
//                                 ),
//                               ],
//                             ),
//
//
//                           ],
//                         ),
//
//                       ),
//                     ]
//                 ),
//                 SizedBox(
//
//                   height: 300,
//                   child: Card(
//                     margin: EdgeInsets.only(top: 50,left: 10,right: 10),
//                     elevation: 4,
//                     child: Column(
//                       mainAxisAlignment: MainAxisAlignment.center,
//                       crossAxisAlignment: CrossAxisAlignment.start,
//                       children: [
//                         Padding(
//                           padding:  EdgeInsets.only(left: 10),
//                           child: Text("Total Sale",
//                             style: TextStyle(
//                                 color: Color(0xFF6A6A6A),
//                                 fontSize: 24,
//                                 fontWeight: FontWeight.bold
//                             ),),
//                         ),
//                         AspectRatio(
//                           aspectRatio: 2,
//                           child: Padding(
//                             padding:  EdgeInsets.only(
//                               left: 10,
//                               right: 10,
//                               top: 10,
//                               bottom: 10,
//                             ),
//                             child: LineChart(
//                               LineChartData(
//                                 lineTouchData:  LineTouchData(enabled: false),
//                                 lineBarsData: [
//                                   LineChartBarData(
//                                     spots: const [
//                                       FlSpot(0, 7),
//                                       FlSpot(0.5, 6),
//                                       FlSpot(1.5, 4),
//                                       FlSpot(3, 7),
//                                       FlSpot(4, 5.4),
//                                       FlSpot(5.6, 7),
//                                       FlSpot(6, 5.8),
//                                       FlSpot(7, 8),
//                                     ],
//                                     isCurved: false,
//                                     barWidth: 2.5,
//                                     color: Colors.blue,
//                                     dotData:  FlDotData(
//                                       show: true,
//                                     ),
//                                   ),
//                                 ],
//                                 minY: 0,
//                                 borderData: FlBorderData(
//                                   show: false,
//                                 ),
//                                 titlesData: FlTitlesData(
//                                   bottomTitles: AxisTitles(
//                                     sideTitles: SideTitles(
//                                       showTitles: false,
//                                       interval: 1,
//                                       // getTitlesWidget: leftTitleWidgets,
//                                     ),
//                                   ),
//                                   leftTitles: AxisTitles(
//                                     sideTitles: SideTitles(
//                                       showTitles: true,
//                                       getTitlesWidget: bottomTitleWidgets,
//                                       interval: 1,
//                                       reservedSize: 36,
//                                     ),
//                                   ),
//                                   topTitles:  AxisTitles(
//                                     sideTitles: SideTitles(showTitles: false),
//                                   ),
//                                   rightTitles:  AxisTitles(
//                                     sideTitles: SideTitles(showTitles: false),
//                                   ),
//                                 ),
//                                 gridData: FlGridData(
//                                   show: true,
//                                   drawVerticalLine: false,
//                                   horizontalInterval: 1,
//                                   checkToShowHorizontalLine: (double value) {
//                                     return value == 1 || value == 2 || value == 3 ||
//                                         value == 4 || value == 5|| value == 6;
//                                   },
//                                 ),
//                               ),
//                             ),
//                           ),
//                         ),
//                       ],
//                     ),
//                   ),
//                 ),
//
//               ]
//           ),
//
//         )
//
//     );
//   }
//
//   Widget bottomTitleWidgets(double value, TitleMeta meta) {
//     const style = TextStyle(
//       color: Color(0xFF6A6A6A),
//       fontSize: 10,
//     );
//     String text;
//     switch (value.toInt()) {
//       case 0:
//         text = 'Jul';
//         break;
//       case 1:
//         text = 'Jun';
//         break;
//       case 2:
//         text = 'May';
//         break;
//       case 3:
//         text = 'Apr';
//         break;
//       case 4:
//         text = 'Mar';
//         break;
//       case 5:
//         text = 'Feb';
//         break;
//       case 6:
//         text = 'Jan';
//         break;
//       default:
//         return Container();
//     }
//
//     return SideTitleWidget(
//       axisSide: meta.axisSide,
//       space: 7,
//       child: Text(text, style: style),
//     );
//   }
//
// }






