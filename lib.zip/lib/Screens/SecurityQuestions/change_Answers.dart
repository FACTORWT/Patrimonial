import 'dart:developer';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:urwealthpal/Constant/Api.dart';
import 'package:urwealthpal/Constant/colors.dart';
import 'package:urwealthpal/Screens/SecurityQuestions/Controllers/setup_question_controller.dart';

class Change_Answers extends StatefulWidget {
  var id;
   Change_Answers({this.id});

  @override
  State<Change_Answers> createState() => _Change_AnswersState();
}

class _Change_AnswersState extends State<Change_Answers> {


  var _formKey = GlobalKey<FormState>();

  TextEditingController userInput = TextEditingController();
  TextEditingController answers = TextEditingController();
  TextEditingController oldAnswers = TextEditingController();

  Set_Security_QuestionController set_security_questionController =
  Get.put(Set_Security_QuestionController());


  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    set_security_questionController.GetUserSecurity_QuestionApi(GetUser_Question_url);
  }

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;

    return Scaffold(
      resizeToAvoidBottomInset: false,
      appBar:AppBar(
        backgroundColor: ContainerColor,
        elevation: 0,
        titleSpacing: 0,
        title: Text("change_ans".tr),
      ),
      body: GetBuilder<Set_Security_QuestionController>(
        builder: (set_security_questionController) {
          if(set_security_questionController.GetUserSecurity_QuestionLoading.value)
            return Center(child: CircularProgressIndicator());
          else
          return ListView.builder(
              itemCount: set_security_questionController.GetUserSecurity_QuestionData.length,
              scrollDirection: Axis.vertical,
              shrinkWrap: true,
              physics: AlwaysScrollableScrollPhysics(),
              itemBuilder: (BuildContext context, index) {
                var listdata = set_security_questionController.GetUserSecurity_QuestionData[index];
                log("xxx"+listdata["question_id"].toString());
                return Card(
                  child: Container(
                    margin: EdgeInsets.symmetric(vertical: 30,horizontal: 10),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceAround,
                      children: [
                        Container(
                          width: size.width*0.80,
                          child: Text( "${index + 1}.)\t${listdata["question"].toString()}",
                            style: TextStyle(
                                fontSize: 15,
                                overflow: TextOverflow.clip,
                                wordSpacing: 0.5
                            ),),
                        ),
                        GestureDetector(
                          onTap: ()async{
                            showDialog(
                              context: context,
                              builder: (context) => new AlertDialog(
                                title:  Text('update_ans'.tr),
                                content:   Container(
                                  height: 130,
                                  child: Column(
                                    children: [
                                      TextFormField(
                                        controller: oldAnswers,
                                        validator: (value) {
                                          if (value!.isEmpty) {
                                            return "answer".tr;
                                          }  else
                                            return null;
                                        },
                                        decoration: InputDecoration(
                                          hintText: "old_ans".tr,
                                          border: OutlineInputBorder(
                                              borderSide: BorderSide(width: .5)
                                          ),
                                        ),
                                        // maxLength: 100,
                                        autovalidateMode: AutovalidateMode
                                            .onUserInteraction,
                                        keyboardType: TextInputType.text,
                                        textAlign: TextAlign.start,
                                      ),
                                      SizedBox(height: 10,),
                                      TextFormField(
                                        controller: answers,
                                        validator: (value) {
                                          if (value!.isEmpty) {
                                            return "answer".tr;
                                          }  else
                                            return null;
                                        },
                                        decoration: InputDecoration(
                                          hintText: "new_ans".tr,
                                          border: OutlineInputBorder(
                                            borderSide: BorderSide(width: .5)
                                          ),
                                        ),
                                        // maxLength: 100,
                                        autovalidateMode: AutovalidateMode
                                            .onUserInteraction,
                                        keyboardType: TextInputType.text,
                                        textAlign: TextAlign.start,
                                      ),
                                    ],
                                  ),
                                ),
                                actions: <Widget>[
                                  new ElevatedButton(
                                    onPressed: () => Navigator.of(context).pop(false),
                                    child:  Text('no'.tr),
                                  ),
                                  ElevatedButton(
                                    onPressed: () async{
                                      var update_ans_id =   listdata["question_id"].toString();
                                      print("update_ans_id--->"+update_ans_id);
                                      setState(() {

                                        var parameter = {
                                          "question_id":update_ans_id.toString(),
                                          "old_answer":oldAnswers.text,
                                          "answer":answers.text
                                        };
                                        set_security_questionController.UpdateAnswerApiCalling(Update_answer_url ,parameter);

                                      });
                                      Navigator.of(context).pop(true);
                                    },
                                    child:  Text('submitBtn'.tr),
                                  ),
                                ],
                              ),);
                          },
                          child: Image.asset("assets/images/edit.png",
                            color: ContainerColor,
                            height: 25,
                            width: 25,),
                        ),
                      ],
                    ),
                  ),
                );

              });
        }
      ),
    );

  }
}
