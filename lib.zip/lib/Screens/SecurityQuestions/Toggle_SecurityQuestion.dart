import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:pinput/pinput.dart';
import 'package:urwealthpal/Constant/Api.dart';
import 'package:urwealthpal/Constant/Images.dart';
import 'package:urwealthpal/Constant/colors.dart';
import 'package:urwealthpal/Screens/MPIN/Controllers/Toggle_MPIN_Controller.dart';
import 'package:urwealthpal/Screens/SecurityQuestions/Controllers/save_question_Controller.dart';
import 'package:urwealthpal/Screens/SecurityQuestions/Controllers/setup_question_controller.dart';

import '../../Constant/Strings.dart';

class Toggle_SecurityQuestion extends StatefulWidget {
  const Toggle_SecurityQuestion({Key? key}) : super(key: key);

  @override
  State<Toggle_SecurityQuestion> createState() =>
      _Toggle_SecurityQuestionState();
}

class _Toggle_SecurityQuestionState extends State<Toggle_SecurityQuestion> {
  final focusNode = FocusNode();
  final _formKey = GlobalKey<FormState>();
  TextEditingController userInput = TextEditingController();

  Set_Security_QuestionController set_security_questionController =
      Get.put(Set_Security_QuestionController()); //GetAPI

  SaveQuestionController saveQuestionController =
      Get.put(SaveQuestionController());
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    set_security_questionController.questioncount.value = 1;
    set_security_questionController.answerList = [];
    set_security_questionController.GetSecurity_QuestionApi( GetUser_Question_url);
  }

  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;

    final defaultPinTheme = PinTheme(
      width: 56,
      height: 56,
      textStyle: TextStyle(
        fontSize: 22,
        color: Color.fromRGBO(30, 60, 87, 1),
      ),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: Colors.grey),
      ),
    );
    return Scaffold(
      resizeToAvoidBottomInset: false,
      appBar: AppBar(
        elevation: 0,
        titleSpacing: 0,
        backgroundColor: ContainerColor,
        title: Text("security".tr),
      ),
      body: GetBuilder<Set_Security_QuestionController>(
          builder: (set_security_questionController) {
        if (set_security_questionController
            .Set_Security_QuestionLoading.value) {
          return Center(child: CircularProgressIndicator());
        }
        return Column(
          children: [
            Stack(
              children: [
                Form(
                    key: _formKey,
                    child: SingleChildScrollView(
                      child: Column(
                        children: [
                          Container(
                              margin: EdgeInsets.only(top: 40),
                              alignment: Alignment.center,
                              width: size.width,
                              child: securityImage),
                          Container(
                            alignment: Alignment.center,
                            width: size.width,
                            child: Text(
                              "askQue".tr,
                              style: TextStyle(
                                  color: ContainerColor,
                                  fontWeight: FontWeight.bold,
                                  fontSize: 32),
                            ),
                          ),
                          Card(
                            clipBehavior: Clip.antiAlias,
                            margin: EdgeInsets.only(
                                top: 30, left: 20, right: 20, bottom: 50),
                            elevation: 2,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(20),
                            ),
                            child: Container(
                              decoration: BoxDecoration(
                                // color: whiteColor,
                                // border: Border.all(color: w),
                                borderRadius:
                                    BorderRadius.all(Radius.circular(20)),
                              ),
                              // height: size.height,
                              // height: 400,
                              margin: EdgeInsets.only(left: 15, right: 15),
                              padding: EdgeInsets.only(
                                bottom: 50,
                              ),
                              child: Column(
                                children: [
                                  SizedBox(
                                    height: 30,
                                  ),
                                  Text(
                                    "Your_AskQue".tr,
                                    style: TextStyle(
                                        fontSize: 18, color: greyColor),
                                  ),
                                  Container(
                                    height: 200,
                                    margin: EdgeInsets.only(
                                        top: 10, left: 2, right: 2),
                                    decoration: BoxDecoration(
                                      color: whiteColor,
                                      border: Border.all(color: whiteColor),
                                      borderRadius:
                                          BorderRadius.all(Radius.circular(30)),
                                    ),
                                    child: ListView.builder(
                                        itemCount: 1,
                                        itemBuilder: (context, index) {
                                          return Column(
                                            children: [
                                              Padding(
                                                padding: EdgeInsets.only(
                                                    top: 40,
                                                    left: 20,
                                                    right: 20),
                                                child: Text(
                                                  "Q.${set_security_questionController.questioncount} ${set_security_questionController.Set_Security_QuestionData[set_security_questionController.questioncount.value - 1]["question"].toString()}",
                                                  style: TextStyle(
                                                      fontSize: 20,
                                                      color: greyColor),
                                                ),
                                              ),
                                              Padding(
                                                padding: EdgeInsets.only(
                                                    top: 30,
                                                    left: 20,
                                                    right: 20),
                                                child: TextFormField(
                                                  controller: userInput,
                                                  validator: (value) {
                                                    if (value!.isEmpty) {
                                                      return "enter_ans".tr;
                                                    } else
                                                      return null;
                                                  },
                                                  decoration: InputDecoration(
                                                    hintText: "Ans...".tr,
                                                  ),
                                                  // maxLength: 100,
                                                  // autovalidateMode:
                                                  // AutovalidateMode.onUserInteraction,
                                                  keyboardType:
                                                      TextInputType.text,
                                                  textAlign: TextAlign.center,
                                                ),
                                              ),
                                            ],
                                          );
                                        }),
                                  ),
                                  SizedBox(
                                    height: 10,
                                  ),
                                  Padding(
                                    padding:
                                        EdgeInsets.only(left: 80, right: 80),
                                    child: GestureDetector(
                                      onTap: () async {
                                        if (_formKey.currentState!.validate()) {
                                          if (set_security_questionController
                                                  .questioncount !=
                                              set_security_questionController
                                                  .Set_Security_QuestionData
                                                  .length) {
                                            print(
                                                set_security_questionController
                                                    .questioncount);
                                            print(
                                                set_security_questionController
                                                    .Set_Security_QuestionData
                                                    .length);
                                            var questionid =
                                                set_security_questionController
                                                        .Set_Security_QuestionData[
                                                    set_security_questionController
                                                        .questioncount
                                                        .value]["question_id"];
                                            var questionanswer = userInput.text;
                                            set_security_questionController
                                                .updatecount(questionid,
                                                    questionanswer, false);
                                            userInput.clear();
                                            print("qusn--id > " +
                                                set_security_questionController
                                                    .Set_Security_QuestionData[
                                                        set_security_questionController
                                                                .questioncount
                                                                .value -
                                                            1]["question_id"]
                                                    .toString());
                                            print("qusn--question > " +
                                                set_security_questionController
                                                    .Set_Security_QuestionData[
                                                        set_security_questionController
                                                                .questioncount
                                                                .value -
                                                            1]["question"]
                                                    .toString());
                                          } else {
                                            var questionid =
                                                set_security_questionController
                                                        .Set_Security_QuestionData[set_security_questionController
                                                        .questioncount
                                                        .value-1]["question_id"];
                                            var questionanswer = userInput.text;
                                            set_security_questionController
                                                .updatecount(questionid,
                                                    questionanswer, true);
                                          }
                                        }
                                      },
                                      child: Container(
                                        height: 40,
                                        width: 150,
                                        decoration: BoxDecoration(
                                            color: buttonColor,
                                            border: Border.all(
                                              color: buttonColor,
                                            ),
                                            borderRadius: BorderRadius.all(
                                                Radius.circular(12))),
                                        child: Center(
                                          child: Text(
                                            set_security_questionController
                                                        .questioncount !=
                                                    set_security_questionController
                                                        .Set_Security_QuestionData
                                                        .length
                                                ? "submitBtn".tr
                                                : "finishBtn".tr,
                                            style: TextStyle(
                                                color: whiteColor,
                                                fontSize: 16,
                                                fontWeight: FontWeight.bold),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ],
                      ),
                    ))
              ],
            ),
          ],
        );
      }),
    );
  }
}
