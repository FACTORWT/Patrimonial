import 'dart:convert';
import 'package:get/get.dart';
import 'package:urwealthpal/Constant/Api.dart';
import 'package:urwealthpal/Constant/ApiBaseHelper.dart';

class SaveQuestionController extends GetxController {
  var SaveQuestionLoading = false.obs;
  var SaveQuestionData;

  SaveQuestionApiCalling(url, parameter) async {
    SaveQuestionLoading.value = true;
    print("SaveQuestion url" + url.toString());
    var response = await ApiBaseHelper().postAPICall(
        Uri.parse(url), parameter, true);
    var responsedata = jsonDecode(response.body);
    print("SaveQuestion responsedata : " + responsedata.toString());
    if (response.statusCode == 200) {
      print("SaveQuestion 2 : " + responsedata.toString());
      SaveQuestionData = responsedata['data'];
      print("SaveQuestion Data...." + responsedata.toString());
      SaveQuestionLoading.value = false;
      update();
    }
    else if (response.statusCode == 422) {
      SaveQuestionData = responsedata['message'];
      var msg = SaveQuestionData.toString();
      toastMsg(msg, false);
      SaveQuestionLoading.value = false;
      update();
    } else
      SaveQuestionData = [];
    SaveQuestionLoading.value = false;
    update();
  }
}