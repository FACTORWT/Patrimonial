import 'dart:convert';
import 'dart:developer';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:urwealthpal/Constant/Api.dart';
import 'package:urwealthpal/Constant/ApiBaseHelper.dart';
import 'package:urwealthpal/Environment/Environment.dart';
import 'package:urwealthpal/main.dart';
import 'package:http/http.dart' as http;
class Set_Security_QuestionController extends GetxController {
  var Set_Security_QuestionLoading = false.obs;
  var Get_Security_QuestionLoading = false.obs;
  var Get_QuestionLoading = false.obs;
  var Set_Security_QuestionData;
  var Get_Security_QuestionData ;
  RxInt questioncount = 1.obs;
  List answerList = [];
  List getquestionList = [];

  Set_Security_QuestionApiCalling(url) async {
    Set_Security_QuestionLoading.value = true;
    log("Set_Security_Question : " + url.toString());
    var response = await ApiBaseHelper().getAPICall(Uri.parse(url), true);
    var responsedata = jsonDecode(response.body);
    log("Set_Security_Question statusCode...." + response.statusCode.toString());
    if (response.statusCode == 200) {
      Set_Security_QuestionLoading.value = false;
      Set_Security_QuestionData = responsedata['data'];
      log("Set_Security_Question Data...." + responsedata.toString());
      Set_Security_QuestionLoading.value = false;
      update();
    }
    else if (response.statusCode == 422) {
      var msg = responsedata['message'].toString();
      toastMsg(msg, false);
      Set_Security_QuestionLoading.value = false;
      update();
    }
    else {
      Set_Security_QuestionData = [];
      Set_Security_QuestionLoading.value = false;
      update();
    }
  }

  Get_QuestionApiCalling(url) async {
    Get_QuestionLoading.value = true;
    print("Get_QuestionApiCalling : " + url.toString());
    var response = await ApiBaseHelper().getAPICall(Uri.parse(url), true);
    var responsedata = jsonDecode(response.body);

    if (response.statusCode == 200) {
      Get_QuestionLoading.value= false;
      getquestionList = responsedata['data'];
      log("Get_QuestionApiCalling Data...." + getquestionList.toString());

      update();
    }
    else if (response.statusCode == 422) {

      var msg = responsedata['message'].toString();
      toastMsg(msg, false);
      Get_QuestionLoading.value = false;
      update();
    }
    else {
      getquestionList = [];
      Get_QuestionLoading.value = false;
      update();
    }
  }

  GetSecurity_QuestionApi(url) async {
    Set_Security_QuestionLoading.value = true;
    log("GetSecurity_QuestionApi : " + url.toString());
    var response = await ApiBaseHelper().getAPICall(Uri.parse(url), true);
    var responsedata = jsonDecode(response.body);
    log("GetSecurity_QuestionApi Data...." + response.statusCode.toString());
    if (response.statusCode == 200) {
      Set_Security_QuestionData = responsedata['data'];
      log("GetSecurity_QuestionApi Data...." + responsedata.toString());
      ToggleSecurity_QuestionApi(Toggle_Security_Question_url);
      Set_Security_QuestionLoading.value = false;
      update();
    }
    else if(response.statusCode == 422){
      Set_Security_QuestionApiCalling(Setup_Question_url);

      var msg = responsedata['message'].toString();
      toastMsg(msg, false);
      update();

    } else {
      Set_Security_QuestionData = [];
      Get_Security_QuestionLoading.value = false;
      update();
    }
  }

  var GetUserSecurity_QuestionLoading = false.obs;
  List GetUserSecurity_QuestionData = [];


  GetUserSecurity_QuestionApi(url) async {
    GetUserSecurity_QuestionLoading.value = true;
    print("GetUserSecurity_QuestionApi : " + url.toString());
    var response = await ApiBaseHelper().getAPICall(Uri.parse(url), true);
    var responsedata = jsonDecode(response.body);
    log("GetUserSecurity_QuestionApi Data...." + response.statusCode.toString());
    if (response.statusCode == 200) {
      GetUserSecurity_QuestionData.clear();
      GetUserSecurity_QuestionData.addAll(responsedata['data']);
      log("GetUserSecurity_QuestionApi DataResponse...." + GetUserSecurity_QuestionData.toString());
      // ToggleSecurity_QuestionApi(Toggle_Security_Question_url);
      GetUserSecurity_QuestionLoading.value = false;
      update();
    }
    else if(response.statusCode == 422){
      GetUserSecurity_QuestionData = [];
      toastMsg(responsedata['message'], false);
      GetUserSecurity_QuestionLoading.value = false;
      update();
      // Set_Security_QuestionApiCalling(Setup_Question_url);
    }
    else {
      GetUserSecurity_QuestionData = [];
      GetUserSecurity_QuestionLoading.value = false;
      update();
    }
  }

  var UpdateAnswerLoading = false.obs;
  var UpdateAnswerData;

  UpdateAnswerApiCalling(url, parameter) async {
    UpdateAnswerLoading.value =true;
    print("UpdateAnswer " + url.toString());
    var response = await ApiBaseHelper().postAPICall(Uri.parse(url), parameter, true);
    var responsedata = jsonDecode(response.body);
    print("UpdateAnswer responsedata : " + responsedata.toString());
    if(response.statusCode==200){
      UpdateAnswerData = responsedata['data'];
      GetUserSecurity_QuestionApi(GetUser_Question_url);
      UpdateAnswerLoading.value =false;
      update();
    }
    else if(response.statusCode == 422){
      var msg = responsedata['message'];
      toastMsg(msg, false);
      UpdateAnswerLoading.value = false;
      update();
    }
    else{
      var msg = responsedata['message'];
      toastMsg(msg, false);
      UpdateAnswerData =[];
      UpdateAnswerLoading.value =false;
      update();
    }

  }


  ToggleSecurity_QuestionApi(url) async {
    print("ToggleSecurity_QuestionApi : " + url.toString());
    var response = await ApiBaseHelper().getAPICall(Uri.parse(url), true);
    Get_Security_QuestionLoading.value = false;
    if(Environment.askQuestion=="1"){
      sp!.setString("askQuestion","0");
      Get.back();
    }else{
      sp!.setString("askQuestion","1");
    }

    update();
  }
  updatecount(questionid, questionanswer, bool status) async {
    print("questioncount before " + questioncount.value.toString());
    var answerdata ={
      "question_id": questionid,
      "answer": questionanswer
    };
    answerList.add(answerdata) ;
    if (status == false) {
      questioncount.value = questioncount.value + 1;
    } else {
      var datass ={
        "answers":[]
      };
      // var data =answerList.join(', ');
      datass['answers'] = answerList;
      print("datassdatass "+datass.toString());
      var jsondata = json.decode(sp!.getString("loginresponse").toString());

      var  token =jsondata['data']['access_token'];
      var _mainHeaders = {
        // 'Content-Type': 'application/json',
        'Content-Type': 'application/json',
        Environment.appxapikey.toString(): Environment.appxapivalue.toString(),
        'Authorization': 'Bearer $token'
      };
      var request = http.Request('POST', Uri.parse(Save_Question_url));
      request.body = json.encode(datass);
      request.headers.addAll(_mainHeaders);
      log("post _mainHeaders : ${_mainHeaders.toString()}");
      log("post datass : ${json.encode(datass).toString()}");
      http.StreamedResponse responses = await request.send();
      var response = await http.Response.fromStream(responses);
      log("post response : ${response.body.toString()}");
      // var response = await ApiBaseHelper().postAPICall(Uri.parse(Save_Question_url),json.encode(datass).toString(), true);
      Get.back();
      answerList.clear();
    }
    print("questioncount " + questioncount.value.toString());
    print("answerList " + jsonEncode(answerList).toString());
    update();
  }
}
