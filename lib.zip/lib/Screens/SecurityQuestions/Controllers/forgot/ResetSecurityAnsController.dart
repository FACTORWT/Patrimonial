import 'dart:convert';
import 'dart:developer';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:urwealthpal/Constant/Api.dart';
import 'package:urwealthpal/Constant/ApiBaseHelper.dart';
import 'package:urwealthpal/Environment/Environment.dart';
import 'package:urwealthpal/Screens/SecurityQuestions/Security_Question.dart';
import 'package:urwealthpal/Screens/SecurityQuestions/forgotSecurityAnswer.dart';
import 'package:urwealthpal/main.dart';
import 'package:http/http.dart' as http;
class ResetForgotAnswerController extends GetxController {
  var ForgotSecAnsLoading = false.obs;
  var ForgotSecAnsData;

  TextEditingController OTP = TextEditingController();

  ForgotSecAnsAPICalling(url) async {
    ForgotSecAnsLoading.value =true;
    print("ForgotSecAns url : " + url.toString());
    var response = await ApiBaseHelper().getAPICall(Uri.parse(url), true);
    ForgotSecAnsData = jsonDecode(response.body);
    if(response.statusCode==200){
      ForgotSecAnsData = jsonDecode(response.body);
      var token = ForgotSecAnsData['data']['token'].toString();
      toastMsg(token, true);
      ForgotSecAnsLoading.value =false;
      Get.to(ForgotSecurityAnswers());
      OTP.clear();
      update();
    }
    else if(response.statusCode==422) {
      ForgotSecAnsData = ForgotSecAnsData['message'];
      var msg = ForgotSecAnsData.toString();
      toastMsg(msg, false);
      ForgotSecAnsLoading.value = false;
      update();
    }
    else
      ForgotSecAnsData =[];
    ForgotSecAnsLoading.value =false;
    update();
  }

  var ResetSecAnsLoading = false.obs;
  var ResetSecAnsData ;



  // Get Question List Api Calling ---->>>>
  var GetUserSecurity_QuestionLoading = false.obs;
  List GetUserSecurity_QuestionData = [];

  List<TextEditingController> answers = [];
  void initializeTextControllers() {
    answers.clear(); // Clear the list to ensure it's empty before initializing
    for (int i = 0; i < GetUserSecurity_QuestionData.length; i++) {
      answers.add(TextEditingController());
    }
  }

  GetUserSecurity_QuestionApi(url) async {
    GetUserSecurity_QuestionLoading.value = true;
    print("GetUserSecurity_QuestionApi : " + url.toString());
    var response = await ApiBaseHelper().getAPICall(Uri.parse(url), true);
    var responsedata = jsonDecode(response.body);
    log("GetUserSecurity_QuestionApi Data...." + response.statusCode.toString());
    if (response.statusCode == 200) {
      GetUserSecurity_QuestionData.clear();
      GetUserSecurity_QuestionData.addAll(responsedata['data']);
      log("GetUserSecurity_QuestionApi DataResponse...." + GetUserSecurity_QuestionData.toString());
      initializeTextControllers();
      GetUserSecurity_QuestionLoading.value = false;
      update();
    }
    else if(response.statusCode == 422){
      GetUserSecurity_QuestionData = [];
      toastMsg(responsedata['message'], false);
      GetUserSecurity_QuestionLoading.value = false;
      update();
    }
    else {
      GetUserSecurity_QuestionData = [];
      GetUserSecurity_QuestionLoading.value = false;
      update();
    }
  }


  ResetSecAnsCalling(url, parameter) async {
    ResetSecAnsLoading.value =true;
    print("reset SecAns... " + url.toString());
    var response = await ApiBaseHelper().postAPICall(Uri.parse(url), parameter, true);
    var responsedata = jsonDecode(response.body);
    if(response.statusCode==200){
      ResetSecAnsData = responsedata['data'];
      Get.off(Security_Question());
      ResetSecAnsData = responsedata['message'];
      var msg = ResetSecAnsData.toString();
      toastMsg(msg, true);
      ResetSecAnsLoading.value =false;
      update();
    }
    else if (response.statusCode==422){
      ResetSecAnsData = responsedata['message'];
      var msg = ResetSecAnsData.toString();
      toastMsg(msg, false);
      ResetSecAnsLoading.value = false;
      update();
    }
    else
      ResetSecAnsData =[];
    ResetSecAnsLoading.value =false;
    update();
  }

}