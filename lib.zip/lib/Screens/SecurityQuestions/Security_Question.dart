import 'dart:async';
import 'dart:convert';
import 'dart:developer';

import 'package:flutter/material.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';
import 'package:urwealthpal/BottomBar/bottombar.dart';
import 'package:urwealthpal/Constant/Api.dart';
import 'package:urwealthpal/Constant/Images.dart';
import 'package:urwealthpal/Constant/Strings.dart';
import 'package:urwealthpal/Constant/colors.dart';
import 'package:urwealthpal/Environment/Environment.dart';
import 'package:urwealthpal/Screens/MPIN/MPIN.dart';
import 'package:urwealthpal/Screens/SecurityQuestions/Controllers/forgot/ResetSecurityAnsController.dart';
import 'package:urwealthpal/Screens/SecurityQuestions/Controllers/save_question_Controller.dart';
import 'package:urwealthpal/Screens/SecurityQuestions/Controllers/setup_question_controller.dart';
import 'package:urwealthpal/Screens/SecurityQuestions/forgotSecurityAnswer.dart';
import 'package:urwealthpal/main.dart';
import 'package:http/http.dart' as http;

import '../../Constant/ApiBaseHelper.dart';

class Security_Question extends StatefulWidget {
  const Security_Question({Key? key}) : super(key: key);

  @override
  State<Security_Question> createState() => _Security_QuestionState();
}

class _Security_QuestionState extends State<Security_Question> {
  var _formKey = GlobalKey<FormState>();
  TextEditingController userInput = TextEditingController();

  Set_Security_QuestionController set_security_questionController =
  Get.put(Set_Security_QuestionController()); //GetAPI

  SaveQuestionController saveQuestionController =
  Get.put(SaveQuestionController());

  var forgotAnswerController =Get.put(ResetForgotAnswerController());

  List questionData = [];

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    set_security_questionController.Get_QuestionApiCalling(Get_Question_url);
  }

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Scaffold(
      resizeToAvoidBottomInset: false,
      body: GetBuilder<Set_Security_QuestionController>(
          builder: (set_security_questionController) {
            if (set_security_questionController
                .Get_QuestionLoading.value) {
              return Center(child: CircularProgressIndicator());
            } else
              return Container(
                height: size.height,
                width: size.width,
                decoration: BoxDecoration(
                  image: DecorationImage(
                      image: AssetImage("assets/images/full_background.png"),
                      fit: BoxFit.cover),
                ),
                child: Column(
                  children: [
                    Stack(
                      children: [
                        Form(
                          key: _formKey,
                          child: SingleChildScrollView(
                            child: Column(
                              children: [
                                Container(
                                    margin: EdgeInsets.only(top: 110),
                                    alignment: Alignment.center,
                                    width: size.width,
                                    child: securityImage),
                                Container(
                                  alignment: Alignment.center,
                                  width: size.width,
                                  child: Text(
                                    "sec".tr,
                                    style: TextStyle(
                                        color: whiteColor,
                                        fontWeight: FontWeight.bold,
                                        fontSize: 32),
                                  ),
                                ),
                                Container(
                                  height: 350,
                                  margin:
                                  EdgeInsets.only(top: 30, left: 20, right: 20),
                                  decoration: BoxDecoration(
                                    color: whiteColor,
                                    border: Border.all(color: whiteColor),
                                    borderRadius:
                                    BorderRadius.all(Radius.circular(30)),
                                  ),
                                  child: ListView.builder(
                                      itemCount: 1,
                                      itemBuilder: (context, index) {
                                        return Column(
                                          children: [
                                            Padding(
                                              padding: EdgeInsets.only(
                                                  top: 40, left: 20, right: 20),
                                              child: Text(
                                                "Q.1 ${set_security_questionController.getquestionList[index]["question"].toString()}",
                                                style: TextStyle(
                                                    fontSize: 20, color: greyColor),
                                              ),
                                            ),
                                            Padding(
                                              padding: EdgeInsets.only(
                                                  top: 30, left: 20, right: 20),
                                              child: TextFormField(
                                                controller: userInput,
                                                validator: (value) {
                                                  if (value!.isEmpty) {
                                                    return "answer".tr;
                                                  }  else
                                                    return null;
                                                },
                                                decoration: InputDecoration(
                                                  hintText: "hintans".tr,
                                                ),
                                                // maxLength: 100,
                                                autovalidateMode: AutovalidateMode
                                                    .onUserInteraction,
                                                keyboardType: TextInputType.text,
                                                textAlign: TextAlign.center,
                                              ),
                                            ),
                                            SizedBox(
                                              height: 20,
                                            ),
                                            Align(
                                              alignment: Alignment.centerLeft,
                                              child: Padding(
                                                padding: EdgeInsets.only(top: 10, left: 10),
                                                child: GestureDetector(
                                                  onTap: () async {
                                                    await forgotAnswerController.ForgotSecAnsAPICalling(ForgotSecAns_url);
                                                    // Get.to(ForgotSecurityAnswers());
                                                  },
                                                  child: Text("forgotSecurityAns".tr,
                                                      style: TextStyle(
                                                        color: appPrimaryColor,
                                                        fontSize: 16,
                                                      )),
                                                ),
                                              ),
                                            ),
                                            Padding(
                                                padding: EdgeInsets.only(
                                                    top: 40, left: 80, right: 80),
                                                child: GestureDetector(
                                                    onTap: () async {
                                                      if (_formKey.currentState!
                                                          .validate()) {
                                                        var jsondata = json.decode(
                                                            sp!
                                                                .getString(
                                                                "loginresponse")
                                                                .toString());

                                                        var token = jsondata['data']
                                                        ['access_token'];
                                                        var _mainHeaders = {
                                                          // 'Content-Type': 'application/json',
                                                          'Content-Type':
                                                          'application/json',
                                                          Environment.appxapikey
                                                              .toString():
                                                          Environment
                                                              .appxapivalue
                                                              .toString(),
                                                          'Authorization':
                                                          'Bearer $token'
                                                        };
                                                        var datass = {
                                                          "question_id":
                                                          set_security_questionController
                                                              .getquestionList[
                                                          index]["question_id"],
                                                          "answer": userInput.text,
                                                        };
                                                        var request = http.Request(
                                                            'POST',
                                                            Uri.parse(
                                                                Verify_AnswerQuestion_url));
                                                        request.body =
                                                            json.encode(datass);
                                                        request.headers
                                                            .addAll(_mainHeaders);
                                                        log("post _mainHeaders : ${_mainHeaders.toString()}");
                                                        log("post datass : ${json.encode(datass).toString()}");
                                                        http.StreamedResponse
                                                        responses =
                                                        await request.send();
                                                        var response = await http
                                                            .Response
                                                            .fromStream(responses);
                                                        log("post response : ${response.body.toString()}");
                                                        log("post statusCode : ${response.statusCode.toString()}");
                                                        var datss = jsonDecode(
                                                            response.body);
                                                        Fluttertoast.showToast(
                                                            msg: datss['message']
                                                                .toString());
                                                        if (response.statusCode ==
                                                            200) {
                                                          if (Environment.askMPIN
                                                              .toString() ==
                                                              "1") {
                                                            print(
                                                                "check mpin condition=> askmpin");
                                                            // Get.to(MPIN());
                                                            ApiBaseHelper().authenticate();
                                                          }else{
                                                            Timer(
                                                                Duration(seconds: 3),
                                                                    () =>Get.offAll(bottombar(bottom: 2)));
                                                          }
                                                        }
                                                        // if (Environment.askMPIN.toString()== "1"){
                                                        //   print("check mpin condition=> askmpin");
                                                        //   Get.to(MPIN());
                                                        // }
                                                      }
                                                      // index =index+1;
                                                      // print("qusn--id"+ set_security_questionController.getquestionList[index]["question_id"].toString());
                                                      // setState(() {
                                                      //
                                                      // });
                                                      // if(set_security_questionController.Set_Security_QuestionData.length -1 == i)
                                                      // {
                                                      //   print(" question");
                                                      //   Navigator.pushReplacement(context,
                                                      //       MaterialPageRoute(builder: (context)=>bottombar(bottom: 2,)));
                                                      // }
                                                      // else if (set_security_questionController.Set_Security_QuestionData.length - 2 == i) {
                                                      //   print("last question");
                                                      //   setState(() {
                                                      //     finish = false;
                                                      //     set_security_questionController.Set_Security_QuestionData[i]["id"].toString();
                                                      //     set_security_questionController.Set_Security_QuestionData[i++]["question"].toString();
                                                      //     print("qusn--id"+ set_security_questionController.Set_Security_QuestionData[i]["id"].toString());
                                                      //   });
                                                      // }
                                                      // else {
                                                      //   questionData[index]['question_id'] = set_security_questionController.Set_Security_QuestionData[i]["id"];
                                                      //   questionData[index]['answer'] = userInput.text.toString();
                                                      //   index++;
                                                      //   print("questionData/.....${questionData.toString()}");
                                                      //   // questionData.addAll("question_id",set_security_questionController.Set_Security_QuestionData[i]["id"]);
                                                      //   setState(() {
                                                      //     set_security_questionController.Set_Security_QuestionData[i]["id"].toString();
                                                      //     set_security_questionController.Set_Security_QuestionData[i++]["question"].toString();
                                                      //     print("qusn--idd"+ set_security_questionController.Set_Security_QuestionData[i]["id"].toString());
                                                      //   });
                                                      // }
                                                      //
                                                      // if (_formKey.currentState!.validate()) {
                                                      //   var save_ques_url = Save_Question_url;
                                                      //   var body ={
                                                      //     "answer":questionData
                                                      //   };
                                                      //   print("save_ques body" + body.toString());
                                                      //   print("save_ques_url..." + save_ques_url.toString());
                                                      //   saveQuestionController.SaveQuestionApiCalling(
                                                      //       save_ques_url, body);
                                                      // }
                                                    },
                                                    child: Container(
                                                        height: 40,
                                                        width: 150,
                                                        decoration: BoxDecoration(
                                                            color: buttonColor,
                                                            border: Border.all(
                                                              color: buttonColor,
                                                            ),
                                                            borderRadius:
                                                            BorderRadius.all(
                                                                Radius.circular(
                                                                    12))),
                                                        child: Center(
                                                            child: Text(
                                                              "submitBtn".tr,
                                                              style: TextStyle(
                                                                  color: whiteColor,
                                                                  fontSize: 16,
                                                                  fontWeight:
                                                                  FontWeight.bold),
                                                            )))))
                                          ],
                                        );
                                      }),
                                )
                                // Container(
                                //   height: 350,
                                //   margin:
                                //       EdgeInsets.only(top: 30, left: 20, right: 20),
                                //   decoration: BoxDecoration(
                                //     color: whiteColor,
                                //     border: Border.all(color: whiteColor),
                                //     borderRadius:
                                //         BorderRadius.all(Radius.circular(30)),
                                //   ),
                                //   child: Column(
                                //     children: [
                                //       Padding(
                                //         padding: EdgeInsets.only(
                                //             top: 40, left: 20, right: 20),
                                //         child: Text("Q.${i+1} ${set_security_questionController
                                //             .Set_Security_QuestionData[i]
                                //         ["question"].toString()}",
                                //           style: TextStyle(
                                //               fontSize: 20, color: greyColor),
                                //         ),
                                //       ),
                                //       Padding(
                                //         padding: EdgeInsets.only(
                                //             top: 30, left: 20, right: 20),
                                //         child: TextFormField(
                                //           controller: userInput,
                                //           validator: (value) {
                                //             if (value == null) {
                                //               return answer;
                                //             } else if (value.length <= 3) {
                                //               return validAnswer;
                                //             } else
                                //               return null;
                                //           },
                                //           decoration: InputDecoration(
                                //             hintText: hintAns,
                                //           ),
                                //           // maxLength: 100,
                                //           autovalidateMode:
                                //               AutovalidateMode.onUserInteraction,
                                //           keyboardType: TextInputType.text,
                                //           textAlign: TextAlign.center,
                                //         ),
                                //       ),
                                //       Padding(
                                //           padding: EdgeInsets.only(
                                //               top: 80, left: 80, right: 80),
                                //           child: GestureDetector(
                                //               onTap: () {
                                //                 print("qusn--id"+ set_security_questionController.Set_Security_QuestionData[i]["id"].toString());
                                //                 if(set_security_questionController.Set_Security_QuestionData.length -1 == i)
                                //                 {
                                //                   print(" question");
                                //                   Navigator.pushReplacement(context,
                                //                       MaterialPageRoute(builder: (context)=>bottombar(bottom: 2,)));
                                //                 }
                                //                else if (set_security_questionController.Set_Security_QuestionData.length - 2 == i) {
                                //                   print("last question");
                                //                   setState(() {
                                //                     finish = false;
                                //                     set_security_questionController.Set_Security_QuestionData[i]["id"].toString();
                                //                     set_security_questionController.Set_Security_QuestionData[i++]["question"].toString();
                                //                     print("qusn--id"+ set_security_questionController.Set_Security_QuestionData[i]["id"].toString());
                                //                   });
                                //                 }
                                //                 else {
                                //                   questionData[index]['question_id'] = set_security_questionController.Set_Security_QuestionData[i]["id"];
                                //                   questionData[index]['answer'] = userInput.text.toString();
                                //                   index++;
                                //                   print("questionData/.....${questionData.toString()}");
                                //                   // questionData.addAll("question_id",set_security_questionController.Set_Security_QuestionData[i]["id"]);
                                //                   setState(() {
                                //                     set_security_questionController.Set_Security_QuestionData[i]["id"].toString();
                                //                     set_security_questionController.Set_Security_QuestionData[i++]["question"].toString();
                                //                     print("qusn--idd"+ set_security_questionController.Set_Security_QuestionData[i]["id"].toString());
                                //                   });
                                //                 }
                                //
                                //                   if (_formKey.currentState!.validate()) {
                                //                     var save_ques_url = Save_Question_url;
                                //                     var body ={
                                //                       "answer":questionData
                                //                     };
                                //                     print("save_ques body" + body.toString());
                                //                     print("save_ques_url..." + save_ques_url.toString());
                                //                     saveQuestionController.SaveQuestionApiCalling(
                                //                         save_ques_url, body);
                                //                   }
                                //               },
                                //               child: Container(
                                //                   height: 40,
                                //                   width: 150,
                                //                   decoration: BoxDecoration(
                                //                       color: buttonColor,
                                //                       border: Border.all(
                                //                         color: buttonColor,
                                //                       ),
                                //                       borderRadius:
                                //                           BorderRadius.all(
                                //                               Radius.circular(12))),
                                //                   child: Center(
                                //                       child: Text(
                                //                     finish == true ? submitBtn: finishBtn,
                                //                     style: TextStyle(
                                //                         color: whiteColor,
                                //                         fontSize: 16,
                                //                         fontWeight:
                                //                             FontWeight.bold),
                                //                   )
                                //                   )
                                //               )
                                //           )
                                //       )
                                //     ],
                                //   ),
                                // ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              );
          }),
    );
  }
}
