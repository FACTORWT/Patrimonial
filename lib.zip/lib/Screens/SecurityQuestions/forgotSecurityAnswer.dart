import 'dart:developer';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:urwealthpal/Constant/Api.dart';
import 'package:urwealthpal/Constant/Images.dart';
import 'package:urwealthpal/Constant/Spacing.dart';
import 'package:urwealthpal/Constant/colors.dart';
import 'package:urwealthpal/Screens/SecurityQuestions/Controllers/forgot/ResetSecurityAnsController.dart';

class ForgotSecurityAnswers extends StatefulWidget {
  const ForgotSecurityAnswers({Key? key}) : super(key: key);

  @override
  State<ForgotSecurityAnswers> createState() => _ForgotSecurityAnswersState();
}

class _ForgotSecurityAnswersState extends State<ForgotSecurityAnswers> {

  var _formKey = GlobalKey<FormState>();
  
  ResetForgotAnswerController resetForgotAnswerController = Get.put(ResetForgotAnswerController());

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    resetForgotAnswerController.GetUserSecurity_QuestionApi(GetUser_Question_url);
  }

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Scaffold(
      resizeToAvoidBottomInset: false,
      body:Container(
                height: size.height,
                width: size.width,
                decoration: BoxDecoration(
                  image: DecorationImage(
                      image: AssetImage("assets/images/full_background.png"),
                      fit: BoxFit.cover),
                ),
                child: Stack(
                  children: [
                    Form(
                      key: _formKey,
                      child: SingleChildScrollView(
                        physics: AlwaysScrollableScrollPhysics(),
                        child: Column(
                          children: [
                            Container(
                                margin: EdgeInsets.only(top: 110),
                                alignment: Alignment.center,
                                width: size.width,
                                child: securityImage),
                            Container(
                              alignment: Alignment.center,
                              width: size.width,
                              child: Text(
                                "sec".tr,
                                style: TextStyle(
                                    color: whiteColor,
                                    fontWeight: FontWeight.bold,
                                    fontSize: 32),
                              ),
                            ),
                            Container(
                              // height: 420,
                              decoration: BoxDecoration(
                                color: whiteColor,
                                border: Border.all(color: whiteColor),
                                borderRadius: BorderRadius.all(Radius.circular(30)),
                              ),
                              // height: size.height,
                              margin: EdgeInsets.only(top: 30,left: 20,right: 20),
                              child: Column(
                                children: [
                                  SizedBox(
                                    height: 40,
                                  ),
                                  Padding(
                                    padding: EdgeInsets.only(left: 20, right: 20),
                                    child: TextFormField(
                                      controller: resetForgotAnswerController.OTP,
                                      inputFormatters: [
                                        FilteringTextInputFormatter.allow(
                                            RegExp('[0-9]'))
                                      ],
                                      keyboardType:
                                      TextInputType.numberWithOptions(
                                          decimal: true),
                                      autovalidateMode:
                                      AutovalidateMode.onUserInteraction,
                                      validator: (value) {
                                        if (value == null) {
                                          return "otptxt".tr;
                                        } else if (value.length != 4) {
                                          return "validotptxt".tr;
                                        } else
                                          return null;
                                      },
                                      maxLength: 4,
                                      textInputAction: TextInputAction.next,
                                      decoration: InputDecoration(
                                        filled: true,
                                        fillColor: whiteColor,
                                        contentPadding: EdgeInsets.only(top: 5),
                                        constraints: BoxConstraints(
                                            minWidth: 30, maxHeight: 70),
                                        border: OutlineInputBorder(
                                          borderRadius: BorderRadius.circular(10),
                                        ),
                                        enabledBorder: OutlineInputBorder(
                                            borderRadius:
                                            BorderRadius.circular(10),
                                            borderSide: BorderSide(
                                                width: 1, color: Namecolors)),
                                        focusedBorder: OutlineInputBorder(
                                            borderRadius:
                                            BorderRadius.circular(10),
                                            borderSide: BorderSide(
                                                width: 1,
                                                color: appPrimaryColor)),
                                        focusedErrorBorder: OutlineInputBorder(
                                            borderRadius:
                                            BorderRadius.circular(10),
                                            borderSide: BorderSide(
                                                width: 1,
                                                color: Colors.redAccent)),
                                        prefixIcon: PasswordIcon,
                                        hintText: "hintOTP".tr,
                                        counterText: "",
                                      ),
                                    ),
                                  ),

                                  GetBuilder<ResetForgotAnswerController>(
                                      builder: (resetForgotAnswerController) {
                                        if(resetForgotAnswerController.GetUserSecurity_QuestionLoading.value)
                                          return Center(child: CircularProgressIndicator());
                                        else
                                          return ListView.builder(
                                              itemCount: resetForgotAnswerController.GetUserSecurity_QuestionData.length,
                                              scrollDirection: Axis.vertical,
                                              shrinkWrap: true,
                                              physics: NeverScrollableScrollPhysics(),
                                              itemBuilder: (BuildContext context, index) {
                                                var listdata = resetForgotAnswerController.GetUserSecurity_QuestionData[index];
                                                return Container(
                                                  margin: EdgeInsets.symmetric(vertical: 15,horizontal: 10),
                                                  child: Column(
                                                    children: [
                                                      Container(
                                                        width: size.width*0.80,
                                                        child: Text( "${index + 1}.)\t${listdata["question"].toString()}",
                                                          style: TextStyle(
                                                              fontSize: 15,
                                                              overflow: TextOverflow.clip,
                                                              wordSpacing: 0.5
                                                          ),),
                                                      ),
                                                      Padding(
                                                        padding: EdgeInsets.symmetric(horizontal: 10),
                                                        child: TextFormField(
                                                          controller: resetForgotAnswerController.answers[index],
                                                          // onChanged: _handleTextChanged,
                                                          validator: (value) {
                                                            if (value!.isEmpty) {
                                                              return "answer".tr;
                                                            }  else
                                                              return null;
                                                          },
                                                          decoration: InputDecoration(
                                                            hintText: "Ans...".tr,
                                                          ),
                                                          // maxLength: 100,
                                                          autovalidateMode: AutovalidateMode
                                                              .onUserInteraction,
                                                          keyboardType: TextInputType.text,
                                                          textAlign: TextAlign.center,
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                );

                                              });
                                      }
                                  ),
                                  sizebox_height_20,
                                  Padding(
                                    padding: EdgeInsets.only(left: 80, right: 80),
                                    child: GestureDetector(
                                      onTap: () {
                                        if (_formKey.currentState!.validate()) {
                                          var body = {
                                            'otp' : resetForgotAnswerController.OTP.text,
                                          };
                                          for (var i = 0; i < resetForgotAnswerController.answers.length; i++) {
                                            String keyName = "answers[${resetForgotAnswerController.GetUserSecurity_QuestionData[i]['question_id'].toString()}]";
                                            body[keyName] = resetForgotAnswerController.answers[i].text.toString();
                                          }
                                          var resetSecAns_url = ResetSecAns_url;

                                          log("check body ----->>>"+body.toString());
                                          log("check resetSecAns_url ----->>>"+resetSecAns_url.toString());
                                          resetForgotAnswerController.ResetSecAnsCalling(resetSecAns_url, body);
                                        }
                                      },
                                      child: Container(
                                        height: 40,
                                        width: 150,
                                        decoration: BoxDecoration(
                                            color: buttonColor,
                                            border: Border.all(
                                              color: buttonColor,
                                            ),
                                            borderRadius: BorderRadius.all(
                                                Radius.circular(12))),
                                        child: Center(
                                          child: Text(
                                            "submitBtn".tr,
                                            style: TextStyle(
                                                color: whiteColor,
                                                fontSize: 16,
                                                fontWeight: FontWeight.bold),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                                  sizebox_height_20
                                ],
                              ),
                            )

                          ],
                        ),
                      ),
                    ),
                  ],
                ),
      )
    );
  }
}
