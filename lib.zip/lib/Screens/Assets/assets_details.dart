import 'dart:developer';
import 'dart:io';
import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:path_provider/path_provider.dart';
import 'package:urwealthpal/Constant/Api.dart';
import 'package:urwealthpal/Constant/Images.dart';
import 'package:urwealthpal/Constant/Spacing.dart';
import 'package:urwealthpal/Constant/colors.dart';
import 'package:urwealthpal/Constant/indicator.dart';
import 'package:urwealthpal/Form/dynamicTextFormField.dart';
import 'package:urwealthpal/Screens/Assets/Controllers/Post_Categories_Controller.dart';
import 'EditAssets.dart';
import 'webView.dart';
import 'package:http/http.dart' as http;

class assets_details extends StatefulWidget {
  var mainCategories_id;
  var mainCategories_status ;
  bool assets ;

  // var selectedTile = -1;

  assets_details({this.mainCategories_id,this.mainCategories_status,required this.assets});

  @override
  State<assets_details> createState() => _assets_detailsState();
}

class _assets_detailsState extends State<assets_details> {

  PostCategoriesController postCategoriesController = Get.put(PostCategoriesController());

  TextEditingController _searchController = TextEditingController();

  String formatAmount(String value) {
    final formatter = NumberFormat('#,##0.00', 'en_US');
    double parsedValue = double.tryParse(value.replaceAll(',', '')) ?? 0.0;
    return formatter.format(parsedValue);
  }

  List topBar = [
    {
      "text": "All",
    },
    {
      "text": "Cash",
    },
    {
      "text": "Banks",
    },
    {
      "text": "Investment",
    }
  ];



  int current = 0;

  int touchedIndex = 0;

  // List<PieChartSectionData> showingSections() {
  //   return List.generate(5, (index) {
  //     final isTouched = index == touchedIndex;
  //     final fontSize = isTouched ? 25.0 : 16.0;
  //     final radius = isTouched ? 60.0 : 50.0;
  //     const shadows = [Shadow(color: Colors.black, blurRadius: 2)];
  //     switch (index) {
  //       case 0:
  //         return PieChartSectionData(
  //           color: Color(0xFF0C2F4F),
  //           value: double.parse(postCategoriesController.CategoriestData['category_data'][0]['pie_chart_data'][0]['count'].toString()),
  //           title: '${double.parse(postCategoriesController.CategoriestData['category_data'][0]['pie_chart_data'][0]['count'].toString()).toStringAsFixed(1)}%',
  //           // value: 50,
  //           // title: '40%',
  //           radius: radius,
  //           titleStyle: TextStyle(
  //             fontSize: fontSize,
  //             fontWeight: FontWeight.bold,
  //             color: Colors.white,
  //             shadows: shadows,
  //           ),
  //         );
  //       case 1:
  //         return PieChartSectionData(
  //           color: Color(0xFFFB5C46),
  //           value: double.parse(postCategoriesController.CategoriestData['category_data'][0]['pie_chart_data'][0]['count'].toString()),
  //           title: '${double.parse(postCategoriesController.CategoriestData['category_data'][0]['pie_chart_data'][0]['count'].toString()).toStringAsFixed(1)}%',
  //           // value: 30,
  //           // title: '30%',
  //           radius: radius,
  //           titleStyle: TextStyle(
  //             fontSize: fontSize,
  //             fontWeight: FontWeight.bold,
  //             color: Colors.white,
  //             shadows: shadows,
  //           ),
  //         );
  //       case 2:
  //         return PieChartSectionData(
  //           color:     Color(0xFFF4D820),
  //           value: double.parse(postCategoriesController.CategoriestData['category_data'][0]['pie_chart_data'][0]['count'].toString()),
  //           title: '${double.parse(postCategoriesController.CategoriestData['category_data'][0]['pie_chart_data'][0]['count'].toString()).toStringAsFixed(1)}%',
  //           // value: 15,
  //           // title: '15%',
  //           radius: radius,
  //           titleStyle: TextStyle(
  //             fontSize: fontSize,
  //             fontWeight: FontWeight.bold,
  //             color: Colors.white,
  //             shadows: shadows,
  //           ),
  //         );
  //       case 3:
  //         return PieChartSectionData(
  //           color:     Color(0xFF39CF75),
  //           value: double.parse(postCategoriesController.CategoriestData['category_data'][0]['pie_chart_data'][0]['count'].toString()),
  //           title: '${double.parse(postCategoriesController.CategoriestData['category_data'][0]['pie_chart_data'][0]['count'].toString()).toStringAsFixed(1)}%',
  //           // value: 15,
  //           // title: '15%',
  //           radius: radius,
  //           titleStyle: TextStyle(
  //             fontSize: fontSize,
  //             fontWeight: FontWeight.bold,
  //             color: Colors.white,
  //             shadows: shadows,
  //           ),
  //         );
  //       case 4:
  //         return PieChartSectionData(
  //           color: Color(0xFF37BCF9),
  //           value: double.parse(postCategoriesController.CategoriestData['category_data'][0]['pie_chart_data'][0]['count'].toString()),
  //           title: '${double.parse(postCategoriesController.CategoriestData['category_data'][0]['pie_chart_data'][0]['count'].toString()).toStringAsFixed(1)}%',
  //           // value: 15,
  //           // title: '15%',
  //           radius: radius,
  //           titleStyle: TextStyle(
  //             fontSize: fontSize,
  //             fontWeight: FontWeight.bold,
  //             color: Colors.white,
  //             shadows: shadows,
  //           ),
  //         );
  //       default:
  //         throw Error();
  //     }
  //   });
  // }

  List<PieChartSectionData> showingSections(List<dynamic> data) {
    List<PieChartSectionData> sections = [];
    for (int i = 0; i < data.length; i++) {
      final isTouched = i == touchedIndex;
      final fontSize = isTouched ? 25.0 : 16.0;
      final radius = isTouched ? 60.0 : 50.0;
      const shadows = [Shadow(color: Colors.black, blurRadius: 2)];

      String name = data[i]['name'];
      dynamic totalAssets = double.parse(data[i]['total_assets'].toString());
      dynamic parent_total = double.parse(data[i]['parent_total'].toString());
      log("check data here ${totalAssets} ..... ${parent_total}");
      sections.add(
        PieChartSectionData(
          color: getColorForIndex(i), // Define a function to get colors based on index
          value: totalAssets != 0.0 ?totalAssets : 0.0,
          title: parent_total != 0.0 ? '${(totalAssets /parent_total* 100).toStringAsFixed(0)}%': "${totalAssets.toStringAsFixed(0)}%", // Display percentage

          radius: radius,
          titleStyle: TextStyle(
            fontSize: fontSize,
            fontWeight: FontWeight.bold,
            color: whiteColor,
            shadows: shadows,
          ),
        ),
      );
    }

    return sections;
  }

  Color getColorForIndex(int index) {
    switch (index) {
      case 0:
        return Colors.blue.shade100;
      case 1:
        return Colors.blue.shade200;
      case 2:
        return Colors.blue.shade300;
      case 3:
        return Colors.blue.shade400;
      case 4:
        return Colors.blue.shade500;
      case 5:
        return Colors.blue.shade600;
      case 6:
        return Colors.blue.shade700;
      case 7:
        return Colors.blue.shade800;
      default:
        return Colors.blue.shade900;
    }
  }


  // final List<PieChartSectionData> sectionList = [];

 //  getpaichartdata() async {
 //  await postCategoriesController.CategoriestData['category_data'][0]['pie_chart_data'].forEach((category) {
 //    log("category---->"+category.toString());
 //    // log("category---->"+category['pie_chart_data'].toString());
 //    // category['pie_chart_data'].forEach((subcategory){
 //    //   log("pie_chart_data---->"+subcategory.toString());
 //    // });
 //     PieChartSectionData sectionData = PieChartSectionData(
 //       // color: category.color,
 //       value: category['count'],
 //       title: category['name'],
 //       showTitle: false,
 //     );
 //     log("sectionData---->"+sectionData.toString());
 //     sectionList.add(sectionData);
 //     log("sectionList---->"+sectionList.toString());
 //
 //   });
 // }

  bool type_name = true;

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    print("mainID " +widget.mainCategories_id.toString());
    callApi();
    _searchController.text;
    // getpaichartdata();
  }

  // getassetsDetail(search)async{
  //   Map<String, String> body = {
  //     que_search :search.toString(),
  //     'category_id': widget.mainCategories_id.toString(),
  //   };
  //  await postCategoriesController.CategoriestApiCalling(PostCategory_url,body);
  // }

  callApi() async {
    var assetUrl = PostCategory_url;
    var assetBody = {
      'category_id': widget.mainCategories_id.toString(),
      // 'sub_category_id': widget.subCategories_id.toString()
    };
    await postCategoriesController.CategoriestApiCalling(assetUrl,assetBody);
  }

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Scaffold(
      appBar: AppBar(
        backgroundColor: ContainerColor,
        elevation: 0,
        titleSpacing: 0,
        title: Text(
         widget.assets==true? "assetsDetailtxt".tr:"liabilitie_detail".tr,
        style: TextStyle(
          color: whiteColor,
        ),),
      ),
      body:RefreshIndicator(
        onRefresh: () async {
          _searchController.clear();
          await PostCategoriesController();
          await Future.delayed(Duration(milliseconds: 1500));
        },
        child: GetBuilder<PostCategoriesController>(
          builder: (postCategoriesController) {
            if(postCategoriesController.CategoriesLoading.value){
              return Center(child: CircularProgressIndicator());
            }
            else{
              return SingleChildScrollView(
                keyboardDismissBehavior: ScrollViewKeyboardDismissBehavior.onDrag,
                child: Column(
                  children: [
                    Container(
                      height: 60,
                      decoration: BoxDecoration(
                        color: ContainerColor,
                        border: Border.all(color: ContainerColor),
                        borderRadius: BorderRadius.only(
                            bottomLeft: (Radius.circular(20)),
                            bottomRight: (Radius.circular(20))),
                      ),
                      child: Padding(
                        padding:  EdgeInsets.only(left: 20,right: 20,bottom: 10),
                        child: Row(
                          children: [
                            Expanded(
                            flex: 7,
                            child: TextFormField(
                              onTap: (){},
                              controller: _searchController,
                              onChanged: (value) async {
                                // getassetsDetail(_searchController.text.toString());
                                var assetUrl = PostCategory_url;
                                var assetBody = {
                                  'category_id': widget.mainCategories_id.toString(),
                                  'search': value.toString()
                                };
                                await postCategoriesController.CategoriestApiCalling(assetUrl,assetBody);
                                setState(() {
                                });
                              },
                              decoration: InputDecoration(
                                filled: true,
                                fillColor: Colors.white,
                                border: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(10),
                                ),
                                focusedBorder: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(10),
                                    borderSide:
                                    BorderSide(width: 1, color: appPrimaryColor)),
                                suffixIcon: SearchIcon,
                                label: Text("search".tr),
                              ),
                            ),
                          ),

                            sizebox_width_5,

                            int.parse(postCategoriesController.CategoriestData['category_data'][0]['form_exist'].toString())==1 &&
                                int.parse(postCategoriesController.CategoriestData['category_data'][0]
                            ['permission']["can_add"].toString())==1 ?

                            Expanded(
                              child: GestureDetector(
                                onTap: (){
                                  log('mainCategories_id==>'+ widget.mainCategories_id.toString());
                                  log('name==>'+ postCategoriesController.CategoriestData["category_data"][0]["name"].toString());
                                  Navigator.push(context,
                                      MaterialPageRoute(builder: (context)=> DynamicTextFormPage(
                                        catid: widget.mainCategories_id,
                                        formName: postCategoriesController.CategoriestData["category_data"][0]["name"].toString(),
                                      )));
                                },
                                child: Container(
                                  height: 40,
                                  decoration: BoxDecoration(
                                      color: sidebarcontainerColor,
                                      border: Border.all(
                                        color: sidebarcontainerColor,
                                      ),
                                      borderRadius: BorderRadius.all(
                                          Radius.circular(50))),
                                  child: Icon(Icons.add , color: whiteColor,size: 25,),
                                ),
                              ),
                            ):
                            Container()
                          ],
                        ),
                      ),
                    ),
                    Card(
                      elevation: 4,
                      shape: BeveledRectangleBorder(
                        borderRadius: BorderRadius.circular(5),
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Padding(
                              padding:  EdgeInsets.only(left: 10),
                              child: Image.network(
                                postCategoriesController.CategoriestData["category_data"][0]["image"],
                                height: 60,width: 60,)
                          ),
                          Padding(
                            padding: EdgeInsets.only(right: 50),
                            child: Container(
                              width: size.width*.25,
                              child: Text(
                                postCategoriesController.CategoriestData["category_data"][0]["name"].toString(),
                                maxLines: 2,
                                overflow: TextOverflow.ellipsis,
                                style: TextStyle(color: Color(0xFF656565),
                                    fontSize: 15,
                                    fontWeight: FontWeight.bold),
                              ),
                            ),
                          ),
                          Container(
                              padding: EdgeInsets.symmetric(horizontal: 30,vertical: 25),
                              child: Center(
                                  child: Text(
                                    postCategoriesController.CategoriestData["category_data"][0]["count"].toString(),
                                    style: TextStyle(
                                        color: whiteColor,
                                        fontSize: 18,
                                        fontWeight: FontWeight.bold
                                    ),)),
                              decoration: BoxDecoration(
                                  color: ContainerColor,
                                  border: Border.all(color: ContainerColor),
                                  borderRadius: BorderRadius.all(Radius.circular(8))
                              )
                          ),
                        ],
                      ),
                    ),
                    postCategoriesController.CategoriestData['category_data'][0]['pie_chart_data'].length==0?
                    Container():
                    Padding(
                      padding: EdgeInsets.only(top: 10, left: 10, right: 10),
                      child: SizedBox(
                        height: 250,
                        child: Card(
                          child: Row(
                            children: [
                              Expanded(
                                flex: 6,
                                child: AspectRatio(
                                  aspectRatio: 1,
                                  child: Stack(
                                    children: [
                                      PieChart(
                                        PieChartData(
                                          pieTouchData: PieTouchData(
                                            touchCallback: (FlTouchEvent event,
                                                pieTouchResponse) {
                                              setState(() {
                                                if (!event
                                                    .isInterestedForInteractions ||
                                                    pieTouchResponse == null ||
                                                    pieTouchResponse
                                                        .touchedSection ==
                                                        null) {
                                                  touchedIndex = -1;
                                                  return;
                                                }
                                                touchedIndex = pieTouchResponse
                                                    .touchedSection!
                                                    .touchedSectionIndex;
                                              });
                                            },
                                          ),
                                          borderData: FlBorderData(
                                            show: false,
                                          ),
                                          sectionsSpace: 2,
                                          // centerSpaceRadius: 40,
                                          sections: showingSections(
                                              postCategoriesController.CategoriestData['category_data'][0]['pie_chart_data']
                                          ),
                                        ),
                                      ),
                                      // Center(
                                      //   child: Container(
                                      //     width: 110,
                                      //     child: Text(
                                      //       "financial_assets".tr,
                                      //       textAlign: TextAlign.center,
                                      //       style: TextStyle(color: Darkgrey),
                                      //     ),
                                      //   ),
                                      // ),
                                    ],
                                  ),
                                ),
                              ),
                              SizedBox(width: 10,),
                              Expanded(
                                flex: 4,
                                child: ListView.builder(
                                  itemCount: postCategoriesController.CategoriestData['category_data'][0]['pie_chart_data'].length,
                                  shrinkWrap: true,
                                  physics: NeverScrollableScrollPhysics(),
                                  itemBuilder: (context, index) {
                                    var titles = postCategoriesController.CategoriestData['category_data'][0]['pie_chart_data'][index];
                                    return Column(
                                      mainAxisAlignment: MainAxisAlignment.end,
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: <Widget>[
                                        titles['total_assets']==0?Container():
                                        Indicator(
                                          color: getColorForIndex(index),
                                          text: "${titles["name"]}\t(${formatAmount(titles['total_assets'].toString())})",
                                          size: 130,
                                          textwidth: 110,
                                          isSquare: true,
                                        ),
                                        SizedBox(
                                          height: 4,
                                        ),
                                      ],
                                    );
                                  },),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ),

                    // sub category list data here ------->>>>>

                    postCategoriesController.CategoriestDataList.length==0?Container():
                    Padding(
                      padding: EdgeInsets.only(top: 10, left: 10, right: 10),
                      child: Container(
                        height: 40,
                        alignment: Alignment.topLeft,
                        child: ListView.builder(
                            itemCount: postCategoriesController.CategoriestDataList.length,
                            scrollDirection: Axis.horizontal,
                            shrinkWrap: true,
                            physics: AlwaysScrollableScrollPhysics(),
                            itemBuilder: (BuildContext context, index) {
                              var listdata = postCategoriesController.CategoriestDataList[index];
                              return GestureDetector(
                                onTap: () async {
                                var  assetBody;
                                  if(index==0){
                                     assetBody = {
                                      'category_id': widget.mainCategories_id.toString(),
                                    };
                                  }else{
                                    assetBody = {
                                      'category_id': widget.mainCategories_id.toString(),
                                      'sub_category_id': listdata['id'].toString()
                                    };
                                  }
                                  var assetUrl = PostCategory_url;
                                  await postCategoriesController.CategoriestApiCalling(assetUrl,assetBody);
                                  setState(() {
                                    current = index;
                                  });
                                },
                                child: Container(
                                  margin: EdgeInsets.all(2),
                                  width: 120,
                                  decoration: BoxDecoration(
                                    color: current == index
                                        ? appPrimaryColor
                                        : whiteColor,
                                    border: Border.all(color: appPrimaryColor),
                                    borderRadius:
                                    BorderRadius.all(Radius.circular(5)),
                                  ),
                                  child: Center(
                                      child: Text(
                                        listdata['name'].toString(),
                                        textAlign: TextAlign.center,
                                        style: TextStyle(
                                            color: current == index
                                                ? whiteColor
                                                : greyColor,
                                            wordSpacing: 0.2,
                                            overflow: TextOverflow.clip,
                                            fontSize: 12),
                                      )),
                                ),
                              );
                            }),
                      ),
                    ),

                    // list view for  listing total assets
                    sizebox_height_5,
                    postCategoriesController.widgitLoad==true?Center(child:
                    Container(
                        alignment: Alignment.center,
                        height: size.height*0.20,
                        child: CircularProgressIndicator())):
                    postCategoriesController.CategoriestData['total_assets'].length==0?
                    Container(
                        height: size.height*0.65,
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.center,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [
                            Text("DataFound".tr,
                              style: TextStyle(fontSize: 14.5,fontWeight: FontWeight.w600,
                                  color: Colors.grey.shade600,letterSpacing: 0.5
                              ),),
                          ],
                        )):
                    ListView.builder(
                        itemCount: postCategoriesController.CategoriestData['total_assets'].length,
                        scrollDirection: Axis.vertical,
                        shrinkWrap: true,
                        physics: NeverScrollableScrollPhysics(),
                        itemBuilder: (BuildContext context, index) {
                          var listdata = postCategoriesController.CategoriestData['total_assets'][index];
                          print("total sadasafaaxcvszvsc====>"+postCategoriesController.CategoriestData['total_assets'].length.toString());
                          return ExpansionTile(

                            // key: Key(selectedTile.toString()),
                            // initiallyExpanded: index == selectedTile,

                            // onExpansionChanged: (bool expanded) {
                            //   setState(() {
                            //     assetSubCategoryList =getcategoriesController.Get_CategoriesData[index1]['sub_categories'];
                            //   });
                            // },

                            title: Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text("${index + 1}.)\t${listdata['form_data'][0]['value'].toString()}",
                                  style: TextStyle(
                                      color: Colors.black,
                                      fontSize: 18,
                                      fontWeight: FontWeight.bold
                                  ),),

                              ],
                            ),

                            // trailing: Icon(Icons.expand_more_outlined),
                            children: <Widget>[
                          int.parse(postCategoriesController.CategoriestData['category_data'][0]
                          ['permission']["can_delete"].toString())==1?
                              Row(
                                mainAxisAlignment: MainAxisAlignment.end,
                                children: [
                                  GestureDetector(
                                    onTap: (){
                                      var assetsId = listdata['id'];
                                      log('assetsId==>'+assetsId.toString());
                                      log('name==>'+ listdata['form_data'][0]['value'].toString());
                                      Navigator.push(context,
                                          MaterialPageRoute(builder: (context)=>EditDynamicTextFormPage(
                                            AssetsId: assetsId,
                                            Catid: widget.mainCategories_id,
                                            formName: listdata['form_data'][0]['value'].toString(),
                                          )));




                                    },
                                      child: Icon(Icons.edit_calendar_outlined,color: Colors.grey.shade700,size: 22,)),
                                  SizedBox(width: 20,),
                                  Padding(
                                    padding:  EdgeInsets.only(right: 15.0),
                                    child: GestureDetector(
                                        onTap: ()async{
                                          showDialog(
                                            context: context,
                                            builder: (context) =>
                                                AlertDialog(
                                              title:  Text('sure_title_txt'.tr),
                                              content:  Text('deleteForm'.tr),
                                              actions: [
                                                TextButton(onPressed: () =>
                                                    Navigator.of(context).pop(false),
                                                  child:  Text('no'.tr,
                                                    style: TextStyle(
                                                        color: appPrimaryColor,
                                                        fontWeight: FontWeight.bold
                                                    ),
                                                  ),),
                                                TextButton(
                                                  onPressed: () async{
                                                    setState(() {
                                                      var assetsId = listdata['id'];
                                                      var deleteUrl = DeleteAssets_url;
                                                      var deleteBody ={
                                                        'asset_id': assetsId.toString(),
                                                      };
                                                      print("deleteBody--->>"+deleteBody.toString());

                                                      postCategoriesController.DeleteAssetsApiCalling(deleteUrl, deleteBody);

                                                      setState(() {

                                                      });

                                                      var assetUrl = PostCategory_url;
                                                      var assetBody = {
                                                        'category_id': widget.mainCategories_id.toString(),
                                                      };

                                                      Get.find<PostCategoriesController>().CategoriestApiCalling(assetUrl,assetBody);

                                                      setState(() {
                                                      });

                                                    });
                                                    // deletefromCart(item__id);
                                                    Navigator.of(context).pop(true);
                                                  },
                                                  child:  Text('yes'.tr,
                                                    style: TextStyle(
                                                        color: appPrimaryColor,
                                                        fontWeight: FontWeight.bold
                                                    ),),
                                                ),
                                                //  ElevatedButton(
                                                //   onPressed: () => Navigator.of(context).pop(false),
                                                //   child:  Text('no'.tr),
                                                // ),
                                                // ElevatedButton(
                                                //   onPressed: () async{
                                                //     setState(() {
                                                //       var assetsId = listdata['id'];
                                                //       var deleteUrl = DeleteAssets_url;
                                                //       var deleteBody ={
                                                //         'asset_id': assetsId.toString(),
                                                //
                                                //       };
                                                //       print("deleteBody--->>"+deleteBody.toString());
                                                //       postCategoriesController.DeleteAssetsApiCalling(deleteUrl, deleteBody);
                                                //       var assetUrl = PostCategory_url;
                                                //       var assetBody = {
                                                //         'category_id': widget.mainCategories_id.toString(),
                                                //       };
                                                //       Get.find<PostCategoriesController>().CategoriestApiCalling(assetUrl,assetBody);
                                                //     });
                                                //     // deletefromCart(item__id);
                                                //     Navigator.of(context).pop(true);
                                                //   },
                                                //   child:  Text('yes'.tr),
                                                // ),
                                              ],
                                            ),);

                                        },

                                        child: Icon(Icons.delete_outline_outlined,color: Colors.red.shade400,size: 22,)),
                                  ),
                                ],
                              ):SizedBox(),

                              ListView.builder(
                                  itemCount: listdata['form_data'].length,
                                  scrollDirection: Axis.vertical,
                                  shrinkWrap: true,
                                  physics: NeverScrollableScrollPhysics(),
                                  itemBuilder: (BuildContext context, index1) {
                                    var listdata2 = listdata['form_data'][index1];
                                    // log("list data for step 2--->>"+listdata2.toString());
                                    return Padding(
                                      padding:  EdgeInsets.only(left: 10.0,right: 10.0),
                                      child: Column(
                                        children: [
                                          // sizebox_height_20,
                                          Divider(
                                              color: Colors.grey.shade600
                                          ),
                                          Row(
                                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                            children: [
                                              Container(
                                                width: size.width*0.4,
                                                padding: EdgeInsets.only(bottom: 10),
                                                // color: primaryColor,
                                                child: Text(listdata2['label'].toString(),
                                                  style: TextStyle(
                                                    color: Colors.black54,
                                                    fontSize: 16,
                                                    fontWeight: FontWeight.w600
                                                  ),),
                                              ),
                                              GestureDetector(
                                                onTap: listdata2['content_type']=='text'?null:(){
                                                  print("object...${listdata2.toString()}");

                                                  // getFileFromUrl(listdata2['value'].toString());
                                                  Get.to(FileWebView(url:listdata2['value'].toString() ));
                                                },
                                                child: Container(
                                                  width: size.width*0.4,
                                                  padding: EdgeInsets.only(bottom: 10),
                                                  // color: Colors.green,
                                                  child:listdata2['content_type']=='text'?listdata2['type']==2?Text(formatAmount(listdata2['value'].toString()),
                                                    style: TextStyle(
                                                      color: Colors.black54,
                                                      fontSize: 16,
                                                    ),) :Text(listdata2['value'].toString(),
                                                    style: TextStyle(
                                                      color: Colors.black54,
                                                      fontSize: 16,
                                                    ),):Text("View".tr,
                                                    style: TextStyle(
                                                        color: buttonColor,
                                                    ),),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ],
                                      ),
                                    );
                                  }),
                            ],
                          );
                        }),
                  ],
                ),
              );
            }
          }
        ),

      ),
    );
  }

  Future<File> getFileFromUrl(String url, {name}) async {
    // Fluttertoast.showToast(msg: "downloading result ");
    var fileName = 'Careerrocket Result';
    if (name != null) {
      fileName = name;
    }
    try {
      var data = await http.get(Uri.parse(url));
      var bytes = data.bodyBytes;
      var dir = await getApplicationDocumentsDirectory();
      File file = File("${dir.path}/" + fileName + ".pdf");
      print(dir.path);
      File urlFile = await file.writeAsBytes(bytes);
      // Fluttertoast.showToast(msg: "downloaded result successfuly");
      return urlFile;
    } catch (e) {
      setState(() {
        // loaded = false;
      });
      // Fluttertoast.showToast(msg: "Error opening result");
      throw Exception("Error opening url file");
    }
  }
}