import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:webview_flutter/webview_flutter.dart';

class FileWebView extends StatefulWidget {
  var url;
  FileWebView({
    Key ?key,this.url
  }) : super(key: key);

  @override
  _FileWebViewState createState() => _FileWebViewState();
}

class _FileWebViewState extends State<FileWebView> {


  String getExtension(String url) {
    final match = RegExp(r'\.([a-zA-Z0-9]+)$').firstMatch(url);
    print("ext............${match != null ? '.${match.group(1)}' : ''}");
    return match != null ? '.${match.group(1)}' : '';
  }

  @override
  void initState() {

    super.initState();

    getExtension(widget.url);
  }
  @override
  Widget build(BuildContext context) {
    WebViewController _controller;
    var num=widget.url;

    return Scaffold(
      appBar: AppBar(
        title: Text("View"),
      ),
      body:   getExtension(widget.url)==".pdf"  ?WebView(
        initialUrl: "https://docs.google.com/gview?embedded=true&url=${widget.url.toString()}",
        javascriptMode: JavascriptMode.unrestricted,
      ):WebView(
        initialUrl: widget.url.toString(),
        javascriptMode: JavascriptMode.unrestricted,
      )
    );
  }
  // Future<void> loadHtmlFromAssets(String filename, controller) async {
  //   String fileText = await rootBundle.loadString(filename);
  //   controller.loadUrl(Uri.dataFromString(fileText, mimeType: 'text/html', encoding: Encoding.getByName('utf-8')).toString());
  // }

}
