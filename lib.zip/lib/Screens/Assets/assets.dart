import 'dart:developer';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:urwealthpal/Constant/Api.dart';
import 'package:urwealthpal/Constant/Images.dart';
import 'package:urwealthpal/Constant/Spacing.dart';
import 'package:urwealthpal/Constant/colors.dart';
import 'package:urwealthpal/Environment/Environment.dart';
import 'package:urwealthpal/Screens/Assets/Controllers/Get_Categories_Controller.dart';
import 'package:urwealthpal/Screens/Assets/assets_details.dart';
import 'package:urwealthpal/Screens/MPIN/AssetsMPIN.dart';
import 'package:urwealthpal/Screens/PurchasePlan/purchase_plan.dart';
import 'package:urwealthpal/main.dart';

class assets extends StatefulWidget {
  const assets({Key? key}) : super(key: key);

  @override
  State<assets> createState() => _assetsState();
}

class _assetsState extends State<assets> {
  TextEditingController _searchController = TextEditingController();

  var getcategoriesController = Get.put(Get_Categories_Controller());

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    _searchController.text;

    // if(sp!.getBool("paymentstatus")== false){
    //   Get.offAll(purchase_plan());
    //   sp!.setBool("paymentstatus", false);
    // }
    // else{
    //   sp!.setBool("paymentstatus", true);
    // }

    getcategoriesController.Get_CategoriesAPICalling(
        Category_url + "?type=${1}");
  }

  getassets(search) async {
    Map<String, String> queryParams = {
      que_search: search.toString(),
    };
    String queryString = Uri(queryParameters: queryParams).query;
    var GetCategoriesUrl = Category_url + '?' + queryString;
    getcategoriesController.Get_CategoriesAPICalling(GetCategoriesUrl);
  }

  List assetSubCategoryList = [];

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return RefreshIndicator(
      onRefresh: () async {
        _searchController.clear();
        await Get_Categories_Controller();
        await Future.delayed(Duration(milliseconds: 1500));
      },
      child: Scaffold(body: GetBuilder<Get_Categories_Controller>(
          builder: (getcategoriesController) {
        if (getcategoriesController.Get_Categories_Loading.value) {
          return Center(
            child: CircularProgressIndicator(),
          );
        } else {
          return SingleChildScrollView(
            child: Column(
              children: [
                Container(
                  height: 60,
                  decoration: BoxDecoration(
                    color: ContainerColor,
                    border: Border.all(color: ContainerColor),
                    borderRadius: BorderRadius.only(
                        bottomLeft: (Radius.circular(20)),
                        bottomRight: (Radius.circular(20))),
                  ),
                  child: Padding(
                    padding: EdgeInsets.only(left: 20, right: 20, bottom: 15),
                    child: TextFormField(
                      onTap: () {},
                      onChanged: (value) {
                        getassets(_searchController.text.toString());
                      },
                      controller: _searchController,
                      decoration: InputDecoration(
                        filled: true,
                        fillColor: Colors.white,
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10),
                        ),
                        focusedBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(10),
                            borderSide:
                                BorderSide(width: 1, color: appPrimaryColor)),
                        suffixIcon: SearchIcon,
                        label: Text("search".tr),
                      ),
                    ),
                  ),
                ),
                ListView.builder(
                    itemCount:
                        getcategoriesController.Get_CategoriesData.length,
                    scrollDirection: Axis.vertical,
                    shrinkWrap: true,
                    physics: NeverScrollableScrollPhysics(),
                    itemBuilder: (BuildContext context, index1) {
                      var Categorieslistdata = getcategoriesController.Get_CategoriesData[index1];
                      log('Get_CategoriesData==>$Categorieslistdata');
                      return Padding(
                        padding: EdgeInsets.only(left: 10, right: 10, top: 5),
                        child: Card(
                          elevation: 2,
                          child: ExpansionTile(
                            collapsedBackgroundColor: Colors.transparent,
                            trailing:
                                Categorieslistdata['sub_categories'].length == 0
                                    ? SizedBox(height: 0)
                                    : Icon(Icons.expand_more_outlined),
                            onExpansionChanged: (bool expanded) {
                              setState(() {
                                assetSubCategoryList = getcategoriesController.Get_CategoriesData[index1]['sub_categories'];
                              });
                            },
                            title: GestureDetector(
                              onTap: () {
                                if (Environment.askMPIN == "1") {
                                  Get.to(AssetsMPIN(
                                      mainCategories_id:
                                          Categorieslistdata["id"].toString(),
                                      id: 1));
                                } else {
                                  Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                          builder: (context) => assets_details(
                                                mainCategories_id:
                                                    Categorieslistdata["id"]
                                                        .toString(),
                                                mainCategories_status: false,
                                                assets: true,
                                              ))
                                  );
                                }
                              },
                              child: Row(
                                children: [
                                  Image.network(
                                    Categorieslistdata["image"].toString(),
                                    height: 45,
                                    width: 45,
                                  ),
                                  sizebox_width_10,
                                  Expanded(
                                    flex: 25,
                                    child: Text(
                                      Categorieslistdata["name"].toString(),
                                      style: TextStyle(
                                          color: Darkgrey,
                                          fontSize: 17,
                                          letterSpacing: 0.5,
                                          height: 1.5,
                                          fontWeight: FontWeight.w600),
                                    ),
                                  ),
                                  sizebox_width_10,
                                  Expanded(
                                    flex: 15,
                                    child: Container(
                                        padding: const EdgeInsets.symmetric(
                                            horizontal: 10, vertical: 20),
                                        child: Center(
                                            child: Text(
                                          Categorieslistdata['sub_categories']
                                              .length
                                              .toString(),
                                          // Categorieslistdata["count"].toString(),
                                          style: TextStyle(
                                              color: whiteColor,
                                              fontSize: 18,
                                              fontWeight: FontWeight.bold),
                                        )),
                                        decoration: BoxDecoration(
                                            color: ContainerColor,
                                            border: Border.all(
                                                color: ContainerColor),
                                            borderRadius: BorderRadius.all(
                                                Radius.circular(8)))),
                                  ),
                                ],
                              ),
                            ),
                            children: <Widget>[
                              ListView.builder(
                                  itemCount:
                                      Categorieslistdata['sub_categories']
                                          .length,
                                  scrollDirection: Axis.vertical,
                                  shrinkWrap: true,
                                  physics: NeverScrollableScrollPhysics(),
                                  itemBuilder: (BuildContext context, index2) {
                                    var SubCategorieslistdata =
                                        Categorieslistdata['sub_categories']
                                            [index2];
                                    print("SubCategorieslistdata-->" +
                                        SubCategorieslistdata.toString());
                                    return Padding(
                                      padding: EdgeInsets.only(
                                          left: 10, right: 10, top: 5),
                                      child: ExpansionTile(
                                        collapsedBackgroundColor:
                                            Colors.transparent,
                                        trailing: SubCategorieslistdata['sub_categories'].length == 0
                                            ? SizedBox(height: 0)
                                            : Icon(Icons.expand_more_outlined),
                                        onExpansionChanged: (bool isexpanded) {
                                          if (Environment.askMPIN == "1") {
                                            Get.to(AssetsMPIN(mainCategories_id: SubCategorieslistdata["id"].toString(), id: 2));
                                          } else {
                                            Navigator.push(
                                                context,
                                                MaterialPageRoute(builder: (context) => assets_details(
                                                  mainCategories_id: SubCategorieslistdata["id"].toString(), mainCategories_status: true, assets: true,
                                                        )));
                                          }
                                          // Navigator.push(
                                          //     context,
                                          //     MaterialPageRoute(
                                          //         builder: (context) =>
                                          //             assets_details(
                                          //               mainCategories_id:
                                          //                   SubCategorieslistdata[
                                          //                           "id"]
                                          //                       .toString(),
                                          //               mainCategories_status:
                                          //                   true,
                                          //               assets: true,
                                          //             )));
                                        },
                                        title: Row(
                                          children: [
                                            Image.network(
                                              SubCategorieslistdata["image"]
                                                  .toString(),
                                              height: 35,
                                              width: 35,
                                            ),
                                            sizebox_width_10,
                                            Text(
                                              SubCategorieslistdata["name"]
                                                  .toString(),
                                              style: TextStyle(
                                                  color: greyColor,
                                                  fontSize: 16,
                                                  fontWeight: FontWeight.w400),
                                            ),
                                          ],
                                        ),
                                        children: <Widget>[
                                          ListView.builder(
                                              itemCount: SubCategorieslistdata[
                                                      'sub_categories']
                                                  .length,
                                              scrollDirection: Axis.vertical,
                                              shrinkWrap: true,
                                              physics:
                                                  NeverScrollableScrollPhysics(),
                                              itemBuilder:
                                                  (BuildContext context,
                                                      index3) {
                                                var SubCategoriesdata =
                                                    SubCategorieslistdata['sub_categories']
                                                        [index3];
                                                // print("subCategoryList${subcategoryList[index3]}");
                                                return Padding(
                                                  padding: EdgeInsets.all(8.0),
                                                  child: GestureDetector(
                                                    onTap: () {
                                                      if (Environment.askMPIN == "1") {
                                                        Get.to(AssetsMPIN(mainCategories_id: SubCategorieslistdata["id"].toString(), id: 2));
                                                      } else {
                                                        Navigator.push(
                                                            context,
                                                            MaterialPageRoute(builder: (context) => assets_details(
                                                              mainCategories_id: SubCategorieslistdata["sub_categories"][0]["id"].toString(), mainCategories_status: true, assets: true,
                                                            )));
                                                      }
                                                      // Navigator.push(
                                                      //     context,
                                                      //     MaterialPageRoute(
                                                      //         builder: (context) =>
                                                      //             assets_details(
                                                      //               mainCategories_id:
                                                      //                   SubCategorieslistdata[
                                                      //                           "id"]
                                                      //                       .toString(),
                                                      //               mainCategories_status:
                                                      //                   true,
                                                      //               assets: true,
                                                      //             )));
                                                    },
                                                    child: Row(
                                                      children: [
                                                        Image.network(
                                                          SubCategoriesdata["image"].toString(),
                                                          height: 60,
                                                          width: 60,
                                                        ),
                                                        Text(
                                                          SubCategoriesdata[
                                                                  "name"]
                                                              .toString(),
                                                          style: TextStyle(
                                                            color: Namecolors,
                                                          ),
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                );
                                              })
                                        ],
                                      ),
                                    );
                                  }),
                            ],
                          ),
                        ),
                      );
                    }),
              ],
            ),
          );
        }
      })),
    );
  }
}
