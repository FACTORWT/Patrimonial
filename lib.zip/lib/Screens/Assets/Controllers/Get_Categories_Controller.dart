import 'dart:convert';
import 'package:get/get.dart';
import 'package:urwealthpal/Constant/ApiBaseHelper.dart';

class Get_Categories_Controller extends GetxController{
  var Get_Categories_Loading = false.obs;
  List Get_CategoriesData=[] ;

  Get_CategoriesAPICalling(url) async {
    Get_Categories_Loading.value =true;

    print("GetCategoriesUrl : " + url.toString());
    var response = await ApiBaseHelper().getAPICall(Uri.parse(url), true);
    var responsedata = jsonDecode(response.body);
    print("GetCategories responsedata : " + responsedata.toString());
    if(response.statusCode==200){
      Get_CategoriesData.clear();
      Get_CategoriesData.addAll(responsedata['data']) ;
      Get_Categories_Loading.value =false;
      update();
    }else{
      Get_CategoriesData =[];
      Get_Categories_Loading.value =false;
      update();
    }
  }
}