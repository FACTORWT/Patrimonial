import 'dart:convert';
import 'dart:developer';
import 'package:get/get.dart';
import 'package:urwealthpal/Constant/ApiBaseHelper.dart';

class PostCategoriesController extends GetxController{

  var CategoriesLoading = false.obs;
  var CategoriestData ;
  bool widgitLoad= false;

  List  CategoriestDataList=[] ;
  List  PieChartDataList=[] ;

    CategoriestApiCalling(url, parameter) async {
    widgitLoad=true;
    CategoriesLoading.value =true;
    print("Categoriesurl " + url.toString());
    print("Categoriesparamater " + parameter.toString());
    var response = await ApiBaseHelper().postAPICall(Uri.parse(url), parameter, true);
    var responsedata = jsonDecode(response.body);
    print("Categories responsedata : " + responsedata.toString());
    if(response.statusCode==200){
      CategoriestData = responsedata['data'];
    //  CategoriestDataList = responsedata['data']['sub_categories'];
      log("  CategoriestData----"+CategoriestData['total_assets'].toString());
      CategoriestDataList.clear();
      if(responsedata['data']['sub_categories'].length==0){
        update();
      }else{

        CategoriestDataList.addAll([{
          "id": 0,
          "name": "All",
          "permission": {
            "can_add": 1,
            "can_delete": 1
          },
          "image": "https://adiyogionlinetrade.com/urwealth/images/default.png"
        }]);

        print("CategoriestDataList all data ---->>"+CategoriestDataList.toString());
        CategoriestDataList.addAll(responsedata['data']['sub_categories']);
      }
      PieChartDataList.clear();
      PieChartDataList.add(responsedata['data']['category_data'][0]['pie_chart_data']);
      print("data........."+PieChartDataList.toString());
      // widgitLoading= false;
      print("widgitLoading........."+widgitLoad.toString());
      widgitLoad= false;
      CategoriesLoading.value =false;
      update();
    } else{
      CategoriestData =[];
      widgitLoad= false;
      CategoriesLoading.value =false;
      update();
    }
    update();
  }


  var deleteLoading = false.obs;
  var DeleteData;

  DeleteAssetsApiCalling(url, parameter) async {
    deleteLoading.value =true;
    var response = await ApiBaseHelper().postAPICall(Uri.parse(url), parameter, true);
    if(response.statusCode==200){
      refresh();
      DeleteData =jsonDecode(response.body);
      print("DeleteData--->>>"+DeleteData.toString());
      // CategoriestApiCalling(url, parameter);
      deleteLoading.value =false;
      update();
      refresh();
    } else if(response.statusCode==422){
      DeleteData =jsonDecode(response.body);
      print("DeleteData else--->>>"+DeleteData.toString());
      DeleteData =[];
      deleteLoading.value =false;
      update();
      refresh();
    }
    DeleteData =jsonDecode(response.body);
    DeleteData =[];
    update();
    refresh();
  }
}

