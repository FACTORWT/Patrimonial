import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:urwealthpal/Constant/ApiBaseHelper.dart';

class LanguageController extends GetxController{
  var LanguageLoading = false.obs;
  List Languagedata=[] ;

  var ChangeLanguageLoading = false.obs;
  List ChangeLanguagedata=[] ;

  LanguageAPICalling(url) async {
    LanguageLoading.value =true;

    print("Language Url : " + url.toString());
    var response = await ApiBaseHelper().getAPICall(Uri.parse(url), true);
    var responsedata = jsonDecode(response.body);
    print("Language responsedata : " + responsedata.toString());
    if(response.statusCode==200){
      Languagedata.clear();
      Languagedata.addAll(responsedata['data']) ;

      LanguageLoading.value =false;
      update();
    }else{
      Languagedata =[];
      LanguageLoading.value =false;
      update();
    }
  }


  ChangeLanguageAPICalling(url,Locale languagecode) async {
    print("ChangeLanguage Url : " + url.toString());
    ChangeLanguageLoading.value =true;

    print("ChangeLanguage Url : " + url.toString());
    var response = await ApiBaseHelper().getAPICall(Uri.parse(url), true);
    var responsedata = jsonDecode(response.body);
    print("ChangeLanguage responsedata : " + responsedata.toString());
    if(response.statusCode==200){

      ChangeLanguagedata.clear();
      ChangeLanguagedata.addAll(responsedata['data']) ;
      updateLanguage(languagecode);
      ChangeLanguageLoading.value =false;
      update();
    }else{
      ChangeLanguagedata =[];
      ChangeLanguageLoading.value =false;
      update();
    }
  }

  updateLanguage(Locale locale) async {
    Get.back();
    Get.updateLocale(locale);
    await forceAppUpdate();
  }

  Future<void> forceAppUpdate() async {
    await engine.performReassemble();
  }
  WidgetsBinding get engine {
    return WidgetsFlutterBinding.ensureInitialized();
  }
}