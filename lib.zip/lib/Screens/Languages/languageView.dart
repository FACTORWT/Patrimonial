import 'dart:developer';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:urwealthpal/BottomBar/bottombar.dart';
import 'package:urwealthpal/Constant/Api.dart';
import 'package:urwealthpal/Constant/Images.dart';
import 'package:urwealthpal/Screens/Languages/Controllers/languageController.dart';
import 'package:urwealthpal/main.dart';

import '../Home/Controllers/HomePage_Controller.dart';

class LanguageView extends StatefulWidget {
  var index ;
   LanguageView({Key? key,this.index}) : super(key: key);

  @override
  State<LanguageView> createState() => _LanguageViewState();
}

class _LanguageViewState extends State<LanguageView> {
  LanguageController languageController =Get.put(LanguageController());
  // LanguageController updatelanguageController =Get.put(LanguageController());

  Home_PageController home_pageController =
  Get.put(Home_PageController());
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    languageController.LanguageAPICalling(Langauges_url);
  }

  @override
  Widget build(BuildContext context) {
    return GetBuilder<LanguageController>(
        builder: (languageController) {
          if (languageController.LanguageLoading.value) {
            return Center(child: CircularProgressIndicator());
          } else
            return languageController.Languagedata.length == 0?Text("No Language",)
                :Container(

              width: double.maxFinite,
      child: Stack(
        clipBehavior: Clip.none,
        children: [
                    AlertDialog(
                      icon: GestureDetector(
                          onTap: () {
                            Get.back();
                          },
                          child: Icon(Icons.close,color: Colors.black,)),
          iconPadding: EdgeInsets.only(left: 250,top: 10,),
          title: Text('Choose Your Language'),
                      content: Container(
                        width: double.maxFinite,
                        child: ListView.builder(
                          shrinkWrap: true,
                          itemCount: languageController.Languagedata.length,
                          itemBuilder: (context,index){
                            return GestureDetector(
                              child: Column(
                                children: [
                                  Container(
                                    padding:  EdgeInsets.all(8.0),
                                    decoration: BoxDecoration(
                                        border: Border.all(color: Colors.grey.shade200,width: 1)
                                    ),
                                    child: Row(
                                      mainAxisAlignment: MainAxisAlignment.start,
                                      children: [
                                        languageController.Languagedata[index]["name"] == "English" ? indiaFlag : spanishFlag,
                                        SizedBox(width: 20,),
                                        Text(languageController.Languagedata[index]["name"].toString(),
                                          style: TextStyle(fontWeight: FontWeight.w500,fontSize: 16.5,letterSpacing: 0.2) ,),
                                      ],
                                    ),
                                  ),
                                  SizedBox(height: 10,)
                                ],
                              ),
                              onTap: () async {

                                // print(languageController.Languagedata[index]['name'].toString());
                                Map<String, String> queryParams = {
                                  'code' :languageController.Languagedata[index]["code"].toString(),
                                };
                                String queryString = Uri(queryParameters: queryParams).query;
                                var change_language_url = ChangeLangauges_url + '?' + queryString;
                                print("change_language_url--->"+change_language_url.toString());
                                await languageController.ChangeLanguageAPICalling(change_language_url, Locale(languageController.Languagedata[index]["code"]));
                                // getlangauge(Locale(languageController.Languagedata[index]["code"].toString()));
                                // toastMsg(languageController.Languagedata[index]["code"].toString(), false);
                                sp!.setString("languagetype", languageController.Languagedata[index]["name"].toString());
                                sp!.setString("languagecode", languageController.Languagedata[index]["code"].toString());
                                Get.offAll(bottombar(bottom: widget.index));
                                // await  home_pageController.HomePageApiCalling(Home_url + "?type=${1}",true);
                                //  await home_pageController.HomePageLibalityApiCalling(Home_url + "?type=${2}",true);
                                // languageController.updateLanguage(Locale(languageController.Languagedata[index]["code"]));
                              },);
                          },
                        ),
                      ),
                    ),
                  ],
      ),
    );
          }
    );
  }

  getlangauge(Locale languagecode)async{
    print("change_language_url--->");
    Map<String, String> queryParams = {
      'code' :languagecode.toString(),
    };
    String queryString = Uri(queryParameters: queryParams).query;
    var change_language_url = ChangeLangauges_url + '?' + queryString;
    print("change_language_url--->"+change_language_url.toString());
    await languageController.ChangeLanguageAPICalling(change_language_url, languagecode);
    // languageController.ChangeLanguageAPICalling(Locale(languageController.Languagedata[index]["code"]));
  }
}
