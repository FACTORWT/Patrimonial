import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:urwealthpal/Constant/Api.dart';
import 'package:urwealthpal/Constant/Images.dart';
import 'package:urwealthpal/Constant/Spacing.dart';
import 'package:urwealthpal/Constant/colors.dart';
import 'package:urwealthpal/Screens/Family_Members/Controllers/familyMembersController.dart';
import 'package:urwealthpal/Screens/Family_Members/addFamilyMembers.dart';
import 'package:urwealthpal/Screens/Family_Members/updateFamilyMember.dart';
import 'package:urwealthpal/Screens/Manage_Assets/manage_assets.dart';

class shareAssets extends StatefulWidget {
  const shareAssets({Key? key}) : super(key: key);

  @override
  State<shareAssets> createState() => _shareAssetsState();
}

class _shareAssetsState extends State<shareAssets> {

  List shareAssetsList = [
    {
      "image": "assets/images/shareAss_Profile_image.png",
      "name": "David John",
      "relation": "Relations- ",
      "relation name": "Son",
      "assets no.": "No. of Assets- ",
      "number": "10",
    },
    {
      "image": "assets/images/shareAss_Profile_image.png",
      "name": "David John",
      "relation": "Relations-",
      "relation name": "Son",
      "assets no.": "No. of Assets-",
      "number": "10"
    }
  ];
  TextEditingController _searchController = TextEditingController();

  var getFamilyMembersController =Get.put(GetFamilyMembersController());

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    _searchController.text;
    getfamily(_searchController.text.toString());
    getdata();
  }
  getdata(){
    getFamilyMembersController. userName.clear();
    getFamilyMembersController.email.clear();
    getFamilyMembersController.mobile.clear();
    getFamilyMembersController.country.clear();
    getFamilyMembersController.state.clear();
    getFamilyMembersController.city.clear();
    getFamilyMembersController.pincode.clear();
    getFamilyMembersController.address.clear();
    getFamilyMembersController.dateInput.clear();
    getFamilyMembersController.password.clear();

    getFamilyMembersController.confirmPassword.clear();
    getFamilyMembersController. SelectedCountryName="Select Country";

    getFamilyMembersController.SelectedStateName="Select State";

    getFamilyMembersController.SelectedCityName="Select City";
  }
  getfamily(search)async{
    Map<String, String> queryParams = {
      que_search :search.toString(),
    };
    String queryString = Uri(queryParameters: queryParams).query;
    var Family_Members_url = Get_Family_Members_url + '?' + queryString;
    getFamilyMembersController.GetFamilyMembersAPICalling(Family_Members_url);
  }

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Scaffold(
      body: Column(
        children: [
          Container(
            height: 60,
            decoration: BoxDecoration(
              color: ContainerColor,
              border: Border.all(color: ContainerColor),
              borderRadius: BorderRadius.only(
                  bottomLeft: (Radius.circular(20)),
                  bottomRight: (Radius.circular(20))),
            ),
            child:   Padding(
              padding:  EdgeInsets.only(left: 20,right: 20,bottom: 15),
              child: Row(
                children: [
                  Expanded(
                    flex: 7,
                    child: TextFormField(
                      onTap: (){
                        // Navigator.push(context, MaterialPageRoute(builder:
                        //     (context)=> SearchBar()));
                      },
                      controller: _searchController,
                      decoration: InputDecoration(
                        filled: true,
                        fillColor: Colors.white,
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10),
                        ),
                        focusedBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(10),
                            borderSide:
                            BorderSide(width: 1, color: appPrimaryColor)),
                        suffixIcon: SearchIcon,
                        label: Text("search".tr),
                      ),
                    ),
                  ),
                  sizebox_width_5,
                  Expanded(
                    child: GestureDetector(
                      onTap: (){
                        Navigator.push(context,
                            MaterialPageRoute(builder: (context)=> AddFamilyMembers()));
                      },
                      child: Container(
                        height: 40,
                        decoration: BoxDecoration(
                            color: sidebarcontainerColor,
                            border: Border.all(
                              color: sidebarcontainerColor,
                            ),
                            borderRadius: BorderRadius.all(
                                Radius.circular(50))),
                        child: Icon(Icons.add , color: whiteColor,size: 25,),
                      ),
                    ),
                  )
                ],
              ),
            ),
          ),
          GetBuilder<GetFamilyMembersController>(
              builder: (getFamilyMembersController) {
                if(getFamilyMembersController.GetFamilyMembersLoading.value){
                  return Center(child: Container(
                      alignment: Alignment.center,
                      height: size.height*0.65,
                      child: CircularProgressIndicator()),);
                }
                else
                  return
                    getFamilyMembersController.GetFamilyMembersData.length==0?Center(child: Column(
                      children: [
                        Text("no_family_txt".tr),
                        GestureDetector(
                          onTap: (){
                            Navigator.push(context,
                                MaterialPageRoute(builder: (context) => AddFamilyMembers()));
                          },
                          child: Container(
                            width: 160,
                            height: 40,
                            decoration: BoxDecoration(
                              color: ContainerColor,
                              border: Border.all(color: ContainerColor),
                              borderRadius: BorderRadius.all(Radius.circular(8)),
                            ),
                            child: Center(
                              child: Text("Add Family Member",
                                textAlign: TextAlign.center,
                                style: TextStyle(
                                  color: whiteColor,
                                  fontSize: 15,),),
                            ),
                          ),
                        ),
                      ],
                    )):
                    ListView.builder(
                        itemCount: getFamilyMembersController.GetFamilyMembersData.length,
                        scrollDirection: Axis.vertical,
                        shrinkWrap: true,
                        physics: NeverScrollableScrollPhysics(),
                        itemBuilder: (BuildContext context, index) {
                          var familyMembersData = getFamilyMembersController.GetFamilyMembersData[index];
                          return Card(
                            elevation: 4,
                            child: Column(
                              children: [
                                Stack(
                                  children: [
                                    Row(
                                      children: [
                                        GestureDetector(
                                            onTap: () async {
                                              var update_result = await Navigator.push(context,
                                                  MaterialPageRoute(builder: (context) =>
                                                      UpdateFamilyMember(
                                                        id: familyMembersData["id"].toString(),)));
                                              if(update_result == 'success'){
                                                setState(() {
                                                  GetFamilyMembersController();
                                                });
                                              }
                                            },
                                            child: Icon(Icons.edit)),
                                        GestureDetector(
                                            onTap: ()async{
                                              showDialog(
                                                context: context,
                                                builder: (context) => new AlertDialog(
                                                  title:  Text('sure_title_txt'.tr),
                                                  content:  Text('delete'.tr),
                                                  actions: <Widget>[
                                                    new ElevatedButton(
                                                      onPressed: () => Navigator.of(context).pop(false),
                                                      child:  Text('no'.tr),
                                                    ),
                                                    ElevatedButton(
                                                      onPressed: () async{
                                                        var item__id =   getFamilyMembersController.GetFamilyMembersData[index]["id"].toString();

                                                        // var indexs = getFamilyMembersController.GetFamilyMembersData.indexWhere((element)=> element['id']==item__id);
                                                        setState(() {

                                                          getFamilyMembersController.GetFamilyMembersData.removeAt(index);

                                                          var parameter = "";
                                                          getFamilyMembersController.DeleteFamilyMemberApiCalling(Delete_familyMember_url +item__id.toString(),parameter);

                                                        });
                                                        // deletefromCart(item__id);
                                                        Navigator.of(context).pop(true);
                                                      },
                                                      child:  Text('yes'.tr),
                                                    ),
                                                  ],
                                                ),);

                                            },
                                            child: Icon(Icons.delete))
                                      ],
                                    ),
                                    Row(
                                      // mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                      children: [
                                        Padding(
                                          padding: EdgeInsets.only(top: 20,left: 15),
                                          child: Column(
                                            mainAxisAlignment: MainAxisAlignment.center,
                                            crossAxisAlignment: CrossAxisAlignment.start,
                                            children: [
                                              Image.network(familyMembersData["image"].toString(),
                                                  height: size.height * 0.15
                                              ),
                                            ],
                                          ),
                                        ),
                                        Padding(
                                          padding: EdgeInsets.only(left: 10),
                                          child: Column(
                                            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                            crossAxisAlignment: CrossAxisAlignment.start,
                                            children: [
                                              Padding(
                                                padding:  EdgeInsets.only(bottom: 8),
                                                child: Text(
                                                  familyMembersData["name"].toString(),
                                                  style: TextStyle(color: Namecolors, fontSize: 22),
                                                ),
                                              ),
                                              Padding(
                                                padding:  EdgeInsets.only(bottom: 8),
                                                child: Row(
                                                  // mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                                  children: [
                                                    Container(
                                                      width: size.width*0.2,
                                                      child: Text(
                                                        familyMembersData["relation"].toString(),
                                                        style:
                                                        TextStyle(color: Namecolors, fontSize: 15),
                                                      ),
                                                    ),

                                                    Text(
                                                      familyMembersData["relation name"].toString(),
                                                      style:
                                                      TextStyle(color: Namecolors, fontSize: 15),
                                                    ),
                                                  ],
                                                ),
                                              ),
                                              Row(
                                                children: [
                                                  Container(
                                                    // width: size.width*0.3,
                                                    child: Text(
                                                      familyMembersData["assets no."].toString(),
                                                      style:
                                                      TextStyle(color: Namecolors, fontSize: 15),
                                                    ),
                                                  ),
                                                  Text(
                                                    familyMembersData["number"].toString(),
                                                    style:
                                                    TextStyle(color: Namecolors, fontSize: 15),
                                                  ),
                                                ],
                                              ),
                                            ],
                                          ),
                                        ),
                                      ],
                                    ),
                                  ],
                                ),
                                Padding(
                                  padding:  EdgeInsets.fromLTRB(10, 10, 10, 10),
                                  child: Row(children: [
                                    Expanded(
                                      child: Container(
                                        height: 40,
                                        decoration: BoxDecoration(
                                            border:Border.all(color: appPrimaryColor),
                                            borderRadius: BorderRadius.all(Radius.circular(8))
                                        ),
                                        child: Center(
                                          child: Text("permission_txt".tr,
                                            textAlign: TextAlign.center,
                                            style: TextStyle(
                                              color:Namecolors,
                                              fontSize: 15,
                                            ),),
                                        ),
                                      ),
                                    ),
                                    Expanded(
                                      child: GestureDetector(
                                        onTap: (){
                                          Navigator.push(context, MaterialPageRoute(
                                              builder: (context) => manage_assets()));
                                        },
                                        child: Container(
                                          margin:  EdgeInsets.only(left: 10),
                                          height: 40,
                                          decoration: BoxDecoration(
                                              color: appPrimaryColor,
                                              border:Border.all(color: appPrimaryColor),
                                              borderRadius: BorderRadius.all(Radius.circular(8))
                                          ),
                                          child: Center(
                                            child: Text("manageAss_tx".tr,
                                              textAlign: TextAlign.center,
                                              style: TextStyle(
                                                color: whiteColor,
                                                fontSize: 15,),),
                                          ),
                                        ),
                                      ),
                                    )
                                  ]
                                  ),
                                ),
                              ],
                            ),
                          );
                        });
              }
          ),
        ],
      ),
    );
  }
}
