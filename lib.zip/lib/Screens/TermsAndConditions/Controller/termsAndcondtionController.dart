import 'dart:convert';
import 'package:get/get.dart';
import 'package:urwealthpal/Constant/ApiBaseHelper.dart';

class TermsAndConditionController extends GetxController{
  var loading = false.obs;
  var TermsCondtiondata ;
  Aboutfetch(url) async {
    loading.value =true;

    print("cmsurl : " + url.toString());
    var response = await ApiBaseHelper().getAPICall(Uri.parse(url), true);
    var responsedata = jsonDecode(response.body);
    if(response.statusCode==200){
      TermsCondtiondata = responsedata['data'];
      loading.value =false;
      update();
    }else{
      TermsCondtiondata =[];
      loading.value =false;
      update();
    }
  }

}