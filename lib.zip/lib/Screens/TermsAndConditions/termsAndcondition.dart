import 'package:flutter/material.dart';
import 'package:flutter_html/flutter_html.dart';
import 'package:get/get.dart';
import 'package:urwealthpal/Constant/Api.dart';
import 'package:urwealthpal/Constant/colors.dart';
import 'package:urwealthpal/Screens/TermsAndConditions/Controller/termsAndcondtionController.dart';

class termsAndcondition extends StatefulWidget {
  const termsAndcondition({Key? key}) : super(key: key);

  @override
  State<termsAndcondition> createState() => _termsAndconditionState();
}

class _termsAndconditionState extends State<termsAndcondition> {
  var termsAndcondtionController = Get.put(TermsAndConditionController());

  List terms = [
    {
      "text": "Lorem ipsum is simple dummy text.",
    },
    {
      "text": "Lorem ipsum is simple dummy text of the printing and typesetting industry.",
    },
    {
      "text": "Lorem ipsum is simple dummy text.",
    },
    {
      "text": "Lorem ipsum is simple dummy text.",
    },
    {
      "text": "Lorem ipsum is simple dummy text.",
    },
    {
      "text": "Lorem ipsum is simple dummy text.",
    },
    {
      "text": "Lorem ipsum is simple dummy text.",
    },
    {
      "text": "Lorem ipsum is simple dummy text.",
    },
    {
      "text": "Lorem ipsum is simple dummy text.",
    },
  ];

  @override
  void initState() {
    // TODO: implement initState
    termsAndcondtionController.Aboutfetch("${cms_url}3");
    super.initState();
  }
  @override
  Widget build(BuildContext context) {
    return RefreshIndicator(
      onRefresh: () async {
        await TermsAndConditionController();
        await Future.delayed(Duration(milliseconds: 1500));
      },
      child: Scaffold(
        appBar: AppBar(
          elevation: 0,
          titleSpacing: 0,
          backgroundColor: ContainerColor,
          title: Text("terms_Condition_txt".tr),
        ),
        body: GetBuilder<TermsAndConditionController>(
          builder: (termsAndcondtionController) {
            if(termsAndcondtionController.loading.value){
              return Center(child: CircularProgressIndicator(),);
            }
            else
            return SingleChildScrollView(
              physics: AlwaysScrollableScrollPhysics(),
              child: Column(children: [
                Padding(
                  padding:  EdgeInsets.only(left: 10,right: 10),
                  child: Html(data: termsAndcondtionController.TermsCondtiondata['cms_contant'],),
                ),
                // ListView.builder(
                //     itemCount: terms.length,
                //     scrollDirection: Axis.vertical,
                //     shrinkWrap: true,
                //     physics: NeverScrollableScrollPhysics(),
                //     itemBuilder: (BuildContext context, index) {
                //       var listdata = terms[index];
                //       return Padding(
                //         padding: EdgeInsets.fromLTRB(10, 2, 10, 0),
                //         child: Column(
                //           children: [
                //             Row(
                //               children: [
                //                 Text(
                //                   '\u2022',
                //                   style: TextStyle(fontSize: 20,
                //                   color: greyColor),
                //                 ),
                //                 SizedBox(
                //                   width: 10,
                //                 ),
                //                 Expanded(
                //                   child: Text(
                //                     listdata['text'].toString(),
                //                     textAlign: TextAlign.justify,
                //                     style: TextStyle(color: greyColor),
                //                   ),
                //                 )
                //               ],
                //             ),
                //           ],
                //         ),
                //       );
                //     }),
                // Padding(
                //   padding:  EdgeInsets.fromLTRB(10, 20, 10, 20),
                //   child: Text(
                //     bottom_txt,
                //     textAlign: TextAlign.justify,
                //     style: TextStyle(color: greyColor, ),
                //   ),
                // ),
              ]),
            );
          }
        ),
      ),
    );

  }
}
