import 'dart:async';
import 'dart:convert';
import 'dart:developer';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:urwealthpal/Constant/Api.dart';
import 'package:urwealthpal/Constant/ApiBaseHelper.dart';
import 'package:urwealthpal/Constant/colors.dart';
import 'package:urwealthpal/Environment/Environment.dart';
import 'package:urwealthpal/Screens/Profile/ProfileControllers/Get_Profile_Controller.dart';
import 'package:urwealthpal/main.dart';
import 'package:http/http.dart' as http;

class editProfile extends StatefulWidget {
  const editProfile({Key? key}) : super(key: key);

  @override
  State<editProfile> createState() => _editProfileState();
}

class _editProfileState extends State<editProfile> {
  var _formKey = GlobalKey<FormState>();

  bool passToogle = true;
  bool passToogles = true;

  GetProfileController profileController =Get.put(GetProfileController());

  List country_list=[];
  // List state_list=[];
  // List city_list=[];

  Future<http.Response> multipartAPICall(url, parameter) async {
    print("post url : $url");
    print("post parameter : $parameter");

    var jsondata = json.decode(sp!.getString("loginresponse").toString());
    print("data: "+jsondata.toString());
    var token =jsondata['data']['access_token'];

    print("get token : $token");
    Map<String, String> mainHeaders = {
      Environment.appxapikey.toString(): Environment.appxapivalue.toString(),
      'Content-Type': 'application/json',
      'Authorization': 'Bearer $token'
    };
    try {
      final request = http.MultipartRequest('POST', Uri.parse(url));
      request.fields.addAll(parameter);

      request.headers.addAll(mainHeaders);

      if (profileController.pickfile != null) {
        request.files.add(await http.MultipartFile.fromPath('image',profileController.pickfile!.path));
      } else {

      }

      http.StreamedResponse responses = await request.send();

      var responsedata = await http.Response.fromStream(responses);
      print("edit profile response body...."+responsedata.toString());

     var dat = jsonDecode(responsedata.body);
      if(responsedata.statusCode == 200){
        Get.find<GetProfileController>().GetProfileApiCalling(Get_profile_url);
        Get.back();

        toastMsg(dat['message'], true);

      }
      else if(responsedata.statusCode == 403){
        if(dat['error'] != null){
          dat['error'].forEach((k,v){
            log("Key :$k");
            log("Value :${v.join(" ")}");
            toastMsg("${v.join(" ")}", false);
          });
        }
      }

      print("post statusCode : ${responsedata.statusCode.toString()}");

      print("post response : ${responsedata.body.toString()}");

      return responsedata;
    } on SocketException {
      throw FetchDataException('No Internet connection');
    } on TimeoutException {
      throw FetchDataException('Something went wrong, try again later');
    }
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    getcallprofile();
  }

  getcallprofile() async {
    log("1");
      await  profileController.GetProfileApiCalling(Get_profile_url);
        log("4");
      profileController.SelectedCountryName = profileController.getProfiledata[0]['country_name']== null? null:
      profileController.getProfiledata[0]['country_name'].toString();
      log("1 country_name ${profileController.getProfiledata[0]['country_name'].toString()}");
      profileController.SelectedCountryId=profileController.getProfiledata[0]['country_id']== null?null:
      profileController.getProfiledata[0]['country_id'].toString();
      // log("1 country_id${profileController.getProfiledata[0]['country_id'].toString()}");
      // profileController. SelectedStateName= profileController.getProfiledata[0]['state_name']== null?null:
      // profileController.getProfiledata[0]['state_name'].toString();
      //   log("1 state_name${profileController.getProfiledata[0]['state_name'].toString()}");
      // profileController.SelectedStateId= profileController.getProfiledata[0]['state_id']== null?null:
      // profileController.getProfiledata[0]['state_id'].toString();
      //   log("1 state_id${profileController.getProfiledata[0]['state_id'].toString()}");
      // profileController.SelectedCityName= profileController.getProfiledata[0]['city_name']== null?null:
      // profileController.getProfiledata[0]['city_name'].toString();
      //   log("1${profileController.getProfiledata[0]['city_name'].toString()}");
      // profileController.SelectedCityId= profileController.getProfiledata[0]['city_id']== null?null:
      // profileController.getProfiledata[0]['city_id'].toString();
      //   log("1${profileController.getProfiledata[0]['city_id'].toString()}");
    log("country > ${profileController. SelectedCountryName} /${profileController. SelectedCountryId}");
    // log("state > ${profileController. SelectedStateName} /${profileController. SelectedStateId}");
    // log("city > ${profileController. SelectedCityName} /${profileController. SelectedCityId}");
    fetchCountry();
    profileController.imagenull();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          elevation: 0,
          titleSpacing: 0,
          backgroundColor: ContainerColor,
          title: Text("editProfile_txt".tr),
        ),
      body: GetBuilder<GetProfileController>(
        builder: (profileController) {
          return SingleChildScrollView(
            physics: AlwaysScrollableScrollPhysics(),
            child: Form(
              key: _formKey,
              child: Padding(
                padding: EdgeInsets.fromLTRB(0, 40, 0, 0),
                child: Column(
                    children: [
                      Stack(
                        children: [
                          // CircleAvatar(
                          //   backgroundColor: buttonColor,
                          //   radius: 50,
                          //   child: CircleAvatar(
                          //     radius: 50-5 ,
                          //     backgroundImage:
                          //     // ignore: unnecessary_null_comparison
                          //     profileController.pickfile!=null?
                          //     Image.file(
                          //       File( profileController.pickfile!.path.toString()),
                          //       fit: BoxFit.contain,
                          //     ).image
                          //         :NetworkImage(profileController.image.toString()),
                          //   ),
                          // ),
                          Container(
                            height: 100,
                            width: 100,
                            decoration: BoxDecoration(
                              color: ContainerColor,
                              image: DecorationImage(
                                  image:  profileController.pickfile!=null?
                                  Image.file(
                                    File( profileController.pickfile!.path.toString(),),
                                    fit: BoxFit.fill,
                                  ).image
                                      :NetworkImage(profileController.image.toString(),),
                              ),
                              border: Border.all(width: 5,
                                color: buttonColor,
                              ),
                              borderRadius: BorderRadius.all(Radius.circular(90)),
                            ),
                            // child: profilePageImage,
                          ),
                          Positioned(
                            bottom: 5,
                            right: 2,
                            child: InkWell(
                              onTap: (){
                                sp?.setString('imageselection', 'false');
                                profileController.getFromGallery();
                              },
                              child: Container(
                                height: 30,
                                width: 30,
                                decoration: BoxDecoration(
                                    color: whiteColor,
                                    border: Border.all(
                                      color: whiteColor,
                                    ),
                                    borderRadius: BorderRadius.all(Radius.circular(20))
                                ),
                                child: Icon(Icons.edit,color: Color(0xFF939292),size: 18,
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                      Text("editProfile_txt".tr,
                        style: TextStyle(
                          color: ContainerColor,
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                        ),
                      ),

                      Padding(
                        padding:  EdgeInsets.fromLTRB(10, 20, 10, 0),
                        child: TextFormField(
                          controller: profileController.userName,
                          autovalidateMode:
                          AutovalidateMode.onUserInteraction,
                          validator: (value) {
                            if (value == null) {
                              return "validUserName_txt".tr;
                            }
                            if (value.length < 3) {
                              return "validLength_UserName_txt".tr;
                            }
                            return null;
                          },
                          keyboardType: TextInputType.name,
                          textInputAction: TextInputAction.next,
                          decoration: InputDecoration(
                            filled: true,
                            fillColor: whiteColor,
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(10),
                            ),
                            enabledBorder: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(10),
                                borderSide: BorderSide( width: 1, color: appPrimaryColor)
                            ),
                            focusedBorder: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(10),
                                borderSide: BorderSide( width: 1, color: appPrimaryColor)
                            ),
                            // labelText: 'Your Name',
                            prefixIcon: Container(
                              // color: Colors.redAccent,
                              child: Image.asset("assets/images/user.png",scale: 3,width: 15,),
                            ),
                            hintText: "userName_txt".tr,
                          ),
                        ),
                      ),

                      Padding(
                        padding:  EdgeInsets.fromLTRB(10, 10, 10, 0),
                        child: TextFormField(
                          controller: profileController.email,
                          autovalidateMode:
                          AutovalidateMode.onUserInteraction,
                          validator: (value) {
                            if (value == null) {
                              return "valid_Email_txt".tr;
                            }
                            if (value == null ||
                                value.isEmpty ||
                                !value.contains('@') ||
                                !value.contains('.')) {
                              return "validLength_Email_txt".tr;
                            }
                            return null;
                          },
                          keyboardType: TextInputType.emailAddress,
                          textInputAction: TextInputAction.next,
                          decoration: InputDecoration(
                            filled: true,
                            fillColor: whiteColor,
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(10),
                            ),
                            enabledBorder: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(10),
                                borderSide: BorderSide( width: 1, color: appPrimaryColor)
                            ),
                            focusedBorder: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(10),
                                borderSide: BorderSide( width: 1, color: appPrimaryColor)
                            ),
                            // labelText: 'Your Name',
                            prefixIcon: Container(
                              // color: Colors.redAccent,
                                child: Image.asset("assets/images/email (1).png",scale: 3,width: 15,)),
                            hintText: "emailId_txt".tr,
                          ),
                        ),
                      ),

                      Padding(
                        padding:  EdgeInsets.fromLTRB(10, 10, 10, 0),
                        child: TextFormField(
                          controller: profileController.mobile,
                          inputFormatters: [FilteringTextInputFormatter.allow(RegExp('[0-9]'))],
                          keyboardType: TextInputType.numberWithOptions(decimal: true),
                          autovalidateMode:
                          AutovalidateMode.onUserInteraction,
                          validator: (value) {
                            if (value == null) {
                              return "valid_Mobile_No_txt".tr;
                            }
                            if (value.length == 0) {
                              return "valid_Mobile_No_txt".tr;
                              // return "validLengthMobile_No_txt".tr;
                            }
                            return null;
                          },
                          textInputAction: TextInputAction.next,
                          decoration: InputDecoration(
                            filled: true,
                            fillColor: whiteColor,
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(10),
                            ),
                            enabledBorder: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(10),
                                borderSide: BorderSide( width: 1, color: appPrimaryColor)
                            ),
                            focusedBorder: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(10),
                                borderSide: BorderSide( width: 1, color: appPrimaryColor)
                            ),
                            prefixIcon: Container(
                              // color: Colors.redAccent,
                              child: Image.asset("assets/images/phoneIcon.png",scale: 3.5,width: 15,),
                            ),
                            hintText: "mobileNo_txt".tr,
                          ),
                        ),
                      ),

                      Padding(
                        padding:  EdgeInsets.fromLTRB(10, 10, 10, 0),
                        child: DropdownButtonFormField(
                          isExpanded: true,
                          validator: ((val) {
                            if (val == null) {
                              return "SelectCountry".tr;
                            }
                          }),
                          decoration: InputDecoration(
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(10),
                            ),
                            enabledBorder: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(10),
                                borderSide: BorderSide( width: 1, color: appPrimaryColor)
                            ),
                            focusedBorder: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(10),
                                borderSide: BorderSide( width: 1, color: appPrimaryColor)
                            ),
                            labelStyle: TextStyle(color: Colors.grey,fontSize: 16),
                            filled: true,
                              prefixIcon: Container(
                                // color: Colors.redAccent,
                                child:
                                Image.asset("assets/images/cityIcon.png",
                                  color: Color(0xFF37BCF9),
                                  scale: 2.6,width: 15,),
                              ),
                            hintStyle: TextStyle(color: Colors.black),
                            hintText:
                              "Select Country"?? profileController.SelectedCountryName.toString(),
                            fillColor: Colors.transparent,
                          ),
                          value: profileController.SelectedCountryName,
                          items: country_list.map((explist) {

                            return DropdownMenuItem(
                              value: explist['name'],
                              child: Text(explist['name']),
                              onTap: () {
                                setState(() {
                                  profileController.SelectedCountryId = explist['id'];
                                  profileController.SelectedCountryName = explist['name'];
                                });
                              },
                            );
                          }).toList(),
                          onChanged: (value) async {
                            setState(() {
                              profileController.SelectedCountryName = value;
                              log("OnSelect> SelectedCountryName...."+profileController.SelectedCountryName.toString() );
                              log("OnSelect> SelectedCountryId...."+profileController.SelectedCountryId.toString() );

                              if (profileController.SelectedCountryId == 0) {
                                profileController.SelectedCountryName = null;
                                profileController.SelectedCountryId = null;
                              }
                            });
                            // profileController.SelectedStateId = null;
                            // profileController.SelectedStateName = null;
                            // profileController.SelectedCityId = null;
                            // profileController.SelectedCityName = null;
                            // await fetchState(profileController.SelectedCountryId.toString());
                          },
                        ),
                      ),

                      // Padding(
                      //   padding:  EdgeInsets.fromLTRB(10, 10, 10, 0),
                      //   child: DropdownButtonFormField(
                      //     isExpanded: true,
                      //     validator: ((val) {
                      //       if (val == null) {
                      //         return "SelectState".tr;
                      //       }
                      //     }),
                      //     decoration: InputDecoration(
                      //       //  labelText: "Select State",
                      //       border: OutlineInputBorder(
                      //         borderRadius: BorderRadius.circular(10),
                      //       ),
                      //       enabledBorder: OutlineInputBorder(
                      //           borderRadius: BorderRadius.circular(10),
                      //           borderSide: BorderSide( width: 1, color: appPrimaryColor)
                      //       ),
                      //       focusedBorder: OutlineInputBorder(
                      //           borderRadius: BorderRadius.circular(10),
                      //           borderSide: BorderSide( width: 1, color: appPrimaryColor)
                      //       ),
                      //       labelStyle: TextStyle(color: Colors.grey,fontSize: 16),
                      //       filled: true,
                      //       prefixIcon: Container(
                      //         // color: Colors.redAccent,
                      //         child:
                      //         Image.asset("assets/images/cityIcon.png",
                      //           color: Color(0xFF37BCF9),
                      //           scale: 2.6,width: 15,),
                      //       ),
                      //       hintStyle:
                      //       TextStyle(color: Colors.black),
                      //       hintText: "hintState_txt".tr,
                      //       fillColor: Colors.transparent,
                      //     ),
                      //     value: profileController.SelectedStateName ,
                      //     items: state_list.map((explist) {
                      //
                      //       return DropdownMenuItem(
                      //         value: explist['name'],
                      //         child: Text(explist['name']),
                      //         onTap: () {
                      //           setState(() {
                      //             profileController.SelectedStateId = explist['id'];
                      //           });
                      //         },
                      //       );
                      //     }).toList(),
                      //     onChanged: (value) async {
                      //       setState(() {
                      //         // SelectedStateNAme = value;
                      //         profileController.SelectedStateName = value;
                      //         if (profileController.SelectedStateId == 0) {
                      //           profileController.SelectedStateId = null;
                      //           profileController.SelectedStateName = null;
                      //         }
                      //       });
                      //       profileController.SelectedCityId = null;
                      //       profileController.SelectedCityName = null;
                      //       await fetchCity(profileController.SelectedStateId.toString());
                      //     },
                      //   ),
                      // ),
                      //
                      // Padding(
                      //   padding:  EdgeInsets.fromLTRB(10, 10, 10, 0),
                      //   child: DropdownButtonFormField(
                      //     isExpanded: true,
                      //     validator: ((val) {
                      //       if (val == null) {
                      //         return "SelectCity".tr;
                      //       }
                      //     }),
                      //     decoration: InputDecoration(
                      //       border: OutlineInputBorder(
                      //         borderRadius: BorderRadius.circular(10),
                      //       ),
                      //       enabledBorder: OutlineInputBorder(
                      //           borderRadius: BorderRadius.circular(10),
                      //           borderSide: BorderSide( width: 1, color: appPrimaryColor)
                      //       ),
                      //       focusedBorder: OutlineInputBorder(
                      //           borderRadius: BorderRadius.circular(10),
                      //           borderSide: BorderSide(width: 1, color: appPrimaryColor)
                      //       ),
                      //       labelStyle: TextStyle(color: Colors.grey,fontSize: 16),
                      //       filled: true,
                      //       prefixIcon: Container(
                      //         // color: Colors.redAccent,
                      //         child:
                      //         Image.asset("assets/images/cityIcon.png",
                      //           color: Color(0xFF37BCF9),
                      //           scale: 2.6,width: 15,),
                      //       ),
                      //       hintStyle:
                      //       TextStyle(color: Colors.black),
                      //       hintText:  "hintCity_txt".tr,
                      //       fillColor: Colors.transparent,
                      //     ),
                      //     value: profileController.SelectedCityName ,
                      //     items: city_list.map((explist) {
                      //
                      //       return DropdownMenuItem(
                      //         value: explist['name'],
                      //         child: Text(explist['name']),
                      //         onTap: () {
                      //           setState(() {
                      //             profileController.SelectedCityId = explist['id'];
                      //           });
                      //         },
                      //       );
                      //     }).toList(),
                      //     onChanged: (value) {
                      //       setState(() {
                      //         profileController.SelectedCityName = value;
                      //         if (profileController.SelectedCityId == 0) {
                      //           profileController.SelectedCityId = null;
                      //         }
                      //       });
                      //     },
                      //   ),
                      // ),

                      Padding(
                        padding: EdgeInsets.only(left: 10, right: 10, top: 40),
                        child: GestureDetector(
                          onTap: () async {
                            if (_formKey.currentState!.validate()) {
                              var updateProfile_url = update_profile_url;
                              var body=
                              {
                                'name' : profileController.userName.text,
                                'email' : profileController.email.text,
                                'mobile' : profileController.mobile.text,
                                'country_id' : profileController.SelectedCountryId.toString(),
                                // 'state_id' : profileController.SelectedStateId.toString(),
                                // 'city_id' : profileController.SelectedCityId.toString()
                              };
                              multipartAPICall(updateProfile_url, body);
                              print('update profile Response......${updateProfile_url}'.toString());
                            }
                          },
                          child: Container(
                            width: 150,
                            height: 40,
                            decoration: BoxDecoration(
                              color: ContainerColor,
                              border: Border.all(color: ContainerColor),
                              borderRadius: BorderRadius.all(Radius.circular(8)
                              ),
                            ),
                            child: Center(
                              child: Text("save_txt".tr,
                                style: TextStyle(
                                  color: whiteColor,
                                  fontSize: 20
                              ),),
                            ),
                          ),
                        ),
                      ),
                    ]
                ),
              ),
            ),
          );
        }
      ),
    );
  }

  Future<void> fetchCountry() async {
    var countryUrl = Uri.parse(Country_url);
    print("countryUrl--> " + countryUrl.toString());
    var response = await ApiBaseHelper().getAPICall(countryUrl, true);
    var CountryData = jsonDecode(response.body);
    if (response.statusCode == 200) {
      setState(() {
        country_list.clear();
        country_list.addAll(CountryData['data']);
        // if(profileController.SelectedCountryId!=null){
        //   fetchState(profileController.SelectedCountryId);
        // }else{
        //
        // }
      });
    }
  }

  // Future<void> fetchState(countryId) async {
  //   state_list.clear();
  //   var stateUrl = Uri.parse(State_url + countryId);
  //   log("fetchState Url--> " + stateUrl.toString());
  //   var response = await ApiBaseHelper().getAPICall(stateUrl, true);
  //   var StateData = jsonDecode(response.body);
  //   if (response.statusCode == 200) {
  //     setState(() {
  //       state_list.addAll(StateData['data']);
  //       log("SelectedStateId--> " + profileController.SelectedStateId.toString());
  //       log("state_list--> " + state_list.toString());
  //       if(profileController.SelectedStateId!=null){
  //         fetchCity(profileController.SelectedStateId);
  //       }else{
  //
  //       }
  //     });
  //   }else{
  //     state_list=[];
  //     setState(() {
  //       profileController.SelectedStateId = null;
  //       profileController.SelectedStateName = null;
  //     });
  //   }
  // }
  //
  // Future<void> fetchCity(state_id) async {
  //   city_list.clear();
  //   var cityUrl = Uri.parse(City_url + state_id);
  //
  //   print("cityurl : " + cityUrl.toString());
  //   var response = await ApiBaseHelper().getAPICall(cityUrl, true);
  //   var CityData = jsonDecode(response.body);
  //   if (response.statusCode == 200) {
  //     setState(() {
  //
  //       city_list.addAll(CityData['data']);
  //       log("SelectedCityId--> " + profileController.SelectedCityId.toString());
  //       log("city_list--> " + city_list.toString());
  //     });
  //   }else{
  //     city_list=[];
  //     setState(() {
  //       profileController.SelectedCityId = null;
  //       profileController.SelectedCityName = null;
  //     });
  //   }
  // }

}