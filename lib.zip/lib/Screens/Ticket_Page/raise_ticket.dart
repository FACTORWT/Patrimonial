import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:urwealthpal/Constant/Api.dart';
import 'package:urwealthpal/Constant/Strings.dart';
import 'package:urwealthpal/Constant/colors.dart';
import 'package:urwealthpal/Screens/Ticket_Page/Controllers/Raise_Ticket_Controller.dart';
import 'package:urwealthpal/Screens/Ticket_Page/Controllers/Ticket_Categories_Controller.dart';
import 'package:urwealthpal/main.dart';

class raise_ticket extends StatefulWidget {
  const raise_ticket({Key? key}) : super(key: key);

  @override
  State<raise_ticket> createState() => _raise_ticketState();
}

class _raise_ticketState extends State<raise_ticket> {

  var _formKey = GlobalKey<FormState>();

  RaiseTicketController raiseTicketController =
      Get.put(RaiseTicketController()); //PostAPI

  Ticket_CategoriesController ticketCategoriesController =
      Get.put(Ticket_CategoriesController()); //GetAPI

  var setting_json_data;

  List prio_list = [];
  var prioName;
  var prioId;

  var catName;
  var catId;

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    prio_list.clear();
    setting_json_data = json.decode(sp!.getString("setting").toString());
    print("check ticket_priorities " +
        setting_json_data['data']['ticket_priorities'].toString());
    setting_json_data['data']['ticket_priorities'][0].forEach((k, v) {
      prio_list.add({"id": k, "name": v});

      ticketCategoriesController.TicketCategoriesApiCalling(
          Ticket_Categories_url);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      resizeToAvoidBottomInset: false,
      appBar: AppBar(
        title: Text("raise_txt".tr),
        backgroundColor: ContainerColor,
        elevation: 0,
        titleSpacing: 0,
      ),
      body: GetBuilder<Ticket_CategoriesController>(
          builder: (ticketCategoriesController) {
        if (ticketCategoriesController.Ticket_Categories_Loading.value) {
          return Center(child: CircularProgressIndicator());
        } else
          return Form(
            key: _formKey,
            child: Column(
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    Container(
                        margin: EdgeInsets.only(left: 20, top: 20),
                        width: 100,
                        child: Text(
                          "category_id_txt".tr,
                          style: TextStyle(
                              color: Colors.black,
                              fontSize: 15,
                              fontWeight: FontWeight.bold),
                        )),
                  ],
                ),
                Padding(
                  padding: EdgeInsets.fromLTRB(20, 10, 20, 0),
                  child: DropdownButtonFormField(
                      validator: ((value) {
                        if (value == null) {
                          return "valid_priority_txt".tr;
                        }
                      }),
                      value: catName,
                      decoration: InputDecoration(
                        border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(10),
                            borderSide:
                                BorderSide(width: 1, color: appPrimaryColor)),
                        enabledBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(10),
                            borderSide:
                                BorderSide(width: 1, color: Colors.black)),
                        focusedBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(10),
                            borderSide:
                                BorderSide(width: 1, color: appPrimaryColor)),
                        filled: true,
                        contentPadding: EdgeInsets.only(top: 5, left: 10),
                        constraints: BoxConstraints(minWidth: 30, maxHeight: 70),
                        hintStyle: TextStyle(color: Colors.grey),
                        hintText: "select_category_txt".tr,
                        fillColor: Colors.white,
                      ),
                      items: ticketCategoriesController.TicketCategoriesData.map(
                          (explist) {
                        print("array " + explist.toString());
                        return DropdownMenuItem(
                          value: explist['name'],
                          child: Text(explist['name']),
                          onTap: () {
                            setState(() {
                              catName = explist['name'];
                              catId = explist['id'];
                            });
                          },
                        );
                      }).toList(),
                      onChanged: (v) {
                        setState(() {
                          catName == v;
                          print("v....${v}."+catId.toString());
                          print("v2....${v}."+catName.toString());
                          if (catId == 0) {
                            catId = null;
                          }
                        });
                      }),
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    Container(
                        margin: EdgeInsets.only(left: 20, top: 20),
                        width: 100,
                        child: Text(
                          "subject_txt".tr,
                          style: TextStyle(
                              color: Colors.black,
                              fontSize: 15,
                              fontWeight: FontWeight.bold),
                        )),
                  ],
                ),
                Padding(
                  padding: EdgeInsets.fromLTRB(20, 10, 20, 0),
                  child: TextFormField(
                    maxLines: 10,
                    controller: raiseTicketController.subject,
                    autovalidateMode: AutovalidateMode.onUserInteraction,
                    scrollPadding: EdgeInsets.only(
                        bottom:
                            MediaQuery.of(context).viewInsets.bottom + 25 * 4),
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return "valid_sub".tr;
                      }
                      return null; // Validation passed
                    },
                    keyboardType: TextInputType.name,
                    textInputAction: TextInputAction.next,
                    decoration: InputDecoration(
                      hintText: "hintSubject_txt".tr,
                      filled: true,
                      fillColor: Colors.white,
                      border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10),
                          borderSide:
                              BorderSide(width: 1, color: appPrimaryColor)),
                      enabledBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10),
                          borderSide: BorderSide(width: 1, color: Colors.black)),
                      focusedBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10),
                          borderSide:
                              BorderSide(width: 1, color: appPrimaryColor)),
                    ),
                  ),
                ),
                Row(
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    Container(
                        margin: EdgeInsets.only(left: 20, top: 20),
                        width: 100,
                        child: Text(
                          "priority_txt".tr,
                          style: TextStyle(
                              color: Colors.black,
                              fontSize: 15,
                              fontWeight: FontWeight.bold),
                        )),
                  ],
                ),
                Padding(
                  padding: EdgeInsets.fromLTRB(20, 10, 20, 0),
                  child: DropdownButtonFormField(
                      validator: ((value) {
                        if (value == null) {
                          return "valid_priority_txt".tr;
                        }
                      }),
                      value: prioName,
                      decoration: InputDecoration(
                        border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(10),
                            borderSide:
                                BorderSide(width: 1, color: appPrimaryColor)),
                        enabledBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(10),
                            borderSide:
                                BorderSide(width: 1, color: Colors.black)),
                        focusedBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(10),
                            borderSide:
                                BorderSide(width: 1, color: appPrimaryColor)),
                        filled: true,
                        contentPadding: EdgeInsets.only(top: 5, left: 10),
                        constraints: BoxConstraints(minWidth: 30, maxHeight: 70),
                        hintStyle: TextStyle(color: Colors.grey),
                        hintText: "select_priority_txt".tr,
                        fillColor: Colors.white,
                      ),
                      items: prio_list.map((explist) {
                        print("array " + explist.toString());
                        return DropdownMenuItem(
                          value: explist['name'],
                          child: Text(explist['name']),
                          onTap: () {
                            setState(() {
                              prioName = explist['name'];
                              prioId = explist['id'];
                            });
                          }
                        );
                      }).toList(),
                      onChanged: (v) {
                        setState(() {
                          prioName == v;
                          print("p....${v}."+prioId.toString());
                          print("p2....${v}."+prioName.toString());
                          if (prioId == 0) {
                            prioId = null;
                          }
                        });
                      }
                  ),
                ),

                GestureDetector(
                  onTap: () {
                    if (_formKey.currentState!.validate()){
                      var raiseTicketUrl = Raise_Ticket_url;
                      var body = ({
                        'category_id' : catId.toString(),
                        'subject' : raiseTicketController.subject.text,
                        'priority' : prioId.toString()
                      });
                      raiseTicketController.RaiseTicketApiCalling(
                          raiseTicketUrl, body);
                    }
                  },
                  child: Container(
                    margin: EdgeInsets.only(top: 40),
                    height: 40,
                    width: 150,
                    decoration: BoxDecoration(
                        color: buttonColor,
                        border: Border.all(
                          color: buttonColor,
                        ),
                        borderRadius: BorderRadius.all(Radius.circular(12))),
                    child: Center(
                      child: Text(
                        "submitBtn".tr,
                        style: TextStyle(
                            color: whiteColor,
                            fontSize: 16,
                            fontWeight: FontWeight.bold),
                      ),
                    ),
                  ),
                ),
              ],
            ),
          );
      }),
    );
  }
}

