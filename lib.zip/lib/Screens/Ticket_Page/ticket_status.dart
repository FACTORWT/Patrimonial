import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:urwealthpal/BottomBar/searchBar.dart';
import 'package:urwealthpal/Constant/Api.dart';
import 'package:urwealthpal/Constant/Images.dart';
import 'package:urwealthpal/Constant/Strings.dart';
import 'package:urwealthpal/Constant/colors.dart';
import 'package:urwealthpal/Screens/Ticket_Page/Controllers/GetTicket_Controller.dart';
import 'package:urwealthpal/Screens/Ticket_Page/Controllers/Post_Ticket_Controller.dart';
import 'package:urwealthpal/Screens/Ticket_Page/raise_ticket.dart';
import 'package:urwealthpal/Screens/Ticket_Page/ticket_chat.dart';

class ticket_status extends StatefulWidget {
  const ticket_status({Key? key}) : super(key: key);

  @override
  State<ticket_status> createState() => _ticket_statusState();
}

class _ticket_statusState extends State<ticket_status> {
  TextEditingController _searchController = TextEditingController();

  List topBar = [
    {
      "text": "All",
    },
    {
      "text": "Open",
    },
    {
      "text": "Close",
    },
  ];
  int current = 0;

  // List TicketList = [
  //   {
  //     "ticket": "Ticket No. - ",
  //     "ticket No.": "4582620",
  //     "statusName": "Status -  ",
  //     "status": "Completed",
  //     "date": "  12/01/2023"
  //   },
  //   {
  //     "ticket": "Ticket No. - ",
  //     "ticket No.": "4582620",
  //     "statusName": "Status -  ",
  //     "status": "Completed",
  //     "date": "  12/01/2023"
  //   },
  //   {
  //     "ticket": "Ticket No. - ",
  //     "ticket No.": "4582620",
  //     "statusName": "Status -  ",
  //     "status": "Completed",
  //     "date": "  12/01/2023"
  //   },
  //   {
  //     "ticket": "Ticket No. - ",
  //     "ticket No.": "4582620",
  //     "statusName": "Status -  ",
  //     "status": "Completed",
  //     "date": "  12/01/2023"
  //   },
  // ];

  TicketController ticketController =Get.put(TicketController());

  GetTicketController getTicketController = Get.put(GetTicketController()); //GetAPI

  @override
  void initState() {
    // TODO: implement initState
    print('PostTicket_url ..... ');
    super.initState();
    print('PostTicket_url ..... ');
    var PostTicket_url = Post_Ticket_url;
    print('PostTicket_url ..... ${PostTicket_url.toString()}');
    var body =jsonEncode({
      'limit' : '10',
      'page' : '1'
    });

    ticketController.TicketApiCalling(PostTicket_url, body);
  }

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Scaffold(
      resizeToAvoidBottomInset: false,
      appBar: AppBar(
        titleSpacing: 0,
        elevation: 0,
        backgroundColor: ContainerColor,
        title: Text("ticketStatus_txt".tr),
      ),
      floatingActionButton: FloatingActionButton(
      backgroundColor: ContainerColor,
      child: Icon(Icons.add),
        onPressed: (){
          Navigator.push(context, MaterialPageRoute(builder: (context) => raise_ticket()));
        },
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            Container(
              height: 60,
              decoration: BoxDecoration(
                color: ContainerColor,
                border: Border.all(color: ContainerColor),
                borderRadius: BorderRadius.only(
                    bottomLeft: (Radius.circular(20)),
                    bottomRight: (Radius.circular(20))),
              ),
              child: Padding(
                padding:  EdgeInsets.only(left: 20,right: 20,bottom: 15),
                child: Row(
                  children: [
                    Expanded(
                      child: TextFormField(
                        onTap: (){
                        },
                        controller: _searchController,
                        decoration: InputDecoration(
                          filled: true,
                          fillColor: whiteColor,
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(10),
                          ),
                          focusedBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(10),
                              borderSide:
                              BorderSide(width: 1, color: appPrimaryColor)),
                          suffixIcon: SearchIcon,
                          label: Text("search".tr),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Padding(
              padding: EdgeInsets.only(top: 10),
              child: Container(
                height: 40,
                child: ListView.builder(
                    itemCount: topBar.length,
                    scrollDirection: Axis.horizontal,
                    shrinkWrap: true,
                    physics: NeverScrollableScrollPhysics(),
                    itemBuilder: (BuildContext context, index) {
                      var listdata = topBar[index];
                      return GestureDetector(
                        onTap: () {
                          setState(() {
                            current = index;
                          });
                        },
                        child: Container(
                          margin: EdgeInsets.all(2),
                          width: 110,
                          decoration: BoxDecoration(
                            color: current == index
                                ? appPrimaryColor
                                : whiteColor,
                            border: Border.all(color: appPrimaryColor),
                            borderRadius:
                            BorderRadius.all(Radius.circular(5)),
                          ),
                          child: Center(
                              child: Text(
                                listdata['text'].toString(),
                                style: TextStyle(
                                    color: current == index
                                        ? whiteColor
                                        : greyColor,
                                    fontSize: 15),
                              )),
                        ),
                      );
                    }),
              ),
            ),

            GetBuilder<TicketController>(
              builder: (ticketController) {
                if(ticketController.TicketListLoading.value){
                  return Center(child: CircularProgressIndicator());
                }
                else
                return ticketController.Ticket_List_Data.length==0?
                Center(child: Text("DataFound".tr,
                  style: TextStyle(fontSize: 20),)):
                  ListView.builder(
                  itemCount: ticketController.Ticket_List_Data.length,
                    scrollDirection: Axis.vertical,
                    shrinkWrap: true,
                    physics: NeverScrollableScrollPhysics(),
                    itemBuilder: (BuildContext context, index) {
                    var TicketData = ticketController.Ticket_List_Data[index];
                    return Padding(
                      padding:  EdgeInsets.only(left: 10,right: 10),
                      child: GestureDetector(

                        onTap: (){
                          getTicketController.GetTicketApiCalling(Get_Ticket_url);
                          print("ticketno : "+TicketData['ticket_no'].toString());
                            Navigator.pop(context, MaterialPageRoute(
                                builder: (context) =>
                                    ticket_chat(title: TicketData["ticket_no"].toString(),
                                      id: TicketData["id"].toString(),
                                    )
                            )
                            );
                            print("ticket No....." +TicketData["ticket_no"].toString());
                        },
                        // onTap: (){
                        //   print("ticketno : "+TicketData['ticket_no'].toString());
                        //   Navigator.push(context, MaterialPageRoute(
                        //       builder: (context) =>
                        //           ticket_chat(title: TicketData["ticket_no"].toString(),)));
                        //   print("ticket No....." +TicketData["ticket_no"].toString());
                        // },

                        child: Card(
                          elevation: 4,
                          child: Column(
                            // mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                            children: [
                              Row(
                                children: [
                                  Padding(
                                    padding:  EdgeInsets.only(left: 20,top: 20),
                                    child: Text("Ticket No. - ",
                                      style: TextStyle(
                                        fontSize: 18,
                                        color: Namecolors
                                      ),),
                                  ),
                                  Padding(
                                    padding:EdgeInsets.only(left: 5,top: 20),
                                    child: Text(TicketData["ticket_no"].toString(),
                                    style: TextStyle(
                                        fontSize: 18,
                                      color: textColor
                                    ),),
                                  ),
                                ],
                              ),
                              Row(
                                children: [
                                Padding(
                                  padding:  EdgeInsets.only(left: 20,top: 20,bottom: 20),
                                  child: Text("Status -  ",
                                    style: TextStyle(
                                        fontSize: 16,
                                        color: Namecolors
                                    ),
                                  ),
                                ),
                                  Padding(
                                    padding:EdgeInsets.only(top: 20,bottom: 20),
                                    child: Text(
                                      TicketData["status_text"].toString(),
                                      style: TextStyle(
                                          fontSize: 16,
                                          color: TicketData["status_text"]=="Pending"?Colors.blue:
                                          Colors.green,
                                        backgroundColor:TicketData["status_text"]=="Pending"?Color(0xFFEBF8FE):
                                        Color(0xFFEDF6EC),
                                      ),
                                    ),
                                  ),

                                  Padding(
                                    padding: EdgeInsets.only(left: 80),
                                    child: Container(
                                      width: 100,
                                      child: Row(
                                        children: [
                                          Calender,
                                          Text(TicketData["date"].toString(),
                                            style: TextStyle(
                                              fontSize: 16
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                          ],
                              )
                            ],
                          ),
                        ),
                      ),
                    );
                }
          );
              }
            ),

            // Row(
            //   mainAxisAlignment: MainAxisAlignment.end,
            //   children: [
            //     Container(
            //       margin: EdgeInsets.symmetric(horizontal: 10,vertical: 10),
            //       child: FloatingActionButton(
            //         backgroundColor: ContainerColor,
            //         elevation: 2,
            //         child: Icon(Icons.add),
            //           onPressed: () {
            //             Navigator.push(
            //                 context,
            //                 MaterialPageRoute(
            //                   builder: (context) => raise_ticket(),
            //                 ));
            //           },
            //       ),
            //     ),
            //   ],
            // ),
          ],
        ),
      ),
    );
  }
}
