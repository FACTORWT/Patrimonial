import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:urwealthpal/Constant/Images.dart';
import 'package:urwealthpal/Constant/Strings.dart';
import 'package:urwealthpal/Constant/colors.dart';

class ticket_chat extends StatefulWidget {
  var title;
  var id;
  ticket_chat({this.title,this.id});

  @override
  State<ticket_chat> createState() => _ticket_chatState();
}

class _ticket_chatState extends State<ticket_chat> {
  List chat = [
    {
      "message": "hi, How to add my\nbank detail",
      "name": "Heli_John",
      "sender": 1
    },
    {"message": "Hi, John", "name": "Sheetela John", "sender": 2},
    {
      "message": "hi, How to add my\nbank detail",
      "name": "Heli_John",
      "sender": 1
    },
    {"message": "Hi, John", "name": "Sheetela John", "sender": 2},
    {
      "message": "hi, How to add my\nbank detail",
      "name": "Heli_John",
      "sender": 1
    },
    {"message": "Hi, John", "name": "Sheetela John", "sender": 2},
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        titleSpacing: 0,
        elevation: 0,
        backgroundColor: ContainerColor,
        title: Text("Ticket No: "+widget.title.toString()),
      ),
      body: Column(children: [
        Expanded(
          child: ListView.builder(
              shrinkWrap: true,
              itemCount: chat.length,
              physics: AlwaysScrollableScrollPhysics(),
              itemBuilder: (context, index) {
                var chatdata = chat[index];
                return Container(
                  padding:  EdgeInsets.only(top: 15,left: 15,right: 15,bottom: 15),
                  alignment: chatdata["sender"] == 2
                      ? Alignment.centerLeft
                      : Alignment.centerRight,
                  child: Row(
                    mainAxisAlignment: chatdata["sender"] == 2
                        ? MainAxisAlignment.start
                        : MainAxisAlignment.end,
                    children: [
                      profileImage,
                      Card(
                        elevation: 2,
                        shape: RoundedRectangleBorder(
                          side: BorderSide(
                            color: NameColors2,
                          ),
                          borderRadius: BorderRadius.circular(5.0),
                        ),
                        child: Padding(
                          padding:  EdgeInsets.only(top: 10,left: 15,right: 15,bottom: 10),
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                chatdata["name"],
                                style: TextStyle(color: ContainerColor),
                              ),
                              Padding(
                                padding:  EdgeInsets.only(top: 10),
                                child: Text(chatdata["message"]),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                );
              }),
        ),
        Container(
            height: 60,
            color: ContainerColor,
            child: Row(
              children: [
                Expanded(
                  child: Padding(
                    padding:  EdgeInsets.only(left: 20),
                    child: TextFormField(
                      style: TextStyle(
                        color: whiteColor
                      ),
                      decoration: InputDecoration(
                        hintText: "chatHint_txt".tr,
                        hintStyle: TextStyle(color: whiteColor),
                      ),
                    ),
                  ),
                ),
                Padding(
                  padding:  EdgeInsets.only(right: 20),
                  child: Container(
                    height: 30,
                    width: 50,
                    decoration: BoxDecoration(
                        color: ContainerColor,
                        border: Border.all(color: whiteColor),
                        borderRadius: BorderRadius.all(Radius.circular(5))),
                    child: Center(
                      child: Text("send_txt".tr,
                      style: TextStyle(
                        color: whiteColor
                      ),),
                    ),
                  ),
                ),
              ],
            )),
      ]),
    );
  }
}
