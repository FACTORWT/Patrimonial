import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:urwealthpal/BottomBar/searchBar.dart';
import 'package:urwealthpal/Constant/Dividers.dart';
import 'package:urwealthpal/Constant/Images.dart';
import 'package:urwealthpal/Constant/Strings.dart';
import 'package:urwealthpal/Constant/colors.dart';
import 'package:urwealthpal/Screens/Ticket_Page/ticket_status.dart';

class ticket extends StatefulWidget {
  const ticket({Key? key}) : super(key: key);

  @override
  State<ticket> createState() => _ticketState();
}

class _ticketState extends State<ticket> {
   TextEditingController _searchController = TextEditingController();

   List categoriesList = [
     {
       "text": "Wealth",
     },
     {
       "text": "Funds Issue"
     },
     {
       "text": "Assets List"
     },
     {
       "text": "How To Add banks"
     },
   ];

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Scaffold(
      appBar: AppBar(
        elevation: 0,
        titleSpacing: 0,
        backgroundColor: ContainerColor,
        title: Text("ticket_tx".tr),
      ),
      body: Column(
        children: [
          Container(
            height: 60,
            decoration: BoxDecoration(
              color: ContainerColor,
              border: Border.all(color: ContainerColor),
              borderRadius: BorderRadius.only(
                  bottomLeft: (Radius.circular(20)),
                  bottomRight: (Radius.circular(20))),
            ),
            child: Padding(
              padding:  EdgeInsets.only(left: 20,right: 20,bottom: 15),
              child: Row(
                children: [
                  Expanded(
                    child: TextFormField(
                      onTap: (){
                      },
                      controller: _searchController,
                      decoration: InputDecoration(
                        filled: true,
                        fillColor: whiteColor,
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10),
                        ),
                        focusedBorder: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(10),
                            borderSide:
                            BorderSide(width: 1, color: appPrimaryColor)),
                        suffixIcon: SearchIcon,
                        label: Text("search".tr),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),

          Padding(
            padding: EdgeInsets.only(top: 15),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                Container(
                  height: 100,
                  width: 160,
                  decoration: BoxDecoration(
                    color: appPrimaryColor,
                    border: Border.all(color: ContainerColor),
                    borderRadius: BorderRadius.all(
                      (Radius.circular(10)),
                    ),
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: [
                      OpenTicket,
                      Padding(
                        padding: EdgeInsets.only(top: 30),
                        child: Column(
                          children: [
                            Text(
                              "openTicket_txt".tr,
                              style: TextStyle(color: whiteColor,
                              fontSize: 16),
                            ),
                          ],
                        ),
                      )
                    ],
                  ),
                ),
                Container(
                  height: 100,
                  width: 160,
                  decoration: BoxDecoration(
                    color: whiteColor,
                    border: Border.all(color: ContainerColor),
                    borderRadius: BorderRadius.all(
                      (Radius.circular(10)),
                    ),
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: [
                      CloseTicket,
                      Padding(
                        padding: EdgeInsets.only(top: 30),
                        child: Column(
                          children: [
                            Text(
                              "closeTicket_txt".tr,
                              style: TextStyle(color: greyColor,
                              fontSize: 16),
                            ),
                          ],
                        ),
                      )
                    ],
                  ),
                )
              ],
            ),
          ),

          Padding(
            padding: EdgeInsets.only(top: 20,right: 180),
            child: Text("categories_txt".tr,
                style: TextStyle(
                  fontSize: 26,
                  color: ContainerColor
                ),),
          ),
          Card(
            margin: EdgeInsets.only(top: 10,right: 10,left: 10),
            child:
            ListView.builder(
                itemCount: categoriesList.length,
                scrollDirection: Axis.vertical,
                shrinkWrap: true,
                physics: NeverScrollableScrollPhysics(),
                itemBuilder: (BuildContext context, index) {
                  var listdata = categoriesList[index];
                  return Padding(
                    padding: EdgeInsets.fromLTRB(10, 2, 10, 0),
                    child: Column(
                      children: [
                        Row(
                          children: [
                            Text(
                              '\u2022',
                              style: TextStyle(fontSize: 40,
                              color: ContainerColor),
                            ),
                            SizedBox(
                              width: 20,
                            ),
                            GestureDetector(
                              onTap: (){
                                Navigator.push(context, MaterialPageRoute(
                                    builder: (context) => ticket_status()));
                              },
                              child: Text(
                                listdata['text'].toString(),
                                style: TextStyle(fontSize: 15,
                                color: Namecolors),
                              ),
                            ),
                          ],
                        ),
                        lineDivider2
                      ],
                    ),
                  );
                }),
          )

        ],
      ),

    );
  }
}
