import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:urwealthpal/Constant/Api.dart';
import 'package:urwealthpal/Constant/ApiBaseHelper.dart';
import 'package:urwealthpal/Screens/Ticket_Page/Controllers/Post_Ticket_Controller.dart';

class RaiseTicketController extends GetxController{
  var RaiseTicketLoading = false.obs;
  var RaiseTicketData ;

  TextEditingController subject = TextEditingController();

  TicketController ticketController =Get.put(TicketController());

  RaiseTicketApiCalling(url, parameter) async {
    RaiseTicketLoading.value =true;
    print("Raise Ticket " + url.toString());
    var response = await ApiBaseHelper().postAPICall(Uri.parse(url), parameter, true);
    var responsedata = jsonDecode(response.body);
    print("Raise Ticket responsedata : " + responsedata.toString());
    if(response.statusCode==200){
      RaiseTicketData = responsedata['data'];
      Get.back();
      subject.clear();

      var PostTicket_url = Post_Ticket_url;
      print('PostTicket_url ..... ');
      print('PostTicket_url ..... ${PostTicket_url.toString()}');
      var body =jsonEncode({
        'limit' : '10',
        'page' : '1'
      });
      ticketController.TicketApiCalling(PostTicket_url, body);

      RaiseTicketLoading.value =false;
      update();
    } else
      RaiseTicketData =[];
    RaiseTicketLoading.value =false;
    update();
  }
}

