import 'dart:convert';
import 'package:get/get.dart';
import 'package:urwealthpal/Constant/ApiBaseHelper.dart';

class TicketController extends GetxController{
  var TicketListLoading = false.obs;
  List Ticket_List_Data=[] ;

  TicketApiCalling(url, parameter) async {
    TicketListLoading.value =true;
    print("Post Ticket " + url.toString());
    var response = await ApiBaseHelper().postAPICall(Uri.parse(url), parameter, true);
    var responsedata = jsonDecode(response.body);
    print("Post Ticket responsedata : " + responsedata.toString());
    if(response.statusCode==200){
      // Ticket_List_Data.clear();
      Ticket_List_Data.addAll(responsedata['data']);
      // Get.off(ticket_chat(title: Ticket_List_Data["ticket_no"].toString(),));
      TicketListLoading.value =false;
      update();
    }else{
        Ticket_List_Data =[];
      TicketListLoading.value =false;
      update();
    }
  }
}
