import 'dart:convert';
import 'package:get/get.dart';
import 'package:urwealthpal/Constant/ApiBaseHelper.dart';

class Ticket_CategoriesController extends GetxController{
  var Ticket_Categories_Loading = false.obs;

  List TicketCategoriesData=[] ;

  TicketCategoriesApiCalling(url) async {
    Ticket_Categories_Loading.value =true;
    print("Ticket_Categories Url : " + url.toString());
    var response = await ApiBaseHelper().getAPICall(Uri.parse(url), true);
    var responsedata = jsonDecode(response.body);
    print("Ticket_Categories responsedata : " + responsedata.toString());
    if(response.statusCode==200){
      TicketCategoriesData.clear();
      TicketCategoriesData.addAll(responsedata['data']) ;
      Ticket_Categories_Loading.value =false;
      update();
    }else{
      TicketCategoriesData =[];
      Ticket_Categories_Loading.value =false;
      update();
    }
  }

}