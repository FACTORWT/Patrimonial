import 'dart:convert';
import 'package:get/get.dart';
import 'package:urwealthpal/Constant/ApiBaseHelper.dart';
import 'package:urwealthpal/Screens/Ticket_Page/ticket_chat.dart';

class GetTicketController extends GetxController{
  var GetTicket_Loading = false.obs;

 var GetTicketData ;


  GetTicketApiCalling(url) async {
    GetTicket_Loading.value =true;
    print("GetTicket Url : " + url.toString());
    var response = await ApiBaseHelper().getAPICall(Uri.parse(url), true);
    var responsedata = jsonDecode(response.body);
    print("GetTicket responsedata : " + responsedata.toString());
    if(response.statusCode==200){
      print("GetTicket responsedata2 : " + responsedata.toString());
      print("GetTicket responsedata3 : " + responsedata.toString());
      GetTicketData=responsedata['data'].toString() ;
      print("Data....."+ responsedata.toString());
      // Get.to(ticket_chat());
      GetTicket_Loading.value =false;
      update();
    }else{
      GetTicketData =[];
      GetTicket_Loading.value =false;
      update();
    }
  }

}