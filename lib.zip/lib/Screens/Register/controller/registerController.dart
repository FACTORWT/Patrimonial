import 'dart:convert';
import 'dart:developer';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:urwealthpal/Constant/Api.dart';
import 'package:urwealthpal/Constant/ApiBaseHelper.dart';
import 'package:urwealthpal/Environment/Environment.dart';
import 'package:urwealthpal/Screens/Register/registerOTP.dart';
import 'package:urwealthpal/main.dart';

class RegisterController extends GetxController {
  var loading = false.obs;
  var registerdata;

  var otpLoading = false.obs;
  var otpData;

  TextEditingController userInput = TextEditingController();
  TextEditingController emailId = TextEditingController();
  TextEditingController mobile = TextEditingController();
  TextEditingController password = TextEditingController();
  TextEditingController confirmPassword = TextEditingController();
  TextEditingController countryController = TextEditingController();
  // TextEditingController stateController = TextEditingController();
  // TextEditingController cityController = TextEditingController();

  bool passToogle = true;
  bool passToogles = true;

  var SelectedCountryName,
      SelectedCountryId;
      // SelectedStateName,
      // SelectedStateId,
      // SelectedCityName,
      // SelectedCityId;

  RegisterApiCalling(url, parameter) async {
    loading.value = true;
    log("body--->"+SelectedCountryId.toString());
    print("register response : " + url.toString());
    var response = await ApiBaseHelper().postAPICall(
        Uri.parse(url), parameter, false);
    var responsedata = jsonDecode(response.body);
    if (response.statusCode == 200) {
      registerdata = responsedata['data'];

       // sp!.clear();
      // ApiBaseHelper().logindata(responsedata);
      // var LoginOTPData = responsedata['data'];
      // var setmpin = LoginOTPData['set_mpin'];
      // sp!.setString("ask_mpin", "0");
      // sp!.setString("set_mpin", LoginOTPData['set_mpin'].toString());
      // sp!.setBool("paymentstatus", false);
      // print("setMPIN...Register..." + Environment.setMPIN.toString());
      // print("askMPIN...Register..." + Environment.askMPIN.toString());
      // print("checkpaymentstatus...Register..." +
      //     Environment.checkpaymentstatus.toString());

      // toastMsg(responsedata['data']['otp'].toString(), true);

      // Fluttertoast.showToast(msg: responsedata['data']['otp'].toString(),
      //     toastLength: Toast.LENGTH_SHORT,
      //     timeInSecForIosWeb: 1,
      //     textColor: Colors.white,
      //     fontSize: 15.0
      // );

      Get.to(registerOTP(
        name: userInput.text.toString(),
        emailId: emailId.text.toString(),
        mobileNo: mobile.text.toString(),
        pass: password.text.toString(),
        confirm_pass: confirmPassword.text.toString(),
        country: SelectedCountryId.toString(),
        // state: SelectedStateId.toString(),
        // city: SelectedCityId.toString(),
      ));
      loading.value = false;

      // ApiBaseHelper().manageroute();
      update();
    }
    else if (response.statusCode == 422) {
      print("hgg"+responsedata['message'].toString());
      otpData = responsedata['message'].toString();
      var msg = otpData.toString();
      print("hggsd"+responsedata['message'].toString());
      toastMsg(otpData.toString(), false);
      otpLoading.value = false;
      update();
    }
    else if (response.statusCode == 403) {

      responsedata['error'].forEach((k,v){
        toastMsg("${v.join(" ")}", false);
      });

      otpLoading.value = false;
      update();
    }

    else {
      registerdata = [];
      loading.value = false;
      update();
    }
  }

  RegisterOTPApiCalling(url, parameter) async {
    otpLoading.value = true;

    print("register otp response : " + url.toString());
    var response = await ApiBaseHelper().postAPICall(
        Uri.parse(url), parameter, false);
    var responsedata = jsonDecode(response.body);
    if (response.statusCode == 200) {
      otpData = responsedata['data'];
      log("register otp response : " + responsedata.toString());
      sp!.setBool("loggedin",true);
      ApiBaseHelper().registerdata(responsedata);
      var LoginOTPData = responsedata['data'];
      var setmpin = LoginOTPData['set_mpin'];
      print("LoginOTPData['access_token']................${LoginOTPData['access_token']}");
      print("LoginOTPData................${LoginOTPData}");
      sp!.setString("access_token",LoginOTPData['access_token']);
      sp!.setString("ask_mpin", "0");
      sp!.setString("ask_mpin", "0");
      sp!.setString("set_mpin", LoginOTPData['set_mpin'].toString());
      sp!.setString("askQuestion", "0");
      sp!.setBool("paymentstatus", false);
      print("setMPIN...Register..." + Environment.setMPIN.toString());
      print("askMPIN...Register..." + Environment.askMPIN.toString());
      print("checkpaymentstatus...Register..." +
          Environment.checkpaymentstatus.toString());

      userInput.clear();
      emailId.clear();
      mobile.clear();
      password.clear();
      confirmPassword.clear();
      countryController.clear();
      // stateController.clear();
      // cityController.clear();
      SelectedCountryName="Select Country";
      // SelectedStateName="Select State";
      // SelectedCityName="Select City";

      toastMsg(responsedata['message'].toString(), true);


      // Fluttertoast.showToast(msg: responsedata['message'].toString(),
      //     toastLength: Toast.LENGTH_SHORT,
      //     timeInSecForIosWeb: 1,
      //     textColor: Colors.white,
      //     fontSize: 15.0
      // );
      otpLoading.value = false;
      ApiBaseHelper().manageroute();
      update();
    }
    else if (response.statusCode == 422) {
      print("hgg"+responsedata['message'].toString());
      otpData = responsedata['message'].toString();
      var msg = otpData.toString();
      print("hggsd"+responsedata['message'].toString());
      toastMsg(otpData.toString(), false);
      otpLoading.value = false;
      update();
    }else if (response.statusCode == 403) {

      responsedata['error'].forEach((k,v){
        toastMsg("${v.join(" ")}", false);
      });

      otpLoading.value = false;
      update();
    }
    else {
      otpData = [];
      toastMsg(responsedata['message'].toString(), true);
      otpLoading.value = false;
      update();
    }
  }
}