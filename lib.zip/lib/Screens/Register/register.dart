import 'dart:convert';
import 'dart:developer';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:urwealthpal/Constant/Api.dart';
import 'package:urwealthpal/Constant/ApiBaseHelper.dart';
import 'package:urwealthpal/Constant/Images.dart';
import 'package:urwealthpal/Constant/colors.dart';
import 'package:urwealthpal/Screens/Login/loginNewScreen.dart';
import 'package:urwealthpal/Screens/Register/controller/registerController.dart';

class register extends StatefulWidget {
  const register({Key? key}) : super(key: key);

  @override
  State<register> createState() => _registerState();
}

class _registerState extends State<register> {
  var _formKey = GlobalKey<FormState>();

  RegisterController registerController=Get.put(RegisterController());

  List country_list = [];
  List state_list = [];
  List city_list = [];
  bool agreeToSms = false;

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    fetchCountry();
  }

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Scaffold(
      resizeToAvoidBottomInset: false,
      body: Container(
        height: size.height,
        width: size.width,
        decoration: BoxDecoration(
          image: DecorationImage(
              image: AssetImage("assets/images/full_background.png"),
              fit: BoxFit.cover),
        ),
        child: Stack(
          children: [
          Form(
          key: _formKey,
          child: SingleChildScrollView(
              child: Column(
                children: [
                  // SizedBox(height: 50,),
                  Container(
                      margin: EdgeInsets.only(top: 100),
                      alignment: Alignment.center,
                      width:size.width,
                      child: signUpImage),
                  Container(
                    alignment: Alignment.center,
                    width: size.width,
                    child: Text(
                      "signUp".tr,
                      style: TextStyle(
                          color: whiteColor,
                          fontWeight: FontWeight.bold,
                          fontSize: 32),
                    ),
                  ),
                  // SizedBox(height: 50,),
                  Container(
                      width: size.width-30,
                    decoration: BoxDecoration(
                      color: whiteColor,
                      border: Border.all(color: whiteColor),
                      borderRadius: BorderRadius.all(Radius.circular(30)),
                    ),
                    // height: size.height,
                    height: 700,
                      margin: EdgeInsets.only(top: 20,bottom: 120,left: 20,right: 20),
                      child: Column(
                        children: [
                          Padding(
                            padding:  EdgeInsets.only(top:30,left: 10,right: 10),
                            child: TextFormField(
                              controller: registerController.userInput,
                              autovalidateMode:
                              AutovalidateMode.onUserInteraction,
                              scrollPadding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom + 25*4),
                              validator: (value) {
                                if (value == null || value.isEmpty) {
                                  return "username".tr;
                                }
                                return null; // Validation passed
                              },
                              keyboardType: TextInputType.name,
                              textInputAction: TextInputAction.next,
                              decoration: InputDecoration(
                                  filled: true,
                                  fillColor: whiteColor,
                                  contentPadding: EdgeInsets.only(top: 5),
                                  constraints: BoxConstraints(
                                      minWidth: 30, maxHeight: 70),
                                  border: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(10),
                                  ),
                                  enabledBorder: OutlineInputBorder(
                                      borderRadius: BorderRadius.circular(10),
                                      borderSide: BorderSide(
                                          width: 1, color: Namecolors)),
                                  focusedBorder: OutlineInputBorder(
                                      borderRadius: BorderRadius.circular(10),
                                      borderSide: BorderSide(
                                          width: 1, color: appPrimaryColor)),
                                  focusedErrorBorder: OutlineInputBorder(
                                      borderRadius: BorderRadius.circular(10),
                                      borderSide: BorderSide(
                                          width: 1, color: Colors.redAccent)),
                                  prefixIcon: Container(
                                    // color: Colors.redAccent,
                                      child: Image.asset("assets/images/user.png",scale: 3,width: 15,)),
                                  hintText: "hintUserName".tr),
                            ),
                          ),
                          SizedBox(height: 15),
                          Padding(
                            padding:  EdgeInsets.only(left: 10,right: 10),
                            child: TextFormField(
                              controller: registerController.emailId,
                              autovalidateMode:
                              AutovalidateMode.onUserInteraction,
                              scrollPadding: EdgeInsets.only(
                                  bottom: MediaQuery.of(context).viewInsets.bottom + 25*4),
                              validator: (value) {
                                if (value == null || value.isEmpty) {
                                  return "email".tr;
                                }
                                if (!RegExp
                                  (r'^[\w-]+(\.[\w-]+)*@[\w-]+(\.[\w-]+)+$')
                                    .hasMatch(value)) {
                                  return "validEmail".tr;
                                }
                                return null; // Validation passed
                              },
                              keyboardType: TextInputType.emailAddress,
                              textInputAction: TextInputAction.next,
                              decoration: InputDecoration(
                                  filled: true,
                                  fillColor: whiteColor,
                                  contentPadding: EdgeInsets.only(top: 5),
                                  constraints: BoxConstraints(
                                      minWidth: 30, maxHeight: 70),
                                  border: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(10),
                                  ),
                                  enabledBorder: OutlineInputBorder(
                                      borderRadius: BorderRadius.circular(10),
                                      borderSide: BorderSide(
                                          width: 1, color: Namecolors)),
                                  focusedBorder: OutlineInputBorder(
                                      borderRadius: BorderRadius.circular(10),
                                      borderSide: BorderSide(
                                          width: 1, color: appPrimaryColor)),
                                  focusedErrorBorder: OutlineInputBorder(
                                      borderRadius: BorderRadius.circular(10),
                                      borderSide: BorderSide(
                                          width: 1, color: Colors.redAccent)),
                                  prefixIcon: Container(
                                    // color: Colors.redAccent,
                                      child: Image.asset("assets/images/email (1).png",scale: 3,width: 15,)),
                                  hintText: "hintEmail".tr),
                            ),
                          ),
                          SizedBox(height: 15),
                          Padding(
                            padding:  EdgeInsets.only(left: 10,right: 10),
                            child: TextFormField(
                              controller: registerController.mobile,
                              scrollPadding: EdgeInsets.only(
                                  bottom: MediaQuery.of(context).viewInsets.bottom + 25*4),
                              inputFormatters: [
                                FilteringTextInputFormatter.allow(
                                    RegExp('[0-9]'))
                              ],
                              keyboardType: TextInputType.numberWithOptions(
                                  decimal: true),
                              autovalidateMode:
                              AutovalidateMode.onUserInteraction,
                              validator: (value) {
                                if (value == null || value.isEmpty) {
                                  return "validMobileNo".tr;
                                }
                                if (value.length == 0) {
                                  return "valid_Mobile_No_txt".tr;
                                }
                                return null; // Validation passed
                              },
                              // maxLength: 10,
                              textInputAction: TextInputAction.next,
                              decoration: InputDecoration(
                                filled: true,
                                fillColor: whiteColor,
                                contentPadding: EdgeInsets.only(top: 5),
                                constraints: BoxConstraints(
                                    minWidth: 30, maxHeight: 70),
                                border: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(10),
                                ),
                                enabledBorder: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(10),
                                    borderSide: BorderSide(
                                        width: 1, color: Namecolors)),
                                focusedBorder: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(10),
                                    borderSide: BorderSide(
                                        width: 1, color: appPrimaryColor)),
                                focusedErrorBorder: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(10),
                                    borderSide: BorderSide(
                                        width: 1, color: Colors.redAccent)),
                                prefixIcon: Container(
                                  // color: Colors.redAccent,
                                    child: Image.asset("assets/images/phoneIcon.png",scale: 3.5,width: 15,)
                                ),
                                hintText: "hintMobileNo".tr,
                                counterText: "",
                              ),
                            ),
                          ),
                          SizedBox(height: 15),
                          // Padding(
                          //   padding:  EdgeInsets.only(left: 10,right: 10),
                          //   child: TextFormField(
                          //     controller: OTP,
                          //     inputFormatters: [FilteringTextInputFormatter.allow(RegExp('[0-9]'))],
                          //     keyboardType: TextInputType.numberWithOptions(decimal: true),
                          //     autovalidateMode:
                          //     AutovalidateMode.onUserInteraction,
                          //     validator: (value) {
                          //       if (value == null) {
                          //         return otptxt;
                          //       }
                          //       else if (value.length != 6) {
                          //         return validotptxt;
                          //       }
                          //       else
                          //         return null;
                          //     },
                          //     maxLength: 6,
                          //     textInputAction: TextInputAction.next,
                          //     decoration: InputDecoration(
                          //       filled: true,
                          //       fillColor: whiteColor,
                          //       contentPadding: EdgeInsets.only(top: 5),
                          //       constraints :BoxConstraints(minWidth: 30, maxHeight:70),
                          //       border: OutlineInputBorder(
                          //         borderRadius: BorderRadius.circular(10),
                          //       ),
                          //       enabledBorder: OutlineInputBorder(
                          //           borderRadius: BorderRadius.circular(10),
                          //           borderSide: BorderSide( width: 1, color: Namecolors)
                          //       ),
                          //       focusedBorder: OutlineInputBorder(
                          //           borderRadius: BorderRadius.circular(10),
                          //           borderSide: BorderSide( width: 1, color: appPrimaryColor)
                          //       ),
                          //       focusedErrorBorder: OutlineInputBorder(
                          //           borderRadius: BorderRadius.circular(10),
                          //           borderSide: BorderSide(
                          //               width: 1, color: Colors.redAccent)),
                          //       prefixIcon: PasswordIcon,
                          //       hintText: hintOTP,
                          //       counterText: "",
                          //     ),
                          //   ),
                          // ),
                          // SizedBox(height: 15),
                          Padding(
                            padding:  EdgeInsets.only(left: 10,right: 10),
                            child: TextFormField(
                              controller: registerController.password,
                              autovalidateMode:
                              AutovalidateMode.onUserInteraction,
                              scrollPadding: EdgeInsets.only(
                                  bottom: MediaQuery.of(context).viewInsets.bottom + 25*4),
                              validator: (value) {
                                if (value == null || value.isEmpty) {
                                  return "validPassword".tr;
                                }
                                if (value.length < 6) {
                                  return "correctPassword".tr;
                                }
                                return null; // Validation passed
                              },
                              obscureText: registerController.passToogle,
                              textInputAction: TextInputAction.next,
                              decoration: InputDecoration(
                                filled: true,
                                fillColor: whiteColor,
                                contentPadding: EdgeInsets.only(top: 5),
                                constraints: BoxConstraints(
                                    minWidth: 30, maxHeight: 70),
                                border: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(10),
                                ),
                                enabledBorder: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(10),
                                    borderSide: BorderSide(
                                        width: 1, color: Namecolors)),
                                focusedBorder: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(10),
                                    borderSide: BorderSide(
                                        width: 1, color: appPrimaryColor)),
                                focusedErrorBorder: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(10),
                                    borderSide: BorderSide(
                                        width: 1, color: Colors.redAccent)),
                                prefixIcon: Container(
                                  // color: Colors.redAccent,
                                    child: Image.asset("assets/images/passIcon.png",
                                      scale: 3,width: 15,)
                                ),
                                hintText: "hintPassword".tr,
                                suffixIcon: InkWell(
                                  onTap: () {
                                    setState(() {
                                      registerController.passToogle = !registerController.passToogle ;
                                    });
                                  },
                                  child: Icon(registerController.passToogle
                                      ? Icons.visibility_off
                                      : Icons.visibility),
                                ),
                              ),
                            ),
                          ),
                          SizedBox(height: 15),
                          Padding(
                            padding:  EdgeInsets.only(left: 10,right: 10),
                            child: TextFormField(
                              controller: registerController.confirmPassword,
                              autovalidateMode:
                              AutovalidateMode.onUserInteraction,
                                scrollPadding: EdgeInsets.only(bottom:40),
                              validator: (value) {
                                if (value!.isEmpty) {
                                  return "reEnterPasswrod".tr;
                                } else if (registerController.password.text !=
                                    registerController.confirmPassword.text) {
                                  return "reEnterPasswrodNotMatch".tr;
                                } else
                                  return null;
                              },
                              obscureText: registerController.passToogles,
                              textInputAction: TextInputAction.done,
                              decoration: InputDecoration(
                                filled: true,
                                fillColor: whiteColor,
                                contentPadding: EdgeInsets.only(top: 5),
                                constraints: BoxConstraints(
                                    minWidth: 30, maxHeight: 70),
                                border: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(10),
                                ),
                                enabledBorder: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(10),
                                    borderSide: BorderSide(
                                        width: 1, color: Namecolors)),
                                focusedBorder: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(10),
                                    borderSide: BorderSide(
                                        width: 1, color: appPrimaryColor)),
                                focusedErrorBorder: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(10),
                                    borderSide: BorderSide(
                                        width: 1, color: Colors.redAccent)),
                                prefixIcon: Container(
                                    // color: Colors.redAccent,
                                    child: Image.asset("assets/images/passIcon.png",
                                      scale: 3,width: 15,)
                                ),
                                hintText: "hintConfirmPassword".tr,
                                suffixIcon: InkWell(
                                  onTap: () {
                                    setState(() {
                                      registerController.passToogles = !registerController.passToogles;
                                    });
                                  },
                                  child: Icon(registerController.passToogles
                                      ? Icons.visibility_off
                                      : Icons.visibility),
                                ),
                              ),
                            ),
                          ),

                          SizedBox(height: 15),
                          registerController.countryController.text.toString()=="null"?Container():
                          Padding(
                            padding: EdgeInsets.only(left: 10,right: 10),
                            child: DropdownButtonFormField(
                              isExpanded: true,
                              validator: ((val) {
                                if (val == null) {
                                  return "SelectCountry".tr;
                                }
                              }),
                              decoration: InputDecoration(
                                contentPadding: EdgeInsets.only(top: 5),
                                constraints: BoxConstraints(
                                    minWidth: 30, maxHeight: 70),
                                border: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(10),
                                ),
                                enabledBorder: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(10),
                                    borderSide: BorderSide(
                                        width: 1, color: Namecolors)),
                                focusedBorder: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(10),
                                    borderSide: BorderSide(
                                        width: 1, color: appPrimaryColor)),
                                focusedErrorBorder: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(10),
                                    borderSide: BorderSide(
                                        width: 1, color: Colors.redAccent)),
                                labelStyle: TextStyle(color: Colors.grey, fontSize: 16),
                                filled: true,
                                prefixIcon: Container(
                                  // color: Colors.redAccent,
                                  child:
                                  Image.asset("assets/images/cityIcon.png",
                                    color: Color(0xFF37BCF9),
                                    scale: 2.6,width: 15,),
                                ),
                                hintStyle: TextStyle(color: Colors.black),
                                hintText:registerController.SelectedCountryName==null?"Select Country":  registerController.SelectedCountryName
                                    .toString(),
                                fillColor: Colors.transparent,
                              ),
                              // value: profileController.SelectedCountryName == null
                              //   ?"Select Country":profileController.SelectedCountryName,
                              items: country_list.map((explist) {
                                print("array " + explist.toString());
                                return DropdownMenuItem(
                                  value: explist['name'],
                                  child: Text(explist['name']),
                                  onTap: () {
                                    setState(() {
                                      registerController.SelectedCountryId =
                                      explist['id'];
                                    });
                                  },
                                );
                              }).toList(),
                              onChanged: (value) {
                                setState(() {

                                  registerController.SelectedCountryName = value;
                            ;
                                  print("countryId...." +
                                      registerController.SelectedCountryId
                                          .toString());

                                  if (registerController.SelectedCountryId == 0) {
                                    registerController.SelectedCountryId = null;
                                  }
                                });
                                // registerController.SelectedStateId = null;
                                // registerController.SelectedStateName = null;
                                // registerController.SelectedCityId = null;
                                // registerController.SelectedCityName = null;

                                // fetchState(registerController.SelectedCountryId
                                //     .toString());
                                // print("object..........>${ registerController.SelectedCityName}");
                                // setState(() {
                                //
                                // });
                              },
                            ),
                          ),
                          SizedBox(height: 15),
                          Padding(
                            padding: const EdgeInsets.symmetric(horizontal: 10.0),
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Checkbox(
                                  value: agreeToSms,
                                  onChanged: (value) {
                                    setState(() {
                                      agreeToSms = value!;
                                    });
                                  },
                                ),
                                Expanded(
                                  child: Text(
                                    "I agree to receive SMS message for verification and account-related security",
                                    style: TextStyle(fontSize: 14, color: Colors.black),
                                  ),
                                ),
                              ],
                            ),
                          ),


                          SizedBox(height: 15),
                          GestureDetector(
                            onTap: () {
                              if (!_formKey.currentState!.validate()) return;

                              if (!agreeToSms) {
                                Get.snackbar(
                                  "Agreement Required",
                                  "Please agree to receive SMS for verification and account-related security.",
                                  backgroundColor: Colors.redAccent,
                                  colorText: Colors.white,
                                );
                                return;
                              }

                              print("register response1......");

                              var registerUrl = register_url;
                              var body = ({
                                'name': registerController.userInput.text.toString(),
                                'mobile': registerController.mobile.text.toString(),
                                'with_otp': "0",
                                'email': registerController.emailId.text.toString(),
                                'password': registerController.password.text.toString(),
                                'password_confirmation': registerController.confirmPassword.text.toString(),
                                'country_id': registerController.SelectedCountryId.toString(),
                              });

                              print('register response......${registerUrl}');
                              registerController.RegisterApiCalling(registerUrl, body);
                            },

                            child: Container(
                              height: 40,
                              width: 150,
                              decoration: BoxDecoration(
                                  color: buttonColor,
                                  border: Border.all(
                                    color: buttonColor,
                                  ),
                                  borderRadius: BorderRadius.all(
                                      Radius.circular(12))),
                              child: Center(
                                child: Text(
                                  "signUp".tr,
                                  style: TextStyle(
                                      color: whiteColor,
                                      fontSize: 16,
                                      fontWeight: FontWeight.bold),
                                ),
                              ),
                            ),
                          ),
                          SizedBox(
                            height: 15,
                          ),
                          RichText(
                            text: TextSpan(
                                text: "account_login_txt".tr,
                                style: TextStyle(
                                  color: Color(0xFF94A0AC),
                                  fontSize: 15,
                                ),
                                children: <TextSpan>[
                                  TextSpan(
                                      text: "login_txt".tr,
                                      style: TextStyle(
                                        color: appPrimaryColor,
                                        fontSize: 15,
                                      ),
                                      recognizer: TapGestureRecognizer()
                                        ..onTap = () {
                                          Navigator.pushReplacement(
                                              context,
                                              MaterialPageRoute(
                                                builder: (context) => NewLoginScreen()
                                              ));
                                        })
                                ]),
                          )
                        ],
                      ),),
                ],
              ),
            ),),
          ],
        ),
      ),
    );
  }

  Future<void> fetchCountry() async {
    var countryUrl = Uri.parse(Country_url);
    log("countryUrl--> " + countryUrl.toString());
    var response = await ApiBaseHelper().getAPICall(countryUrl, false);
    var CountryData = jsonDecode(response.body);
    log("Country.....${CountryData}");
    if (response.statusCode == 200) {
      setState(() {
        country_list.addAll(CountryData['data']);
        registerController.SelectedCountryName == null
            ? "Select Country"
            : registerController.SelectedCountryName;
        registerController.SelectedCountryId == null
            ? 0
            : registerController.SelectedCountryId;
        // fetchState(registerController.SelectedCountryId.toString());
        // registerController.SelectedStateId == null
        //     ? 0
        //     : registerController.SelectedStateId;
        // fetchCity(registerController.SelectedStateId);
      });
    }
  }

  // Future<void> fetchState(countryId) async {
  //   var stateUrl = Uri.parse(State_url + countryId.toString());
  //   print("profileUrl--> " + stateUrl.toString());
  //   var response = await ApiBaseHelper().getAPICall(stateUrl, false);
  //   print("profileUrl--> " + response.body.toString());
  //
  //   var StateData = jsonDecode(response.body);
  //   if (response.statusCode == 200) {
  //     registerController.SelectedCityName=null;
  //     registerController.SelectedCityId=null;
  //     state_list.clear();
  //     setState(() {
  //       state_list.addAll(StateData['data']);
  //     });
  //   }
  // }

  // Future<void> fetchCity(state_id) async {
  //   var cityUrl = Uri.parse(City_url + state_id.toString());
  //   print("cityurl : " + cityUrl.toString());
  //   var response = await ApiBaseHelper().getAPICall(cityUrl, false);
  //   print("cityurl : " + response.body.toString());
  //   var CityData = jsonDecode(response.body);
  //   if (response.statusCode == 200)
  //     city_list.clear();
  //     setState(() {
  //       city_list.addAll(CityData['data']);
  //     });
  //   }
  }