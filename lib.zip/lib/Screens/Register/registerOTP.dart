import 'dart:convert';
import 'dart:developer';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:urwealthpal/Constant/Api.dart';
import 'package:urwealthpal/Constant/ApiBaseHelper.dart';
import 'package:urwealthpal/Constant/Images.dart';
import 'package:urwealthpal/Constant/colors.dart';
import 'package:urwealthpal/Screens/Register/controller/registerController.dart';

class registerOTP extends StatefulWidget {
  var name;
  var emailId;
  var mobileNo;
  var pass;
  var confirm_pass;
  var country;
  var state;
  var city;

  registerOTP(
      {this.name, this.emailId, this.mobileNo, this.pass, this.confirm_pass,this.country,this.state,this.city});

  @override
  State<registerOTP> createState() => _registerOTPState();
}

class _registerOTPState extends State<registerOTP> {
  var _formKey = GlobalKey<FormState>();
  var OTP = TextEditingController();

  RegisterController registerController=Get.put(RegisterController());

  // String generateOTP() {
  //   Random random = Random();
  //   int otp = random.nextInt(9000) + 1000; // Generate a random number between 1000 and 9999
  //   return otp.toString();
  // }

  var Generated_OTP;

  List country_list = [];
  List state_list = [];
  List city_list = [];

  @override
  void initState() {
    // TODO: implement initState
    // String otp = generateOTP();
    setState(() {
      // Generated_OTP = otp.toString();
    });
    // print('Generated OTP: $otp');
    // Fluttertoast.showToast(msg: 'Generated OTP: $otp',
    //     toastLength: Toast.LENGTH_SHORT,
    //     backgroundColor: appPrimaryColor,
    //     timeInSecForIosWeb: 1,
    //     textColor: whiteColor,
    //     fontSize: 15.0
    // );
    super.initState();
    log("afgfh----->"+widget.country.toString());
    log("afgfh state----->"+widget.state.toString());
    log("afgfh city----->"+widget.city.toString());
  }

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Scaffold(
        resizeToAvoidBottomInset: false,
        body: Container(
          height: size.height,
          width: size.width,
          decoration: BoxDecoration(
            image: DecorationImage(
                image: AssetImage("assets/images/full_background.png"),
                fit: BoxFit.cover),
          ),
          child: Column(
            children: [
              Stack(children: [
                Form(
                    key: _formKey,
                    child: SingleChildScrollView(
                      child: Column(
                        children: [
                          Container(
                              margin: EdgeInsets.only(top: 110),
                              alignment: Alignment.center,
                              width: size.width,
                              child: OTPImage),
                          Container(
                            alignment: Alignment.center,
                            width: size.width,
                            child: Text(
                              "otp".tr,
                              style: TextStyle(
                                  color: whiteColor,
                                  fontWeight: FontWeight.bold,
                                  fontSize: 32),
                            ),
                          ),
                          Container(
                            height: 350,
                            margin:
                                EdgeInsets.only(top: 30, left: 20, right: 20),
                            decoration: BoxDecoration(
                              color: whiteColor,
                              border: Border.all(color: whiteColor),
                              borderRadius:
                                  BorderRadius.all(Radius.circular(30)),
                            ),
                            child: Column(
                              children: [
                                Padding(
                                  padding: EdgeInsets.fromLTRB(10, 100, 10, 0),
                                  child: TextFormField(
                                    controller: OTP,
                                    inputFormatters: [
                                      FilteringTextInputFormatter.allow(
                                          RegExp('[0-9]'))
                                    ],
                                    keyboardType:
                                        TextInputType.numberWithOptions(
                                            decimal: true),
                                    autovalidateMode:
                                        AutovalidateMode.onUserInteraction,
                                    validator: (value) {
                                      if (value == null) {
                                        return "otptxt".tr;
                                      } else if (value.length != 4) {
                                        return "validotptxt".tr;
                                      } else
                                        return null;
                                    },
                                    maxLength: 10,
                                    textInputAction: TextInputAction.next,
                                    decoration: InputDecoration(
                                      filled: true,
                                      fillColor: whiteColor,
                                      contentPadding: EdgeInsets.only(top: 5),
                                      constraints: BoxConstraints(
                                          minWidth: 30, maxHeight: 70),
                                      border: OutlineInputBorder(
                                        borderRadius: BorderRadius.circular(10),
                                      ),
                                      enabledBorder: OutlineInputBorder(
                                          borderRadius:
                                              BorderRadius.circular(10),
                                          borderSide: BorderSide(
                                              width: 1, color: Namecolors)),
                                      focusedBorder: OutlineInputBorder(
                                          borderRadius:
                                              BorderRadius.circular(10),
                                          borderSide: BorderSide(
                                              width: 1,
                                              color: appPrimaryColor)),
                                      focusedErrorBorder: OutlineInputBorder(
                                          borderRadius:
                                              BorderRadius.circular(10),
                                          borderSide: BorderSide(
                                              width: 1,
                                              color: Colors.redAccent)),
                                      prefixIcon: PasswordIcon,
                                      hintText: "hintOTP".tr,
                                      counterText: "",
                                    ),
                                  ),
                                ),
                                Padding(
                                  padding: EdgeInsets.only(
                                      top: 50, left: 80, right: 80),
                                  child: GestureDetector(
                                    onTap: () {
                                      print('register response1......');
                                      if (_formKey.currentState!.validate()) {
                                        print('register response2......');
                                        var registerUrl = register_url;
                                        var body = ({
                                          'name': widget.name.toString(),
                                          'mobile': widget.mobileNo.toString(),
                                          'email': widget.emailId.toString(),
                                          'password': widget.pass.toString(),
                                          'password_confirmation': widget.confirm_pass.toString(),
                                          'with_otp': '1'.toString(),
                                          'otp': OTP.text.toString(),
                                          'country_id' : widget.country.toString(),
                                          'state_id' : widget.state.toString(),
                                          'city_id' : widget.city.toString(),
                                        });
                                        print('register response..body....${body}');
                                        print(
                                            'register response......${registerUrl}');
                                        registerController.RegisterOTPApiCalling(
                                            registerUrl, body);
                                      }
                                    },
                                    child: Container(
                                      height: 40,
                                      width: 150,
                                      decoration: BoxDecoration(
                                          color: buttonColor,
                                          border: Border.all(
                                            color: buttonColor,
                                          ),
                                          borderRadius: BorderRadius.all(
                                              Radius.circular(12))),
                                      child: Center(
                                        child: Text(
                                          "submitBtn".tr,
                                          style: TextStyle(
                                              color: whiteColor,
                                              fontSize: 16,
                                              fontWeight: FontWeight.bold),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ))
              ]),
            ],
          ),
        ));
  }

  // Future<void> fetchCountry() async {
  //   var countryUrl = Uri.parse(Country_url);
  //   print("countryUrl--> " + countryUrl.toString());
  //   var response = await ApiBaseHelper().getAPICall(countryUrl, false);
  //   var CountryData = jsonDecode(response.body);
  //   log("Country.....${CountryData}");
  //   if (response.statusCode == 200) {
  //     setState(() {
  //       country_list.addAll(CountryData['data']);
  //       registerController.SelectedCountryName == null
  //           ? "Select Country"
  //           : registerController.SelectedCountryName;
  //       registerController.SelectedCountryId == null
  //           ? 0
  //           : registerController.SelectedCountryId;
  //       fetchState(registerController.SelectedCountryId.toString());
  //       registerController.SelectedStateId == null
  //           ? 0
  //           : registerController.SelectedStateId;
  //       fetchCity(registerController.SelectedStateId);
  //     });
  //   }
  // }
  //
  // Future<void> fetchState(countryId) async {
  //   var stateUrl = Uri.parse(State_url + countryId);
  //   print("profileUrl--> " + stateUrl.toString());
  //   var response = await ApiBaseHelper().getAPICall(stateUrl, false);
  //   var StateData = jsonDecode(response.body);
  //   if (response.statusCode == 200) {
  //     state_list.clear();
  //     setState(() {
  //       state_list.addAll(StateData['data']);
  //     });
  //   }
  // }
  //
  // Future<void> fetchCity(state_id) async {
  //   var cityUrl = Uri.parse(City_url + state_id);
  //   print("cityurl : " + cityUrl.toString());
  //   var response = await ApiBaseHelper().getAPICall(cityUrl, false);
  //   var CityData = jsonDecode(response.body);
  //   if (response.statusCode == 200) {
  //     city_list.clear();
  //     setState(() {
  //       city_list.addAll(CityData['data']);
  //     });
  //   }
  // }
}