import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:urwealthpal/Constant/Api.dart';
import 'package:urwealthpal/Constant/colors.dart';
import 'package:urwealthpal/Screens/Notification/controller/notificationController.dart';

class notification extends StatefulWidget {
  const notification({Key? key}) : super(key: key);

  @override
  State<notification> createState() => _notificationState();
}

class _notificationState extends State<notification> {
  var notificationcontroller =Get.put(NotificationController());

  // List notification = [
  //   {
  //     "text": "Your Expense request from 2023-09-15 has been approved",
  //     "date" : "15-09-2023"
  //   },
  //   {
  //     "text": "Your Expense request from 2023-09-15 has been approved",
  //     "date" : "15-09-2023"
  //   },
  //   {
  //     "text": "Your Expense request from 2023-09-15 has been approved",
  //     "date" : "15-09-2023"
  //   },
  //   {
  //     "text": "Your Expense request from 2023-09-15 has been approved",
  //     "date" : "15-09-2023"
  //   },
  //   {
  //     "text": "Your Expense request from 2023-09-15 has been approved",
  //     "date" : "15-09-2023"
  //   },
  //   {
  //     "text": "Your Expense request from 2023-09-15 has been approved",
  //     "date" : "15-09-2023"
  //   },
  //   {
  //     "text": "Your Expense request from 2023-09-15 has been approved",
  //     "date" : "15-09-2023"
  //   },
  //   {
  //     "text": "Your Expense request from 2023-09-15 has been approved",
  //     "date" : "15-09-2023"
  //   },
  //   {
  //     "text": "Your Expense request from 2023-09-15 has been approved",
  //     "date" : "15-09-2023"
  //   },
  // ];

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    notificationcontroller.Aboutfetch(notification_url);
  }

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return RefreshIndicator(
      onRefresh: () async {
        await NotificationController();
        await Future.delayed(Duration(milliseconds: 1500));
      },
      child: Scaffold(
        appBar: AppBar(
          elevation: 0,
          titleSpacing: 0,
          backgroundColor: ContainerColor,
          title: Text("notifications".tr),
        ),

        body:
        GetBuilder<NotificationController>(
          builder: (notificationcontroller) {
            if(notificationcontroller.load.value){
              return Center(child: CircularProgressIndicator());
            }
            else
            return
              notificationcontroller.notificationdata.length==0?Center(child: Text("DataFound".tr)):
              ListView.builder(
                itemCount: notificationcontroller.notificationdata.length,
                scrollDirection: Axis.vertical,
                shrinkWrap: true,
                physics: NeverScrollableScrollPhysics(),
                itemBuilder: (BuildContext context, index) {
                  var listdata = notificationcontroller.notificationdata[index];
                  return Padding(
                    padding:  EdgeInsets.only(top: 10,left: 10,right: 10),
                    child: Card(
                      elevation: 4,
                      child: Padding(
                        padding:  EdgeInsets.only(top: 10,left: 10,right: 10,bottom: 10),
                        child: Column(
                          mainAxisAlignment: MainAxisAlignment.spaceAround,
                          children: [
                            Padding(
                              padding:  EdgeInsets.only(top: 10),
                              child: Text( '${listdata['message'].toString()}',
                              style: TextStyle(
                                fontSize: 15,
                                  fontWeight: FontWeight.w600,
                              ),),
                            ),
                            Container(
                              width: 100,
                              margin: EdgeInsets.only(top: 10,left: 220),
                              child: Text( '${listdata['date'].toString()}',
                                style: TextStyle(
                                fontSize: 15,
                                    fontWeight: FontWeight.w600,
                              ),),
                            )
                          ],
                        ),
                      ),
                    ),
                  );
                });
          }
        ),
      ),
    );
  }
}
