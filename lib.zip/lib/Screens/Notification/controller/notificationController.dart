import 'dart:convert';
import 'package:get/get.dart';
import 'package:urwealthpal/Constant/ApiBaseHelper.dart';

class NotificationController extends GetxController{
  var load = false.obs;
  List notificationdata=[] ;
  Aboutfetch(url) async {
    load.value =true;

    print("notificationUrl : " + url.toString());
    var response = await ApiBaseHelper().getAPICall(Uri.parse(url), true);
    var responsedata = jsonDecode(response.body);
    print("notification responsedata : " + responsedata.toString());
    if(response.statusCode==200){
      notificationdata.clear();
      notificationdata.addAll(responsedata['data']) ;
      load.value =false;
      update();
    }else{
      notificationdata =[];
      load.value =false;
      update();
    }
  }
}