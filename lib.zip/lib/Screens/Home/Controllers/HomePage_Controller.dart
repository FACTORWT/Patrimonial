import 'dart:convert';
import 'dart:developer';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:urwealthpal/BottomBar/bottombar.dart';
import 'package:urwealthpal/Constant/ApiBaseHelper.dart';
import 'package:fl_chart/fl_chart.dart';
import 'package:urwealthpal/Constant/colors.dart';
import 'package:urwealthpal/Screens/PurchasePlan/purchase_plan.dart';
import 'package:urwealthpal/main.dart';

class Home_PageController extends GetxController{
  var HomePageLoading = false.obs;
  var HomePageData ;
  bool widgitLoading= false;
  List HomeListData=[] ;
  List<DataItem> HomeBarChartNameData=[] ;

  HomePageApiCalling(url,isLoader) async {
    if(isLoader==true){
      widgitLoading =true;
      HomePageLoading(true);
    }
    log("HomePageApiCalling Url : " + url.toString());
    var response = await ApiBaseHelper().getAPICall(Uri.parse(url), true);
    var responsedata = jsonDecode(response.body);
    log("HomePageApiCalling responsedata : " + responsedata.toString());
    log("HomePageApiCalling statusCode : " + response.statusCode.toString());
    if(response.statusCode==200){

      HomePageData=responsedata['data'];

      log("data--->"+HomePageData['has_subscription'].toString());
      // sp!.getBool("paymentstatus");

      if(HomePageData['has_subscription'].toString() =="0"){
        Get.offAll(purchase_plan());
        sp!.setBool("paymentstatus", false);
      }
      else{
        sp!.setBool("paymentstatus", true);
      }

      HomeListData.clear();
      HomeListData.addAll(responsedata['data']['categories']) ;
      createBarGroups;
      HomePageData['bar_chart'].forEach((e){
        log("bar_chart > "+e.toString() );
      });

      widgitLoading=false;
      HomePageLoading(false);
      update();
    }
    else{
      HomePageData =[];
      HomeListData =[];
      widgitLoading=false;
      HomePageLoading(false);

      if(HomePageData['has_subscription'].toString() =="0"){
        Get.offAll(purchase_plan());
        sp!.setBool("paymentstatus", false);
      }
      else{
        sp!.setBool("paymentstatus", true);
      }
      update();
    }
  }

  var HomePageLibalitesLoading = false.obs;
  var HomePageLibalitesData ;
  List HomePageLibalitesListData=[] ;
  List<DataItem> HomeBarChartLibalityNameData=[] ;

  HomePageLibalityApiCalling(url,isLoader) async {
    if(isLoader==true){
      widgitLoading=true;
      HomePageLibalitesLoading(true);
        }
    log("HomePageLibalityApiCalling Url : " + url.toString());
    var response = await ApiBaseHelper().getAPICall(Uri.parse(url), true);
    var responsedata = jsonDecode(response.body);
    log("HomePageLibalityApiCalling responsedata : " + responsedata.toString());
    log("HomePageLibalityApiCalling statusCode : " + response.statusCode.toString());
    if(response.statusCode==200){

      HomePageLibalitesData=responsedata['data'];
      HomePageLibalitesListData.clear();
      HomePageLibalitesListData.addAll(responsedata['data']['categories']) ;
      createBarLibalityGroups;
      HomePageLibalitesData['bar_chart'].forEach((e){
        log("bar_chart > "+e.toString() );
      });

      widgitLoading=false;
      HomePageLibalitesLoading(false);
      update();
    }
    else{
      HomePageLibalitesData =[];
      HomePageLibalitesListData =[];
      widgitLoading=false;
      HomePageLibalitesLoading(false);
      update();
    }
  }
  List<BarChartGroupData> createBarLibalityGroups() {
    var colors =[];
    List<BarChartGroupData> barGroups = [];

    HomeBarChartLibalityNameData = [];
    for (int i = 0; i < HomePageLibalitesData['bar_chart'].length; i++) {
      final month = HomePageLibalitesData['bar_chart'][i]["month"];
      final totalAssets = HomePageLibalitesData['bar_chart'][i]["total_assets"];
      final barsData = HomePageLibalitesData['bar_chart'][i]["data"];

      List<BarChartRodData> barRods = [];
      colors =[Colors.blue.shade100,Colors.blue.shade200,Colors.blue.shade300,Colors.blue.shade400,Colors.blue.shade500,Colors.blue.shade600];
      for (int j = 0; j < barsData.length; j++) {
        final barData = barsData[j];
        final barId = barData["id"];
        final barName = barData["name"];
        final barTotalAssets = barData["total_assets"];
        colors.addAll([Colors.blue.shade100,Colors.blue.shade200,Colors.blue.shade300,Colors.blue.shade400,Colors.blue.shade500,Colors.blue.shade600]);
        if(barTotalAssets!=0){
          HomeBarChartLibalityNameData.add(DataItem(color: colors[j], name: barName));
        }
        log("Colors>> "+colors.toString());
        barRods.add(BarChartRodData(
          toY: barTotalAssets.toDouble(),
          color: colors[j],
          width: 8,
          // borderRadius: BorderRadius.vertical(
          //     top: Radius.circular(0))
          borderRadius: BorderRadius.vertical(
              top: Radius.zero),
        ));
      }

      barGroups.add(BarChartGroupData(
        x: i,
        barRods: barRods,

        // Index of bars to display tooltips
      ));
    }
    log("barGroups >> "+barGroups.toString());
    update();
    return barGroups;
  }

  RxDouble barTotalAssets=0.0.obs;
  List<BarChartGroupData> createBarGroups() {
    var colors =[];
    List<BarChartGroupData> barGroups = [];

    // double maxValue = barGroups.reduce((value, element) => value > element ? value : element) as double;

    HomeBarChartNameData = [];
    HomeBarChartNameData.clear();
    log("bar_chartlength>> "+HomePageData['bar_chart'].length.toString());
    for (int i = 0; i < HomePageData['bar_chart'].length; i++) {
      final month = HomePageData['bar_chart'][i]["month"];
      final totalAssets = HomePageData['bar_chart'][i]["total_assets"];
      final barsData = HomePageData['bar_chart'][i]["data"];


      List<BarChartRodData> barRods = [];
      barRods.clear();
       colors =[Colors.blue.shade100,Colors.blue.shade200,Colors.blue.shade300,Colors.blue.shade400,Colors.blue.shade500,Colors.blue.shade600];
      log("barsDatalength>> "+barsData.toString());
      for (int j = 0; j < barsData.length; j++) {
        final barData = barsData[j];
        final barId = barData["id"];
        final barName = barData["name"];
         barTotalAssets.value = double.parse(barData["total_assets"].toString());

        colors.addAll([Colors.blue.shade100,Colors.blue.shade200,Colors.blue.shade300,Colors.blue.shade400,Colors.blue.shade500,Colors.blue.shade600]);
        if(barTotalAssets.value!=0){

          HomeBarChartNameData.add(DataItem(color: colors[j], name: barName));
        }

        log("Colors>> "+colors[j].toString());
        log("barTotalAssets>>"+barTotalAssets.value.toString());
        barRods.add(BarChartRodData(
            toY: double.parse(barTotalAssets.value.toString()),
            color: colors[j],
            width: 8,
            // borderRadius: BorderRadius.vertical(
            //     top: Radius.circular(0))
            borderRadius: BorderRadius.vertical(
            top: Radius.zero),
        )
        );

      }
      barGroups.add(BarChartGroupData(
        x: i,
        barRods: barRods,
        // Index of bars to display tooltips
      ));
    }
    log("barGroups >> "+barGroups.toString());
    update();
    return barGroups;
  }
  Widget bottomTitleWidgets(double value, TitleMeta meta,texts) {
    const style = TextStyle(
      color: Color(0xFF6A6A6A),
      fontSize: 10,
    );
    String text;
    switch (value.toInt()) {
      case 0:
        text = texts;
        break;
      case 1:
        text = texts;
        break;
      case 2:
        text = texts;
        break;

      default:
        return Container();
    }
    return SideTitleWidget(
      axisSide: meta.axisSide,
      space: 7,
      child: Text(text, style: style),
    );
  }
}
class DataItem {
  Color color;
  var name;

  DataItem(
      {required this.color, required this.name, });
}