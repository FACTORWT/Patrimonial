import 'dart:developer';
import 'dart:async';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:urwealthpal/Constant/Api.dart';
import 'package:urwealthpal/Constant/Images.dart';
import 'package:urwealthpal/Constant/Spacing.dart';
import 'package:urwealthpal/Constant/indicator.dart';
import 'package:urwealthpal/Constant/colors.dart';
import 'package:urwealthpal/Screens/Home/Controllers/HomePage_Controller.dart';
import 'package:urwealthpal/Screens/PurchasePlan/purchasecontroller.dart';

import '../../main.dart';

class homescreen extends StatefulWidget {
  const homescreen({Key? key}) : super(key: key);

  @override
  State<homescreen> createState() => _homescreenState();
}

class _homescreenState extends State<homescreen> {
  Home_PageController home_pageController =
      Get.put(Home_PageController()); //GetAPI
  Widget bottomTitleWidgets(double value, TitleMeta meta) {
    const style = TextStyle(
      color: Color(0xFF6A6A6A),
      fontSize: 10,
    );
    String text;
    switch (value.toInt()) {
      case 0:
        text = home_pageController.HomePageData['bar_chart'][value.toInt()]
            ["month"];
        break;
      case 1:
        text = home_pageController.HomePageData['bar_chart'][value.toInt()]
            ["month"];
        break;
      case 2:
        text = home_pageController.HomePageData['bar_chart'][value.toInt()]
            ["month"];
        break;
      default:
        return Container();
    }
    return SideTitleWidget(
      axisSide: meta.axisSide,
      space: 7,
      child: Text(text, style: style),
    );
  }

  // List topBar =
  // [
  //   {
  //     "text": "Financial Assets",
  //   },
  //   {
  //     "text": "Fixed Assets",
  //   },
  //   {
  //     "text": "Business Ownership",
  //   },
  //   {
  //     "text": "Retirement",
  //   }
  // ];




  String formattedAmount = '';
  // Function to format amount with thousand separators
  String formatAmount(String value) {
    final formatter = NumberFormat('#,##0.00', 'en_US');
    double parsedValue = double.tryParse(value.replaceAll(',', '')) ?? 0.0;
    return formatter.format(parsedValue);
  }
  PurchaseController _purchaseController = Get.put(PurchaseController());




  Color getColorForIndex(int index) {
    switch (index) {
      case 0:
        return Colors.blue.shade100;
      case 1:
        return Colors.blue.shade200;
      case 2:
        return Colors.blue.shade300;
      case 3:
        return Colors.blue.shade400;
      case 4:
        return Colors.blue.shade500;
      case 5:
        return Colors.blue.shade600;
      case 6:
        return Colors.blue.shade700;
      case 7:
        return Colors.blue.shade800;
      default:
        return Colors.blue.shade900;
    }
  }

  // final List<DataItem> _myData = List.generate(
  //     30,
  //         (index) => DataItem(
  //       x: index,
  //       y1: Random().nextInt(20) + Random().nextDouble(),
  //       y2: Random().nextInt(20) + Random().nextDouble(),
  //       y3: Random().nextInt(20) + Random().nextDouble(),
  //     ));

  int current = 0;
  int current2 = 0;

  int touchedIndex = -1;

  bool passToogle = true;
  bool passToogles = true;

  bool passToogle2 = true;
  bool passToogles2 = true;

  bool type = true;

  List<String> purchaseData=[];
  // dynamic typeId=1 ;

  //  gethomeData(catId,typeid)async{
  //
  //    Map<String, String> queryParams = {
  //      'category_id': catId.toString(),
  //      "type":typeid.toString()
  //    };
  //
  //    String queryString = Uri(queryParameters: queryParams).query;
  //
  //    var Home_urls = Home_url + '?' + queryString;
  //
  // // isLoader false for chnage pia chart data without loader
  //    home_pageController.HomePageApiCalling(Home_urls,false);
  //  }

  @override
  void initState() {
    super.initState();
    getPurchaseHistoryPlanData();
    liabilitiesdata();
    getdataa();
  }


  List<Map<String, dynamic>> activeItems = [];

  getPurchaseHistoryPlanData() async {
    await _purchaseController.callpurchaseplanHistory_list(Get_MySubscriptionPlan_url);
    print("PurchaseplanHistoryData==>${_purchaseController.PurchaseplanHistoryData}");

    for (var item in _purchaseController.PurchaseplanHistoryData) {
      if (item['is_active'] == 1) {
        activeItems.add(item);
      }
    }
    print("activeItems==>${activeItems}");
  }



getdataa(){
  print("purchaseData>>>>>>  ");

  purchaseData= sp!.getStringList("PurchaseData")==null?[]:sp!.getStringList("PurchaseData")!;
  print("purchaseData>>>>>>  ${purchaseData}");
}
  liabilitiesdata() async {
    await home_pageController.HomePageApiCalling(Home_url + "?type=${1}", true);
    await home_pageController.HomePageLibalityApiCalling(
        Home_url + "?type=${2}", true);
    log('total_assets==>'+home_pageController.HomePageData["pie_chart"][0]["total_assets"].toString());
  }


      List<PieChartSectionData> showingSectionss(List<dynamic> data) {

      // String label = item.containsKey('assets') ? item['assets'] : item['liabilities'];
      // double value = (item['assets'] ?? item['liabilities'] ?? 0).toDouble();
      List<PieChartSectionData> sections = [];



      for (int i = 0; i < data.length; i++) {
        final isTouched = i == touchedIndex;
        final fontSize = isTouched ? 25.0 : 16.0;
        final radius = isTouched ? 60.0 : 50.0;
        const shadows = [Shadow(color: Colors.black, blurRadius: 2)];
        dynamic totalAssets =data[i].containsKey('assets') ? data[i]['assets'].toString() : data[i]['liabilities'].toString();
        double parent_total = data[i]['total'].toDouble();
        // log("${totalAssets} ..... ${parent_total}");
        sections.add(
          PieChartSectionData(
            color: getColorForIndex(
                i),


            // Define a function to get colors based on index
            value:double.parse(totalAssets)  != 0.0 ? double.parse(totalAssets) : 0.0,
            title: parent_total != 0.0
                ? '${(double.parse(totalAssets) / parent_total * 100).toStringAsFixed(0)}%'
                : "${double.parse(totalAssets).toStringAsFixed(0)}%", // Display percentage
            radius: radius,
            titleStyle: TextStyle(
              fontSize: fontSize,
              fontWeight: FontWeight.bold,
              color: whiteColor,
              shadows: shadows,
            ),
          ),
        );
        log('sections==>'+sections.toString());
      }

      return sections;
  }

  List<PieChartSectionData> showingSections(List<dynamic> data) {
    List<PieChartSectionData> sections = [];
    for (int i = 0; i < data.length; i++) {
      final isTouched = i == touchedIndex;
      final fontSize = isTouched ? 25.0 : 16.0;
      final radius = isTouched ? 60.0 : 50.0;
      const shadows = [Shadow(color: Colors.black, blurRadius: 2)];
      String name = data[i]['name'];
      double totalAssets = data[i]['total_assets'].toDouble();
      double parent_total = data[i]['parent_total'].toDouble();
      // log("${totalAssets} ..... ${parent_total}");
      sections.add(
        PieChartSectionData(
          color: getColorForIndex(
              i),


          // Define a function to get colors based on index
          value: totalAssets != 0.0 ? totalAssets : 0.0,
          title: parent_total != 0.0
              ? '${(totalAssets / parent_total * 100).toStringAsFixed(0)}%'
              : "${totalAssets.toStringAsFixed(0)}%", // Display percentage
          radius: radius,
          titleStyle: TextStyle(
            fontSize: fontSize,
            fontWeight: FontWeight.bold,
            color: whiteColor,
            shadows: shadows,
          ),
        ),
      );
      log('sections==>'+sections.toString());
    }

    return sections;
  }
  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    // Generate dummy data to feed the chart

    return RefreshIndicator(
      onRefresh: () async {
        await Home_PageController();
        await Future.delayed(Duration(milliseconds: 1500));
      },
      child: Scaffold(
          resizeToAvoidBottomInset: false,
          body: GetBuilder<Home_PageController>(builder: (home_pageController) {
            if (home_pageController.HomePageLoading.value) {
              return Center(child: CircularProgressIndicator());
            } else {
              return SingleChildScrollView(
                child: Column(
                  children: [
                    Stack(
                      children: [
                        Container(
                          height: 80,
                          decoration: BoxDecoration(
                            color: ContainerColor,
                            border: Border.all(color: ContainerColor),
                            borderRadius: BorderRadius.only(
                                bottomLeft: (Radius.circular(40)),
                                bottomRight: (Radius.circular(50)),
                            ),
                          ),
                        ),
                        Container(
                          margin: EdgeInsets.fromLTRB(25, 15, 25, 0),
                          decoration: BoxDecoration(
                              image: DecorationImage(
                            image: AssetImage("assets/images/box.png"),
                            fit: BoxFit.fill,
                          )),
                          child: Padding(
                            padding: EdgeInsets.only(left: 20),
                            child: Row(children: [
                              // homeProfileImage,
                              Container(
                                  height: 100,
                                  width: 100,
                                  decoration: BoxDecoration(
                                      color: appPrimaryColor,
                                      border: Border.all(
                                        width: 5,
                                        color: buttonColor,
                                      ),
                                      borderRadius: BorderRadius.all(
                                          Radius.circular(90))),
                                  child: ClipOval(
                                    child: CachedNetworkImage(
                                        imageUrl: home_pageController
                                            .HomePageData["image"],
                                        fit: BoxFit.fill),
                                  )),
                              Column(
                                mainAxisAlignment: MainAxisAlignment.center,
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Container(
                                    width:size.width-200,
                                    child: Padding(
                                      padding: EdgeInsets.only(left: 5),
                                      child: Text(
                                        home_pageController.HomePageData["name"]
                                            .toString(),overflow: TextOverflow.ellipsis,
                                        // profileName,
                                        style: TextStyle(
                                            color: whiteColor, fontSize: 18),
                                      ),
                                    ),
                                  ),
                                  Padding(
                                    padding: EdgeInsets.only(top: 10),
                                    child: Row(
                                      children: [
                                        Padding(
                                          padding: EdgeInsets.only(left: 5),
                                          child: profileCallIcon,
                                        ),
                                        Padding(
                                          padding: EdgeInsets.only(left: 5),
                                          child: Text(home_pageController.HomePageData["mobile"].toString(),
                                               style: TextStyle(
                                                color: whiteColor,
                                                fontSize: 12),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                  Padding(
                                    padding: EdgeInsets.only(top: 10, left: 4),
                                    child: Row(
                                      children: [
                                        profilEmailIcon,
                                        Padding(
                                          padding: EdgeInsets.only(left: 5),
                                          child: Container(
                                            width:size.width-200,
                                            child: Text(home_pageController.HomePageData["email"].toString(),overflow: TextOverflow.ellipsis,style: TextStyle(
                                                  color: whiteColor,
                                                  fontSize: 12),),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ],
                              ),
                            ]),
                          ),
                        )
                        // Container(
                        //   margin: EdgeInsets.fromLTRB(25, 25, 25, 0),
                        //   height: 120,
                        //   decoration: BoxDecoration(
                        //       color: sidebarcontainerColor,
                        //       border: Border.all(color: sidebarcontainerColor),
                        //       borderRadius: BorderRadius.all(Radius.circular(10))),
                        //   child: Stack(
                        //     children: [
                        //       ClipRRect(
                        //           borderRadius: BorderRadius.all(Radius.circular(10)),
                        //           child: profileTopImage
                        //       ),
                        //       Padding(
                        //         padding: EdgeInsets.only(left: 20),
                        //         child: Row(children: [
                        //           // homeProfileImage,
                        //           Container(
                        //               height: 100,
                        //                 width: 100,
                        //                 decoration: BoxDecoration(
                        //                     color: appPrimaryColor,
                        //                     border: Border.all(width: 5,
                        //                       color: buttonColor,
                        //                     ),
                        //                     borderRadius: BorderRadius.all(Radius.circular(90))
                        //                 ),
                        //               child: ClipOval(
                        //                   child: Image.network(home_pageController.HomePageData["image"]))),
                        //           Column(
                        //             mainAxisAlignment: MainAxisAlignment.center,
                        //             crossAxisAlignment: CrossAxisAlignment.start,
                        //             children: [
                        //               Text(
                        //                 home_pageController.HomePageData["name"],
                        //                 // profileName,
                        //                 style: TextStyle(
                        //                     color: whiteColor, fontSize: 20),
                        //               ),
                        //               Padding(
                        //                 padding: EdgeInsets.only(top: 10),
                        //                 child: Row(
                        //                   children: [
                        //                     profileCallIcon,
                        //                     Padding(
                        //                       padding: EdgeInsets.only(left: 5),
                        //                       child: Text(
                        //                         home_pageController.HomePageData["mobile"],
                        //                         // profileMobileNo,
                        //                         style: TextStyle(
                        //                             color: whiteColor,
                        //                             fontSize: 12),
                        //                       ),
                        //                     ),
                        //                   ],
                        //                 ),
                        //               ),
                        //               Padding(
                        //                 padding: EdgeInsets.only(top: 10),
                        //                 child: Row(
                        //                   children: [
                        //                     profilEmailIcon,
                        //                     Padding(
                        //                       padding: EdgeInsets.only(left: 5),
                        //                       child: Text(
                        //                         home_pageController.HomePageData["email"],
                        //                         // profileEmail,
                        //                         style: TextStyle(
                        //                             color: whiteColor,
                        //                             fontSize: 12),
                        //                       ),
                        //                     ),
                        //                   ],
                        //                 ),
                        //               ),
                        //             ],
                        //           ),
                        //         ]),
                        //       ),
                        //       Padding(
                        //         padding: EdgeInsets.only(top: 60, left: 165),
                        //         child: ClipRRect(
                        //             borderRadius:
                        //                 BorderRadius.all(Radius.circular(10)),
                        //             child: profileBottomImage),
                        //       ),
                        //     ],
                        //   ),
                        // ),
                      ],
                    ),
                  if( activeItems[0]['dashboard_toggle']!=0)
                    ( activeItems[0]['assets_toggle']==0 || activeItems[0]['assets_toggle']==0)?
                        SizedBox.shrink():
                    Column(
                      children: [
                        home_pageController.widgitLoading == true
                            ? Center(
                            child: Container(
                                alignment: Alignment.center,
                                height: size.height * 0.20,
                                child: CircularProgressIndicator()))
                            : int.parse(home_pageController.HomePageData["asset_liabilities_chart"][0]["total"].toString())==0
                            ? Container(
                            height: size.height * 0.20,
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Text("DataFound".tr,
                                  style: TextStyle(
                                    fontSize: 14.5,
                                    fontWeight: FontWeight.w600,
                                    color: Colors.grey.shade600,
                                    letterSpacing: 0.5,
                                  ),
                                ),
                              ],
                            ))
                            : Card(
                          margin: EdgeInsets.all(15),
                          child: Container(
                            height: 240,
                            width: size.width,
                            alignment: Alignment.center,
                            padding: EdgeInsets.only(left:10, right:10),
                            child: Row(
                              children: [
                                Expanded(
                                  flex: 6,
                                  child: AspectRatio(
                                    aspectRatio: 1,
                                    child: Stack(
                                      children: [
                                        PieChart(
                                          PieChartData(
                                            pieTouchData: PieTouchData(
                                              touchCallback: (FlTouchEvent event,pieTouchResponse) {
                                                setState(() {
                                                  if (!event.isInterestedForInteractions || pieTouchResponse == null ||
                                                      pieTouchResponse.touchedSection == null) {
                                                    touchedIndex = -1;
                                                    return;
                                                  }
                                                  touchedIndex = pieTouchResponse.touchedSection!.touchedSectionIndex;
                                                });
                                              },
                                            ),
                                            borderData: FlBorderData(
                                              show: false,
                                            ),
                                            sectionsSpace: 2,
                                            // centerSpaceRadius: 40,
                                            sections: showingSectionss(home_pageController.HomePageData["asset_liabilities_chart"]),
                                          ),
                                        ),
                                        // Center(
                                        //   child: Container(
                                        //     width: 110,
                                        //     child: Text(
                                        //       "financial_assets".tr,
                                        //       textAlign: TextAlign.center,
                                        //       style: TextStyle(color: Darkgrey),
                                        //     ),
                                        //   ),
                                        // ),
                                      ],
                                    ),
                                  ),
                                ),
                                SizedBox(width: 10,),
                                Expanded(
                                  flex: 4,
                                  child: ListView.builder(
                                    itemCount: home_pageController.HomePageData["asset_liabilities_chart"].length,
                                    shrinkWrap: true,
                                    physics: NeverScrollableScrollPhysics(),
                                    itemBuilder: (context, index) {
                                      var titles = home_pageController.HomePageData["asset_liabilities_chart"][index].containsKey('assets') ? "Assets" : "Liabilities";
                                      return Column(
                                        mainAxisAlignment:
                                        MainAxisAlignment.end,
                                        crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                        children: [
                                          home_pageController.HomePageData["asset_liabilities_chart"] == 0
                                              ? Container()
                                              : Indicator(
                                            color: getColorForIndex(index),
                                            text: "${titles}\t(${home_pageController.HomePageData["asset_liabilities_chart"][index].containsKey('assets') ?formatAmount(home_pageController.HomePageData["asset_liabilities_chart"][index]['assets'].toString()):formatAmount(home_pageController.HomePageData["asset_liabilities_chart"][index]['liabilities'].toString())})"
                                            ,
                                            size: 220,
                                            textwidth: 150,
                                            isSquare: true,
                                          ),
                                          SizedBox(height: 7,),
                                        ],
                                      );
                                    },
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),

                    Padding(
                      padding: EdgeInsets.only(top: 15),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: [
                          GestureDetector(
                            // onTap: () {
                            //   typeId =1;
                            //   home_pageController.HomePageApiCalling(Home_url + "?type=${typeId}",true);
                            //   setState(() {
                            //     type = true;
                            //   });
                            // },
                            child: Container(
                              height: 80,
                              width: 160,
                              decoration: BoxDecoration(
                                color:
                                    type == true ? appPrimaryColor : whiteColor,
                                boxShadow: [
                                  BoxShadow(
                                    color: greyColor,
                                    blurRadius: 5.0,
                                  ),
                                ],
                                border: Border.all(color: ContainerColor),
                                borderRadius: BorderRadius.all(
                                  (Radius.circular(10)),
                                ),
                              ),
                              child: Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceAround,
                                children: [
                                  Image.asset(
                                    "assets/images/home_manage.png",
                                    scale: 3,
                                    color: type == true
                                        ? whiteColor
                                        : appPrimaryColor,
                                  ),
                                  Text(
                                    "assetstxt".tr,
                                    style: TextStyle(
                                        color: type == true
                                            ? whiteColor
                                            : appPrimaryColor,
                                        fontSize: 18),
                                  )
                                ],
                              ),
                            ),
                          ),
                          GestureDetector(
                            // onTap: () {
                            //   typeId =2;
                            //   home_pageController.HomePageApiCalling(Home_url + "?type=${typeId}",true);
                            //   setState(() {
                            //     type = false;
                            //   });
                            // },
                            child: Container(
                              height: 80,
                              width: 160,
                              decoration: BoxDecoration(
                                color: type == false
                                    ? appPrimaryColor
                                    : whiteColor,
                                boxShadow: [
                                  BoxShadow(
                                    color: greyColor,
                                    blurRadius: 5.0,
                                  ),
                                ],
                                border: Border.all(color: ContainerColor),
                                borderRadius: BorderRadius.all(
                                  (Radius.circular(10)),
                                ),
                              ),
                              child: Column(
                                children: [
                                  Row(
                                    mainAxisAlignment: MainAxisAlignment.end,
                                    children: [
                                      GestureDetector(
                                        onTap: () {
                                          setState(() {
                                            passToogle = !passToogle;
                                          });
                                        },
                                        child: Container(
                                          width: 30,
                                          child: Icon(
                                            passToogle
                                                ? Icons.visibility_off
                                                : Icons.visibility,
                                            color: type == false
                                                ? whiteColor
                                                : Colors.black,
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                  Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceAround,
                                    children: [
                                      Image.asset(
                                        "assets/images/money.png",
                                        scale: 3,
                                        color: type == false
                                            ? whiteColor
                                            : appPrimaryColor,
                                      ),
                                      Column(
                                        children: [
                                          Text(
                                            'totalAss'.tr,
                                            style: TextStyle(
                                              color: type == false
                                                  ? whiteColor
                                                  : greyColor,
                                            ),
                                          ),
                                          Row(
                                            children: [
                                              Text(
                                                'slash'.tr,
                                                style: TextStyle(
                                                  color: type == false
                                                      ? whiteColor
                                                      : greyColor,
                                                  fontSize: 15,
                                                ),
                                              ),
                                              passToogle
                                                  ? Row(
                                                      children: [
                                                        // type == false
                                                        //     ? whiteColor
                                                        //     : greyColor,
                                                        Icon(
                                                          Icons.circle,
                                                          color: type == false
                                                              ? whiteColor
                                                              : greyColor,
                                                          size: 15,
                                                        ),
                                                        // Icon(
                                                        //   Icons.circle,
                                                        //   color: type == false
                                                        //       ? whiteColor
                                                        //       : greyColor,
                                                        //   size: 15,
                                                        // ),
                                                        // Icon(
                                                        //   Icons.circle,
                                                        //   color: type == false
                                                        //       ? whiteColor
                                                        //       : greyColor,
                                                        //   size: 15,
                                                        // ),
                                                        // Icon(
                                                        //   Icons.circle,
                                                        //   color: type == false
                                                        //       ? whiteColor
                                                        //       : greyColor,
                                                        //   size: 15,
                                                        // )
                                                      ],
                                                    )
                                                  : Text(
                                                "${formatAmount(home_pageController.HomePageData["total_assets"].toString(),)}",
                                                      style: TextStyle(
                                                        color: type == false
                                                            ? whiteColor
                                                            : greyColor,
                                                      ),
                                                    ),
                                            ],
                                          ),
                                        ],
                                      ),
                                    ],
                                  ),
                                ],
                              ),
                            ),
                          )
                        ],
                      ),
                    ),

                    if( activeItems[0]['dashboard_toggle']!=0)
                      activeItems[0]['assets_toggle']==1?
                      Column(
                      children: [
                        home_pageController.widgitLoading == true
                            ? Center(
                            child: Container(
                                alignment: Alignment.center,
                                height: size.height * 0.20,
                                child: CircularProgressIndicator()))
                            : int.parse(home_pageController.HomePageData["all_asset_chart"][0]["total_assets"].toString())==0
                            ? Container(
                            height: size.height * 0.20,
                            child: Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              crossAxisAlignment: CrossAxisAlignment.center,
                              children: [
                                Text("DataFound".tr,
                                  style: TextStyle(
                                    fontSize: 14.5,
                                    fontWeight: FontWeight.w600,
                                    color: Colors.grey.shade600,
                                    letterSpacing: 0.5,
                                  ),
                                ),
                              ],
                            ))
                            : Card(
                          margin: EdgeInsets.all(15),
                          child: Container(
                            height: 240,
                            width: size.width,
                            alignment: Alignment.center,
                            padding: EdgeInsets.only(left:10, right:10),
                            child: Row(
                              children: [
                                Expanded(
                                  flex: 6,
                                  child: AspectRatio(
                                    aspectRatio: 1,
                                    child: Stack(
                                      children: [
                                        PieChart(
                                          PieChartData(
                                            pieTouchData: PieTouchData(
                                              touchCallback: (FlTouchEvent event,pieTouchResponse) {
                                                setState(() {
                                                  if (!event.isInterestedForInteractions || pieTouchResponse == null ||
                                                      pieTouchResponse.touchedSection == null) {
                                                    touchedIndex = -1;
                                                    return;
                                                  }
                                                  touchedIndex = pieTouchResponse.touchedSection!.touchedSectionIndex;
                                                });
                                              },
                                            ),
                                            borderData: FlBorderData(
                                              show: false,
                                            ),
                                            sectionsSpace: 2,
                                            // centerSpaceRadius: 40,
                                            sections: showingSections(home_pageController.HomePageData["all_asset_chart"][0]['data']),
                                          ),
                                        ),
                                        // Center(
                                        //   child: Container(
                                        //     width: 110,
                                        //     child: Text(
                                        //       "financial_assets".tr,
                                        //       textAlign: TextAlign.center,
                                        //       style: TextStyle(color: Darkgrey),
                                        //     ),
                                        //   ),
                                        // ),
                                      ],
                                    ),
                                  ),
                                ),
                                SizedBox(width: 10,),
            Expanded(
            flex: 4,
            child: ListView.builder(
            itemCount: home_pageController.HomePageData["all_asset_chart"][0]["data"].length,
            shrinkWrap: true,
            physics: NeverScrollableScrollPhysics(),
            itemBuilder: (context, index) {
            var titles = home_pageController.HomePageData["all_asset_chart"
                ""][0]["data"][index];
            return Column(
            mainAxisAlignment:
            MainAxisAlignment.end,
            crossAxisAlignment:
            CrossAxisAlignment.start,
            children: [
            titles['total_assets'] == 0
            ? Container()
                : Indicator(
            color: getColorForIndex(index),
            text: "${titles["name"]}\t(${formatAmount(titles['total_assets'].toString())})"
            // "(${titles['total_assets']})"
            ,
            size: 200,
            textwidth: 150,
            isSquare: true,
            ),
            SizedBox(height: 7,),
            ],
            );
            },
            ),
            ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ):
                      SizedBox.shrink(),

                    Padding(
                      padding: EdgeInsets.only(top: 10, left: 10, right: 10),
                      child: Container(
                        alignment: Alignment.topLeft,
                        height: 40,
                        child: ListView.builder(
                            itemCount: home_pageController.HomeListData.length,
                            scrollDirection: Axis.horizontal,
                            shrinkWrap: true,
                            physics: AlwaysScrollableScrollPhysics(),
                            itemBuilder: (BuildContext context, index) {
                              var listdata = home_pageController.HomeListData[index];
                              return GestureDetector(
                                onTap: () {

                                  home_pageController.widgitLoading = true;
                                  setState(() {});
                                  var categoryId = listdata['id'].toString();
                                  print("categoryIId--->>" + categoryId.toString());

                                  // liabilitiesdata();
                                  Map<String, String> queryParams = {
                                    'category_id': categoryId.toString(),
                                    "type": "1".toString()
                                  };
                                  log('queryParams==>'+queryParams.toString());
                                  log('barTotalAssets1==>'+home_pageController.barTotalAssets.value.toString());

                                  String queryString = Uri(queryParameters: queryParams).query;

                                  var Home_urls = Home_url + '?' + queryString;
                                  log('Home_urls==>'+Home_urls.toString());
                                  home_pageController.HomePageApiCalling(Home_urls, false);
                                  setState(() {
                                    current = index;
                                  });
                                },
                                child: Container(
                                  margin: EdgeInsets.all(2),
                                  width: 120,
                                  decoration: BoxDecoration(
                                    color: current == index
                                        ? appPrimaryColor
                                        : whiteColor,
                                    border: Border.all(color: appPrimaryColor),
                                    borderRadius:
                                        BorderRadius.all(Radius.circular(5)),
                                  ),
                                  child: Center(
                                      child: Text(
                                    listdata['name'].toString(),
                                    textAlign: TextAlign.center,
                                    textScaleFactor: 1.0,
                                    style: TextStyle(
                                        color: current == index
                                            ? whiteColor
                                            : greyColor,
                                        fontSize: 12,
                                        wordSpacing: 0.2,
                                        overflow: TextOverflow.clip),
                                  )),
                                ),
                              );
                            }),
                      ),
                    ),
                    if( activeItems[0]['dashboard_toggle']!=0)
                      activeItems[0]['assets_toggle']==1?
                    Column(
                      children: [
                        home_pageController.widgitLoading == true
                            ? Center(
                                child: Container(
                                    alignment: Alignment.center,
                                    height: size.height * 0.20,
                                    child: CircularProgressIndicator()))
                            : int.parse(home_pageController.HomePageData["pie_chart"][0]
                                            ["total_assets"].toString())==0
                                ? Container(
                                    height: size.height * 0.20,
                                    child: Column(
                                      mainAxisAlignment: MainAxisAlignment.center,
                                      crossAxisAlignment: CrossAxisAlignment.center,
                                      children: [
                                        Text("DataFound".tr,
                                          style: TextStyle(
                                              fontSize: 14.5,
                                              fontWeight: FontWeight.w600,
                                              color: Colors.grey.shade600,
                                              letterSpacing: 0.5,
                                          ),
                                        ),
                                      ],
                                    ))
                                : Card(
                                    margin: EdgeInsets.all(15),
                                    child: Container(
                                      height: 240,
                                      width: size.width,
                                      alignment: Alignment.center,
                                      padding: EdgeInsets.only(left:10, right:10),
                                      child: Row(
                                        children: [
                                          Expanded(
                                            flex: 6,
                                            child: AspectRatio(
                                              aspectRatio: 1,
                                              child: Stack(
                                                children: [
                                                  PieChart(
                                                    PieChartData(
                                                      pieTouchData: PieTouchData(
                                                        touchCallback: (FlTouchEvent event,pieTouchResponse) {
                                                          setState(() {
                                                            if (!event.isInterestedForInteractions || pieTouchResponse == null ||
                                                                pieTouchResponse.touchedSection == null) {
                                                              touchedIndex = -1;
                                                              return;
                                                            }
                                                            touchedIndex = pieTouchResponse.touchedSection!.touchedSectionIndex;
                                                          });
                                                        },
                                                      ),
                                                      borderData: FlBorderData(
                                                        show: false,
                                                      ),
                                                      sectionsSpace: 2,
                                                      // centerSpaceRadius: 40,
                                                      sections: showingSections(home_pageController.HomePageData["pie_chart"][0]["data"]),
                                                    ),
                                                  ),
                                                  // Center(
                                                  //   child: Container(
                                                  //     width: 110,
                                                  //     child: Text(
                                                  //       "financial_assets".tr,
                                                  //       textAlign: TextAlign.center,
                                                  //       style: TextStyle(color: Darkgrey),
                                                  //     ),
                                                  //   ),
                                                  // ),
                                                ],
                                              ),
                                            ),
                                          ),
                                          SizedBox(width: 10,),
                                          Expanded(
                                            flex: 4,
                                            child: ListView.builder(
                                              itemCount: home_pageController.HomePageData["pie_chart"][0]["data"].length,
                                              shrinkWrap: true,
                                              physics: NeverScrollableScrollPhysics(),
                                              itemBuilder: (context, index) {
                                                var titles = home_pageController.HomePageData["pie_chart"][0]["data"][index];
                                                return Column(
                                                  mainAxisAlignment:
                                                      MainAxisAlignment.end,
                                                  crossAxisAlignment:
                                                      CrossAxisAlignment.start,
                                                  children: [
                                                    titles['total_assets'] == 0
                                                        ? Container()
                                                        : Indicator(
                                                            color: getColorForIndex(index),
                                                            text: "${titles["name"]}\t(${formatAmount(titles['total_assets'].toString())})"
                                                                    // "(${titles['total_assets']})"
                                                      ,
                                                            size: 200,
                                                            textwidth: 150,
                                                            isSquare: true,
                                                          ),
                                                    SizedBox(height: 7,),
                                                  ],
                                                );
                                              },
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                      ],
                    ):
                      SizedBox.shrink(),

                    for (var i in home_pageController.HomePageData["pie_chart"])
                      int.parse(i["total_assets"].toString()) == 0
                          ? Container()
                          :
                      // Card(
                      //         margin: EdgeInsets.only(left: 15, right: 15),
                      //         child: Container(
                      //           // height: 400,
                      //           width: size.width,
                      //           alignment: Alignment.center,
                      //           padding: EdgeInsets.only(left: 10, right: 10),
                      //           child: Column(
                      //             mainAxisAlignment: MainAxisAlignment.center,
                      //             crossAxisAlignment: CrossAxisAlignment.center,
                      //             children: [
                      //               Padding(
                      //                 padding: EdgeInsets.only(top: 20),
                      //                 child: Container(
                      //                   height: 50,
                      //                   child: Text(
                      //                     // typeId==1? "barchartAsst".tr:"barchartlib".tr,
                      //                     "barchartAsst".tr,
                      //                     style: TextStyle(
                      //                       color: ContainerColor,
                      //                       fontSize: 20,
                      //                       // fontWeight: FontWeight.bold
                      //                     ),
                      //                   ),
                      //                 ),
                      //               ),
                      //               Container(
                      //               //  color: Colors.red,
                      //                 height: 250,
                      //                 child: Padding(
                      //                   padding: const EdgeInsets.all(20),
                      //                   child: BarChart(BarChartData(
                      //                       borderData: FlBorderData(
                      //                           border:  const Border(
                      //                         top: BorderSide.none,
                      //                         right: BorderSide.none,
                      //                         left: BorderSide.none,
                      //                         bottom: BorderSide.none,
                      //                       )),
                      //                   titlesData: FlTitlesData(
                      //                         bottomTitles: AxisTitles(
                      //                           sideTitles: SideTitles(
                      //                             showTitles: true,
                      //                             interval: 1,
                      //                             getTitlesWidget: bottomTitleWidgets,
                      //                           ),
                      //                         ),
                      //                         leftTitles: AxisTitles(
                      //                           sideTitles: SideTitles(
                      //                             showTitles: true,
                      //                              interval: 17,
                      //                             reservedSize: 42,
                      //                           ),
                      //                         ),
                      //                         topTitles: AxisTitles(
                      //                           sideTitles: SideTitles(
                      //                               showTitles: false
                      //                           ),
                      //                         ),
                      //                         rightTitles: AxisTitles(
                      //                           sideTitles: SideTitles(
                      //                               showTitles: false
                      //                           ),
                      //                         ),
                      //                       ),
                      //                       gridData: FlGridData(
                      //                         show: false,
                      //                         drawVerticalLine: false,
                      //                         horizontalInterval: 20,
                      //
                      //
                      //                         // checkToShowHorizontalLine:
                      //                         //     (double value) {
                      //                         //   return value == 5 ||
                      //                         //       value == 10 ||
                      //                         //       value == 15 ||
                      //                         //       value == 20 ||
                      //                         //       value == 25 ||
                      //                         //       value == 30;
                      //                         // },
                      //                       ),
                      //                      // maxY: 1000000,
                      //                      //  maxY: home_pageController.barTotalAssets.value.toDouble(),
                      //                       // minY: 10,
                      //                       // borderData: FlBorderData(
                      //                       //     border: const Border(
                      //                       //       top: BorderSide.none,
                      //                       //       right: BorderSide.none,
                      //                       //       left: BorderSide(width: 1),
                      //                       //       bottom: BorderSide(width: 1),
                      //                       //     )),
                      //                       groupsSpace: 50,
                      //                       barGroups: home_pageController.createBarGroups()
                      //                   ),
                      //                   ),
                      //                 ),
                      //
                      //                 // barGroups: _myData
                      //                 //     .map((dataItem) =>
                      //                 //     BarChartGroupData(x: dataItem.x, barRods: [
                      //                 //       BarChartRodData(
                      //                 //           toY: dataItem.y1, width: 8, color: Colors.amber,
                      //                 //           borderRadius: BorderRadius.vertical(
                      //                 //               top: Radius.zero)),
                      //                 //       BarChartRodData(
                      //                 //           toY: dataItem.y2, width: 8, color: Colors.red,
                      //                 //           borderRadius: BorderRadius.vertical(
                      //                 //               top: Radius.zero)),
                      //                 //       BarChartRodData(
                      //                 //           toY: dataItem.y3, width: 8, color: Colors.blue,
                      //                 //           borderRadius: BorderRadius.vertical(
                      //                 //               top: Radius.zero)),
                      //                 //     ]))
                      //                 //     .toList())),
                      //               ),
                      //
                      //               Container(
                      //                 width: size.width,
                      //                 alignment: Alignment.center,
                      //                 padding:
                      //                     EdgeInsets.only(top: 10, left: 10),
                      //                 child: Column(
                      //                   mainAxisAlignment:
                      //                       MainAxisAlignment.center,
                      //                   crossAxisAlignment:
                      //                       CrossAxisAlignment.center,
                      //                   children: [
                      //                     for (var i in home_pageController
                      //                         .HomeBarChartNameData)
                      //                       // Text(i.toString())
                      //                       Indicator(
                      //                         color: i.color,
                      //                         // size: 120,
                      //                         text: i.name,
                      //                         // textwidth: 100,
                      //                         isSquare: true,
                      //                       ),
                      //                     SizedBox(
                      //                       height: 4,
                      //                     ),
                      //                   ],
                      //                 ),
                      //               ),
                      //             ],
                      //           ),
                      //         ),
                      //       ),
                      Card(
                        margin: EdgeInsets.only(left: 15, right: 15),
                        child: Container(
                          width: size.width,
                          alignment: Alignment.center,
                          padding: EdgeInsets.only(left: 10, right: 10),
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            crossAxisAlignment: CrossAxisAlignment.center,
                            children: [
                              Padding(
                                padding: EdgeInsets.only(top: 20),
                                child: Container(
                                  height: 50,
                                  child: Text(
                                    // typeId==1? "barchartAsst".tr:"barchartlib".tr,
                                    "barchartAsst".tr,
                                    style: TextStyle(
                                      color: ContainerColor,
                                      fontSize: 20,
                                      // fontWeight: FontWeight.bold
                                    ),
                                  ),
                                ),
                              ),

                              // Container(
                              //    height: 250,
                              //   child: Padding(
                              //     padding: EdgeInsets.all(20.0),
                              //     child: AspectRatio(
                              //       aspectRatio: 1.5,
                              //       child: BarChart(
                              //         BarChartData(
                              //           borderData: FlBorderData(
                              //             border: const Border(
                              //               top: BorderSide.none,
                              //               right: BorderSide.none,
                              //               left: BorderSide.none,
                              //               bottom: BorderSide.none,
                              //             ),
                              //           ),
                              //           titlesData: FlTitlesData(
                              //             bottomTitles: AxisTitles(
                              //               sideTitles: SideTitles(
                              //                 showTitles: true,
                              //                 interval: 1,
                              //                 getTitlesWidget: bottomTitleWidgets,
                              //               ),
                              //             ),
                              //             leftTitles: AxisTitles(
                              //               sideTitles: SideTitles(
                              //                 showTitles: true,
                              //                 interval: 17,
                              //                 reservedSize: 42,
                              //               ),
                              //             ),
                              //             topTitles: AxisTitles(
                              //               sideTitles: SideTitles(
                              //                   showTitles: false
                              //               ),
                              //             ),
                              //             rightTitles: AxisTitles(
                              //               sideTitles: SideTitles(
                              //                   showTitles: false
                              //               ),
                              //             ),
                              //           ),
                              //           gridData: FlGridData(
                              //             show: false,
                              //             drawVerticalLine: false,
                              //             horizontalInterval: 20,
                              //           ),
                              //           groupsSpace: 50,
                              //           alignment: BarChartAlignment.spaceAround,
                              //           maxY: _calculateMaxY(home_pageController.HomePageData["bar_chart"],250),
                              //           barGroups: List.generate(
                              //             home_pageController.HomePageData["bar_chart"].length,
                              //                 (index) {
                              //               var bars = home_pageController.HomePageData['bar_chart'][index]["data"];
                              //               var total = home_pageController.HomePageData['bar_chart'][index]['total_assets'];
                              //               return BarChartGroupData(
                              //                 x: index,
                              //                 barsSpace: 4,
                              //                 barRods: List.generate(
                              //                   bars.length,
                              //                       (barIndex) {
                              //                     var barData = bars[barIndex];
                              //                     var value = barData['total_assets'] ?? 0;
                              //                     // Calculate the percentage
                              //                     var percentage = total != 0 ? (value / total) * 100 : 0;
                              //                     return BarChartRodData(
                              //                       toY: percentage.toDouble(), // Use y instead of toY
                              //                       color: Colors.blue,
                              //                       width: 10,
                              //                       borderRadius: BorderRadius.vertical(top: Radius.zero),
                              //                     );
                              //                   },
                              //                 ),
                              //               );
                              //             },
                              //           ),
                              //         ),
                              //       ),
                              //     ),
                              //   ),
                              // ),

                              Container(
                                height: 250,
                                child: Stack(
                                  children: [
                                    Padding(
                                      padding: EdgeInsets.all(20.0),
                                      child: AspectRatio(
                                        aspectRatio: 1.5,
                                        child: BarChart(
                                          BarChartData(
                                            borderData: FlBorderData(
                                              border:  Border(
                                                top: BorderSide.none,
                                                right: BorderSide.none,
                                                left: BorderSide.none,
                                                bottom: BorderSide.none,
                                              ),
                                            ),
                                            titlesData: FlTitlesData(
                                              bottomTitles: AxisTitles(
                                                sideTitles: SideTitles(
                                                  showTitles: true,
                                                  interval: 1,
                                                  getTitlesWidget: bottomTitleWidgets,
                                                ),
                                              ),
                                              leftTitles: AxisTitles(
                                                sideTitles: SideTitles(
                                                  showTitles: true,
                                                  interval: 17,
                                                  reservedSize: 42,
                                                  getTitlesWidget: (value, meta) {
                                                    return Text('${value.toInt()}', style: TextStyle(color: Colors.black));
                                                  },
                                                ),
                                              ),
                                              topTitles: AxisTitles(
                                                sideTitles: SideTitles(showTitles: false),
                                              ),
                                              rightTitles: AxisTitles(
                                                sideTitles: SideTitles(showTitles: false),
                                              ),
                                            ),
                                            gridData: FlGridData(
                                              show: false,
                                              drawVerticalLine: false,
                                              horizontalInterval: 20,
                                            ),
                                            groupsSpace: 50,
                                            alignment: BarChartAlignment.spaceAround,
                                            maxY: _calculateMaxY(home_pageController.HomePageData["bar_chart"], 250),
                                            barGroups: List.generate(
                                              home_pageController.HomePageData["bar_chart"].length,
                                                  (index) {
                                                var bars = home_pageController.HomePageData['bar_chart'][index]["data"];
                                                var total = home_pageController.HomePageData['bar_chart'][index]['total_assets'];
                                                return BarChartGroupData(
                                                  x: index,
                                                  barsSpace: 4,
                                                  barRods: List.generate(
                                                    bars.length,
                                                        (barIndex) {
                                                      var barData = bars[barIndex];
                                                      var value = barData['total_assets'] ?? 0;
                                                      // Calculate the percentage
                                                      var percentage = total != 0 ? (value / total) * 100 : 0;
                                                      return BarChartRodData(
                                                        toY: percentage.toDouble(),
                                                        color: Colors.blue,
                                                        width: 10,
                                                        borderRadius: BorderRadius.vertical(top: Radius.zero),
                                                      );
                                                    },
                                                  ),
                                                );
                                              },
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                    Positioned(
                                      left: 0,
                                      top: 0,
                                      bottom: 0,
                                      child: RotatedBox(
                                        quarterTurns: 3,
                                        child: Center(
                                          child: Text(
                                            'Unit of Measurement'.tr,
                                            style: TextStyle(color: Colors.black, fontSize: 14),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ],
                                ),
                              ),


                              Container(
                                width: size.width,
                                alignment: Alignment.center,
                                padding:
                                EdgeInsets.only(top: 10, left: 10),
                                child: Column(
                                  mainAxisAlignment:
                                  MainAxisAlignment.center,
                                  crossAxisAlignment:
                                  CrossAxisAlignment.center,
                                  children: [
                                    for (var i in home_pageController
                                        .HomeBarChartNameData)
                                    // Text(i.toString())
                                      Indicator(
                                        color: i.color,
                                        size: 200,
                                        text: i.name,
                                        textwidth: 150,
                                        isSquare: true,
                                      ),
                                    SizedBox(
                                      height: 4,
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),

                    /// LIBILITIES.....

                    home_pageController.widgitLoading == true
                        ? Center(
                            child: Container(
                                alignment: Alignment.center,
                                height: size.height * 0.20,
                                child: CircularProgressIndicator()))
                        : Column(
                            children: [
                              Container(
                                  // margin: EdgeInsets.symmetric(vertical: 20),
                                  child: Divider(
                                color: sidebarcontainerColor,
                                height: 50,
                                thickness: 3,
                                indent: 5,
                                endIndent: 5,
                              )),
                              Row(
                                mainAxisAlignment:
                                    MainAxisAlignment.spaceEvenly,
                                children: [
                                  GestureDetector(
                                    // onTap: () {
                                    //   typeId =2;
                                    //   home_pageController.HomePageApiCalling(Home_url + "?type=${2}",true);
                                    //   setState(() {
                                    //     type = true;
                                    //   });
                                    // },
                                    child: Container(
                                      height: 80,
                                      width: 160,
                                      decoration: BoxDecoration(
                                        color: type == true
                                            ? appPrimaryColor
                                            : whiteColor,
                                        boxShadow: [
                                          BoxShadow(
                                            color: greyColor,
                                            blurRadius: 5.0,
                                          ),
                                        ],
                                        border:
                                            Border.all(color: ContainerColor),
                                        borderRadius: BorderRadius.all(
                                          (Radius.circular(10)),
                                        ),
                                      ),
                                      child: Row(
                                        mainAxisAlignment:
                                            MainAxisAlignment.spaceAround,
                                        children: [
                                          Image.asset(
                                            "assets/images/home_manage.png",
                                            scale: 3,
                                            color: type == true
                                                ? whiteColor
                                                : appPrimaryColor,
                                          ),
                                          Text(
                                            "liabilitie".tr,
                                            style: TextStyle(
                                                color: type == true
                                                    ? whiteColor
                                                    : appPrimaryColor,
                                                fontSize: 18),
                                          )
                                        ],
                                      ),
                                    ),
                                  ),
                                  GestureDetector(
                                    // onTap: () {
                                    //   typeId =2;
                                    //   home_pageController.HomePageApiCalling(Home_url + "?type=${typeId}",true);
                                    //   setState(() {
                                    //     type = false;
                                    //   });
                                    // },
                                    child: Container(
                                      height: 80,
                                      width: 160,
                                      decoration: BoxDecoration(
                                        color: type == false
                                            ? appPrimaryColor
                                            : whiteColor,
                                        boxShadow: [
                                          BoxShadow(
                                            color: greyColor,
                                            blurRadius: 5.0,
                                          ),
                                        ],
                                        border:
                                            Border.all(color: ContainerColor),
                                        borderRadius: BorderRadius.all(
                                          (Radius.circular(10)),
                                        ),
                                      ),
                                      child: Column(
                                        children: [
                                          Row(
                                            mainAxisAlignment:
                                                MainAxisAlignment.end,
                                            children: [
                                              GestureDetector(
                                                onTap: () {
                                                  setState(() {
                                                    passToogle2 = !passToogle2;
                                                  });
                                                },
                                                child: Container(
                                                  width: 30,
                                                  child: Icon(
                                                    passToogle2
                                                        ? Icons.visibility_off
                                                        : Icons.visibility,
                                                    color: type == false
                                                        ? whiteColor
                                                        : Colors.black,
                                                  ),
                                                ),
                                              ),
                                            ],
                                          ),
                                          Row(
                                            mainAxisAlignment:
                                                MainAxisAlignment.spaceAround,
                                            children: [
                                              Image.asset(
                                                "assets/images/money.png",
                                                scale: 3,
                                                color: type == false
                                                    ? whiteColor
                                                    : appPrimaryColor,
                                              ),
                                              Column(
                                                children: [
                                                  Text(
                                                    'totalValueOfAssets'.tr,
                                                    style: TextStyle(
                                                      color: type == false
                                                          ? whiteColor
                                                          : greyColor,
                                                    ),
                                                  ),
                                                  Row(
                                                    children: [
                                                      Text(
                                                        'slash'.tr,
                                                        style: TextStyle(
                                                          color: type == false
                                                              ? whiteColor
                                                              : greyColor,
                                                          fontSize: 15,
                                                        ),
                                                      ),
                                                      passToogle2
                                                          ? Row(
                                                              children: [
                                                                // type == false
                                                                //     ? whiteColor
                                                                //     : greyColor,
                                                                Icon(
                                                                  Icons.circle,
                                                                  color: type ==
                                                                          false
                                                                      ? whiteColor
                                                                      : greyColor,
                                                                  size: 15,
                                                                ),
                                                                // Icon(
                                                                //   Icons.circle,
                                                                //   color: type == false
                                                                //       ? whiteColor
                                                                //       : greyColor,
                                                                //   size: 15,
                                                                // ),
                                                                // Icon(
                                                                //   Icons.circle,
                                                                //   color: type == false
                                                                //       ? whiteColor
                                                                //       : greyColor,
                                                                //   size: 15,
                                                                // ),
                                                                // Icon(
                                                                //   Icons.circle,
                                                                //   color: type == false
                                                                //       ? whiteColor
                                                                //       : greyColor,
                                                                //   size: 15,
                                                                // )
                                                              ],
                                                            )
                                                          : Text(
                                                        formatAmount(home_pageController.HomePageData["total_liabilities"].toString(),),
                                                              style: TextStyle(
                                                                color: type == false
                                                                    ? whiteColor
                                                                    : greyColor,
                                                              ),
                                                            ),
                                                    ],
                                                  ),
                                                ],
                                              )
                                            ],
                                          ),
                                        ],
                                      ),
                                    ),
                                  )
                                ],
                              ),
                              Padding(
                                padding: EdgeInsets.only(
                                    top: 10, left: 10, right: 10),
                                child: Container(
                                  alignment: Alignment.topLeft,
                                  height: 40,
                                  child: ListView.builder(
                                      itemCount: home_pageController.HomePageLibalitesListData.length,
                                      scrollDirection: Axis.horizontal,
                                      shrinkWrap: true,
                                      physics: AlwaysScrollableScrollPhysics(),
                                      itemBuilder:
                                          (BuildContext context, index) {
                                        var listdata = home_pageController
                                            .HomePageLibalitesListData[index];
                                        return GestureDetector(
                                          onTap: () {
                                            home_pageController.widgitLoading =
                                                true;
                                            setState(() {});
                                            var categoryId =
                                                listdata['id'].toString();
                                            print("categoryId--->>" +
                                                categoryId.toString());
                                            // gethomeData(categoryId,typeId);
                                            Map<String, String> queryParams = {
                                              'category_id': categoryId.toString(),
                                               "type": "2".toString()
                                            };

                                            String queryString = Uri(queryParameters: queryParams).query;

                                            var Home_urls =
                                                Home_url + '?' + queryString;
                                            home_pageController.HomePageLibalityApiCalling(
                                                    Home_urls, false);

                                            // liabilitiesdata();

                                            setState(() {
                                              current2 = index;
                                            });
                                          },
                                          child: Container(
                                            margin: EdgeInsets.all(2),
                                            width: 120,
                                            decoration: BoxDecoration(
                                              color: current2 == index
                                                  ? appPrimaryColor
                                                  : whiteColor,
                                              border: Border.all(
                                                  color: appPrimaryColor),
                                              borderRadius: BorderRadius.all(
                                                  Radius.circular(5)),
                                            ),
                                            child: Center(
                                                child: Text(
                                              listdata['name'].toString(),
                                              textAlign: TextAlign.center,
                                              textScaleFactor: 1.0,
                                              style: TextStyle(
                                                  color: current == index
                                                      ? whiteColor
                                                      : greyColor,
                                                  fontSize: 12,
                                                  wordSpacing: 0.2,
                                                  overflow: TextOverflow.clip),
                                            )),
                                          ),
                                        );
                                      }),
                                ),
                              ),
                              if( activeItems[0]['dashboard_toggle']!=0)
                                activeItems[0]['libilities_toggle']==1?
                             Column(
                                children: [
                                  home_pageController.widgitLoading == true
                                      ? Center(
                                      child: Container(
                                          alignment: Alignment.center,
                                          height: size.height * 0.20,
                                          child: CircularProgressIndicator())
                                  )
                                      : int.parse(home_pageController.HomePageLibalitesData[
                                  "pie_chart"][0]
                                  ["total_assets"]
                                      .toString()) == 0
                                      ? Container(
                                      height: size.height * 0.20,
                                      child: Column(
                                        mainAxisAlignment:
                                        MainAxisAlignment.center,
                                        crossAxisAlignment:
                                        CrossAxisAlignment.center,
                                        children: [
                                          Text(
                                            "DataFound".tr,
                                            style: TextStyle(
                                                fontSize: 14.5,
                                                fontWeight: FontWeight.w600,
                                                color: Colors.grey.shade600,
                                                letterSpacing: 0.5),
                                          ),
                                        ],
                                      ))
                                      : Card(
                                    margin: EdgeInsets.all(15),
                                    child: Container(
                                      height: 240,
                                      width: size.width,
                                      alignment: Alignment.center,
                                      padding: EdgeInsets.only(
                                          left: 10, right: 10),
                                      child: Row(
                                        children: [
                                          Expanded(
                                            flex: 6,
                                            child: AspectRatio(
                                              aspectRatio: 1,
                                              child: Stack(
                                                children: [
                                                  PieChart(
                                                    PieChartData(
                                                      pieTouchData:
                                                      PieTouchData(
                                                        touchCallback:
                                                            (FlTouchEvent
                                                        event,
                                                            pieTouchResponse) {
                                                          setState(() {
                                                            if (!event
                                                                .isInterestedForInteractions ||
                                                                pieTouchResponse ==
                                                                    null ||
                                                                pieTouchResponse
                                                                    .touchedSection ==
                                                                    null) {
                                                              touchedIndex =
                                                              -1;
                                                              return;
                                                            }
                                                            touchedIndex =
                                                                pieTouchResponse
                                                                    .touchedSection!
                                                                    .touchedSectionIndex;
                                                          });
                                                        },
                                                      ),
                                                      borderData:
                                                      FlBorderData(
                                                        show: false,
                                                      ),
                                                      sectionsSpace: 2,
                                                      // centerSpaceRadius: 40,
                                                      sections: showingSections(
                                                          home_pageController.HomePageLibalitesData["pie_chart"][0]["data"]),
                                                    ),
                                                  ),
                                                  // Center(
                                                  //   child: Container(
                                                  //     width: 110,
                                                  //     child: Text(
                                                  //       "financial_assets".tr,
                                                  //       textAlign: TextAlign.center,
                                                  //       style: TextStyle(color: Darkgrey),
                                                  //     ),
                                                  //   ),
                                                  // ),
                                                ],
                                              ),
                                            ),
                                          ),
                                          SizedBox(width: 10,),
                                          Expanded(
                                            flex: 5,
                                            child: ListView.builder(
                                              itemCount: home_pageController.HomePageLibalitesData["pie_chart"][0]["data"].length,
                                              shrinkWrap: true,
                                              physics:
                                              NeverScrollableScrollPhysics(),
                                              itemBuilder:
                                                  (context, index) {
                                                var titles = home_pageController.HomePageLibalitesData["pie_chart"][0]["data"][index];
                                                // print("pie char text------>"+titles.toString());
                                                return Column(
                                                  mainAxisAlignment: MainAxisAlignment.end,
                                                  crossAxisAlignment: CrossAxisAlignment.start,
                                                  children: <Widget>[
                                                    titles['total_assets'] == 0
                                                        ? Container()
                                                        : Indicator(
                                                      color:
                                                      getColorForIndex(index),
                                                      // text: titles["name"],
                                                      text:
                                                      // "${titles["name"]}(${titles['total_assets']})",
                                                      "${titles["name"]}\t(${formatAmount(titles['total_assets'].toString())})",
                                                      size: 200,
                                                      textwidth: 150,
                                                      isSquare: true,
                                                    ),
                                                    SizedBox(
                                                      height: 4,
                                                    ),
                                                  ],
                                                );
                                              },
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),
                                  ),
                                ],
                              ):
                                SizedBox.shrink(),

                              // for (var i in home_pageController.HomePageLibalitesData["pie_chart"])
                              //   int.parse(i["total_assets"].toString()) == 0
                              //       ? Container()
                              //       : Card(
                              //           margin: EdgeInsets.only(
                              //               left: 15, right: 15),
                              //           child: Container(
                              //             // height: 400,
                              //             width: size.width,
                              //             alignment: Alignment.center,
                              //             padding: EdgeInsets.only(
                              //                 left: 10, right: 10),
                              //             child: Column(
                              //               mainAxisAlignment:
                              //                   MainAxisAlignment.center,
                              //               crossAxisAlignment:
                              //                   CrossAxisAlignment.center,
                              //               children: [
                              //                 Padding(
                              //                   padding:
                              //                       EdgeInsets.only(top: 20),
                              //                   child: Container(
                              //                     height: 50,
                              //                     child: Text(
                              //                       "barchartlib".tr,
                              //                       style: TextStyle(
                              //                         color: ContainerColor,
                              //                         fontSize: 20,
                              //                         // fontWeight: FontWeight.bold
                              //                       ),
                              //                     ),
                              //                   ),
                              //                 ),
                              //                 Container(
                              //                   height: 250,
                              //                   child: BarChart(BarChartData(
                              //                       borderData: FlBorderData(
                              //                           border: Border(
                              //                         top: BorderSide.none,
                              //                         right: BorderSide.none,
                              //                         left: BorderSide.none,
                              //                         bottom: BorderSide.none,
                              //                       )),
                              //                       titlesData: FlTitlesData(
                              //                         bottomTitles: AxisTitles(
                              //                           sideTitles: SideTitles(
                              //                             showTitles: true,
                              //                             interval: 1,
                              //                             getTitlesWidget:
                              //                                 bottomTitleWidgets,
                              //                           ),
                              //                         ),
                              //                         leftTitles: AxisTitles(
                              //                           sideTitles: SideTitles(
                              //                             showTitles: true,
                              //                             interval: 5,
                              //                             reservedSize: 36,
                              //                           ),
                              //                         ),
                              //                         topTitles: AxisTitles(
                              //                           sideTitles: SideTitles(
                              //                               showTitles: false),
                              //                         ),
                              //                         rightTitles: AxisTitles(
                              //                           sideTitles: SideTitles(
                              //                               showTitles: false),
                              //                         ),
                              //                       ),
                              //                       gridData: FlGridData(
                              //                         show: false,
                              //                         drawVerticalLine: false,
                              //                         horizontalInterval: 1,
                              //                         checkToShowHorizontalLine:
                              //                             (double value) {
                              //                           return value == 5 ||
                              //                               value == 10 ||
                              //                               value == 15 ||
                              //                               value == 20 ||
                              //                               value == 25 ||
                              //                               value == 30;
                              //                         },
                              //                       ),
                              //                       // maxY: 30,
                              //                       // minY: 5,
                              //                       groupsSpace: 50,
                              //                       barGroups: home_pageController
                              //                           .createBarLibalityGroups())),
                              //                   // barGroups: _myData
                              //                   //     .map((dataItem) =>
                              //                   //     BarChartGroupData(x: dataItem.x, barRods: [
                              //                   //       BarChartRodData(
                              //                   //           toY: dataItem.y1, width: 8, color: Colors.amber,
                              //                   //           borderRadius: BorderRadius.vertical(
                              //                   //               top: Radius.zero)),
                              //                   //       BarChartRodData(
                              //                   //           toY: dataItem.y2, width: 8, color: Colors.red,
                              //                   //           borderRadius: BorderRadius.vertical(
                              //                   //               top: Radius.zero)),
                              //                   //       BarChartRodData(
                              //                   //           toY: dataItem.y3, width: 8, color: Colors.blue,
                              //                   //           borderRadius: BorderRadius.vertical(
                              //                   //               top: Radius.zero)),
                              //                   //     ]))
                              //                   //     .toList())),
                              //                 ),
                              //                 Container(
                              //                   width: size.width,
                              //                   alignment: Alignment.center,
                              //                   padding: EdgeInsets.only(
                              //                       top: 10, left: 10),
                              //                   child: Column(
                              //                     mainAxisAlignment:
                              //                         MainAxisAlignment.center,
                              //                     crossAxisAlignment:
                              //                         CrossAxisAlignment.center,
                              //                     children: [
                              //                       for (var i
                              //                           in home_pageController
                              //                               .HomeBarChartLibalityNameData)
                              //                         // Text(i.toString())
                              //                         Indicator(
                              //                           color: i.color,
                              //                           // size: 120,
                              //                           text: i.name,
                              //                           // textwidth: 100,
                              //                           isSquare: true,
                              //                         ),
                              //                       SizedBox(
                              //                         height: 4,
                              //                       ),
                              //                     ],
                              //                   ),
                              //                 ),
                              //               ],
                              //             ),
                              //           ),
                              //         ),


                              for (var i in home_pageController.HomePageLibalitesData["pie_chart"])
                                int.parse(i["total_assets"].toString()) == 0
                                    ? Container()
                                    : Card(
                                        margin: EdgeInsets.only(
                                            left: 15, right: 15),
                                        child: Container(
                                          // height: 400,
                                          width: size.width,
                                          alignment: Alignment.center,
                                          padding: EdgeInsets.only(
                                              left: 10, right: 10),
                                          child: Column(
                                            mainAxisAlignment:
                                                MainAxisAlignment.center,
                                            crossAxisAlignment:
                                                CrossAxisAlignment.center,
                                            children: [
                                              Padding(
                                                padding:
                                                    EdgeInsets.only(top: 20),
                                                child: Container(
                                                  height: 50,
                                                  child: Text(
                                                    "barchartlib".tr,
                                                    style: TextStyle(
                                                      color: ContainerColor,
                                                      fontSize: 20,
                                                      // fontWeight: FontWeight.bold
                                                    ),
                                                  ),
                                                ),
                                              ),
                                              // Container(
                                              //   height: 250,
                                              //   child: Stack(
                                              //     children:[
                                              //       Padding(
                                              //       padding: EdgeInsets.all(20.0),
                                              //       child: AspectRatio(
                                              //         aspectRatio: 1.5,
                                              //         child: BarChart(BarChartData(
                                              //
                                              //             borderData: FlBorderData(
                                              //                 border: Border(
                                              //               top: BorderSide.none,
                                              //               right: BorderSide.none,
                                              //               left: BorderSide.none,
                                              //               bottom: BorderSide.none,
                                              //             )),
                                              //             titlesData: FlTitlesData(
                                              //               bottomTitles: AxisTitles(
                                              //                 sideTitles: SideTitles(
                                              //                   showTitles: true,
                                              //                   interval: 1,
                                              //                   getTitlesWidget:
                                              //                       bottomTitleWidgets,
                                              //                 ),
                                              //               ),
                                              //               leftTitles: AxisTitles(
                                              //                 sideTitles: SideTitles(
                                              //                   showTitles: true,
                                              //                   interval: 17,
                                              //                   reservedSize: 42,
                                              //                 ),
                                              //               ),
                                              //               topTitles: AxisTitles(
                                              //                 sideTitles: SideTitles(
                                              //                     showTitles: false),
                                              //               ),
                                              //               rightTitles: AxisTitles(
                                              //                 sideTitles: SideTitles(
                                              //                     showTitles: false),
                                              //               ),
                                              //             ),
                                              //             gridData: FlGridData(
                                              //               show: false,
                                              //               drawVerticalLine: false,
                                              //               horizontalInterval: 20,
                                              //               // checkToShowHorizontalLine:
                                              //               //     (double value) {
                                              //               //   return value == 5 ||
                                              //               //       value == 10 ||
                                              //               //       value == 15 ||
                                              //               //       value == 20 ||
                                              //               //       value == 25 ||
                                              //               //       value == 30;
                                              //               // },
                                              //             ),
                                              //             // maxY: 30,
                                              //             // minY: 5,
                                              //           maxY: _calculateMaxY(home_pageController.HomePageLibalitesData["bar_chart"],250),
                                              //             groupsSpace: 50,
                                              //             alignment: BarChartAlignment.spaceAround,
                                              //             //barGroups: home_pageController.createBarLibalityGroups())),
                                              //           barGroups: List.generate(
                                              //             home_pageController.HomePageLibalitesData["bar_chart"].length,
                                              //                 (index) {
                                              //               var bars = home_pageController.HomePageLibalitesData['bar_chart'][index]["data"];
                                              //               var total = home_pageController.HomePageLibalitesData['bar_chart'][index]['total_assets'];
                                              //               return BarChartGroupData(
                                              //                 x: index,
                                              //                 barsSpace: 4,
                                              //                 barRods: List.generate(
                                              //                   bars.length,
                                              //                       (barIndex) {
                                              //                     var barData = bars[barIndex];
                                              //                     var value = barData['total_assets'] ?? 0;
                                              //                     // Calculate the percentage
                                              //                     var percentage = total != 0 ? (value / total) * 100 : 0;
                                              //                     return BarChartRodData(
                                              //                       toY: percentage.toDouble(), // Use y instead of toY
                                              //                       color: Colors.blue,
                                              //                       width: 10,
                                              //                       borderRadius: BorderRadius.vertical(top: Radius.zero),
                                              //                     );
                                              //                   },
                                              //                 ),
                                              //               );
                                              //             },
                                              //           ),
                                              //         ),)
                                              //
                                              //       ),
                                              //     ),
                                              //       Positioned(
                                              //         left: 0,
                                              //         top: 0,
                                              //         bottom: 0,
                                              //         child: RotatedBox(
                                              //           quarterTurns: 3,
                                              //           child: Center(
                                              //             child: Text(
                                              //               'Unit of Measurement'.tr,
                                              //               style: TextStyle(color: Colors.black, fontSize: 14),
                                              //             ),
                                              //           ),
                                              //         ),
                                              //       ),
                                              //     ]
                                              //   ),
                                              //   // barGroups: _myData
                                              //   //     .map((dataItem) =>
                                              //   //     BarChartGroupData(x: dataItem.x, barRods: [
                                              //   //       BarChartRodData(
                                              //   //           toY: dataItem.y1, width: 8, color: Colors.amber,
                                              //   //           borderRadius: BorderRadius.vertical(
                                              //   //               top: Radius.zero)),
                                              //   //       BarChartRodData(
                                              //   //           toY: dataItem.y2, width: 8, color: Colors.red,
                                              //   //           borderRadius: BorderRadius.vertical(
                                              //   //               top: Radius.zero)),
                                              //   //       BarChartRodData(
                                              //   //           toY: dataItem.y3, width: 8, color: Colors.blue,
                                              //   //           borderRadius: BorderRadius.vertical(
                                              //   //               top: Radius.zero)),
                                              //   //     ]))
                                              //   //     .toList())),
                                              // ),
                                              Container(
                                                height: 250,
                                                child: Stack(
                                                  children: [
                                                    Padding(
                                                      padding: EdgeInsets.all(20.0),
                                                      child: AspectRatio(
                                                        aspectRatio: 1.5,
                                                        child: BarChart(
                                                          BarChartData(
                                                            borderData: FlBorderData(
                                                              border:  Border(
                                                                top: BorderSide.none,
                                                                right: BorderSide.none,
                                                                left: BorderSide.none,
                                                                bottom: BorderSide.none,
                                                              ),
                                                            ),
                                                            titlesData: FlTitlesData(
                                                              bottomTitles: AxisTitles(
                                                                sideTitles: SideTitles(
                                                                  showTitles: true,
                                                                  interval: 1,
                                                                  getTitlesWidget: bottomTitleWidgets,
                                                                ),
                                                              ),
                                                              leftTitles: AxisTitles(
                                                                sideTitles: SideTitles(
                                                                  showTitles: true,
                                                                  interval: 17,
                                                                  reservedSize: 42,
                                                                ),
                                                              ),
                                                              topTitles: AxisTitles(
                                                                sideTitles: SideTitles(showTitles: false),
                                                              ),
                                                              rightTitles: AxisTitles(
                                                                sideTitles: SideTitles(showTitles: false),
                                                              ),
                                                            ),
                                                            gridData: FlGridData(
                                                              show: false,
                                                              drawVerticalLine: false,
                                                              horizontalInterval: 20,
                                                            ),
                                                            maxY: _calculateMaxY(home_pageController.HomePageLibalitesData["bar_chart"], 250),
                                                            groupsSpace: 50,
                                                            alignment: BarChartAlignment.spaceAround,
                                                            barGroups: List.generate(
                                                              home_pageController.HomePageLibalitesData["bar_chart"].length,
                                                                  (index) {
                                                                var bars = home_pageController.HomePageLibalitesData['bar_chart'][index]["data"];
                                                                var total = home_pageController.HomePageLibalitesData['bar_chart'][index]['total_assets'];
                                                                log('Assets>>>'+total.toString());

                                                                return BarChartGroupData(
                                                                  x: index,
                                                                  barsSpace: 4,
                                                                  barRods: List.generate(
                                                                    bars.length,
                                                                        (barIndex) {
                                                                      var barData = bars[barIndex];
                                                                      var value = barData['total_assets'] ?? 0;
                                                                      // Calculate the percentage
                                                                      var percentage = total != 0 ? (value / total) * 100 : 0;
                                                                      log('Assets>>>'+percentage.toString());
                                                                      return BarChartRodData(
                                                                        toY: percentage.toDouble(),
                                                                        color: Colors.blue,
                                                                        width: 10,
                                                                        borderRadius: BorderRadius.vertical(top: Radius.zero),
                                                                      );
                                                                    },
                                                                  ),
                                                                );
                                                              },
                                                            ),
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                    Positioned(
                                                      left: 0,
                                                      top: 0,
                                                      bottom: 0,
                                                      child: RotatedBox(
                                                        quarterTurns: 3,
                                                        child: Center(
                                                          child: Text(
                                                            'Unit of Measurement'.tr,
                                                            style: TextStyle(color: Colors.black, fontSize: 14),
                                                          ),
                                                        ),
                                                      ),
                                                    ),
                                                  ],
                                                ),
                                              ),

                                              Container(
                                                width: size.width,
                                                alignment: Alignment.center,
                                                padding: EdgeInsets.only(
                                                    top: 10, left: 10),
                                                child: Column(
                                                  mainAxisAlignment:
                                                      MainAxisAlignment.center,
                                                  crossAxisAlignment:
                                                      CrossAxisAlignment.center,
                                                  children: [
                                                    for (var i
                                                        in home_pageController
                                                            .HomeBarChartLibalityNameData)
                                                      // Text(i.toString())
                                                      Indicator(
                                                        color: i.color,
                                                        // size: 120,
                                                        text: i.name,
                                                        // textwidth: 100,
                                                        isSquare: true,
                                                      ),
                                                    SizedBox(
                                                      height: 4,
                                                    ),
                                                  ],
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                       ),
                              sizebox_height_20
                            ],
                          )
                  ],
                ),
              );
            }
          })),
    );
  }
  // double _calculateMaxY( data) {
  //   log('data==>'+data.toString());
  //   double max = 0;
  //   for (var monthData in data) {
  //     var bars = monthData['data'];
  //     var total = monthData['total_assets'];
  //     for (var barData in bars) {
  //       var value = barData['total_assets'] / total * 100;
  //       if (value > max) {
  //         max = value;
  //       }
  //     }
  //   }
  //   return max + 10; // Add some padding
  // }

  double _calculateMaxY(List<dynamic> data, double containerHeight) {
    double max = 0;
    for (var monthData in data) {
      var bars = monthData['data'];
      var total = monthData['total_assets'];
      for (var barData in bars) {
        var value = barData['total_assets'] / total * 100;
        if (value > max) {
          max = value;
        }
      }
    }

    // Calculate maxY based on containerHeight
    double maxY = (max + 10) * containerHeight ; // Add some padding
    double maxValueHeight = maxY / 100 * containerHeight;

    // If the maximum value height exceeds the container height, scale down maxY
    if (maxValueHeight > containerHeight) {
      maxY = (containerHeight / maxValueHeight) * maxY;
    }

    return maxY;
  }






}
