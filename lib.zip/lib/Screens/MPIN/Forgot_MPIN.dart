import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:pinput/pinput.dart';
import 'package:urwealthpal/Constant/Api.dart';
import 'package:urwealthpal/Constant/Images.dart';
import 'package:urwealthpal/Constant/colors.dart';
import 'package:urwealthpal/Screens/MPIN/Controllers/Reset_MPIN_Controller.dart';

class Forgot_MPIN extends StatefulWidget {
  const Forgot_MPIN({Key? key}) : super(key: key);

  @override
  State<Forgot_MPIN> createState() => _Forgot_MPINState();
}

class _Forgot_MPINState extends State<Forgot_MPIN> {
  var _formKey = GlobalKey<FormState>();

  final focusNode = FocusNode();

  // @override
  // void dispose() {
  //   resetMPINController.dispose();
  //   focusNode.dispose();
  //   super.dispose();
  // }

  ResetMPINController resetMPINController = Get.put(ResetMPINController());

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;

    final defaultPinTheme = PinTheme(
      width: 56,
      height: 56,
      textStyle: TextStyle(
        fontSize: 22,
        color: Color.fromRGBO(30, 60, 87, 1),
      ),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: Colors.grey),
      ),
    );

    return Scaffold(
      resizeToAvoidBottomInset: false,
      body: Container(
        height: size.height,
        width: size.width,
        decoration: BoxDecoration(
          image: DecorationImage(
              image: AssetImage("assets/images/full_background.png"),
              fit: BoxFit.cover),
        ),
        child: Column(
          children: [
            Stack(
              children: [
                Form(
                    key: _formKey,
                    child: SingleChildScrollView(
                      child: Column(
                        children: [
                          Container(
                              margin: EdgeInsets.only(top: 110),
                              alignment: Alignment.center,
                              width: size.width,
                              child: MPINImage),
                          Container(
                            alignment: Alignment.center,
                            width: size.width,
                            child: Text(
                              "forgotMPIN".tr,
                              style: TextStyle(
                                  color: whiteColor,
                                  fontWeight: FontWeight.bold,
                                  fontSize: 32),
                            ),
                          ),
                          Container(
                            height: 350,
                            margin:
                                EdgeInsets.only(top: 30, left: 20, right: 20),
                            decoration: BoxDecoration(
                              color: whiteColor,
                              border: Border.all(color: whiteColor),
                              borderRadius:
                                  BorderRadius.all(Radius.circular(30)),
                            ),
                            child: Column(
                              children: [
                                SizedBox(
                                  height: 60,
                                ),
                                Padding(
                                  padding: EdgeInsets.only(left: 20, right: 20),
                                  child: TextFormField(
                                    controller: resetMPINController.OTP,
                                    // androidSmsAutofillMethod:AndroidSmsAutofillMethod.smsUserConsentApi,
                                    // listenForMultipleSmsOnAndroid: true,
                                    inputFormatters: [
                                      FilteringTextInputFormatter.allow(
                                          RegExp('[0-9]'))
                                    ],
                                    keyboardType:TextInputType.numberWithOptions(
                                            decimal: true),
                                    autovalidateMode:
                                        AutovalidateMode.onUserInteraction,
                                    validator: (value) {
                                      if (value == null) {
                                        return "otptxt".tr;
                                      } else if (value.length != 4) {
                                        return "validotptxt".tr;
                                      } else
                                        return null;
                                    },
                                    maxLength: 4,
                                    textInputAction: TextInputAction.next,
                                    decoration: InputDecoration(
                                      filled: true,
                                      fillColor: whiteColor,
                                      contentPadding: EdgeInsets.only(top: 5),
                                      constraints: BoxConstraints(
                                          minWidth: 30, maxHeight: 70),
                                      border: OutlineInputBorder(
                                        borderRadius: BorderRadius.circular(10),
                                      ),
                                      enabledBorder: OutlineInputBorder(
                                          borderRadius:
                                              BorderRadius.circular(10),
                                          borderSide: BorderSide(
                                              width: 1, color: Namecolors)),
                                      focusedBorder: OutlineInputBorder(
                                          borderRadius:
                                              BorderRadius.circular(10),
                                          borderSide: BorderSide(
                                              width: 1,
                                              color: appPrimaryColor)),
                                      focusedErrorBorder: OutlineInputBorder(
                                          borderRadius:
                                              BorderRadius.circular(10),
                                          borderSide: BorderSide(
                                              width: 1,
                                              color: Colors.redAccent)),
                                      prefixIcon: PasswordIcon,
                                      hintText: "hintOTP".tr,
                                      counterText: "",
                                    ),
                                  ),
                                ),
                                SizedBox(
                                  height: 20,
                                ),
                                Container(
                                  alignment: Alignment.center,
                                  width: size.width,
                                  child: Text(
                                    "EnterMPIN".tr,
                                    style: TextStyle(
                                        color: Colors.black,
                                        fontWeight: FontWeight.bold,
                                        fontSize: 22),
                                  ),
                                ),
                                SizedBox(
                                  height: 20,
                                ),
                                Pinput(
                                  controller: resetMPINController.pinController,
                                  focusNode: focusNode,

                                  defaultPinTheme: defaultPinTheme,
                                  validator: (value) {
                                    return value!.length == 0
                                        ? 'Please Fill Pin First'
                                        : null;
                                  },
                                  hapticFeedbackType:
                                      HapticFeedbackType.lightImpact,
                                  onCompleted: (pin) {
                                    debugPrint('onCompleted: $pin');
                                  },
                                  onChanged: (value) {
                                    debugPrint('onChanged: $value');
                                  },
                                  cursor: Column(
                                    mainAxisAlignment: MainAxisAlignment.end,
                                    children: [
                                      Container(
                                        margin: EdgeInsets.only(bottom: 9),
                                        width: 22,
                                        height: 1,
                                        color: appPrimaryColor,
                                      ),
                                    ],
                                  ),
                                  focusedPinTheme: defaultPinTheme.copyWith(
                                    decoration:
                                        defaultPinTheme.decoration!.copyWith(
                                      borderRadius: BorderRadius.circular(8),
                                      border:
                                          Border.all(color: appPrimaryColor),
                                    ),
                                  ),
                                  submittedPinTheme: defaultPinTheme.copyWith(
                                    decoration:
                                        defaultPinTheme.decoration!.copyWith(
                                      borderRadius: BorderRadius.circular(10),
                                      border:
                                          Border.all(color: appPrimaryColor),
                                    ),
                                  ),
                                  errorPinTheme: defaultPinTheme.copyBorderWith(
                                    border: Border.all(color: Colors.redAccent),
                                  ),
                                ),
                                SizedBox(
                                  height: 40,
                                ),
                                Padding(
                                  padding: EdgeInsets.only(left: 80, right: 80),
                                  child: GestureDetector(
                                    onTap: () {
                                      if (_formKey.currentState!.validate()) {
                                        var resetMPIN_url = reset_MPIN_url;
                                        var body = {
                                          'otp' : resetMPINController.OTP.text,
                                          'mpin': resetMPINController.pinController.text
                                        };
                                        resetMPINController.ResetMPINApiCalling(resetMPIN_url, body);
                                      }
                                    },
                                    child: Container(
                                      height: 40,
                                      width: 150,
                                      decoration: BoxDecoration(
                                          color: buttonColor,
                                          border: Border.all(
                                            color: buttonColor,
                                          ),
                                          borderRadius: BorderRadius.all(
                                              Radius.circular(12))),
                                      child: Center(
                                        child: Text(
                                          "submitBtn".tr,
                                          style: TextStyle(
                                              color: whiteColor,
                                              fontSize: 16,
                                              fontWeight: FontWeight.bold),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ))
              ],
            )
          ],
        ),
      ),
    );
  }
}
