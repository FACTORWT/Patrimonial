import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:pinput/pinput.dart';
import 'package:urwealthpal/Constant/Api.dart';
import 'package:urwealthpal/Constant/Images.dart';
import 'package:urwealthpal/Constant/colors.dart';
import 'package:urwealthpal/Screens/MPIN/Controllers/Change_MPIN_Controller.dart';

import '../../Constant/Strings.dart';

class change_MPIN extends StatefulWidget {
  const change_MPIN({Key? key}) : super(key: key);

  @override
  State<change_MPIN> createState() => _change_MPINState();
}

class _change_MPINState extends State<change_MPIN> {
  final focusNode = FocusNode();
  final focusNodes = FocusNode();

  final _formKey = GlobalKey<FormState>();

  ChangeMPINController changeMPINController =Get.put(ChangeMPINController());

  // @override
  // void dispose() {
  //   changeMPINController.dispose();
  //   focusNode.dispose();
  //   focusNodes.dispose();
  //   super.dispose();
  // }

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;

    final defaultPinTheme = PinTheme(
      width: 56,
      height: 56,
      textStyle: TextStyle(
        fontSize: 22,
        color: Color.fromRGBO(30, 60, 87, 1),
      ),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: Colors.grey),
      ),
    );

    return Scaffold(
      resizeToAvoidBottomInset: false,
      appBar: AppBar(
        backgroundColor: ContainerColor,
        elevation: 0,
        titleSpacing: 0,
        title: Text("change_MPIN_txt".tr),
      ),
      body: Column(
        children: [
          Form(
              key: _formKey,
              child: SingleChildScrollView(
                child: Column(
                  children: [
                    Container(
                        margin: EdgeInsets.only(top: 30),
                        alignment: Alignment.center,
                        width: size.width,
                        child: MPINImage),
                    Container(
                      alignment: Alignment.center,
                      width: size.width,
                      child: Text(
                        "change_MPIN_txt".tr,
                        style: TextStyle(
                            color: buttonColor,
                            fontWeight: FontWeight.bold,
                            fontSize: 32),
                      ),
                    ),
                    Card(
                      margin: EdgeInsets.only(top: 30,left: 20,right: 20,bottom: 50),
                      elevation: 2,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(20),
                      ),
                      child: Container(
                        decoration: BoxDecoration(
                          // color: whiteColor,
                          // border: Border.all(color: w),
                          borderRadius: BorderRadius.all(Radius.circular(20)),
                        ),
                        // // height: size.height,
                        // // height: 400,
                        margin: EdgeInsets.only(left: 15 ,right: 15),
                        padding: EdgeInsets.only(bottom: 50,),
                        child: Column(
                          children: [
                            SizedBox(
                              height: 40,
                            ),
                            Container(
                              margin: EdgeInsets.only(right: 160),
                              // alignment: Alignment.topLeft,
                              child: Text(
                                "old_MPIN_txt".tr,
                                style:
                                TextStyle(fontSize: 18, color: greyColor),
                              ),
                            ),
                            SizedBox(
                              height: 20,
                            ),
                            Pinput(
                              controller: changeMPINController.oldpinController,
                              focusNode: focusNode,
                              // androidSmsAutofillMethod:
                              // AndroidSmsAutofillMethod
                              //     .smsUserConsentApi,
                              //listenForMultipleSmsOnAndroid: true,
                              defaultPinTheme: defaultPinTheme,
                              validator: (value) {
                                return value!.length == 0
                                    ? 'Please Fill Pin First'
                                    : null;
                              },
                              // onClipboardFound: (value) {
                              //   debugPrint('onClipboardFound: $value');
                              //   pinController.setText(value);
                              // },

                              hapticFeedbackType:
                              HapticFeedbackType.lightImpact,
                              onCompleted: (pin) {
                                debugPrint('onCompleted: $pin');
                              },
                              onChanged: (value) {
                                debugPrint('onChanged: $value');
                              },
                              cursor: Column(
                                mainAxisAlignment: MainAxisAlignment.end,
                                children: [
                                  Container(
                                    margin: EdgeInsets.only(bottom: 9),
                                    width: 22,
                                    height: 1,
                                    color: appPrimaryColor,
                                  ),
                                ],
                              ),
                              focusedPinTheme: defaultPinTheme.copyWith(
                                decoration:
                                defaultPinTheme.decoration!.copyWith(
                                  borderRadius: BorderRadius.circular(8),
                                  border:
                                  Border.all(color: appPrimaryColor),
                                ),
                              ),
                              submittedPinTheme: defaultPinTheme.copyWith(
                                decoration:
                                defaultPinTheme.decoration!.copyWith(
                                  borderRadius: BorderRadius.circular(10),
                                  border:
                                  Border.all(color: appPrimaryColor),
                                ),
                              ),
                              errorPinTheme: defaultPinTheme.copyBorderWith(
                                border: Border.all(color: Colors.redAccent),
                              ),
                            ),
                            SizedBox(
                              height: 20,
                            ),
                            Container(
                              margin: EdgeInsets.only(right: 160),
                              child: Text(
                                "new_MPIN_txt".tr,
                                style:
                                TextStyle(fontSize: 18, color: greyColor),
                              ),
                            ),
                            SizedBox(
                              height: 20,
                            ),
                            Pinput(
                              controller: changeMPINController.newpinController,
                              focusNode: focusNodes,
                              // androidSmsAutofillMethod:
                              // AndroidSmsAutofillMethod
                              //     .smsUserConsentApi,
                              // listenForMultipleSmsOnAndroid: true,
                              defaultPinTheme: defaultPinTheme,
                              validator: (value) {
                                return value!.length == 0
                                    ? 'Please Fill Pin First'
                                    : null;
                              },
                              // onClipboardFound: (value) {
                              //   debugPrint('onClipboardFound: $value');
                              //   pinController.setText(value);
                              // },

                              hapticFeedbackType:
                              HapticFeedbackType.lightImpact,
                              onCompleted: (pin) {
                                debugPrint('onCompleted: $pin');
                              },
                              onChanged: (value) {
                                debugPrint('onChanged: $value');
                              },
                              cursor: Column(
                                mainAxisAlignment: MainAxisAlignment.end,
                                children: [
                                  Container(
                                    margin: EdgeInsets.only(bottom: 9),
                                    width: 22,
                                    height: 1,
                                    color: appPrimaryColor,
                                  ),
                                ],
                              ),
                              focusedPinTheme: defaultPinTheme.copyWith(
                                decoration:
                                defaultPinTheme.decoration!.copyWith(
                                  borderRadius: BorderRadius.circular(8),
                                  border:
                                  Border.all(color: appPrimaryColor),
                                ),
                              ),
                              submittedPinTheme: defaultPinTheme.copyWith(
                                decoration:
                                defaultPinTheme.decoration!.copyWith(
                                  borderRadius: BorderRadius.circular(10),
                                  border:
                                  Border.all(color: appPrimaryColor),
                                ),
                              ),
                              errorPinTheme: defaultPinTheme.copyBorderWith(
                                border: Border.all(color: Colors.redAccent),
                              ),
                            ),
                            SizedBox(
                              height: 30,
                            ),
                            Padding(
                              padding: EdgeInsets.only(
                                   left: 80, right: 80),
                              child: GestureDetector(
                                onTap: () async {
                                  if (_formKey.currentState!.validate()) {
                                    var changeMPIN_url = change_MPIN_url;
                                    var body ={
                                      'old_mpin' : changeMPINController.oldpinController.text,
                                      'mpin' :  changeMPINController.newpinController.text
                                    };
                                    print("old MPIN body" + body.toString());
                                    print("old MPIN changeMPIN_url..." + changeMPIN_url.toString());
                                    changeMPINController.ChangeMPINApiCalling(
                                        changeMPIN_url, body);
                                  }
                                },
                                child: Container(
                                  height: 40,
                                  width: 150,
                                  decoration: BoxDecoration(
                                      color: buttonColor,
                                      border: Border.all(
                                        color: buttonColor,
                                      ),
                                      borderRadius: BorderRadius.all(
                                          Radius.circular(12))),
                                  child: Center(
                                    child: Text(
                                      "submitBtn".tr,
                                      style: TextStyle(
                                          color: whiteColor,
                                          fontSize: 16,
                                          fontWeight: FontWeight.bold),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
              )),
        ],
      ),
    );

  }
}
