import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:pinput/pinput.dart';
import 'package:urwealthpal/Constant/Api.dart';
import 'package:urwealthpal/Constant/Images.dart';
import 'package:urwealthpal/Constant/colors.dart';
import 'package:urwealthpal/Screens/MPIN/Controllers/Toggle_MPIN_Controller.dart';

import '../../Constant/Strings.dart';

class Toggle_MPIN extends StatefulWidget {
  const Toggle_MPIN({Key? key}) : super(key: key);

  @override
  State<Toggle_MPIN> createState() => _Toggle_MPINState();
}

class _Toggle_MPINState extends State<Toggle_MPIN> {
  final focusNode = FocusNode();
  final _formKey = GlobalKey<FormState>();

  ToggleMPINController toggleMPINController =Get.put(ToggleMPINController());

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
  }

  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;

    final defaultPinTheme = PinTheme(
      width: 56,
      height: 56,
      textStyle: TextStyle(
        fontSize: 22,
        color: Color.fromRGBO(30, 60, 87, 1),
      ),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: Colors.grey),
      ),
    );
    return Scaffold(
      resizeToAvoidBottomInset: false,
      appBar: AppBar(
        elevation: 0,
        titleSpacing: 0,
        backgroundColor: ContainerColor,
        title: Text("mpin".tr),
      ),
      body:
      Column(
        children: [
          Stack(
            children: [
              Form(
                  key: _formKey,
                  child: SingleChildScrollView(
                    child: Column(
                      children: [
                        Container(
                            margin: EdgeInsets.only(top: 40),
                            alignment: Alignment.center,
                            width: size.width,
                            child: MPINImage),
                        Container(
                          alignment: Alignment.center,
                          width: size.width,
                          child: Text(
                              "mpin".tr,
                            style: TextStyle(
                                color: ContainerColor,
                                fontWeight: FontWeight.bold,
                                fontSize: 32),
                          ),
                        ),
                        Card(
                          clipBehavior: Clip.antiAlias,
                          margin: EdgeInsets.only(top: 30,left: 20,right: 20,bottom: 50),
                          elevation: 2,
                          shape: RoundedRectangleBorder(
                            borderRadius: BorderRadius.circular(20),
                          ),
                          child: Container(
                            decoration: BoxDecoration(
                              // color: whiteColor,
                              // border: Border.all(color: w),
                              borderRadius: BorderRadius.all(Radius.circular(20)),
                            ),
                            // height: size.height,
                            // height: 400,
                            margin: EdgeInsets.only(left: 15 ,right: 15),
                            padding: EdgeInsets.only(bottom: 50,),
                            child: Column(
                              children: [
                                SizedBox(
                                  height: 50,
                                ),
                                Text(
                                  "your_PIN".tr,
                                  style:
                                  TextStyle(fontSize: 18, color: greyColor),
                                ),
                                SizedBox(
                                  height: 30,
                                ),
                                Pinput(
                                  controller: toggleMPINController.pinController,
                                  focusNode: focusNode,
                                  // androidSmsAutofillMethod:
                                  // AndroidSmsAutofillMethod
                                  //     .smsUserConsentApi,
                                  // listenForMultipleSmsOnAndroid: true,
                                  defaultPinTheme: defaultPinTheme,
                                  validator: (value) {
                                    return value!.length == 0
                                        ? 'Please Fill Pin First'
                                        : null;
                                  },
                                  // onClipboardFound: (value) {
                                  //   debugPrint('onClipboardFound: $value');
                                  //   pinController.setText(value);
                                  // },

                                  hapticFeedbackType:
                                  HapticFeedbackType.lightImpact,
                                  onCompleted: (pin) {
                                    debugPrint('onCompleted: $pin');
                                  },
                                  onChanged: (value) {
                                    debugPrint('onChanged: $value');
                                  },
                                  cursor: Column(
                                    mainAxisAlignment: MainAxisAlignment.end,
                                    children: [
                                      Container(
                                        margin: EdgeInsets.only(bottom: 9),
                                        width: 22,
                                        height: 1,
                                        color: appPrimaryColor,
                                      ),
                                    ],
                                  ),
                                  focusedPinTheme: defaultPinTheme.copyWith(
                                    decoration:
                                    defaultPinTheme.decoration!.copyWith(
                                      borderRadius: BorderRadius.circular(8),
                                      border:
                                      Border.all(color: appPrimaryColor),
                                    ),
                                  ),
                                  submittedPinTheme: defaultPinTheme.copyWith(
                                    decoration:
                                    defaultPinTheme.decoration!.copyWith(
                                      borderRadius: BorderRadius.circular(10),
                                      border:
                                      Border.all(color: appPrimaryColor),
                                    ),
                                  ),
                                  errorPinTheme: defaultPinTheme.copyBorderWith(
                                    border: Border.all(color: Colors.redAccent),
                                  ),
                                ),
                                SizedBox(
                                  height: 50,
                                ),
                                Padding(
                                  padding: EdgeInsets.only(
                                       left: 80, right: 80),
                                  child: GestureDetector(
                                    onTap: () async {
                                      if (_formKey.currentState!.validate()) {
                                        var mpins=  toggleMPINController.pinController.text;
                                        var checkMPIN_url = check_MPIN_url;
                                        print("checkMPIN_url"+checkMPIN_url.toString());
                                        var body ={
                                          'mpin' :  toggleMPINController.pinController.text
                                        };
                                        toggleMPINController.CheckMPINApiCalling(checkMPIN_url, body,
                                            mpins);
                                      }
                                    },
                                    child: Container(
                                      height: 40,
                                      width: 150,
                                      decoration: BoxDecoration(
                                          color: buttonColor,
                                          border: Border.all(
                                            color: buttonColor,
                                          ),
                                          borderRadius: BorderRadius.all(
                                              Radius.circular(12))),
                                      child: Center(
                                        child: Text(
                                          "submitBtn".tr,
                                          style: TextStyle(
                                              color: whiteColor,
                                              fontSize: 16,
                                              fontWeight: FontWeight.bold),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  ))
            ],
          ),
        ],
      ),
    );
  }
}
