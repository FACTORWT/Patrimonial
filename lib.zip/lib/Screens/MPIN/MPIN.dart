import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:pinput/pinput.dart';
import 'package:urwealthpal/Constant/Api.dart';
import 'package:urwealthpal/Constant/Images.dart';
import 'package:urwealthpal/Constant/Strings.dart';
import 'package:urwealthpal/Constant/colors.dart';
import 'package:urwealthpal/Screens/MPIN/Controllers/Check_MPIN_Controller.dart';
import 'package:urwealthpal/Screens/MPIN/Controllers/Forgot_MPIN_Controller.dart';
import 'package:local_auth/local_auth.dart';
class MPIN extends StatefulWidget {
  const MPIN({Key? key}) : super(key: key);

  @override
  State<MPIN> createState() => _MPINState();
}

class _MPINState extends State<MPIN> {
  final focusNode = FocusNode();
  final _formKey = GlobalKey<FormState>();

  CheckMPINController checkMPINController =Get.put(CheckMPINController());

  var getForgotMPINController =Get.put(GetForgot_MPINController());
  void initState() {
    // TODO: implement initState
    super.initState();
    checkMPINController.pinController.clear();
  }
  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;

    final defaultPinTheme = PinTheme(
      width: 56,
      height: 56,
      textStyle: TextStyle(
        fontSize: 22,
        color: Color.fromRGBO(30, 60, 87, 1),
      ),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: Colors.grey),
      ),
    );
    return Scaffold(
      resizeToAvoidBottomInset: false,
      body: Container(
        height: size.height,
        width: size.width,
        decoration: BoxDecoration(
          image: DecorationImage(
              image: AssetImage("assets/images/full_background.png"),
              fit: BoxFit.cover),
        ),
        child: Column(
          children: [
            Stack(
              children: [
                Form(
                    key: _formKey,
                    child: SingleChildScrollView(
                      child: Column(
                        children: [
                          Container(
                              margin: EdgeInsets.only(top: 110),
                              alignment: Alignment.center,
                              width: size.width,
                              child: MPINImage),
                          Container(
                            alignment: Alignment.center,
                            width: size.width,
                            child: Text(
                              "mpin".tr,
                              style: TextStyle(
                                  color: whiteColor,
                                  fontWeight: FontWeight.bold,
                                  fontSize: 32),
                            ),
                          ),
                          Container(
                            height: 350,
                            margin:
                                EdgeInsets.only(top: 30, left: 20, right: 20),
                            decoration: BoxDecoration(
                              color: whiteColor,
                              border: Border.all(color: whiteColor),
                              borderRadius:
                                  BorderRadius.all(Radius.circular(30)),
                            ),
                            child: Column(
                              children: [
                                SizedBox(
                                  height: 50,
                                ),
                                Text(
                                  "validMPIN".tr,
                                  style:
                                      TextStyle(fontSize: 18, color: greyColor),
                                ),
                                SizedBox(
                                  height: 30,
                                ),
                                Pinput(
                                  controller: checkMPINController.pinController,
                                  focusNode: focusNode,
                                  // androidSmsAutofillMethod:
                                  //     AndroidSmsAutofillMethod.smsUserConsentApi,
                                  // listenForMultipleSmsOnAndroid: true,
                                  defaultPinTheme: defaultPinTheme,
                                  validator: (value) {
                                    return value!.length == 0
                                        ? 'Please Fill Pin First'
                                        : null;
                                  },

                                  // onClipboardFound: (value) {
                                  //   debugPrint('onClipboardFound: $value');
                                  //   pinController.setText(value);
                                  // },

                                  hapticFeedbackType:
                                      HapticFeedbackType.lightImpact,
                                  onCompleted: (pin) {
                                    debugPrint('onCompleted: $pin');
                                  },
                                  onChanged: (value) {
                                    debugPrint('onChanged: $value');
                                  },
                                  cursor: Column(
                                    mainAxisAlignment: MainAxisAlignment.end,
                                    children: [
                                      Container(
                                        margin: EdgeInsets.only(bottom: 9),
                                        width: 22,
                                        height: 1,
                                        color: appPrimaryColor,
                                      ),
                                    ],
                                  ),
                                  focusedPinTheme: defaultPinTheme.copyWith(
                                    decoration:
                                        defaultPinTheme.decoration!.copyWith(
                                      borderRadius: BorderRadius.circular(8),
                                      border:
                                          Border.all(color: appPrimaryColor),
                                    ),
                                  ),
                                  submittedPinTheme: defaultPinTheme.copyWith(
                                    decoration:
                                        defaultPinTheme.decoration!.copyWith(
                                      borderRadius: BorderRadius.circular(10),
                                      border:
                                          Border.all(color: appPrimaryColor),
                                    ),
                                  ),
                                  errorPinTheme: defaultPinTheme.copyBorderWith(
                                    border: Border.all(color: Colors.redAccent),
                                  ),
                                ),
                                SizedBox(
                                  height: 20,
                                ),
                                Align(
                                  alignment: Alignment.centerLeft,
                                  child: Padding(
                                    padding: EdgeInsets.only(top: 10, left: 10),
                                    child: GestureDetector(
                                      onTap: () async {
                                        await getForgotMPINController.GetForgot_MPIN_APICalling(Get_forgotMPIN_url);
                                        // Navigator.push(
                                        //     context,
                                        //     MaterialPageRoute(
                                        //         builder: (context) =>
                                        //             Forgot_MPIN()));
                                      },
                                      child: Text("forgotMPIN".tr,
                                          style: TextStyle(
                                            color: appPrimaryColor,
                                            fontSize: 16,
                                          )),
                                    ),
                                  ),
                                ),
                                Padding(
                                  padding: EdgeInsets.only(
                                      top: 40, left: 80, right: 80),
                                  child: GestureDetector(
                                    onTap: () async {
                                      if (_formKey.currentState!.validate()) {
                                        // Navigator.pushReplacement(context,
                                        //     MaterialPageRoute(builder: (context)=>
                                        //         bottombar(bottom: 2,)));
                                        var checkMPIN_url = check_MPIN_url;
                                        print("checkMPIN_url"+checkMPIN_url.toString());
                                        var body ={
                                          'mpin' :  checkMPINController.pinController.text
                                        };
                                        print("mpin body==>"+body.toString());
                                        checkMPINController.CheckMPINApiCalling(
                                            checkMPIN_url, body);
                                    }
                                    },
                                    child: Container(
                                      height: 40,
                                      width: 150,
                                      decoration: BoxDecoration(
                                          color: buttonColor,
                                          border: Border.all(
                                            color: buttonColor,
                                          ),
                                          borderRadius: BorderRadius.all(
                                              Radius.circular(12))),
                                      child: Center(
                                        child: Text(
                                          "submitBtn".tr,
                                          style: TextStyle(
                                              color: whiteColor,
                                              fontSize: 16,
                                              fontWeight: FontWeight.bold),
                                        ),
                                      ),
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ))
              ],
            ),
          ],
        ),
      ),
    );
  }
}