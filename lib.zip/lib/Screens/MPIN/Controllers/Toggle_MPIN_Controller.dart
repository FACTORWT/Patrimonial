import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:urwealthpal/Constant/Api.dart';
import 'package:urwealthpal/Constant/ApiBaseHelper.dart';
import 'package:urwealthpal/Environment/Environment.dart';
import 'package:urwealthpal/main.dart';

class ToggleMPINController extends GetxController{

  var CheckMPINLoading = false.obs;
  var CheckMPINData ;

  TextEditingController pinController = TextEditingController();

  CheckMPINApiCalling(url, parameter,mpin) async {
    CheckMPINLoading.value =true;
    print("check MPIN " + url.toString());
    var response = await ApiBaseHelper().postAPICall(Uri.parse(url), parameter, true);
    var responsedata = jsonDecode(response.body);
    if(response.statusCode==200){
      pinController.clear();
      CheckMPINData = responsedata['data'];
      var body = {
        'mpin': mpin.toString()
      };

     await ToggleMPINApiCalling(toggle_MPIN_url, body);
      CheckMPINData = responsedata['message'];
      var msg = CheckMPINData.toString();
      toastMsg(msg, true);
      CheckMPINLoading.value =false;
      update();
    }
    else if (response.statusCode==422){
      CheckMPINData = responsedata['message'];
      var msg = CheckMPINData.toString();
      toastMsg(msg, false);
      CheckMPINLoading.value = false ;
      update();
    }
      else
        CheckMPINData =[];
      CheckMPINLoading.value =false;
      update();
    }
  }


var ToggleMPINLoading = false.obs;
var ToggleMPINData ;

  ToggleMPINApiCalling(url, parameter) async {
    ToggleMPINLoading.value =true;
    print("toggle MPIN " + url.toString());
    var response = await ApiBaseHelper().postAPICall(Uri.parse(url), parameter, true);
    if(Environment.askMPIN=="1"){
       sp!.setString("ask_mpin","0");
    }else{
      sp!.setString("ask_mpin","1");
    }
    Get.back();
    // ToggleMPINData = jsonDecode(response.body);
    // if(response.statusCode==200){
    //   ToggleMPINData =  jsonDecode(response.body);
    //   print("ToggleMPINData...."+ToggleMPINData.toString());
    //   ToggleMPINLoading.value =false;
    //   update();
    // } else if(response.statusCode==403) {
    //   ToggleMPINData =  jsonDecode(response.body);
    //   var msg = ToggleMPINData['message'].toString();
    //   print("ToggleMPINData....403"+ToggleMPINData.toString());
    //   toastMsg(msg, true);
    //   ToggleMPINLoading.value = false;
    //   Get.back();
    //   update();
    // }
  }

