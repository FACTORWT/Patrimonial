import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:urwealthpal/BottomBar/bottombar.dart';
import 'package:urwealthpal/Constant/Api.dart';
import 'package:urwealthpal/Constant/ApiBaseHelper.dart';
import 'package:urwealthpal/Screens/MPIN/MPIN.dart';

class ResetMPINController extends GetxController{
  var ResetMPINLoading = false.obs;
  var ResetMPINData ;

  TextEditingController pinController = TextEditingController();
  TextEditingController OTP = TextEditingController();

  ResetMPINApiCalling(url, parameter) async {
    ResetMPINLoading.value =true;
    print("reset MPIN " + url.toString());
    var response = await ApiBaseHelper().postAPICall(Uri.parse(url), parameter, true);
    var responsedata = jsonDecode(response.body);
    if(response.statusCode==200){
      ResetMPINData = responsedata['data'];
      Get.off(MPIN());
      ResetMPINData = responsedata['message'];
      var msg = ResetMPINData.toString();
      toastMsg(msg, true);
      ResetMPINLoading.value =false;
      update();
    }
    else if (response.statusCode==422){
      ResetMPINData = responsedata['message'];
      var msg = ResetMPINData.toString();
      toastMsg(msg, false);
      ResetMPINLoading.value = false;
      update();
    }
      else
        ResetMPINData =[];
      ResetMPINLoading.value =false;
      update();
    }
  }
