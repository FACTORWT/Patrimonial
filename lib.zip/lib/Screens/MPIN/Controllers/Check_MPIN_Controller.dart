import 'dart:convert';
import 'dart:developer';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:urwealthpal/BottomBar/bottombar.dart';
import 'package:urwealthpal/Constant/Api.dart';
import 'package:urwealthpal/Constant/ApiBaseHelper.dart';
import 'package:urwealthpal/Screens/Assets/assets_details.dart';

class CheckMPINController extends GetxController{
  var CheckMPINLoading = false.obs;
  var CheckMPINData ;

  TextEditingController pinController = TextEditingController();

  CheckMPINApiCalling(url, parameter) async {
    CheckMPINLoading.value =true;
    print("check MPIN " + url.toString());
    var response = await ApiBaseHelper().postAPICall(Uri.parse(url), parameter, true);
    var responsedata = jsonDecode(response.body);
    if(response.statusCode==200){
      CheckMPINData = responsedata['data'];
      print('CheckMPINData==>'+CheckMPINData.toString());
      Get.off(bottombar(bottom: 2,));
      CheckMPINData = responsedata['message'];
      var msg = CheckMPINData.toString();
      toastMsg(msg, true);
      CheckMPINLoading.value =false;
      update();
    }
    else if(response.statusCode==422){
      CheckMPINData = responsedata['message'];
      var msg = CheckMPINData.toString();
      toastMsg(msg, false);
      CheckMPINLoading.value = false;
      update();
    }
      else
      CheckMPINData =[];
      CheckMPINLoading.value =false;
      update();
    }

    var id ;

  CheckMPINAsstesApiCalling(url, parameter,mainassetsid,ID) async {
    CheckMPINLoading.value =true;
    print("check MPIN " + url.toString());
    var response = await ApiBaseHelper().postAPICall(Uri.parse(url), parameter, true);
    var responsedata = jsonDecode(response.body);
    if(response.statusCode==200) {
      CheckMPINData = responsedata['data'];
      print("check ID " + ID.toString());
      if (ID.toString() == "1") {
        print("check ID " + ID.toString());
        Get.off(assets_details(mainCategories_id: mainassetsid.toString(),
          mainCategories_status: false,
          assets: true,));
      }
      else if (ID.toString() == "2") {
        Get.off(assets_details(mainCategories_id: mainassetsid.toString(),
          mainCategories_status: true,
          assets: true,));
      } else if (ID.toString() == "3") {
        Get.off(assets_details(
          mainCategories_id: mainassetsid.toString(), assets: false,));
    }else{
      Get.off(assets_details(mainCategories_id: mainassetsid.toString(), assets: false,));}


      CheckMPINData = responsedata['message'];

      // assets_details(
      //     mainCategories_id:
      //     Categorieslistdata["id"]
      //         .toString(),
      //     assets: false)));

      var msg = CheckMPINData.toString();
      toastMsg(msg, true);
      CheckMPINLoading.value =false;
      update();
    }
    else if(response.statusCode==422){
      CheckMPINData = responsedata['message'];
      var msg = CheckMPINData.toString();
      toastMsg(msg, false);
      CheckMPINLoading.value = false;
      update();
    }
    else
      CheckMPINData =[];
    CheckMPINLoading.value =false;
    update();
  }
  }
