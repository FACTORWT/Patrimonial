import 'dart:convert';
import 'package:get/get.dart';
import 'package:urwealthpal/Constant/Api.dart';
import 'package:urwealthpal/Constant/ApiBaseHelper.dart';
import 'package:urwealthpal/Screens/MPIN/Forgot_MPIN.dart';

class GetForgot_MPINController extends GetxController{
  var getForgotMPIN_Loading = false.obs;
  var getForgotMPIN_data ;

  GetForgot_MPIN_APICalling(url) async {
    getForgotMPIN_Loading.value =true;
    print("getForgotMPIN url : " + url.toString());
    var response = await ApiBaseHelper().getAPICall(Uri.parse(url), true);
     getForgotMPIN_data = jsonDecode(response.body);
    // print("getForgotMPIN responsedata : " + responsedata.toString());
    if(response.statusCode==200){
      getForgotMPIN_data = jsonDecode(response.body);
      var token = getForgotMPIN_data['data']['token'].toString();
      toastMsg(token, true);
      getForgotMPIN_Loading.value =false;
      Get.to(Forgot_MPIN());
      update();
    }
    else if(response.statusCode==422) {
      getForgotMPIN_data = getForgotMPIN_data['message'];
      var msg = getForgotMPIN_data.toString();
      toastMsg(msg, false);
      getForgotMPIN_Loading.value = false;
      update();
    }
    else
      getForgotMPIN_data =[];
      getForgotMPIN_Loading.value =false;
      update();
    }
  }