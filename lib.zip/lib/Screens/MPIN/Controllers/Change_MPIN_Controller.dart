import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:urwealthpal/Constant/Api.dart';
import 'package:urwealthpal/Constant/ApiBaseHelper.dart';

class ChangeMPINController extends GetxController{
  var ChangeMPINLoading = false.obs;
  var ChangeMPINData ;

  TextEditingController oldpinController = TextEditingController();
  TextEditingController newpinController = TextEditingController();

  ChangeMPINApiCalling(url, parameter) async {
    ChangeMPINLoading.value =true;
    print("change MPIN " + url.toString());
    var response = await ApiBaseHelper().postAPICall(Uri.parse(url), parameter, true);
    var responsedata = jsonDecode(response.body);
    if(response.statusCode==200){
      ChangeMPINData = responsedata['message'];
      Get.back();
      oldpinController.clear();
      newpinController.clear();
      var msg = ChangeMPINData.toString();
      toastMsg(msg, true);
      ChangeMPINLoading.value =false;
      update();
    }else{
      if(response.statusCode==422) {
        ChangeMPINData = responsedata['message'];
        var msg = ChangeMPINData.toString();
        toastMsg(msg, false);
        ChangeMPINLoading.value = false;
        update();
      }

      // if(response.statusCode==200){
      //   ChangePasswordNData = responsedata['message'];
      //   var msg = ChangePasswordNData.toString();
      //   toastMsg(msg, true);
      //   Get.back();
      //   old_password.clear();
      //   new_Password.clear();
      //   confim_new_Password.clear();
      //   ChangePasswordLoading.value =false;
      //   update();
      // }else if(response.statusCode==422) {
      //   ChangePasswordNData = responsedata['message'];
      //   var msg = ChangePasswordNData.toString();
      //   toastMsg(msg, true);
      //   ChangePasswordLoading.value = false;
      //   update();
      // }









      else
        ChangeMPINData =[];
      ChangeMPINLoading.value =false;
      update();
    }
  }
}
