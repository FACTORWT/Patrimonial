import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:urwealthpal/BottomBar/bottombar.dart';
import 'package:urwealthpal/Constant/Api.dart';
import 'package:urwealthpal/Constant/ApiBaseHelper.dart';
import 'package:urwealthpal/main.dart';

class SetMPINController extends GetxController{
  var SetMPINLoading = false.obs;
  var SetMPINData ;

  TextEditingController pinController = TextEditingController();

  SetMPINApiCalling(url, parameter) async {
    SetMPINLoading.value =true;
    print("set MPIN " + url.toString());
    var response = await ApiBaseHelper().postAPICall(Uri.parse(url), parameter, true);
    var responsedata = jsonDecode(response.body);
    if(response.statusCode==200){
      SetMPINData = responsedata['data'];
      sp!.setString("set_mpin","0");
      sp!.setString("ask_mpin","1");
      Get.offAll(bottombar(bottom: 2,));
      SetMPINLoading.value =false;
      update();
    }
    else if (response.statusCode==422){
      SetMPINData = SetMPINData['message'];
      var msg = SetMPINData.toString();
      toastMsg(msg, false);
      SetMPINLoading.value = false;
      update();
    }
      else
        SetMPINData =[];
      SetMPINLoading.value =false;
      update();
    }
  }