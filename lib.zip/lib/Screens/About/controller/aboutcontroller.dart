import 'dart:convert';
import 'package:get/get.dart';
import 'package:urwealthpal/Constant/ApiBaseHelper.dart';

class AboutCountroller extends GetxController{
  var loading = false.obs;
  var aboutdata ;
   Aboutfetch(url) async {
     loading.value =true;
     print("cmsurl : " + url.toString());
     var response = await ApiBaseHelper().getAPICall(Uri.parse(url), true);
     var responsedata = jsonDecode(response.body);
     if(response.statusCode==200){
       aboutdata = responsedata['data'];
       loading.value =false;
       update();
     }else{
       aboutdata =[];
       loading.value =false;
       update();
     }
   }

}