import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:urwealthpal/Constant/colors.dart';
import 'package:urwealthpal/Screens/About/controller/aboutcontroller.dart';
import 'package:flutter_html/flutter_html.dart';
import '../../Constant/Api.dart';

class about_us extends StatefulWidget {
  const about_us({Key? key}) : super(key: key);

  @override
  State<about_us> createState() => _about_usState();
}

class _about_usState extends State<about_us> {
  var aboutcontroller =Get.put(AboutCountroller());
  @override
  void initState() {
    // TODO: implement initState
   aboutcontroller.Aboutfetch("${cms_url}1");
    super.initState();
  }
  @override
  Widget build(BuildContext context) {
    return RefreshIndicator(
      onRefresh: () async {
        await AboutCountroller();
        await Future.delayed(Duration(milliseconds: 1500));
      },
      child: Scaffold(
        appBar: AppBar(
          elevation: 0,
          titleSpacing: 0,
          backgroundColor: ContainerColor,
          title: Text("about_us_txt".tr),
        ),
        body: GetBuilder<AboutCountroller>(
          builder: (aboutCountroller) {
            if(aboutCountroller.loading.value){
              return Center(child: CircularProgressIndicator());
            }
            else
            return SingleChildScrollView(
              physics: AlwaysScrollableScrollPhysics(),
              child: Column(
                children: [
                  Padding(
                    padding:  EdgeInsets.only(left: 10,right: 10),
                   child: Html(data: aboutCountroller.aboutdata['cms_contant'],),
              )
                  // Padding(
                  //   padding: EdgeInsets.only(top: 10,left: 10,right: 10),
                  //   child: Text(aboutCountroller.aboutdata['cms_contant'],
                  //   textAlign: TextAlign.justify,
                  //   style: TextStyle(
                  //     color: greyColor
                  //   ),),
                  // ),
                  // Padding(
                  //   padding: EdgeInsets.only(top: 10,left: 10,right: 10),
                  //   child: Text(main_txt,
                  //   textAlign: TextAlign.justify,
                  //   style: TextStyle(
                  //     color: greyColor
                  //   ),),
                  // ),
                  // Padding(
                  //   padding: EdgeInsets.only(top: 10,left: 10,right: 10),
                  //   child: Text(main_txt,
                  //   textAlign: TextAlign.justify,
                  //   style: TextStyle(
                  //     color: greyColor
                  //   ),),
                  // ),
                ],
              ),
            );
          }
        ),
      ),
    );
  }
}
