import 'dart:convert';
import 'package:get/get.dart';
import 'package:urwealthpal/Constant/Api.dart';
import 'package:urwealthpal/Constant/ApiBaseHelper.dart';

class FAQController extends GetxController{
  var FaqDataLoading = false.obs;
  List FaqData=[] ;

  FAQApiCalling(url) async {
    FaqDataLoading.value =true;
    print("FAQ Url : " + url.toString());
    var response = await ApiBaseHelper().getAPICall(Uri.parse(url), true);
    var responsedata = jsonDecode(response.body);
    print("FAQ responsedata : " + responsedata.toString());
    if(response.statusCode==200){
      FaqData.clear();
      FaqData.addAll(responsedata['data']) ;
      FaqDataLoading.value =false;
      update();
    }
    else if(response.statusCode==404) {
      FaqData = responsedata['message'];
      toastMsg(FaqData, false);
      FaqDataLoading.value = false;
      update();
    }
    else{
      FaqData =[];
      FaqDataLoading.value =false;
      update();
    }
  }
}