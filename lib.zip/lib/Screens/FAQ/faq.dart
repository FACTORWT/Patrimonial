import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:urwealthpal/Constant/Api.dart';
import 'package:urwealthpal/Constant/Strings.dart';
import 'package:urwealthpal/Constant/colors.dart';
import 'package:urwealthpal/Screens/FAQ/faqController.dart';

class faq extends StatefulWidget {
  const faq({Key? key}) : super(key: key);

  @override
  State<faq> createState() => _faqState();
}

class _faqState extends State<faq> {

  var faqController =Get.put(FAQController());

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    faqController.FAQApiCalling(FAQ_url);
  }

  // List faq = [
  //   {
  //     "text" : "Do you offer any discount?",
  //     "text1":
  //     "Yes, our products are based on discounted rate and you can see them any time to visit"
  //         "the https://adiyogitechnosoft.com/products page."
  //   },
  //   {
  //     "text": "We are worried about quality: how do you assure?",
  //     "text1":
  //     "Yes, our products are based on discounted rate and you can see them any time to visit"
  //         "the https://adiyogitechnosoft.com/products page."
  //   },
  //   {
  //     "text": "How much time will it take for you to make ecommerce app?",
  //     "text1":
  //     "Yes, our products are based on discounted rate and you can see them any time to visit"
  //         "the https://adiyogitechnosoft.com/products page."
  //   },
  //   {
  //     "text": "What makes you different from other IT company in Jodhpur?",
  //     "text1":
  //     "Yes, our products are based on discounted rate and you can see them any time to visit"
  //         "the https://adiyogitechnosoft.com/products page."
  //   },
  //   {
  //     "text": "What technology do you use?",
  //     "text1":
  //     "Yes, our products are based on discounted rate and you can see them any time to visit"
  //         "the https://adiyogitechnosoft.com/products page."
  //   },
  //   {
  //     "text": "What are the things, you can perform first for website SEO?",
  //     "text1":
  //     "Yes, our products are based on discounted rate and you can see them any time to visit"
  //         "the https://adiyogitechnosoft.com/products page."
  //   },
  //   {
  //     "text": "Which tools do you prefer for creating graphics?",
  //     "text1":
  //     "Yes, our products are based on discounted rate and you can see them any time to visit"
  //         "the https://adiyogitechnosoft.com/products page."
  //   },
  // ];

  @override
  Widget build(BuildContext context) {
    return RefreshIndicator(
      onRefresh: () async {
        await FAQController();
        await Future.delayed(Duration(milliseconds: 1500));
      },
      child: Scaffold(
        appBar: AppBar(
          elevation: 0,
          titleSpacing: 0,
          backgroundColor: ContainerColor,
          title: Text("faq_txt".tr),
        ),
        body:  GetBuilder<FAQController>(
    builder: (faqController) {
      if (faqController.FaqDataLoading.value) {
        return Center(child: CircularProgressIndicator());
      }
      else
        return
          faqController.FaqData.length == 0 ? Center(
              child: Text("DataFound".tr)) :
          ListView.builder(
              itemCount: faqController.FaqData.length,
              scrollDirection: Axis.vertical,
              shrinkWrap: true,
              physics: AlwaysScrollableScrollPhysics(),
              itemBuilder: (BuildContext context, index) {
                var listdata = faqController.FaqData[index];
                return Column(
                  children: [
                    Padding(
                      padding: EdgeInsets.only(top: 10),
                      child: ExpansionTile(
                        title: Text(
                          listdata["question"].toString(),
                          style: TextStyle(color: ContainerColor,
                              fontWeight: FontWeight.bold),
                        ),
                        children: <Widget>[
                          ListTile(
                            title: Text(
                              listdata["answer"].toString(),
                              style: TextStyle(
                                  color: Namecolors, fontSize: 14),
                            ),
                          )
                        ],
                      ),
                    ),
                  ],
                );
              });
    }
      ),
    )
    );
  }
}
