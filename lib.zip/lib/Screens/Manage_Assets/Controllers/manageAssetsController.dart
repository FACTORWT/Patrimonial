import 'dart:convert';
import 'dart:developer';
import 'package:get/get.dart';
import 'package:urwealthpal/Constant/ApiBaseHelper.dart';

class ManageAssetsController extends GetxController{

  var UpdatePermissionLoading = false.obs;
  var UpdatePermissionData ;

  var GetPermissionLoading = false.obs;

  List  PermissionList=[] ;

  GetPermissionApiCalling(url, parameter) async {
    GetPermissionLoading.value =true;
    print("UpdatePermission " + url.toString());
    var response = await ApiBaseHelper().postAPICall(Uri.parse(url), parameter, true);
    var responsedata = jsonDecode(response.body);
    print("UpdatePermission responsedata : " + responsedata.toString());
    if(response.statusCode==200){
      PermissionList.clear();
      PermissionList.addAll(responsedata['data']);
      log("PermissionList responsedata : " + PermissionList.toString());
      GetPermissionLoading.value =false;
      update();
    } else
      PermissionList =[];
    GetPermissionLoading.value =false;
    update();
  }

  updateaddvalue(index,index2,UpdateFamilyPermission_url,body) async {
    if(PermissionList[index]['sub_categories'][index2]['can_add'].toString()=="1"){
      PermissionList[index]['sub_categories'][index2]['can_add'] ="0";
    }else{
      PermissionList[index]['sub_categories'][index2]['can_add'] ="1";
    }
    var response = await ApiBaseHelper().postAPICall(Uri.parse(UpdateFamilyPermission_url), body, true);
    var responsedata = jsonDecode(response.body);
    log("updateaddvalue responsedata : "+responsedata.toString());
    update();
  }
  updatedeletevalue(index,index2,UpdateFamilyPermission_url,body) async {
    if(PermissionList[index]['sub_categories'][index2]['can_delete'].toString()=="1"){
      PermissionList[index]['sub_categories'][index2]['can_delete'] ="0";
    }else{
      PermissionList[index]['sub_categories'][index2]['can_delete'] ="1";
    }
    var response = await ApiBaseHelper().postAPICall(Uri.parse(UpdateFamilyPermission_url), body, true);
    var responsedata = jsonDecode(response.body);
    log("updatedeletevalue responsedata : "+responsedata.toString());
    update();
  }
}

