import 'dart:developer';

import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:urwealthpal/Constant/Api.dart';
import 'package:urwealthpal/Constant/Images.dart';
import 'package:urwealthpal/Constant/Spacing.dart';
import 'package:urwealthpal/Constant/colors.dart';
import 'package:urwealthpal/Screens/Manage_Assets/Controllers/manageAssetsController.dart';

class manage_assets extends StatefulWidget {
  var names;
  var phoneNo;
  var emailID;
  var images;
  var familyMemberID;
   manage_assets({this.names,this.phoneNo,this.emailID,this.images,this.familyMemberID});

  @override
  State<manage_assets> createState() => _manage_assetsState();
}

class _manage_assetsState extends State<manage_assets> {
  List manageList = [];
  List checkList = [];

  bool click = true;
  int current = 0;
  var selectedindex;

  var manageAssetsController =Get.put(ManageAssetsController());

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    getcallApi();
  }

  getcallApi() async {
    var getPerUrl = GetFamilyPermission_url;
    var getPerBody = {
      "family_member_id" : widget.familyMemberID.toString()
    };
    log("check menage assets--->>"+getPerUrl.toString());
    log("check menage getPerBody--->>"+getPerBody.toString());
    await  manageAssetsController.GetPermissionApiCalling(getPerUrl,getPerBody);
  }

  // UpdatePermissionApiCalling(url, parameter) async {
  //   manageAssetsController.UpdatePermissionLoading.value =true;
  //   print("UpdatePermission " + url.toString());
  //   var response = await ApiBaseHelper().postAPICall(Uri.parse(url), parameter, true);
  //   var responsedata = jsonDecode(response.body);
  //   print("UpdatePermission responsedata : " + responsedata.toString());
  //   if(response.statusCode==200){
  //     manageAssetsController.UpdatePermissionData = responsedata['data'];
  //     manageAssetsController.UpdatePermissionLoading.value =false;
  //     getcallApi();
  //     setState(() {
  //
  //     });
  //   } else
  //     manageAssetsController.UpdatePermissionData =[];
  //   manageAssetsController.UpdatePermissionLoading.value =false;
  //   setState(() {
  //
  //   });;
  // }

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Scaffold(
        appBar: AppBar(
          elevation: 0,
          titleSpacing: 0,
          backgroundColor: ContainerColor,
          title: Text("manageAss_tx".tr),
        ),
        body: SingleChildScrollView(
          child: GetBuilder<ManageAssetsController>(
              builder: (manageAssetsController) {
                if(manageAssetsController.GetPermissionLoading.value){
                  return Center(child: Container(
                    alignment: Alignment.center,
                    height: size.height-150,
                    child: CircularProgressIndicator(),
                  ));
                }
                else{
                  return Column(
                    children: [
                      Stack(
                        children: [
                          Container(
                            height: 60,
                            decoration: BoxDecoration(
                              color: ContainerColor,
                              border: Border.all(color: ContainerColor),
                              borderRadius: BorderRadius.only(
                                  bottomLeft: (Radius.circular(30)),
                                  bottomRight: (Radius.circular(30))),
                            ),
                          ),
                          Container(
                            margin: EdgeInsets.fromLTRB(25, 20, 25, 0),
                            height: 120,
                            decoration: BoxDecoration(
                                color: sidebarcontainerColor,
                                border: Border.all(color: sidebarcontainerColor),
                                borderRadius: BorderRadius.all(Radius.circular(10))),
                            child: Stack(
                              children: [
                                ClipRRect(
                                    borderRadius: BorderRadius.all(Radius.circular(10)),
                                    child: profileTopImage),
                                Padding(
                                  padding: EdgeInsets.only(left: 20),
                                  child: Row(children: [
                                    CachedNetworkImage(imageUrl: widget.images.toString(),
                                      height: 100,
                                      width: 100,),
                                    Column(
                                      mainAxisAlignment: MainAxisAlignment.center,
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Padding(
                                          padding: EdgeInsets.all(5),
                                          child: Text(
                                            widget.names.toString(),
                                            style: TextStyle(
                                                color: whiteColor, fontSize: 20),
                                          ),
                                        ),
                                        Padding(
                                          padding: EdgeInsets.all(5),
                                          child: Row(
                                            children: [
                                              profileCallIcon,
                                              Padding(
                                                padding: EdgeInsets.only(left: 5),
                                                child: Text(
                                                  widget.phoneNo.toString(),
                                                  style: TextStyle(
                                                      color: whiteColor,
                                                      fontSize: 12),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                        Padding(
                                          padding: EdgeInsets.all(5),
                                          child: Row(
                                            children: [
                                              profilEmailIcon,
                                              Padding(
                                                padding: EdgeInsets.only(left: 5),
                                                child: Text(
                                                  widget.emailID.toString(),
                                                  style: TextStyle(
                                                      color: whiteColor,
                                                      fontSize: 12),
                                                ),
                                              ),
                                            ],
                                          ),
                                        ),
                                      ],
                                    ),
                                  ]),
                                ),
                                Padding(
                                  padding: EdgeInsets.only(top: 60, left: 165),
                                  child: ClipRRect(
                                      borderRadius:
                                      BorderRadius.all(Radius.circular(10)),
                                      child: profileBottomImage),
                                ),
                              ],
                            ),
                          ),

                          Padding(
                            padding:  EdgeInsets.only(top: 150),
                            child: ListView.builder(
                                itemCount: manageAssetsController.PermissionList.length,
                                scrollDirection: Axis.vertical,
                                shrinkWrap: true,
                                physics: NeverScrollableScrollPhysics(),
                                itemBuilder:
                                    (BuildContext context, index1) {
                                  var Categorieslistdata = manageAssetsController.PermissionList[index1];
                                  return Padding(
                                    padding:  EdgeInsets.only(left: 10,right: 10,top: 5),
                                    child: Card(
                                      // shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10),
                                      //   side: BorderSide(color: greyColor),),
                                      elevation: 2,
                                      child: ExpansionTile(
                                        onExpansionChanged: (bool expanded) {
                                          setState(() {
                                            // assetSubCategoryList =getcategoriesController.Get_CategoriesData[index1]['sub_categories'];
                                          });
                                        },
                                        title: GestureDetector(
                                          onTap: (){
                                            // Navigator.push(context,
                                            //     MaterialPageRoute(builder: (context)=>
                                            //         assets_details(
                                            //           mainCategories_id: Categorieslistdata["id"].toString(),)));
                                          },
                                          child: Row(
                                            children: [
                                              CachedNetworkImage(
                                                imageUrl: Categorieslistdata["image"].toString(),
                                                height: 55,width: 60,),
                                              sizebox_width_5,
                                              Expanded(
                                                flex: 25,
                                                child: Text(
                                                  Categorieslistdata["name"].toString(),
                                                  style: TextStyle(color: Darkgrey,
                                                      fontSize: 18,letterSpacing: 0.5,height: 1.5,
                                                      fontWeight: FontWeight.bold
                                                  ),
                                                ),
                                              ),
                                              sizebox_width_5,
                                              // Expanded( flex: 15,
                                              //   child: Container(
                                              //       padding: EdgeInsets.symmetric(horizontal: 5,vertical: 10),
                                              //       child: Center(
                                              //           child: Column(
                                              //             children: [
                                              //               Text(
                                              //                 Categorieslistdata["count"].toString(),
                                              //                 style: TextStyle(
                                              //                     color: whiteColor,
                                              //                     fontSize: 18,
                                              //                     fontWeight: FontWeight.bold
                                              //                 ),),
                                              //               Text(
                                              //                 "moduletxt".tr,
                                              //                 style: TextStyle(
                                              //                     color: whiteColor,
                                              //                     fontSize: 14.5,letterSpacing: 0.25,
                                              //                     fontWeight: FontWeight.w500
                                              //                 ),),
                                              //             ],
                                              //           )),
                                              //       decoration: BoxDecoration(
                                              //           color: ContainerColor,
                                              //           border: Border.all(color: ContainerColor),
                                              //           borderRadius: BorderRadius.all(Radius.circular(8))
                                              //       )
                                              //   ),
                                              // ),
                                            ],
                                          ),
                                        ),
                                        children: <Widget>[
                                          ListView.builder(
                                              itemCount: Categorieslistdata['sub_categories'].length,
                                              scrollDirection: Axis.vertical,
                                              shrinkWrap: true,
                                              physics: NeverScrollableScrollPhysics(),
                                              itemBuilder: (BuildContext context, index2) {
                                                var SubCategorieslistdata = Categorieslistdata['sub_categories'][index2];
                                                print("SubCategorieslistdata-->"+SubCategorieslistdata.toString());
                                                return Padding(
                                                  padding:  EdgeInsets.only(left: 10,right: 10,top: 5),
                                                  child: Card(
                                                    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10),
                                                      side: BorderSide(color: NameColors2),),
                                                    child: Column(
                                                      children: [
                                                        Row(
                                                          children: [
                                                            Padding(
                                                              padding: EdgeInsets.all(5),
                                                              child: CachedNetworkImage(
                                                                imageUrl:SubCategorieslistdata["image"].toString(),
                                                                height: 50,width: 50,),
                                                            ),
                                                            Text(
                                                              SubCategorieslistdata["name"].toString().toLowerCase(),
                                                              style: TextStyle(color: greyColor,
                                                                  fontSize: 16,
                                                                fontWeight: FontWeight.w500
                                                                  ),
                                                            ),
                                                          ],
                                                        ),
                                                        Row(
                                                          mainAxisAlignment: MainAxisAlignment.center,
                                                          children: [
                                                            Text("Can Add",style: TextStyle(
                                                                color: appBarColor,
                                                                fontSize: 14),),
                                                            Transform.scale(
                                                                scale: 1.0,
                                                                child: Switch(
                                                                  onChanged: (val) async {
                                                                    var updatePerUrl = UpdateFamilyPermission_url;
                                                                    var updatePerBody = {
                                                                      "family_member_id" : widget.familyMemberID.toString(),
                                                                      "category_id" :  SubCategorieslistdata["id"].toString(),
                                                                      "type" : "can_add",
                                                                      "action" : SubCategorieslistdata["can_add"].toString() =="1"?"0":"1",
                                                                    };
                                                                    manageAssetsController.updateaddvalue(index1,index2,UpdateFamilyPermission_url,updatePerBody);
                                                                    // await  UpdatePermissionApiCalling(updatePerUrl,updatePerBody);
                                                                    // setState(() {});
                                                                  },
                                                                  value: SubCategorieslistdata["can_add"].toString() =="1"?true:false,
                                                                  activeColor: whiteColor,
                                                                  activeTrackColor: appPrimaryColor,
                                                                  inactiveThumbColor: whiteColor,
                                                                  inactiveTrackColor: Red,
                                                                )
                                                            ),

                                                            Text("Can Delete",style: TextStyle(
                                                                color: appBarColor,
                                                                fontSize: 14),),

                                                            Transform.scale(
                                                                scale: 1.0,
                                                                child: Switch(
                                                                  onChanged: (val) async {
                                                                    var updatePerUrl = UpdateFamilyPermission_url;
                                                                    var updatePerBody = {
                                                                      "family_member_id" : widget.familyMemberID.toString(),
                                                                      "category_id" :  SubCategorieslistdata["id"].toString(),
                                                                      "type" : "can_delete",
                                                                      "action" : SubCategorieslistdata["can_delete"].toString() =="1"?"0":"1",
                                                                    };
                                                                    manageAssetsController.updatedeletevalue(index1,index2,updatePerUrl,updatePerBody);
                                                                    // await  UpdatePermissionApiCalling(updatePerUrl,updatePerBody);
                                                                    // setState(() {});
                                                                  },
                                                                  value: SubCategorieslistdata["can_delete"].toString() =="1"?true:false,
                                                                  activeColor: whiteColor,
                                                                  activeTrackColor: appPrimaryColor,
                                                                  inactiveThumbColor: whiteColor,
                                                                  inactiveTrackColor: Red,
                                                                )
                                                            ),
                                                          ],
                                                        ),
                                                      ],
                                                    ),
                                                  ),
                                                );
                                              }),
                                        ],
                                      ),
                                    ),
                                  );
                                }),
                          ),
                        ],
                      )
                    ],
                  );
                }

            }
          ),
        ));
  }
}

