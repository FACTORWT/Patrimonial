import 'dart:async';
import 'dart:convert';
import 'dart:developer';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:urwealthpal/Constant/Api.dart';
// import 'package:urwealthpal/Constant/Api.dart';
import 'package:urwealthpal/Constant/ApiBaseHelper.dart';
import 'package:urwealthpal/Constant/Images.dart';
import 'package:urwealthpal/Constant/MaitainceScreen.dart';
import 'package:urwealthpal/Constant/colors.dart';
import 'package:urwealthpal/Constant/forceUpdate_screen.dart';
import 'package:urwealthpal/Environment/Environment.dart';
import 'package:urwealthpal/Screens/WelcomeScreens/WelcomController.dart';
import 'package:urwealthpal/Screens/WelcomeScreens/welcomeScreen1.dart';
import 'package:urwealthpal/main.dart';
import 'package:local_auth/local_auth.dart';

class splashscreen extends StatefulWidget {
   splashscreen({Key? key}) : super(key: key);

  @override
  State<splashscreen> createState() => _splashscreenState();
}
class _splashscreenState extends State<splashscreen> {
  WelcomeController  welcomeController= Get.put(WelcomeController()) ;
  var setting_json_data;
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    getRoute();


  }

  final LocalAuthentication auth = LocalAuthentication();

  Future<void> _authenticate() async {
    bool isAuthenticated = false;
log("message authenticate");
    try {
      isAuthenticated = await auth.authenticate(
        localizedReason: 'Please authenticate to access',
        options: const AuthenticationOptions(
            biometricOnly: true, // Allow only biometric authentication
            sensitiveTransaction: true,
            stickyAuth: true),
      );
      if (isAuthenticated) {
        showDialog(
          context: context,
          builder: (_) => AlertDialog(
            title: Text('Authenticated'),
            content: Text('You have been authenticated successfully!'),
          ),
        );
      }
    } catch (e) {
      print('Error during authentication: $e');
    }
  }  @override



  getRoute() async {

    var settingurl = Uri.parse(settings_url);

    log("Setting url : " + settingurl.toString());
    var response = await ApiBaseHelper().getAPICall(settingurl, false);
    // log("response  : " + response.toString());

    var setting = jsonDecode(response.body);
    ApiBaseHelper().settingdata(setting);
    setting_json_data = await jsonDecode(sp!.getString("setting").toString());

   await welcomeController.setvideo( setting_json_data['data']["welcome_video"]);

    welcomeController.stopVideo();
    // Get.offAll(VideoScreen());
    log("setting data....." + setting_json_data.toString());


    if(int.parse(setting_json_data['data']['app_maintenance_update'].toString())==
        int.parse(maintainversion.toString())){
      log("appForceUpdate---->>>"+setting_json_data['data']['app_force_update'].toString());
      // log("appversion---->>>"+appversion);
      showDialog(
          context: context,
          barrierDismissible: false ,
          builder: (_) => WillPopScope(
            onWillPop: () async {
              return false;
            },
            child: MaitainceScreen(
              Maitaince_text: setting_json_data['data']['app_maintenance_msg'].toString(),
              appurl: setting_json_data['data']['playstore_url'].toString(),
              applogo: setting_json_data['data']['admin_logo'].toString(),
              appname: setting_json_data['data']['application_name'].toString(),
            ),
          ));
    }


    else if(double.parse(setting_json_data['data']['app_version'].toString())>=
        appversion){
      showDialog(
          context: context,
          barrierDismissible: false ,
          builder: (_) => WillPopScope(
            onWillPop: () async {
              return false;
            },
            child: ForceUpdatePage(
              forceupdate: setting_json_data['data']['app_force_update'].toString(),
              appurl:  setting_json_data['data']['playstore_url'].toString(),
              applogo: setting_json_data['data']['admin_logo'].toString(),
              appname:  setting_json_data['data']['application_name'].toString(),
              updateText: setting_json_data['data']['app_update_msg'].toString(),

            ),
          ));
    }
   else{
      if(Environment.appuserlog==false){

        log("setting data....."+Environment.appuserlog.toString() );
        Timer(
            Duration(seconds: 3),
                () =>
                Get.offAll(VideoScreen()
                )
        );
      }
      else
      {
        log("setting data.....else check" + setting_json_data.toString());
        ApiBaseHelper().manageroute();

      }
    }
  }
  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    var width=size.width;
    var height=size.height;

    return Scaffold(
        body: Container(
            height: MediaQuery.of(context).size.height,
            color: appPrimaryColor,
            child: Stack(
              children: [
                Center(child: splashImage),
                Center(
                  child: Container(
                    height:height*0.35,
                    width: width*0.8,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color:appPrimaryColor,
                    ),
                    child: splashNewBackImage,
                  ),
                ),
                // Positioned(child: Center(
                //   child: Column(
                //     mainAxisAlignment: MainAxisAlignment.center,
                //     crossAxisAlignment: CrossAxisAlignment.center,
                //     children: [
                //       Text(
                //         "Use your Fingerprint to log into the App!",
                //         style: TextStyle(
                //             color: Colors.white,
                //             fontSize: 15,
                //             fontWeight: FontWeight.normal),
                //       ),
                //       SizedBox(
                //         height: 30,
                //       ),
                //       ElevatedButton.icon(
                //         onPressed: _authenticate,
                //         icon: Icon(Icons.fingerprint),
                //         label: Text('Authenticate'),
                //       ),
                //     ],
                //   ),
                // ),)
              ],
            )
        )
    );
  }

  // getAPICall(Uri url, header) async {
  //   var headers = {
  //     'Content-Type': ' application/json',
  //     'x-api-key': '155b9e8b0561e13fccc90cc9a119647986bb0b75c6f9d5a60c20dba3'
  //   };
  //   var request = http.MultipartRequest('GET', Uri.parse('https://www.patrimonial.us/api/settings'));
  //
  //   request.headers.addAll(headers);
  //
  //   http.StreamedResponse response = await request.send();
  //   print("get statusCode : ${response.statusCode.toString()}");
  //
  //   if (response.statusCode == 200) {
  //     print(await response.stream.bytesToString());
  //   }
  //   else {
  //     print(response.reasonPhrase);
  //   }
  //
  // }
}