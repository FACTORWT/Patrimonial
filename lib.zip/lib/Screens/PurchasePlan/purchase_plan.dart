import 'dart:async';
import 'dart:developer';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:in_app_purchase/in_app_purchase.dart';
import 'package:urwealthpal/Constant/Api.dart';
import 'package:urwealthpal/Constant/colors.dart';
import 'package:flutter_html/flutter_html.dart';
import 'package:urwealthpal/Screens/PurchasePlan/purchasecontroller.dart';
import 'package:html/parser.dart' show parse;

late StreamSubscription<dynamic> _streamSubscription;
// List<ProductDetails> _products = [];
const _variant = {"wel_50_id","bro_7mnth_id","bas_3dys_id","silv_12_id"};
class purchase_plan extends StatefulWidget {
  const purchase_plan({Key? key}) : super(key: key);

  @override
  State<purchase_plan> createState() => _purchase_planState();
}

class _purchase_planState extends State<purchase_plan> {

  final InAppPurchase _inAppPurchase = InAppPurchase.instance;

  PurchaseController _purchaseController = Get.put(PurchaseController());

  String _getShortText(String html) {
    final document = parse(html);
    final plainText = document.body?.text.trim() ?? '';
    if (plainText.length <= 20) return plainText;
    return '${plainText.substring(0, 20)}...';
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();

    _purchaseController.callpurchaseplan_list(Get_SubscriptionPlan_url);

    Stream purchaseUpdated = InAppPurchase.instance.purchaseStream;
    _streamSubscription = purchaseUpdated.listen((purchaseList) {
      _listenToPurchase(purchaseList);
    }, onDone: (){
      _streamSubscription.cancel();
    }, onError: (error){
      ScaffoldMessenger.of(context).showSnackBar( SnackBar(content: Text("Error>> ${error}")));
    });

  }

  @override

  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Scaffold(
      appBar: AppBar(
        elevation: 0,
        titleSpacing: 20,
        backgroundColor: ContainerColor,
        title: Text("purchasePlantxt".tr),
      ),
      body: SingleChildScrollView(
        child: Padding(
          padding: EdgeInsets.only(top: 10, left: 5, right: 5),
          child: GetBuilder<PurchaseController>(builder: (purchaseController) {
            if (purchaseController.PurchaseplanLoading.value) {
              return Center(child: Container(
                  alignment: Alignment.center,
                  height: size.height*0.80,
                  child: CircularProgressIndicator()));
            } else
              return  purchaseController.productsNew.length==0?Center(child: Text("DataFound".tr)):
              ListView.builder(
                  itemCount:purchaseController.productsNew.length,
                  scrollDirection: Axis.vertical,
                  shrinkWrap: true,
                  physics: NeverScrollableScrollPhysics(),
                  itemBuilder: (BuildContext context, index) {
                    var purchase_planData =purchaseController.productsNew[index];
                    log(purchase_planData.title.toString());
                    log('description==>>'+purchase_planData.title.toString());
                    print('yess==>');
                    return Container(

                      height: size.height*0.20,

                      decoration: BoxDecoration(
                          image: DecorationImage(
                              image: AssetImage("assets/images/gold plan.png"))
                      ),

                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.spaceAround,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [

                          // Container(
                          //   padding: EdgeInsets.only(top: 10,),
                          //   width: MediaQuery.of(context).size.width-55,
                          //   // color: Colors.red,
                          //   alignment: Alignment.center,
                          //   child: Html(
                          //     data: purchase_planData.title.toString(),
                          //     style: {
                          //       "p": Style(
                          //         fontSize: FontSize(20),
                          //         color: const Color(0xFF85D9FF),
                          //         textOverflow: TextOverflow.ellipsis,
                          //
                          //         fontWeight: FontWeight.bold,
                          //         textAlign: TextAlign.center,
                          //         margin: EdgeInsets.only(bottom: 13),
                          //       ),
                          //       "li": Style(
                          //         listStyleType: ListStyleType.DISC,
                          //       ),
                          //       "ul": Style(
                          //         padding: EdgeInsets.only(left: 20),
                          //       ),
                          //     },
                          //   )
                          // ),

                          Text(
                            purchase_planData.title.toString().split("(")[0],
                            style: TextStyle(
                              fontSize: 18,
                              color: whiteColor,
                            ),
                          ),
                          Text(
                            purchase_planData.price.toString().split("(")[0],
                            style: TextStyle(
                              fontSize: 18,
                              color: whiteColor,
                            ),
                          ),

                          // Text(
                          //   purchase_planData.description.toString(),
                          //   textAlign: TextAlign.center,
                          //   style: TextStyle(
                          //     fontSize: 14,
                          //     color: Color(0xFFA8B0FF),
                          //   ),
                          // ),

                          Row(
                            mainAxisAlignment: MainAxisAlignment.end,
                            children: [
                              GestureDetector(
                                onTap: () {

                                  _buy(index);



                                },
                                child: Container(
                                  color: Colors.red.withOpacity(0.0),
                                  child: Padding(
                                    padding:  EdgeInsets.only(bottom: 15,right: 5),
                                    child: Row(
                                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                      children: [
                                        Text(
                                          "ChoosePlant_txt".tr,
                                          style: TextStyle(
                                              fontSize: 16,
                                              color: whiteColor,
                                              fontWeight: FontWeight.bold),
                                        ),
                                        Padding(
                                          padding: EdgeInsets.only(left: 15),
                                          child: Icon(
                                            Icons.arrow_forward_ios,
                                            color: whiteColor,
                                          ),
                                        )
                                      ],
                                    ),
                                  ),
                                ),
                              ),
                            ],
                          )

                        ],
                      ),
                    );
                  });
          }),
        ),
      ),
    );
  }

  displayBottomSheet(BuildContext context, heading, description, amount, id) {
    Size size = MediaQuery.of(context).size;
    return showModalBottomSheet(
        context: context,
        backgroundColor: Colors.transparent,
        barrierColor: Colors.black87.withOpacity(0.5),
        isDismissible: true,
        builder: (context) => Container(
          width: size.width,
          height: 380,
          padding: EdgeInsets.all(12),
          decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.vertical(top: Radius.circular(2)),
              boxShadow: [
                BoxShadow(
                    offset: Offset(2, 1),
                    color: Colors.grey.shade700,
                    blurRadius: 10,
                    spreadRadius: 5)
              ]),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Column(
                children: [
                  Container(
                    height: 5,
                    decoration: BoxDecoration(
                      color: Colors.black54,
                      borderRadius: BorderRadius.horizontal(
                          left: Radius.circular(50),
                          right: Radius.circular(50)),
                    ),
                    margin: EdgeInsets.symmetric(horizontal: 150),
                  ),

                  SizedBox(
                    height: 50,
                  ),
                  Container(
                      width: size.width,
                      child: Text(
                        heading.toString(),
                        maxLines: 1,
                        style: TextStyle(
                            letterSpacing: 0.25,
                            fontWeight: FontWeight.w700,
                            fontSize: 20,
                            color: Colors.grey.shade800),
                      )),
                  SizedBox(
                    height: 20,
                  ),
                  // Container(
                  //     margin: EdgeInsets.symmetric(vertical: 4),
                  //     width: size.width,
                  //     child: Text(
                  //       description.toString(),
                  //       maxLines: 3,
                  //       style: TextStyle(
                  //           fontWeight: FontWeight.w400,
                  //           fontSize: 14,
                  //           color: Colors.grey.shade800,
                  //           letterSpacing: 0.25),
                  //     )),
                  Container(
                      margin: EdgeInsets.symmetric(vertical: 4),
                      width: size.width,
                    // color: Colors.red,
                    alignment: Alignment.center,
                    child: Html(
                      data: description.toString(),
                      style: {
                        "p": Style(
                          fontSize: FontSize(20),
                          color: const Color(0xFF85D9FF),
                          fontWeight: FontWeight.bold,
                          textAlign: TextAlign.center,
                          margin: EdgeInsets.only(bottom: 13),
                        ),
                        "li": Style(
                          listStyleType: ListStyleType.DISC,
                        ),
                        "ul": Style(
                          padding: EdgeInsets.only(left: 20),
                        ),
                      },
                    )
                  ),
                  SizedBox(
                    height: 10,
                  ),
                ],
              ),
              Padding(
                padding: EdgeInsets.fromLTRB(10, 20, 10, 10),
                child: Row(children: [
                  // Expanded(
                  //   child: GestureDetector(
                  //     onTap: (){
                  //       Navigator.pop(context);
                  //     },
                  //     child: Container(
                  //       height: 40,
                  //       decoration: BoxDecoration(
                  //           border: Border.all(color: appPrimaryColor),
                  //           borderRadius:
                  //           BorderRadius.all(Radius.circular(8))),
                  //       child: Padding(
                  //         padding: EdgeInsets.only(top: 10),
                  //         child: Text(
                  //           "Failure",
                  //           textAlign: TextAlign.center,
                  //           style: TextStyle(
                  //             color: Namecolors,
                  //             fontSize: 15,
                  //           ),
                  //         ),
                  //       ),
                  //     ),
                  //   ),
                  // ),
                  Expanded(
                    child: GestureDetector(
                      onTap: () {
                        var body = {
                          "productID":id.toString(),
                          "purchaseID":DateTime.now().microsecondsSinceEpoch.toString(),
                          "transactionDate":DateTime.now().toString(),
                          "localVerificationData":"",
                        };
                        log("body>>> "+body.toString());
                        _purchaseController.savepurchase(Save_SubscriptionPlan_url,body);

                      },
                      child: Container(
                        margin: EdgeInsets.only(left: 10),
                        height: 40,
                        decoration: BoxDecoration(
                            color: appPrimaryColor,
                            border: Border.all(color: appPrimaryColor),
                            borderRadius:
                            BorderRadius.all(Radius.circular(8))),
                        child: Padding(
                          padding: EdgeInsets.only(top: 10),
                          child: Text(
                            "Buy For Free",
                            textAlign: TextAlign.center,
                            style: TextStyle(
                              color: whiteColor,
                              fontSize: 15,
                            ),
                          ),
                        ),
                      ),
                    ),
                  )
                ]),
              ),
            ],
          ),
        ));
  }

  _listenToPurchase(List<PurchaseDetails> purchaseDetailsList) {
    purchaseDetailsList.forEach((PurchaseDetails purchaseDetails) async {
      if (purchaseDetails.status == PurchaseStatus.pending) {
        // ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Pending")));
      } else if (purchaseDetails.status == PurchaseStatus.error) {
        log("inapppurchase error "+PurchaseStatus.error.name);
        // ScaffoldMessenger.of(context).showSnackBar( SnackBar(content: Text("Error>> ${PurchaseStatus.error.name}")));
      } else if (purchaseDetails.status == PurchaseStatus.purchased) {

        var body = {
          "productID":purchaseDetails.productID.toString(),
          "purchaseID":purchaseDetails.purchaseID.toString(),
          "transactionDate":purchaseDetails.transactionDate.toString(),
          "localVerificationData":purchaseDetails.verificationData.localVerificationData.toString(),
        };

        log("body----->>>>>>"+body.toString());
        _purchaseController.savepurchase(Save_SubscriptionPlan_url,body);

        // ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text("Purchased")));
      }
    });
  }

  _buy(index){
    if(_purchaseController.productsNew[index].price == "Free"){


      displayBottomSheet(
          context,
          _purchaseController.productsNew[index].title,
          _purchaseController.productsNew[index].description,
          _purchaseController.productsNew[index].price,
          _purchaseController.productsNew[index].id);

    }
    else{
      final PurchaseParam param = PurchaseParam(productDetails:_purchaseController.products[index]);
      log("products List---->>>"+_purchaseController.products[index].toString());
      _inAppPurchase.buyConsumable(purchaseParam: param);
    }
  }

}