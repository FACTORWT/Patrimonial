import 'dart:async';
import 'dart:convert';
import 'dart:developer';
import 'dart:io';
import 'package:flutter_pdfview/flutter_pdfview.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';
import 'package:in_app_purchase/in_app_purchase.dart';
import 'package:path_provider/path_provider.dart';
import 'package:urwealthpal/Constant/ApiBaseHelper.dart';
import 'package:urwealthpal/Environment/Environment.dart';
import 'package:urwealthpal/main.dart';
import 'package:http/http.dart' as http;

class PurchaseController extends GetxController{
  var PurchaseplanLoading = false.obs;
  var SavePurchaseplanLoading = false.obs;
  List PurchaseplanData =[] ;
  List PurchaseplanHistoryData =[] ;
  List<String> PurchaseData =[] ;
  var PurchasePlanDataId ;
  List<ProductDetails> products = [];
  List<ProductDetails> productsNew = [];
  var   productDetails;



  var variant = {"wel_50_id","bro_7mnth_id","bas_3dys_id","silv_12_id"};
  var freeVariant = {""};
  final InAppPurchase _inAppPurchase = InAppPurchase.instance;

   // callpurchaseplan_list(url) async {
  //   PurchaseplanLoading(true);
  //   var jsondata = json.decode(sp!.getString("loginresponse").toString());
  //   print("data: "+url.toString());
  //   var  token =jsondata['data']['access_token'];
  //   var _mainHeaders = {
  //     'Content-Type': 'application/json',
  //     Environment.appxapikey.toString(): Environment.appxapivalue.toString(),
  //     'Authorization': 'Bearer ${token}'
  //   };
  //   final request = http.MultipartRequest('GET', Uri.parse(url));
  //   request.headers.addAll(_mainHeaders);
  //   http.StreamedResponse responses = await request.send();
  //
  //   var response = await http.Response.fromStream(responses);
  //   log("response-------->"+response.body);
  //   log("_mainHeaders-------->"+_mainHeaders.toString());
  //   // var response = await ApiBaseHelper().getAPICall(Uri.parse(url), true);
  //   var responsedata = jsonDecode(response.body);
  //   if(response.statusCode==200){
  //     PurchaseplanData.clear();
  //     variant.clear();
  //     PurchaseplanData.addAll(responsedata['data']['subscriptions']);
  //     log("PurchaseplanDatanew>>> "+PurchaseplanData.toString());
  //     PurchaseplanLoading(false);
  //
  //     PurchaseplanData.forEach((element) {
  //       variant.add(element['iap_id'].toString());
  //
  //
  //     });
  //     log("variant>>> "+variant.toString());
  //     ProductDetailsResponse productDetailsResponse =await _inAppPurchase.queryProductDetails(variant);
  //
  //     // List<ProductDetails> productDetails = ProductDetails(id: "0",currencyCode:"" ,
  //     //     description:"Get Free Access To App For 7days trial",price:"Free" ,rawPrice:0.0 ,
  //     //     title:"Free Plan" ,currencySymbol:"0" ) as List<ProductDetails>;
  //
  //     productsNew.clear();
  //
  //     productDetailsResponse.productDetails.forEach((element) {
  //       log("element>>> "+element.title);
  //       productDetails = ProductDetails(id: element.id,currencyCode:element.currencyCode ,
  //           description:element.description,price:element.price ,rawPrice:element.rawPrice ,
  //           title:element.title ,currencySymbol:element.currencySymbol);
  //
  //       productsNew.add(productDetails) ;
  //       log("productDetails----->>>>>"+productsNew.length.toString());
  //
  //     });
  //
  //     PurchaseplanData.forEach((element) {
  //
  //       if(element['is_trial_plan']==1){
  //
  //         productDetails = ProductDetails(id: element['iap_id'], currencyCode:"" ,
  //             description:element['description'], price:"Free", rawPrice:0.0 ,
  //             title:element['plan_title'], currencySymbol:"0" );
  //         productsNew.add(productDetails);
  //       }
  //
  //     });
  //
  //     log("productsNew>>> "+productsNew.toString());
  //     if(productDetailsResponse.error==null){
  //       products = productDetailsResponse.productDetails;
  //       update();
  //     }
  //     update();
  //   }else{
  //     PurchaseplanData=[];
  //     PurchaseplanLoading(false);
  //     update();
  //   }
  // }

  callpurchaseplan_list(String url) async {
    PurchaseplanLoading(true);
    var jsondata = json.decode(sp!.getString("loginresponse").toString());
    print("data: $url");

    var token = jsondata['data']['access_token'];
    var _mainHeaders = {
      'Content-Type': 'application/json',
      Environment.appxapikey.toString(): Environment.appxapivalue.toString(),
      'Authorization': 'Bearer $token'
    };

    try {
      // ✅ Simple GET request
      final response = await http.get(Uri.parse(url), headers: _mainHeaders);

      log("response--------> ${response.body}");
      log("_mainHeaders--------> $_mainHeaders");

      if (response.statusCode == 200) {
        var responsedata = jsonDecode(response.body);

        PurchaseplanData.clear();
        variant.clear();
        PurchaseplanData.addAll(responsedata['data']['subscriptions']);
        log("PurchaseplanDatanew>>> $PurchaseplanData");
        PurchaseplanLoading(false);

        PurchaseplanData.forEach((element) {
          variant.add(element['iap_id'].toString());
        });
        log("variant>>> $variant");

        ProductDetailsResponse productDetailsResponse =
        await _inAppPurchase.queryProductDetails(variant.toSet());

        productsNew.clear();

        productDetailsResponse.productDetails.forEach((element) {
          log("element>>> ${element.title}");
          productDetails = ProductDetails(
            id: element.id,
            currencyCode: element.currencyCode,
            description: element.description,
            price: element.price,
            rawPrice: element.rawPrice,
            title: element.title,
            currencySymbol: element.currencySymbol,
          );

          productsNew.add(productDetails);
          log("productDetails----->>>>> ${productsNew.length}");
        });

        PurchaseplanData.forEach((element) {
          if (element['is_trial_plan'] == 1) {
            productDetails = ProductDetails(
              id: element['iap_id'],
              currencyCode: "",
              description: element['description'],
              price: "Free",
              rawPrice: 0.0,
              title: element['plan_title'],
              currencySymbol: "0",
            );
            productsNew.add(productDetails);
          }
        });

        log("productsNew>>> $productsNew");
        if (productDetailsResponse.error == null) {
          products = productDetailsResponse.productDetails;
          update();
        }
        update();
      } else {
        PurchaseplanData = [];
        PurchaseplanLoading(false);
        update();
      }
    } catch (e) {
      log("Error in callpurchaseplan_list: $e");
      PurchaseplanData = [];
      PurchaseplanLoading(false);
      update();
    }
  }



  callpurchaseplanHistory_list(String url) async {
    PurchaseplanLoading(true);

    var jsondata = json.decode(sp!.getString("loginresponse").toString());
    var token = jsondata['data']['access_token'];

    var _mainHeaders = {
      'Content-Type': 'application/json',
      Environment.appxapikey.toString(): Environment.appxapivalue.toString(),
      'Authorization': 'Bearer $token'
    };

    log("url Response>>> $url");
    log("_mainHeaders Response>>> $_mainHeaders");

    try {
      final response = await http.get(
        Uri.parse(url),
        headers: _mainHeaders,
      );

      log("Raw Response>>> ${response.body}");

      if (response.statusCode == 200) {
        var responsedata = jsonDecode(response.body);
        log("PurchaseplanHistoryData Response>>> $responsedata");

        PurchaseplanHistoryData.clear();
        PurchaseplanHistoryData.addAll(responsedata['data']);
        log("PurchaseplanHistoryData>>> $PurchaseplanHistoryData");

        PurchaseplanLoading(false);
        update();
      } else {
        PurchaseplanHistoryData = [];
        PurchaseplanLoading(false);
        update();
        log("Error: ${response.statusCode} ${response.reasonPhrase}");
      }
    } catch (e) {
      PurchaseplanHistoryData = [];
      PurchaseplanLoading(false);
      update();
      log("Exception>>> $e");
    }
  }


  String remotePDFpath = "";
  int currentPage = 0;
  int pages = 0;
  var top_post = 0.obs;
  var right_post = 0.obs;
  bool isReady = false;
  String errorMessage = '';
  var DurationMessage = ''.obs;
  final Completer<PDFViewController> controllerpdfview = Completer<PDFViewController>();
  Future<File> createFileOfPdfUrl(String url) async {
    print("Start download file from internet!");
    try {
      // "https://berlin2017.droidcon.cod.newthinking.net/sites/global.droidcon.cod.newthinking.net/files/media/documents/Flutter%20-%2060FPS%20UI%20of%20the%20future%20%20-%20DroidconDE%2017.pdf";
      // final url = "https://pdfkit.org/docs/guide.pdf";
      // final url = "http://www.pdf995.com/samples/pdf.pdf";
      final filename = url.substring(url.lastIndexOf("/") + 1);
      var dir;
      if(Platform.isAndroid){
        dir = await getApplicationDocumentsDirectory();
      }else{
        dir = await getLibraryDirectory();
      }
      log("path> ${dir.path}/ $filename");
      File file = File("${dir.path}/$filename");
      if (await file.exists()) {
        update();
        return file;
      }else{
        var data = await http.get(Uri.parse(url));
        var contentLength = data.contentLength;
        var bytes = data.bodyBytes;
        log("contentLength>  $contentLength");
        log("bytesLength>  ${bytes.length}");
        File urlFile = await file.writeAsBytes(bytes);
        print("Download files");
        return urlFile;
      }


    } catch (e) {
      throw Exception('Error parsing asset file!');
    }
  }


  List invoicedata = [];

  invoice_list(String url) async {
    PurchaseplanLoading(true);

    log("url>>>> $url");

    var jsondata = json.decode(sp!.getString("loginresponse").toString());
    var token = jsondata['data']['access_token'];

    var _mainHeaders = {
      'Content-Type': 'application/json',
      Environment.appxapikey.toString(): Environment.appxapivalue.toString(),
      'Authorization': 'Bearer $token',
    };

    try {
      final response = await http.get(Uri.parse(url), headers: _mainHeaders);

      var responsedata = jsonDecode(response.body);
      log("InvoiceData Response>>> $responsedata");

      if (response.statusCode == 200) {
        invoicedata.add(responsedata['data']);
        PurchaseplanLoading(false);

        var urls = responsedata['data']['url'];
        if (urls != null && urls.toString().isNotEmpty) {
          await createFileOfPdfUrl(urls).then((f) {
            remotePDFpath = f.path;
            log("remotePDFpath >> $remotePDFpath");
            update();
          });
        }

        update();
      } else {
        PurchaseplanLoading(false);
        update();
      }
    } catch (e) {
      log("Error in invoice_list: $e");
      PurchaseplanLoading(false);
      update();
    }
  }



  savepurchase(url,parameter) async {
    SavePurchaseplanLoading(true);
    var jsondata = json.decode(sp!.getString("loginresponse").toString());
    print("data: "+jsondata.toString());
    var  token =jsondata['data']['access_token'];
    var _mainHeaders = {
      // 'Content-Type': 'application/json',
      Environment.appxapikey.toString(): Environment.appxapivalue.toString(),
      'Authorization': 'Bearer ${token}'
    };
    log("_mainHeaders>> "+_mainHeaders.toString());
    final response = await http
        .post(
      Uri.parse(url),
      body: parameter,
      headers:  _mainHeaders ,
    )
        .timeout(
      Duration(
        seconds: int.parse(Environment.apptimeout.toString()),
      ),);
    log("post statusCode : ${response.statusCode.toString()}");
    log("post response : ${response.body.toString()}");
    var responsedata = jsonDecode(response.body);
    if(response.statusCode==200){
      sp!.setBool("paymentstatus", true);
      sp!.setString("ask_mpin", responsedata['data']['ask_mpin'].toString());
      sp!.setString("set_mpin", responsedata['data']['set_mpin'].toString());
      SavePurchaseplanLoading(false);
      print("setMPIN...SavePurchase..."+Environment.setMPIN.toString());
      print("askMPIN...SavePurchase..."+Environment.askMPIN.toString());
      print("checkpaymentstatus...SavePurchase..."+Environment.checkpaymentstatus.toString());
      ApiBaseHelper().manageroute();
      Fluttertoast.showToast(msg: "Payment Success");
      update();
    }else{
      Fluttertoast.showToast(msg: "Payment Failure");
      SavePurchaseplanLoading(false);
      update();
    }
  }
}