import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:urwealthpal/Constant/Api.dart';
import 'package:urwealthpal/Constant/Dividers.dart';
import 'package:urwealthpal/Constant/Spacing.dart';
import 'package:urwealthpal/Constant/colors.dart';
import 'package:urwealthpal/Screens/PurchasePlan/invoice_view_page.dart';

import 'purchasecontroller.dart';

class MySubscription extends StatefulWidget {
  const MySubscription({Key? key}) : super(key: key);

  @override
  State<MySubscription> createState() => _MySubscriptionState();
}

// List MySubscriptionList = [
//   {
//     "voucher_no" : "VN000106",
//     "subscription_name": "Welcome plan",
//     "plan_price": "50",
//     "plan_duration": "2",
//     "plan_duration_text": "Monthly",
//     "purchase_date": "26-02-2024",
//     "start_date": "26-02-2024",
//     "expire_date": "27-03-2024",
//     "plan_total": "50",
//   },
//   {
//     "voucher_no" : "VN000106",
//     "subscription_name": "Welcome plan",
//     "plan_price": "50",
//     "plan_duration": "2",
//     "plan_duration_text": "Monthly",
//     "purchase_date": "26-02-2024",
//     "start_date": "26-02-2024",
//     "expire_date": "27-03-2024",
//     "plan_total": "50",
//   },
//   {
//     "voucher_no" : "VN000106",
//     "subscription_name": "Welcome plan",
//     "plan_price": "50",
//     "plan_duration": "2",
//     "plan_duration_text": "Monthly",
//     "purchase_date": "26-02-2024",
//     "start_date": "26-02-2024",
//     "expire_date": "27-03-2024",
//     "plan_total": "50",
//   },
//   {
//     "voucher_no" : "VN000106",
//     "subscription_name": "Welcome plan",
//     "plan_price": "50",
//     "plan_duration": "2",
//     "plan_duration_text": "Monthly",
//     "purchase_date": "26-02-2024",
//     "start_date": "26-02-2024",
//     "expire_date": "27-03-2024",
//     "plan_total": "50",
//   },
//   {
//     "voucher_no" : "VN000106",
//     "subscription_name": "Welcome plan",
//     "plan_price": "50",
//     "plan_duration": "2",
//     "plan_duration_text": "Monthly",
//     "purchase_date": "26-02-2024",
//     "start_date": "26-02-2024",
//     "expire_date": "27-03-2024",
//     "plan_total": "50",
//   },
//   {
//     "voucher_no" : "VN000106",
//     "subscription_name": "Welcome plan",
//     "plan_price": "50",
//     "plan_duration": "2",
//     "plan_duration_text": "Monthly",
//     "purchase_date": "26-02-2024",
//     "start_date": "26-02-2024",
//     "expire_date": "27-03-2024",
//     "plan_total": "50",
//   },
// ];


class _MySubscriptionState extends State<MySubscription> {

  PurchaseController _purchaseController = Get.put(PurchaseController());

  @override
  void initState() {
    // TODO: implement initState
    super.initState();

    _purchaseController.callpurchaseplanHistory_list(Get_MySubscriptionPlan_url);
  }

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Scaffold(
      appBar: AppBar(

        title: Text("Subscription_txt".tr),
      ),
      body:  GetBuilder<PurchaseController>(builder: (purchaseController) {
        if (purchaseController.PurchaseplanLoading.value) {
          return Center(child: Container(
              alignment: Alignment.center,
              // height: size.height*0.80,
              child: CircularProgressIndicator()));
        } else
          return  purchaseController.PurchaseplanHistoryData.length==0?Center(child: Text("DataFound".tr)): Padding(
            padding: EdgeInsets.symmetric(vertical: 5,horizontal: 5),
            child: ListView.builder(
                itemCount: purchaseController.PurchaseplanHistoryData.length,
                scrollDirection: Axis.vertical,
                shrinkWrap: true,
                physics: AlwaysScrollableScrollPhysics(),
                itemBuilder: (BuildContext context, index) {
                  var listdata = purchaseController.PurchaseplanHistoryData[index];
                  return Card(
                    elevation: 4,
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(15.0),
                    ),
                    child: Column(
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.end,
                          children: [
                            Container(
                              padding: EdgeInsets.symmetric(horizontal: 5,vertical: 5),
                              decoration: BoxDecoration(
                                  color: ContainerColor,
                                  border: Border.all(
                                      color: ContainerColor,
                                      width: 1.5
                                  ),
                                  // borderRadius:
                                  // BorderRadius.circular(10),
                                  borderRadius: BorderRadius.only(
                                    topRight: Radius.circular(10),
                                    bottomLeft: Radius.circular(10),
                                  )
                              ),
                              child: Text(
                                listdata['is_active_text'].toString(),
                                textAlign: TextAlign.center,
                                style: TextStyle(
                                    color: Colors.white,
                                    fontSize: 14.5,
                                    fontWeight: FontWeight.bold),
                              ),
                            ),
                          ],
                        ),
                        Container(
                          padding: EdgeInsets.symmetric(vertical: 5,horizontal: 10),
                          child: Row(
                            children: [
                              Container(
                                width: MediaQuery.of(context).size.width-210,
                                // color: Colors.red,
                                child: Text(
                                  "VoucherNo_txt".tr,
                                  style: TextStyle(
                                      color: ContainerColor,
                                      fontSize: 16,
                                      fontWeight: FontWeight.bold),
                                ),
                              ),
                              Container(
                                width: MediaQuery.of(context).size.width-340,
                                // color: Colors.green,
                                child: Text(
                                  ":",
                                  style: TextStyle(
                                      color: ContainerColor,
                                      fontSize: 16,
                                      fontWeight: FontWeight.w500
                                  ),
                                ),
                              ),
                              Container(
                                width: MediaQuery.of(context).size.width-300,
                                // color: Colors.yellow,
                                child: Text(
                                  "${listdata['voucher_no'].toString()}",
                                  style: TextStyle(
                                      fontWeight: FontWeight.w600,
                                      fontSize: 13
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          padding: EdgeInsets.symmetric(vertical: 5,horizontal: 10),
                          child: Row(
                            children: [
                              Container(
                                width: MediaQuery.of(context).size.width-210,
                                // color: Colors.red,
                                child: Text(
                                  "SubscriptionName_txt".tr,
                                  style: TextStyle(
                                      color: ContainerColor,
                                      fontSize: 16,
                                      fontWeight: FontWeight.bold),
                                ),
                              ),
                              Container(
                                width: MediaQuery.of(context).size.width-340,
                                // color: Colors.green,
                                child: Text(
                                  ":",
                                  style: TextStyle(
                                      color: ContainerColor,
                                      fontSize: 16,
                                      fontWeight: FontWeight.w500
                                  ),
                                ),
                              ),
                              Container(
                                width: MediaQuery.of(context).size.width-300,
                                // color: Colors.yellow,
                                child: Text(
                                  "${listdata['subscription_name'].toString()}",
                                  style: TextStyle(
                                      fontWeight: FontWeight.w600,
                                      fontSize: 13
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          padding: EdgeInsets.symmetric(vertical: 5,horizontal: 10),
                          child: Row(
                            children: [
                              Container(
                                width: MediaQuery.of(context).size.width-210,
                                // color: Colors.red,
                                child: Text(
                                  "PlanPrice_txt".tr,
                                  style: TextStyle(
                                      color: ContainerColor,
                                      fontSize: 16,
                                      fontWeight: FontWeight.bold),
                                ),
                              ),
                              Container(
                                width: MediaQuery.of(context).size.width-340,
                                // color: Colors.green,
                                child: Text(
                                  ":",
                                  style: TextStyle(
                                      color: ContainerColor,
                                      fontSize: 16,
                                      fontWeight: FontWeight.w500
                                  ),
                                ),
                              ),
                              Container(
                                width: MediaQuery.of(context).size.width-300,
                                // color: Colors.yellow,
                                child: Text(
                                  "\$${listdata['plan_price'].toString()}/-",
                                  style: TextStyle(
                                      fontWeight: FontWeight.w600,
                                      fontSize: 13
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          padding: EdgeInsets.symmetric(vertical: 5,horizontal: 10),
                          child: Row(
                            children: [
                              Container(
                                width: MediaQuery.of(context).size.width-210,
                                // color: Colors.red,
                                child: Text(
                                  "PlanDuration_txt".tr,
                                  style: TextStyle(
                                      color: ContainerColor,
                                      fontSize: 16,
                                      fontWeight: FontWeight.bold),
                                ),
                              ),
                              Container(
                                width: MediaQuery.of(context).size.width-340,
                                // color: Colors.green,
                                child: Text(
                                  ":",
                                  style: TextStyle(
                                      color: ContainerColor,
                                      fontSize: 16,
                                      fontWeight: FontWeight.w500
                                  ),
                                ),
                              ),
                              Container(
                                width: MediaQuery.of(context).size.width-300,
                                // color: Colors.yellow,
                                child: Text(
                                  "${listdata['plan_duration'].toString()}",
                                  style: TextStyle(
                                      fontWeight: FontWeight.w600,
                                      fontSize: 13
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          padding: EdgeInsets.symmetric(vertical: 5,horizontal: 10),
                          child: Row(
                            children: [
                              Container(
                                width: MediaQuery.of(context).size.width-210,
                                // color: Colors.red,
                                child: Text(
                                  "PurchaseDate_txt".tr,
                                  style: TextStyle(
                                      color: ContainerColor,
                                      fontSize: 16,
                                      fontWeight: FontWeight.bold),
                                ),
                              ),
                              Container(
                                width: MediaQuery.of(context).size.width-340,
                                // color: Colors.green,
                                child: Text(
                                  ":",
                                  style: TextStyle(
                                      color: ContainerColor,
                                      fontSize: 16,
                                      fontWeight: FontWeight.w500
                                  ),
                                ),
                              ),
                              Container(
                                width: MediaQuery.of(context).size.width-300,
                                // color: Colors.yellow,
                                child: Text(
                                  "${listdata['purchase_date'].toString()}",
                                  style: TextStyle(
                                      fontWeight: FontWeight.w600,
                                      fontSize: 13
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                        Container(
                          padding: EdgeInsets.symmetric(vertical: 5,horizontal: 10),
                          child: Row(
                            children: [
                              Container(
                                width: MediaQuery.of(context).size.width-210,
                                // color: Colors.red,
                                child: Text(
                                  "Plan_Total_txt".tr,
                                  style: TextStyle(
                                      color: ContainerColor,
                                      fontSize: 16,
                                      fontWeight: FontWeight.bold),
                                ),
                              ),
                              Container(
                                width: MediaQuery.of(context).size.width-340,
                                // color: Colors.green,
                                child: Text(
                                  ":",
                                  style: TextStyle(
                                      color: ContainerColor,
                                      fontSize: 16,
                                      fontWeight: FontWeight.w500
                                  ),
                                ),
                              ),
                              Container(
                                width: MediaQuery.of(context).size.width-300,
                                // color: Colors.yellow,
                                child: Text(
                                  "\$${listdata['plan_total'].toString()}/-",
                                  style: TextStyle(
                                      fontWeight: FontWeight.w600,
                                      fontSize: 13
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),

                        Row(
                          mainAxisAlignment: MainAxisAlignment.end,
                          children: [
                            Padding(
                              padding: EdgeInsets.symmetric(vertical: 5,horizontal: 10),
                              child: GestureDetector(
                                onTap: (){
                                  Get.to(InvoiceViewPage(id: listdata['id'].toString(),));
                                },
                                child: Container(
                                  height: 30,
                                  width: size.width-250,
                                  decoration: BoxDecoration(
                                      color: ContainerColor,
                                      border: Border.all(
                                          color:  ContainerColor,
                                          width: 1.5
                                      ),
                                      borderRadius: BorderRadius.all(Radius.circular(5))
                                      ),

                                  child: Center(
                                    child: Text(
                                      "ViewInvoice_txt".tr,
                                      style: TextStyle(
                                          color: Colors.white,
                                          fontSize: 14,
                                          fontWeight: FontWeight.bold),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),

                        SizedBox(height: 5,),

                        Container(
                          padding: EdgeInsets.symmetric(horizontal: 8.0,vertical: 9),
                          decoration: BoxDecoration(
                              color: ContainerColor,
                              border: Border.all(
                                  color:  ContainerColor,
                                  width: 1.5
                              ),
                              borderRadius: BorderRadius.only(
                                  bottomRight: Radius.circular(15.0),
                                  bottomLeft: Radius.circular(15.0)
                              )
                          ),

                          child:  Row(
                            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                            children: [
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Row(
                                    children: [
                                      Text("start_date".tr, style: TextStyle(
                                                     color: Colors.white,
                                                     fontSize: 13,
                                                     fontWeight: FontWeight.bold),
                                                 ),
                                      sizebox_width_5,
                                      Text(
                                        ":",
                                        style: TextStyle(
                                            color: Colors.white,
                                            fontSize: 13,
                                            fontWeight: FontWeight.bold),
                                      ),
                                      sizebox_width_5,

                                    ],
                                  ),
                                  SizedBox(height: 1,),
                                  Text(listdata['start_date'].toString(),
                                    textAlign: TextAlign.center,
                                    style: TextStyle(
                                        color: Colors.white,
                                        fontSize: 13,
                                        fontWeight: FontWeight.bold),
                                  ),
                                ],
                              ),

                             Container(
                               padding: EdgeInsets.symmetric(horizontal: 8.0,vertical: 9),
                               width: 2,
                               color: Colors.white,
                             ),

                              Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Row(
                                    children: [
                                      Text("ExpireDate_txt".tr, style: TextStyle(
                                          color: Colors.white,
                                          fontSize: 13,
                                          fontWeight: FontWeight.bold),
                                      ),
                                      sizebox_width_5,
                                      Text(
                                        ":",
                                        style: TextStyle(
                                            color: Colors.white,
                                            fontSize: 13,
                                            fontWeight: FontWeight.bold),
                                      ),
                                      sizebox_width_5,

                                    ],
                                  ),
                                  SizedBox(height: 1,),
                                  Text(listdata['expire_date'].toString(),
                                    textAlign: TextAlign.center,
                                    style: TextStyle(
                                        color: Colors.white,
                                        fontSize: 13,
                                        fontWeight: FontWeight.bold),
                                  ),
                                ],
                              ),

                            ],
                          ),
                        ),

                      ],
                    ),
                  );
                }),
          );
        }
      ),
    );
  }
}
