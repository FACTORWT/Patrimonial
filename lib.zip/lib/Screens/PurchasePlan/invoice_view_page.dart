import 'dart:developer';
import 'dart:io';
import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:flutter_pdfview/flutter_pdfview.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';
import 'package:urwealthpal/Constant/Api.dart';
import 'package:urwealthpal/Constant/colors.dart';
import 'package:urwealthpal/Screens/PurchasePlan/purchasecontroller.dart';

class InvoiceViewPage extends StatefulWidget {
  var id;
   InvoiceViewPage({this.id});

  @override
  State<InvoiceViewPage> createState() => _InvoiceViewPageState();
}

class _InvoiceViewPageState extends State<InvoiceViewPage> {

  PurchaseController _purchaseController = Get.put(PurchaseController());

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    _purchaseController.invoice_list(Get_Invoice_url+widget.id.toString());
  }



  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        elevation: 0,
        titleSpacing: 0,
        backgroundColor: ContainerColor,
        title: Text("InvoiceView_txt".tr),
        actions: [
          IconButton(
            icon: Icon(Icons.download),
            onPressed: () {
              download(Dio(), _purchaseController.invoicedata[0]['url'],  fileName);
            },
          ),
        ],
      ),

      body: GetBuilder<PurchaseController>(builder: (purchaseController) {
        if (purchaseController.PurchaseplanLoading.value) {
          return Center(child: Container(
              alignment: Alignment.center,
              // height: size.height*0.80,
              child: CircularProgressIndicator()));
        } else
          return  purchaseController.PurchaseplanHistoryData.length==0?Center(child: Text("DataFound".tr)):
          PDFView(
            filePath: purchaseController.remotePDFpath,
            enableSwipe: true,
            fitEachPage: true,
            swipeHorizontal: false,
            autoSpacing: false,
            pageFling: true,
            pageSnap: true,
            defaultPage: purchaseController.currentPage,
            fitPolicy: FitPolicy.BOTH,

            preventLinkNavigation:
            false, // if set to true the link is handled in flutter
            onRender: (_pages) {
              setState(() {
                purchaseController.pages = _pages!;
                purchaseController.isReady = true;
              });
            },
            onError: (error) {
              setState(() {
                purchaseController
                    .errorMessage =
                    error.toString();
              });
              print("Check pdf path>> " +
                  error.toString());
            },
            onPageError: (page, error) {
              setState(() {
                purchaseController
                    .errorMessage =
                '$page: ${error.toString()}';
              });
              print(
                  'Check >> Error PDF > $page: ${error.toString()}');
            },
            onViewCreated: (PDFViewController
            pdfViewController) {
              purchaseController
                  .controllerpdfview
                  .complete(
                  pdfViewController);
            },
            onLinkHandler: (String? uri) {
              print('goto uri: $uri');
            },
            onPageChanged:
                (int? page, int? total) {
              print(
                  'page change: $page/$total');
              setState(() {
                purchaseController
                    .currentPage = page!;
              });
            },
          );
        }
      ),
    );
  }


  var fileName = '/storage/emulated/0/Download/Patrimonial/payslip.pdf' ;

  Future<bool> download(Dio dio, String url, String savePath) async {
    bool returntype = false;
    Directory? tempDir =await Directory('/storage/emulated/0/Download/Patrimonial');
    savePath ="/${savePath}";
    log("Check download");
    try {
      await dio.download(url, '${savePath}',

          onReceiveProgress: (received, total) async {
            int percentage = ((received / total) * 100).floor();
            var   progress = (percentage ?? 0) / 100;

            log("percentage : $percentage");
            log("percentage progress : $progress");

            if (percentage == 100) {

            }

          }

      );
      log("percentage returntype>> : ${returntype.toString()}");
      Fluttertoast.showToast(msg: savePath.toString(),backgroundColor: Colors.lightGreenAccent,textColor: Colors.black);
      return Future.value(true);

    } catch (e) {
      log("Check download exception >"+e.toString());
      return Future.value(false);
    }
  }


}