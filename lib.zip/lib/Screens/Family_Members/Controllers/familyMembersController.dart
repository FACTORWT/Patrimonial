import 'dart:convert';
import 'dart:developer';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:image_cropper/image_cropper.dart';
import 'package:image_picker/image_picker.dart';
import 'package:urwealthpal/BottomBar/bottombar.dart';
import 'package:urwealthpal/Constant/Api.dart';
import 'package:urwealthpal/Constant/ApiBaseHelper.dart';
import 'package:urwealthpal/Constant/colors.dart';

class GetFamilyMembersController extends GetxController{
  var UpdateFamilyMemberLoading = false.obs;
  var UpdateFamilyMemberData ;
  var image;
  var toggleOn ;
  var getupdatememberedata  ;

  File ?pickfile;
  File ?pickfile1;

  imagenull(){

    pickfile=null;

    userName.clear();
    email.clear();
    mobile.clear();
    country.clear();
    state.clear();
    city.clear();
    pincode.clear();
    address.clear();
    dateInput.clear();
    password.clear();
    confirmPassword.clear();
    relationName.clear();
    SelectedCountryName="Select Country";
    SelectedStateName="Select State";
    SelectedCityName="Select City";
    SelectedCountryId="" ;
    SelectedStateId="" ;
    SelectedCityId ="";

  }

  Future getFromGallery() async {
    XFile? pickedFile = await ImagePicker().pickImage(
        source: ImageSource.gallery,
        maxWidth: 1800,
        maxHeight: 1800,
        imageQuality: 100);
    if (pickedFile != null) {

      CroppedFile? cropFile = await ImageCropper().cropImage(
          sourcePath: pickedFile.path,
          aspectRatioPresets: [
            CropAspectRatioPreset.original,
            CropAspectRatioPreset.ratio3x2,
            CropAspectRatioPreset.ratio4x3,
            CropAspectRatioPreset.ratio5x3,
            CropAspectRatioPreset.ratio5x4,
            CropAspectRatioPreset.ratio7x5,
            CropAspectRatioPreset.ratio16x9,
            CropAspectRatioPreset.square
          ],
          uiSettings: [
            AndroidUiSettings(
              toolbarTitle: 'Crop Image',
              toolbarColor: ContainerColor,
              cropFrameColor: ContainerColor,
              backgroundColor: ContainerColor,
              activeControlsWidgetColor: ContainerColor,
              cropGridColor: ContainerColor,
              toolbarWidgetColor: Colors.white,
              initAspectRatio: CropAspectRatioPreset.original,
              lockAspectRatio: false,
            ),
          ]
      );


      CroppedFile? cropFile1 = await ImageCropper().cropImage(
          sourcePath: pickedFile.path,
          aspectRatioPresets: [
            CropAspectRatioPreset.original,
            CropAspectRatioPreset.ratio3x2,
            CropAspectRatioPreset.ratio4x3,
            CropAspectRatioPreset.ratio5x3,
            CropAspectRatioPreset.ratio5x4,
            CropAspectRatioPreset.ratio7x5,
            CropAspectRatioPreset.ratio16x9,
            CropAspectRatioPreset.square
          ],
          uiSettings: [
            AndroidUiSettings(
              toolbarTitle: 'Crop Image',
              toolbarColor: ContainerColor,
              cropFrameColor: ContainerColor,
              backgroundColor: ContainerColor,
              activeControlsWidgetColor: ContainerColor,
              cropGridColor: ContainerColor,
              toolbarWidgetColor: Colors.white,
              initAspectRatio: CropAspectRatioPreset.original,
              lockAspectRatio: false,
            ),
          ]
      );


      pickfile = File(cropFile!.path);
      pickfile1 = File(cropFile1!.path);
      update();
      refresh();
      print("pick file form gellary" + pickfile.toString());
      print("pick file form gellary" + pickfile1.toString());
    }
  }

  TextEditingController userName = TextEditingController();
  TextEditingController relationName = TextEditingController();
  TextEditingController email = TextEditingController();
  TextEditingController mobile = TextEditingController();
  TextEditingController country = TextEditingController();
  TextEditingController state = TextEditingController();
  TextEditingController city = TextEditingController();
  TextEditingController pincode = TextEditingController();
  TextEditingController address = TextEditingController();
  TextEditingController dateInput = TextEditingController();
  TextEditingController password = TextEditingController();
  TextEditingController confirmPassword = TextEditingController();
  bool passToogle = true;
  bool passToogles = true;

  var SelectedCountryName,
      SelectedCountryId,
      SelectedStateName,
      SelectedStateId,
      SelectedCityName,
      SelectedCityId;
  var GetFamilyMembersLoading = false.obs;
  var GetmemberdetailLoading = false.obs;
  List GetFamilyMembersData=[];

 var MemberStatus ;
 var MemberStatusName ;

  var DeleteFamilyMemberLoading = false.obs;
  var DeleteFamilyMemberData ;

  var AddFamilyMemberLoading = false.obs;
  var AddFamilyMemberData ;

  GetFamilyMembersAPICalling(url) async {
    GetFamilyMembersLoading.value =true;

    print("GetFamilyMembersUrl : " + url.toString());
    var response = await ApiBaseHelper().getAPICall(Uri.parse(url), true);
    var responsedata = jsonDecode(response.body);
    print("GetFamilyMembers responsedata : " + responsedata.toString());
    if(response.statusCode==200){
      GetFamilyMembersData.clear();
      GetFamilyMembersData.addAll(responsedata['data']) ;
      GetFamilyMembersLoading.value =false;
      update();
    }else{
      GetFamilyMembersData =[];
      GetFamilyMembersLoading.value =false;
      update();
    }
  }

  GetFamilyMemberDetailAPICalling(url) async {
    GetmemberdetailLoading.value =true;

    print("GetFamilyMembersUrl : " + url.toString());
    var response = await ApiBaseHelper().getAPICall(Uri.parse(url), true);
    var responsedata = jsonDecode(response.body);
    print("GetFamilyMembers responsedata : " + responsedata.toString());
    if(response.statusCode==200){
      getupdatememberedata = responsedata['data'].toString();
      userName.text= responsedata['data'][0]['name'].toString();
      relationName.text= responsedata['data'][0]['relation'].toString();
      email.text= responsedata['data'][0]['email'].toString();
      mobile.text= responsedata['data'][0]['mobile'].toString();
      country.text= responsedata['data'][0]['country'].toString();
      state.text= responsedata['data'][0]['state'].toString();
      city.text= responsedata['data'][0]['city'].toString();
      MemberStatus= responsedata['data'][0]['status'].toString();
      MemberStatusName= responsedata['data'][0]['status_name'].toString();
      dateInput.text= responsedata['data'][0]['dob'].toString();

      SelectedCountryName = responsedata['data'][0]['country']== null? null:
      responsedata['data'][0]['country'].toString();

      SelectedCountryId=responsedata['data'][0]['country_id']== null?null:
      responsedata['data'][0]['country_id'].toString();

      SelectedStateName= responsedata['data'][0]['state']== null?null:
      responsedata['data'][0]['state'].toString();

      SelectedStateId= responsedata['data'][0]['state_id']== null?null:
      responsedata['data'][0]['state_id'].toString();

      SelectedCityName= responsedata['data'][0]['city']== null?null:
      responsedata['data'][0]['city'].toString();

      SelectedCityId= responsedata['data'][0]['city_id']== null?null:
      responsedata['data'][0]['city_id'].toString();

      pincode.text= responsedata['data'][0]['pincode'].toString();
      address.text= responsedata['data'][0]['address'].toString();
      image = responsedata['data'][0]['image'].toString();
      print("profile responsecvxhnd : " + image.toString());
      update();
      GetmemberdetailLoading.value =false;
      update();
    }else{
      getupdatememberedata =[];
      GetmemberdetailLoading.value =false;
      update();
    }
  }

  UpdateFamilyMemberApiCalling(url, parameter) async {
    UpdateFamilyMemberLoading.value =true;
    print("UpdateFamilyMember---->>>>>" + url.toString());
    var response = await ApiBaseHelper().multipartAPIForProfile(Uri.parse(url),
        parameter,pickfile==null?[]: [MultipartBody2('image',File(pickfile!.path))] ,true);
    var responsedata = jsonDecode(response.body);
    print("UpdateFamilyMember responsedata : " + responsedata.toString());
    if(response.statusCode==200){
      UpdateFamilyMemberData = responsedata['data'];
      UpdateFamilyMemberLoading.value =false;
      Map<String, String> queryParams = {
        que_search :"".toString(),
      };
      String queryString = Uri(queryParameters: queryParams).query;
      var Family_Members_url = Get_Family_Members_url + '?' + queryString;
      GetFamilyMembersAPICalling(Family_Members_url);
      pickfile=null;
      // Get.back();
      Get.offAll(bottombar(bottom: 3,));
      toastMsg(responsedata['message'], true);
      update();
    }
    else if(response.statusCode==403){
      log("check : "+responsedata.toString());
      if(responsedata['error'] != null){
        responsedata['error'].forEach((k,v){
          log("Key :$k");
          log("Value :${v.join(" ")}");
          toastMsg("${v.join(" ")}", false);
        });
        UpdateFamilyMemberData.value = false;
        update();
      }
    }
    else
      UpdateFamilyMemberData =[];
    UpdateFamilyMemberLoading.value =false;
    Get.offAll(bottombar(bottom: 3,));
    update();
  }

  AddFamilyMemberApiCalling(url, parameter,) async {
    AddFamilyMemberLoading.value =true;
    print("AddFamilyMember " + url.toString());
    var response = await ApiBaseHelper().multipartAPIForProfile(Uri.parse(url),
        parameter, pickfile1==null? []: [MultipartBody2('image',File(pickfile1!.path))] ,true);
    var responsedata = jsonDecode(response.body);
    print("AddFamilyMember responsedata : " + responsedata.toString());
    if(response.statusCode==200){
      pickfile1=null;
      userName.clear();
      email.clear();
      mobile.clear();
      country.clear();
      state.clear();
      city.clear();
      pincode.clear();
      address.clear();
      dateInput.clear();
      password.clear();
      confirmPassword.clear();
      relationName.clear();
      SelectedCountryName="Select Country";
      SelectedStateName="Select State";
      SelectedCityName="Select City";
      AddFamilyMemberData = responsedata['data'];
      AddFamilyMemberLoading.value =false;
      update();
      Map<String, String> queryParams = {
        que_search :"".toString(),
      };
      String queryString = Uri(queryParameters: queryParams).query;
      var Family_Members_url = Get_Family_Members_url + '?' + queryString;
      GetFamilyMembersAPICalling(Family_Members_url);
      // Get.back();
      Get.back(result: "success");
      toastMsg(responsedata['message'], true);
      update();
    }
    else if(response.statusCode==403){
    log("check : "+responsedata.toString());
      if(responsedata['error'] != null){
        responsedata['error'].forEach((k,v){
          log("Key :$k");
          log("Value :${v.join(" ")}");
          toastMsg("${v.join(" ")}", false);
        });
        AddFamilyMemberLoading.value = false;
        update();
      }
    }
  else{
      AddFamilyMemberData =[];
      AddFamilyMemberLoading.value =false;
      Get.back();
      Get.back(result: "failed");
      update();
    }
  }

  DeleteFamilyMemberApiCalling(url, parameter) async {
    DeleteFamilyMemberLoading.value =true;
    print("DeleteFamilyMember " + url.toString());
    var response = await ApiBaseHelper().postAPICall(Uri.parse(url), parameter, true);
    var responsedata = jsonDecode(response.body);
    print("DeleteFamilyMember responsedata : " + responsedata.toString());
    if(response.statusCode==200){
      DeleteFamilyMemberData = responsedata['data'];
      Map<String, String> queryParams = {
        que_search :"",
      };
      String queryString = Uri(queryParameters: queryParams).query;
      var Family_Members_url = Get_Family_Members_url + '?' + queryString;
      GetFamilyMembersAPICalling(Family_Members_url);
      DeleteFamilyMemberLoading.value =false;
      update();
    } else
      DeleteFamilyMemberData =[];
      DeleteFamilyMemberLoading.value =false;
    update();
  }

  var ResetFamilyMembersLoading = false.obs;
  var ResetFamilyMemberData ;

  ResetFamilyMembersAPICalling(url) async {
    ResetFamilyMembersLoading.value =true;
    print("ResetFamilyMembersUrl : " + url.toString());
    var response = await ApiBaseHelper().getAPICall(Uri.parse(url), true);
    var responsedata = jsonDecode(response.body);
    print("ResetFamilyMembers responsedata : " + responsedata.toString());
    if(response.statusCode==200){
      ResetFamilyMemberData = responsedata['data'];
      Get.defaultDialog(
          title: 'reset_title_txt'.tr,
          content: Column(
            children: [
              Image.asset("assets/images/yes.gif",height: 100,width: 100,),
              Text( responsedata['message'].toString(),
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: textColor
                ),)
            ],
          ),
          actions: [
          GestureDetector(
            onTap: (){
              Get.back();
            },
            child: Center(
              child: Container(
                            height: 30,
                            width: 50,
                            decoration: BoxDecoration(
                              color: ContainerColor,
                                borderRadius: BorderRadius.circular(5),
                            ),
                            child: Center(
                              child: Text("ok".tr,
                                // textAlign: TextAlign.center,
                                style: TextStyle(
                                  color: whiteColor
                                ),),
                            ),
              ),
            ),
          )
    ]);
      log("data----->>>>"+ResetFamilyMemberData.toString());

      ResetFamilyMembersLoading.value =false;
      update();
    }else{
      ResetFamilyMemberData =[];
      ResetFamilyMembersLoading.value =false;
      update();
    }
  }

}