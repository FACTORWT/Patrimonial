import 'dart:convert';
import 'dart:developer';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:urwealthpal/Constant/Api.dart';
import 'package:urwealthpal/Constant/ApiBaseHelper.dart';
import 'package:urwealthpal/Constant/colors.dart';
import 'package:urwealthpal/Screens/Family_Members/Controllers/familyMembersController.dart';


class UpdateFamilyMember extends StatefulWidget {
  var id;
  UpdateFamilyMember({this.id});

  @override
  State<UpdateFamilyMember> createState() => _UpdateFamilyMemberState();
}

class _UpdateFamilyMemberState extends State<UpdateFamilyMember> {
  var _formKey = GlobalKey<FormState>();

  List country_list = [];
  List state_list = [];
  List city_list = [];
  late String formattedDate;
  GetFamilyMembersController getFamilyMembersController =
  Get.put(GetFamilyMembersController());

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    print("id---${widget.id.toString()}");
    getfamilyMemberDetail();
    // getFamilyMembersController.dateInput.text = getFamilyMembersController.dateInput.toString();

    // =getFamilyMembersController.SelectedCountryName;
  }
  getfamilyMemberDetail() async {
    var Member_detail_url = Get_Family_Member_url + widget.id;
    getFamilyMembersController.GetFamilyMemberDetailAPICalling(Member_detail_url);
    await fetchCountry();

  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("update_member_title".tr),
        titleSpacing: 0,
        elevation: 0,
        backgroundColor: ContainerColor,
      ),
      body: (SingleChildScrollView(
        physics: AlwaysScrollableScrollPhysics(),
        child: Form(
          key: _formKey,
          child: GetBuilder<GetFamilyMembersController>(
              builder: (getFamilyMembersController) {
                if(getFamilyMembersController.GetmemberdetailLoading.value){
                  return Center(child: Container(
                      alignment: Alignment.center,
                      height: 600,
                      child: CircularProgressIndicator()),);
                }
                else
                  return Column(children: [
                    Stack(
                      children: [
                        Container(
                          margin: EdgeInsets.symmetric(vertical: 10,),
                          height: 100,
                          width: 100,
                          decoration: BoxDecoration(
                            color: ContainerColor,
                            image: DecorationImage(
                              image:  getFamilyMembersController.pickfile!=null?
                              Image.file(
                                File( getFamilyMembersController.pickfile!.path.toString()),
                                fit: BoxFit.contain,
                              ).image
                                  :NetworkImage(getFamilyMembersController.image.toString()),
                            ),
                            border: Border.all(width: 5,
                              color: buttonColor,
                            ),
                            borderRadius: BorderRadius.all(Radius.circular(90)),
                          ),
                          // child: profilePageImage,
                        ),
                        Positioned(
                          bottom: 5,
                          right: 2,
                          child: InkWell(
                            onTap: (){
                              getFamilyMembersController.getFromGallery();
                            },
                            child: Container(
                              height: 30,
                              width: 30,
                              decoration: BoxDecoration(
                                  color: whiteColor,
                                  border: Border.all(
                                    color: whiteColor,
                                  ),
                                  borderRadius: BorderRadius.all(Radius.circular(20))
                              ),
                              child: Icon(Icons.edit,color: Color(0xFF939292),size: 18,
                              ),
                            ),
                          ),
                        ),
                      ],
                    ),

                    Padding(
                      padding: EdgeInsets.fromLTRB(10, 20, 10, 0),
                      child: TextFormField(
                        controller: getFamilyMembersController.userName,
                        autovalidateMode: AutovalidateMode.onUserInteraction,
                        validator: (value) {
                          if (value == null) {
                            return "validUserName_txt".tr;
                          }
                          if (value.length < 3) {
                            return "validLength_UserName_txt".tr;
                          }
                          return null;
                        },
                        keyboardType: TextInputType.name,
                        textInputAction: TextInputAction.next,
                        decoration: InputDecoration(
                          filled: true,
                          fillColor: whiteColor,
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(10),
                          ),
                          enabledBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(10),
                              borderSide:
                              BorderSide(width: 1, color: appPrimaryColor)),
                          focusedBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(10),
                              borderSide:
                              BorderSide(width: 1, color: appPrimaryColor)),
                          // labelText: 'Your Name',
                          prefixIcon: Container(
                            // color: Colors.redAccent,
                            child: Image.asset(
                              "assets/images/user.png",
                              scale: 3,
                              width: 15,
                            ),
                          ),
                          hintText: "userName_txt".tr,
                        ),
                      ),
                    ), //name

                    Padding(
                      padding: EdgeInsets.fromLTRB(10, 10, 10, 0),
                      child: TextFormField(
                        controller: getFamilyMembersController.email,
                        autovalidateMode: AutovalidateMode.onUserInteraction,
                        validator: (value) {
                          if (value == null) {
                            return "valid_Email_txt".tr;
                          }
                          if (value == null ||
                              value.isEmpty ||
                              !value.contains('@') ||
                              !value.contains('.')) {
                            return "validLength_Email_txt".tr;
                          }
                          return null;
                        },
                        keyboardType: TextInputType.emailAddress,
                        textInputAction: TextInputAction.next,
                        decoration: InputDecoration(
                          filled: true,
                          fillColor: whiteColor,
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(10),
                          ),
                          enabledBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(10),
                              borderSide:
                              BorderSide(width: 1, color: appPrimaryColor)),
                          focusedBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(10),
                              borderSide:
                              BorderSide(width: 1, color: appPrimaryColor)),
                          // labelText: 'Your Name',
                          prefixIcon: Container(
                            // color: Colors.redAccent,
                              child: Image.asset(
                                "assets/images/email (1).png",
                                scale: 3,
                                width: 15,
                              )),
                          hintText: "emailId_txt".tr,
                        ),
                      ),
                    ), //email

                    Padding(
                      padding: EdgeInsets.fromLTRB(10, 10, 10, 0),
                      child: TextFormField(
                        controller: getFamilyMembersController.mobile,
                        inputFormatters: [
                          FilteringTextInputFormatter.allow(RegExp('[0-9]'))
                        ],
                        keyboardType: TextInputType.numberWithOptions(decimal: true),
                        autovalidateMode: AutovalidateMode.onUserInteraction,
                        validator: (value) {
                          if (value == null) {
                            return "valid_Mobile_No_txt".tr;
                          }
                          if (value.length == 0) {
                            return "valid_Mobile_No_txt".tr;
                          }
                          return null;
                        },
                        textInputAction: TextInputAction.next,
                        decoration: InputDecoration(
                          filled: true,
                          fillColor: whiteColor,
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(10),
                          ),
                          enabledBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(10),
                              borderSide:
                              BorderSide(width: 1, color: appPrimaryColor)),
                          focusedBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(10),
                              borderSide:
                              BorderSide(width: 1, color: appPrimaryColor)),
                          prefixIcon: Container(
                            // color: Colors.redAccent,
                            child: Image.asset(
                              "assets/images/phoneIcon.png",
                              scale: 3.5,
                              width: 15,
                            ),
                          ),
                          hintText: "mobileNo_txt".tr,
                        ),
                      ),
                    ),
                    //mobileNo.

                    // Padding(
                    //   padding: EdgeInsets.fromLTRB(10, 10, 10, 0),
                    //   child: DropdownButtonFormField(
                    //     isExpanded: true,
                    //     validator: ((val) {
                    //       if (val == null) {
                    //         return "SelectCountry".tr;
                    //       }
                    //     }),
                    //     decoration: InputDecoration(
                    //       border: OutlineInputBorder(
                    //         borderRadius: BorderRadius.circular(10),
                    //       ),
                    //       enabledBorder: OutlineInputBorder(
                    //           borderRadius: BorderRadius.circular(10),
                    //           borderSide:
                    //           BorderSide(width: 1, color: appPrimaryColor)),
                    //       focusedBorder: OutlineInputBorder(
                    //           borderRadius: BorderRadius.circular(10),
                    //           borderSide:
                    //           BorderSide(width: 1, color: appPrimaryColor)),
                    //       labelStyle: TextStyle(color: Colors.grey, fontSize: 16),
                    //       filled: true,
                    //       prefixIcon: Container(
                    //         // color: Colors.redAccent,
                    //         child:
                    //         Image.asset("assets/images/cityIcon.png",
                    //           color: Color(0xFF37BCF9),
                    //           scale: 2.6,width: 15,),
                    //       ),
                    //       hintStyle: TextStyle(color: Colors.black),
                    //       hintText:  getFamilyMembersController.SelectedCountryName
                    //           .toString(),
                    //       fillColor: Colors.transparent,
                    //     ),
                    //     value: getFamilyMembersController.SelectedCountryName == "null"
                    //         ?"Select Country":getFamilyMembersController.SelectedCountryName,
                    //     items: country_list.map((explist) {
                    //       print("array " + explist.toString());
                    //       return DropdownMenuItem(
                    //         value: explist['name'],
                    //         child: Text(explist['name']),
                    //         onTap: () {
                    //           setState(() {
                    //             getFamilyMembersController.SelectedCountryId = explist['id'];
                    //           });
                    //         },
                    //       );
                    //     }).toList(),
                    //     onChanged: (value) {
                    //       setState(() {
                    //         // SelectedStateNAme = value;
                    //         getFamilyMembersController.SelectedCountryName = value;
                    //         // profileController.SelectedCountryName = value;
                    //         print("countryId...." +
                    //             getFamilyMembersController.SelectedCountryId
                    //                 .toString());
                    //
                    //         if (getFamilyMembersController.SelectedCountryId == 0) {
                    //           getFamilyMembersController.SelectedCountryId = null;
                    //         }
                    //       });
                    //       getFamilyMembersController.SelectedStateId = null;
                    //       getFamilyMembersController.SelectedStateName = null;
                    //       fetchState(getFamilyMembersController.SelectedCountryId
                    //           .toString());
                    //     },
                    //   ),
                    // ), //country
                    Padding(
                      padding:  EdgeInsets.fromLTRB(10, 10, 10, 0),
                      child: DropdownButtonFormField(
                        isExpanded: true,
                        validator: ((val) {
                          if (val == null) {
                            return "SelectCountry".tr;
                          }
                        }),
                        decoration: InputDecoration(
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(10),
                          ),
                          enabledBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(10),
                              borderSide: BorderSide( width: 1, color: appPrimaryColor)
                          ),
                          focusedBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(10),
                              borderSide: BorderSide( width: 1, color: appPrimaryColor)
                          ),
                          labelStyle: TextStyle(color: Colors.grey,fontSize: 16),
                          filled: true,
                          prefixIcon: Container(
                            // color: Colors.redAccent,
                            child:
                            Image.asset("assets/images/cityIcon.png",
                              color: Color(0xFF37BCF9),
                              scale: 2.6,width: 15,),
                          ),
                          hintStyle: TextStyle(color: Colors.black),
                          hintText:
                          "hintCountry_txt".tr,
                          fillColor: Colors.transparent,
                        ),
                        value: getFamilyMembersController.SelectedCountryName,
                        items: country_list.map((explist) {

                          return DropdownMenuItem(
                            value: explist['name'],
                            child: Text(explist['name']),
                            onTap: () {
                              setState(() {
                                getFamilyMembersController.SelectedCountryId = explist['id'];
                                getFamilyMembersController.SelectedCountryName = explist['name'];
                              });
                            },
                          );
                        }).toList(),
                        onChanged: (value) async {
                          setState(() {
                            getFamilyMembersController.SelectedCountryName = value;
                            log("OnSelect> SelectedCountryName...."+getFamilyMembersController.SelectedCountryName.toString() );
                            log("OnSelect> SelectedCountryId...."+getFamilyMembersController.SelectedCountryId.toString() );

                            if (getFamilyMembersController.SelectedCountryId == 0) {
                              getFamilyMembersController.SelectedCountryName = null;
                              getFamilyMembersController.SelectedCountryId = null;
                            }
                          });
                          getFamilyMembersController.SelectedStateId = null;
                          getFamilyMembersController.SelectedStateName = null;
                          getFamilyMembersController.SelectedCityId = null;
                          getFamilyMembersController.SelectedCityName = null;
                          await fetchState(getFamilyMembersController.SelectedCountryId.toString());
                          await fetchCity(getFamilyMembersController.SelectedStateId.toString());
                        },
                      ),
                    ),
                    Padding(
                      padding:  EdgeInsets.fromLTRB(10, 10, 10, 0),
                      child: DropdownButtonFormField(
                        isExpanded: true,
                        validator: ((val) {
                          if (val == null) {
                            return "SelectState".tr;
                          }
                        }),
                        decoration: InputDecoration(
                          //  labelText: "Select State",
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(10),
                          ),
                          enabledBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(10),
                              borderSide: BorderSide( width: 1, color: appPrimaryColor)
                          ),
                          focusedBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(10),
                              borderSide: BorderSide( width: 1, color: appPrimaryColor)
                          ),
                          labelStyle: TextStyle(color: Colors.grey,fontSize: 16),
                          filled: true,
                          prefixIcon: Container(
                            // color: Colors.redAccent,
                            child:
                            Image.asset("assets/images/cityIcon.png",
                              color: Color(0xFF37BCF9),
                              scale: 2.6,width: 15,),
                          ),
                          hintStyle:
                          TextStyle(color: Colors.black),
                          hintText: "hintState_txt".tr,
                          fillColor: Colors.transparent,
                        ),
                        value: getFamilyMembersController.SelectedStateName ,
                        items: state_list.map((explist) {
                          return DropdownMenuItem(
                            value: explist['name'],
                            child: Text(explist['name']),
                            onTap: () {
                              setState(() {
                                getFamilyMembersController.SelectedStateId = explist['id'];
                              });
                            },
                          );
                        }).toList(),
                        onChanged: (value) async {
                          setState(() {
                            // SelectedStateNAme = value;
                            getFamilyMembersController.SelectedStateName = value;
                            if (getFamilyMembersController.SelectedStateId == 0) {
                              getFamilyMembersController.SelectedStateId = null;
                              getFamilyMembersController.SelectedStateName = null;
                            }
                          });
                          getFamilyMembersController.SelectedCityId = null;
                          getFamilyMembersController.SelectedCityName = null;
                          await fetchCity(getFamilyMembersController.SelectedStateId.toString());
                        },
                      ),
                    ),
                    Padding(
                      padding:  EdgeInsets.fromLTRB(10, 10, 10, 0),
                      child: DropdownButtonFormField(
                        isExpanded: true,
                        validator: ((val) {
                          if (val == null) {
                            return "SelectCity".tr;
                          }
                        }),
                        decoration: InputDecoration(
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(10),
                          ),
                          enabledBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(10),
                              borderSide: BorderSide( width: 1, color: appPrimaryColor)
                          ),
                          focusedBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(10),
                              borderSide: BorderSide(width: 1, color: appPrimaryColor)
                          ),
                          labelStyle: TextStyle(color: Colors.grey,fontSize: 16),
                          filled: true,
                          prefixIcon: Container(
                            // color: Colors.redAccent,
                            child:
                            Image.asset("assets/images/cityIcon.png",
                              color: Color(0xFF37BCF9),
                              scale: 2.6,width: 15,),
                          ),
                          hintStyle:
                          TextStyle(color: Colors.black),
                          hintText:  "hintCity_txt".tr,
                          fillColor: Colors.transparent,
                        ),
                        value: getFamilyMembersController.SelectedCityName ,
                        items: city_list.map((explist) {

                          return DropdownMenuItem(
                            value: explist['name'],
                            child: Text(explist['name']),
                            onTap: () {
                              setState(() {
                                getFamilyMembersController.SelectedCityId = explist['id'];
                              });
                            },
                          );
                        }).toList(),
                        onChanged: (value) {
                          setState(() {
                            getFamilyMembersController.SelectedCityName = value;
                            if (getFamilyMembersController.SelectedCityId == 0) {
                              getFamilyMembersController.SelectedCityId = null;
                            }
                          });
                        },
                      ),
                    ),
                    // Padding(
                    //   padding: EdgeInsets.fromLTRB(10, 10, 10, 0),
                    //   child: DropdownButtonFormField(
                    //     isExpanded: true,
                    //     validator: ((val) {
                    //       if (val == null) {
                    //         return "SelectState".tr;
                    //       }
                    //     }),
                    //     decoration: InputDecoration(
                    //       //  labelText: "Select State",
                    //       border: OutlineInputBorder(
                    //         borderRadius: BorderRadius.circular(10),
                    //       ),
                    //       enabledBorder: OutlineInputBorder(
                    //           borderRadius: BorderRadius.circular(10),
                    //           borderSide:
                    //           BorderSide(width: 1, color: appPrimaryColor)),
                    //       focusedBorder: OutlineInputBorder(
                    //           borderRadius: BorderRadius.circular(10),
                    //           borderSide:
                    //           BorderSide(width: 1, color: appPrimaryColor)),
                    //       labelStyle: TextStyle(color: Colors.grey, fontSize: 16),
                    //       filled: true,
                    //       prefixIcon: Container(
                    //         // color: Colors.redAccent,
                    //         child:
                    //         Image.asset("assets/images/cityIcon.png",
                    //           color: Color(0xFF37BCF9),
                    //           scale: 2.6,width: 15,),
                    //       ),
                    //       hintStyle: TextStyle(color: Colors.black),
                    //       hintText: getFamilyMembersController.SelectedStateName.toString(),
                    //       fillColor: Colors.transparent,
                    //     ),
                    //     value:  getFamilyMembersController.SelectedStateName=="null"?"Selected State":getFamilyMembersController.SelectedStateName,
                    //     items: state_list.map((explist) {
                    //       print("array " + explist.toString());
                    //       return DropdownMenuItem(
                    //         value: explist['name'],
                    //         child: Text(explist['name']),
                    //         onTap: () {
                    //           setState(() {
                    //             getFamilyMembersController.SelectedStateId =
                    //             explist['id'];
                    //           });
                    //         },
                    //       );
                    //     }).toList(),
                    //     onChanged: (value) {
                    //       setState(() {
                    //         // SelectedStateNAme = value;
                    //         getFamilyMembersController.SelectedStateName = value;
                    //
                    //         if (getFamilyMembersController.SelectedStateId == 0) {
                    //           getFamilyMembersController.SelectedStateId = null;
                    //         }
                    //       });
                    //       getFamilyMembersController.SelectedCityId = null;
                    //       getFamilyMembersController.SelectedCityName = null;
                    //       fetchCity(
                    //           getFamilyMembersController.SelectedCityId.toString());
                    //     },
                    //   ),
                    // ),
                    //state

                    // Padding(
                    //   padding: EdgeInsets.fromLTRB(10, 10, 10, 0),
                    //   child: DropdownButtonFormField(
                    //     isExpanded: true,
                    //     validator: ((val) {
                    //       if (val == null) {
                    //         return "SelectCity".tr;
                    //       }
                    //     }),
                    //     decoration: InputDecoration(
                    //       border: OutlineInputBorder(
                    //         borderRadius: BorderRadius.circular(10),
                    //       ),
                    //       enabledBorder: OutlineInputBorder(
                    //           borderRadius: BorderRadius.circular(10),
                    //           borderSide:
                    //           BorderSide(width: 1, color: appPrimaryColor)),
                    //       focusedBorder: OutlineInputBorder(
                    //           borderRadius: BorderRadius.circular(10),
                    //           borderSide:
                    //           BorderSide(width: 1, color: appPrimaryColor)),
                    //       labelStyle: TextStyle(color: Colors.black, fontSize: 16),
                    //       filled: true,
                    //       prefixIcon: Container(
                    //         // color: Colors.redAccent,
                    //         child:
                    //         Image.asset("assets/images/cityIcon.png",
                    //           color: Color(0xFF37BCF9),
                    //           scale: 2.6,width: 15,),
                    //       ),
                    //       hintStyle: TextStyle(color: Colors.black),
                    //       hintText: getFamilyMembersController.SelectedCityName.toString(),
                    //       fillColor: Colors.transparent,
                    //     ),
                    //     value: getFamilyMembersController.SelectedCityName=="null"?"Selected City":getFamilyMembersController.SelectedCityName.toString(),
                    //     items: city_list.map((explist) {
                    //       print("array " + explist.toString());
                    //       return DropdownMenuItem(
                    //         value: explist['name'],
                    //         child: Text(explist['name']),
                    //         onTap: () {
                    //           setState(() {
                    //             getFamilyMembersController.SelectedCityId =
                    //             explist['id'];
                    //           });
                    //         },
                    //       );
                    //     }).toList(),
                    //     onChanged: (value) {
                    //       setState(() {
                    //         getFamilyMembersController.SelectedCityName = value;
                    //         if (getFamilyMembersController.SelectedCityId == 0) {
                    //           getFamilyMembersController.SelectedCityId = null;
                    //         }
                    //       });
                    //     },
                    //   ),
                    // ), //city

                    Padding(
                      padding: EdgeInsets.fromLTRB(10, 10, 10, 0),
                      child: TextFormField(
                        controller: getFamilyMembersController.pincode,
                        autovalidateMode: AutovalidateMode.onUserInteraction,
                        validator: (value) {
                          if (value == null) {
                            return "pinCode_txt".tr;
                          }
                          if (value.length != 6) {
                            return "vaidPinCode".tr;
                          }
                          return null;
                        },
                        keyboardType: TextInputType.name,
                        textInputAction: TextInputAction.next,
                        decoration: InputDecoration(
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(10),
                            ),
                            enabledBorder: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(10),
                                borderSide:
                                BorderSide(width: 1, color: appPrimaryColor)),
                            focusedBorder: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(10),
                                borderSide:
                                BorderSide(width: 1, color: appPrimaryColor)),
                            hintText: "hintpin_txt".tr,
                            prefixIcon: Container(
                              // color: Colors.redAccent,
                              child: Image.asset(
                                "assets/images/passIcon.png",
                                scale: 3.5,
                                width: 15,
                              ),
                            )),
                      ),
                    ), //pincode

                    Padding(
                      padding: EdgeInsets.fromLTRB(10, 10, 10, 0),
                      child: TextFormField(
                        scrollPadding: EdgeInsets.only(
                            bottom: MediaQuery.of(context).viewInsets.bottom + 25*4),
                        controller: getFamilyMembersController.dateInput,
                        validator: (value) {
                          if (value!.isEmpty) {
                            return "dob_txt".tr;
                          } else
                            return null;
                        },
                        decoration: InputDecoration(
                          hintText: "hint_dob_txt".tr,
                          filled: true,
                          prefixIcon: Container(
                              child:
                              Icon(Icons.calendar_month_outlined,
                                color: Color(0xFF37BCF9),)
                          ),
                          fillColor: Colors.white,
                          // contentPadding: EdgeInsets.only(top: 5,left: 10),
                          // constraints: BoxConstraints(
                          //     minWidth: 30, maxHeight: 70),
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(10),
                          ),
                          enabledBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(10),
                              borderSide:
                              BorderSide(width: 1, color: appPrimaryColor)),
                          focusedBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(10),
                              borderSide:
                              BorderSide(width: 1, color: appPrimaryColor)),
                        ),
                        onTap: () async {
                          DateTime? pickedDate = await showDatePicker(
                              context: context,
                              initialDate: DateTime.now(),
                              firstDate: DateTime(1950),
                              lastDate: DateTime(2100));
                          if (pickedDate != null) {
                            print(pickedDate);
                            formattedDate =
                                DateFormat('yyyy-MM-dd').format(pickedDate);
                            print(formattedDate);
                            setState(() {
                              getFamilyMembersController.dateInput.text = formattedDate;
                            });
                          } else {
                            print('print_dob'.tr);
                          }
                        },
                      ),
                    ), //dob

                    Padding(
                      padding: EdgeInsets.fromLTRB(10, 10, 10, 0),
                      child: TextFormField(
                        controller: getFamilyMembersController.address,
                        autovalidateMode: AutovalidateMode.onUserInteraction,
                        validator: (value) {
                          if (value == null) {
                            return "address_txt".tr;
                          }
                          if (value.length < 6) {
                            return "valid_address_txt".tr;
                          }
                          return null;
                        },
                        keyboardType: TextInputType.streetAddress,

                        maxLines: 1,
                        textInputAction: TextInputAction.next,
                        decoration: InputDecoration(
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(10),
                            ),
                            enabledBorder: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(10),
                                borderSide:
                                BorderSide(width: 1, color: appPrimaryColor)),
                            focusedBorder: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(10),
                                borderSide:
                                BorderSide(width: 1, color: appPrimaryColor)),
                            hintText: "hint_address".tr,
                            prefixIcon: Container(
                              // color: Colors.redAccent,
                              child: Image.asset(
                                "assets/images/cityIcon.png",
                                color: Color(0xFF37BCF9),
                                scale: 2.6,
                                width: 15,
                              ),
                            )),
                      ),
                    ),

                    Padding(
                      padding: EdgeInsets.fromLTRB(10, 10, 10, 0),
                      child: TextFormField(
                        controller: getFamilyMembersController.relationName,
                        autovalidateMode: AutovalidateMode.onUserInteraction,
                        validator: (value) {
                          if (value == null) {
                            return "relation_txt".tr;
                          }
                          if (value.length < 3) {
                            return "validrelation_txt".tr;
                          }
                          return null;
                        },
                        keyboardType: TextInputType.name,
                        textInputAction: TextInputAction.next,
                        decoration: InputDecoration(
                          filled: true,
                          fillColor: whiteColor,
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(10),
                          ),
                          enabledBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(10),
                              borderSide:
                              BorderSide(width: 1, color: appPrimaryColor)),
                          focusedBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(10),
                              borderSide:
                              BorderSide(width: 1, color: appPrimaryColor)),
                          // labelText: 'Your Name',
                          prefixIcon: Container(
                            // color: Colors.redAccent,
                            child: Image.asset(
                              "assets/images/user.png",
                              scale: 3,
                              width: 15,
                            ),
                          ),
                          hintText: "relation_txt".tr,
                        ),
                      ),
                    ),

                    Padding(
                      padding: EdgeInsets.only(left: 10, right: 10, top: 40),
                      child: GestureDetector(
                        onTap: () async {
                          if (_formKey.currentState!.validate()) {
                            var Update_familyMemberUrl = Update_familyMember_url;
                            var body = ({
                              'id' : widget.id.toString(),
                              'name' : getFamilyMembersController.userName.text.toString(),
                              'email' : getFamilyMembersController.email.text.toString(),
                              'mobile' : getFamilyMembersController.mobile.text.toString(),
                              'country_id' : getFamilyMembersController.SelectedCountryId.toString(),
                              'state_id' : getFamilyMembersController.SelectedStateId.toString(),
                              'city_id' : getFamilyMembersController.SelectedCityId.toString(),
                              'pincode' : getFamilyMembersController.pincode.text.toString(),
                              'dob' : getFamilyMembersController.dateInput.text.toString(),
                              'address' : getFamilyMembersController.address.text.toString(),
                              'status' : getFamilyMembersController.MemberStatus.toString(),
                              'relation' : getFamilyMembersController.relationName.text.toString(),
                            });
                            print("body....."+body.toString());
                            getFamilyMembersController.UpdateFamilyMemberApiCalling(
                              Update_familyMemberUrl, body,);

                          }
                        },
                        child: Container(
                          width: 150,
                          height: 40,
                          decoration: BoxDecoration(
                            color: ContainerColor,
                            border: Border.all(color: ContainerColor),
                            borderRadius: BorderRadius.all(Radius.circular(8)),
                          ),
                          child: Center(
                            child: Text(
                              "save_txt".tr,
                              style: TextStyle(color: whiteColor, fontSize: 20),
                            ),
                          ),
                        ),
                      ),
                    ),
                    SizedBox(
                      height: 40,
                    )
                  ]);
              }
          ),
        ),
      )),
    );
  }


  Future<void> fetchCountry() async {
    var countryUrl = Uri.parse(Country_url);
    print("countryUrl--> " + countryUrl.toString());
    var response = await ApiBaseHelper().getAPICall(countryUrl, true);
    var CountryData = jsonDecode(response.body);
    if (response.statusCode == 200) {
      setState(() {
        country_list.clear();
        country_list.addAll(CountryData['data']);
        if(getFamilyMembersController.SelectedCountryId!=null){
          fetchState(getFamilyMembersController.SelectedCountryId);
        }else{

        }
      });
    }
  }

  Future<void> fetchState(countryId) async {
    state_list.clear();
    var stateUrl = Uri.parse(State_url + countryId);
    log("fetchState Url--> " + stateUrl.toString());
    var response = await ApiBaseHelper().getAPICall(stateUrl, true);
    var StateData = jsonDecode(response.body);
    if (response.statusCode == 200) {
      setState(() {
        state_list.addAll(StateData['data']);
        log("SelectedStateId--> " + getFamilyMembersController.SelectedStateId.toString());
        log("state_list--> " + state_list.toString());
        if(getFamilyMembersController.SelectedStateId!=null){
          fetchCity(getFamilyMembersController.SelectedStateId);
        }else{

        }
      });
    }else{
      state_list=[];
      setState(() {
        getFamilyMembersController.SelectedStateId = null;
        getFamilyMembersController.SelectedStateName = null;
      });
    }
  }

  Future<void> fetchCity(state_id) async {
    city_list.clear();
    var cityUrl = Uri.parse(City_url + state_id);

    print("cityurl : " + cityUrl.toString());
    var response = await ApiBaseHelper().getAPICall(cityUrl, true);
    var CityData = jsonDecode(response.body);
    if (response.statusCode == 200) {
      setState(() {

        city_list.addAll(CityData['data']);
        log("getFamilyMembersController--> " + getFamilyMembersController.SelectedCityId.toString());
        log("city_list--> " + city_list.toString());
      });
    }else{
      city_list=[];
      setState(() {
        getFamilyMembersController.SelectedCityId = null;
        getFamilyMembersController.SelectedCityName = null;
      });
    }
  }
}
