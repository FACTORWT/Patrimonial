import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:urwealthpal/Constant/Api.dart';
import 'package:urwealthpal/Constant/Images.dart';
import 'package:urwealthpal/Constant/Spacing.dart';
import 'package:urwealthpal/Constant/colors.dart';
import 'package:urwealthpal/Screens/Family_Members/Controllers/familyMembersController.dart';
import 'package:urwealthpal/Screens/Family_Members/addFamilyMembers.dart';
import 'package:urwealthpal/Screens/Family_Members/updateFamilyMember.dart';
import 'package:urwealthpal/Screens/Manage_Assets/manage_assets.dart';
import 'package:urwealthpal/Screens/PurchasePlan/purchasecontroller.dart';

class Family_Members extends StatefulWidget {


 const  Family_Members({Key? key}) : super(key: key);

  @override
  State<Family_Members> createState() => _Family_MembersState();
}

class _Family_MembersState extends State<Family_Members> {
  PurchaseController _purchaseController = Get.put(PurchaseController());

  TextEditingController _searchController = TextEditingController();

  var getFamilyMembersController =Get.put(GetFamilyMembersController());


  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    _searchController.text;
    getPurchaseHistoryPlanData();
    // if(sp!.getBool("paymentstatus")== false){
    //   Get.offAll(purchase_plan());
    //   sp!.setBool("paymentstatus", false);
    // }
    // else{
    //   sp!.setBool("paymentstatus", true);
    // }

    getfamily(_searchController.text.toString());
    getdata();
  }
  getdata(){
    getFamilyMembersController. userName.clear();
    getFamilyMembersController.email.clear();
    getFamilyMembersController.mobile.clear();
    getFamilyMembersController.country.clear();
    getFamilyMembersController.state.clear();
    getFamilyMembersController.city.clear();
    getFamilyMembersController.pincode.clear();
    getFamilyMembersController.address.clear();
    getFamilyMembersController.dateInput.clear();
    getFamilyMembersController.password.clear();

    getFamilyMembersController.confirmPassword.clear();
    getFamilyMembersController. SelectedCountryName="Select Country";

    getFamilyMembersController.SelectedStateName="Select State";

    getFamilyMembersController.SelectedCityName="Select City";
  }

  getfamily(search)async{
  Map<String, String> queryParams = {
    que_search :search.toString(),
  };
  String queryString = Uri(queryParameters: queryParams).query;
  var Family_Members_url = Get_Family_Members_url + '?' + queryString;
  getFamilyMembersController.GetFamilyMembersAPICalling(Family_Members_url);
}

  List<Map<String, dynamic>> activeItems = [];

  getPurchaseHistoryPlanData() async {
    await _purchaseController.callpurchaseplanHistory_list(Get_MySubscriptionPlan_url);
    print("PurchaseplanHistoryData==>${_purchaseController.PurchaseplanHistoryData}");

    for (var item in _purchaseController.PurchaseplanHistoryData) {
      if (item['is_active'] == 1) {
        activeItems.add(item);
      }
    }
    print("activeItems==>${activeItems}");
  }

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return RefreshIndicator(
      onRefresh: () async {
        _searchController.clear();
        await getfamily("");
        await Future.delayed(Duration(milliseconds: 1500));
      },
      child: Scaffold(
        resizeToAvoidBottomInset: false,

        body: GetBuilder<PurchaseController>(
          builder: (_purchaseController) {
            if(_purchaseController.PurchaseplanLoading.value){
              return Center(child: CircularProgressIndicator());
            }else{
              return SingleChildScrollView(
                physics: AlwaysScrollableScrollPhysics(),
                child: Column(
                  children: [
                    Container(
                      height: 60,
                      decoration: BoxDecoration(
                        color: ContainerColor,
                        border: Border.all(color: ContainerColor),
                        borderRadius: BorderRadius.only(
                            bottomLeft: (Radius.circular(20)),
                            bottomRight: (Radius.circular(20))),
                      ),
                      child: Padding(
                        padding:  EdgeInsets.only(left: 20,right: 20,bottom: 10),
                        child: Row(
                          children: [
                            Expanded(
                              flex: 7,
                              child: TextFormField(
                                onTap: (){

                                },
                                controller: _searchController,
                                onChanged: (value){
                                  getfamily(_searchController.text.toString());
                                },
                                decoration: InputDecoration(
                                  filled: true,
                                  fillColor: Colors.white,
                                  border: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(10),
                                  ),
                                  focusedBorder: OutlineInputBorder(
                                      borderRadius: BorderRadius.circular(10),
                                      borderSide:
                                      BorderSide(width: 1, color: appPrimaryColor)),
                                  suffixIcon: SearchIcon,
                                  label: Text("search".tr),
                                ),
                              ),
                            ),
                            sizebox_width_5,
                            activeItems[0]['familymember_add_toggle']==0?
                            SizedBox.shrink():
                            Expanded(
                              child: GestureDetector(
                                onTap: (){
                                  Navigator.push(context,
                                      MaterialPageRoute(builder: (context)=> AddFamilyMembers()));
                                },
                                child: Container(
                                  height: 40,
                                  decoration: BoxDecoration(
                                      color: sidebarcontainerColor,
                                      border: Border.all(
                                        color: sidebarcontainerColor,
                                      ),
                                      borderRadius: BorderRadius.all(
                                          Radius.circular(50))),
                                  child: Icon(Icons.add , color: whiteColor,size: 25,),
                                ),
                              ),
                            )
                          ],
                        ),
                      ),
                    ),

                    GetBuilder<GetFamilyMembersController>(
                        builder: (getFamilyMembersController) {
                          if(getFamilyMembersController.GetFamilyMembersLoading.value){
                            return Center(child: Container(
                                alignment: Alignment.center,
                                height: size.height*0.65,
                                child: CircularProgressIndicator()),);
                          }
                          else
                            return
                              getFamilyMembersController.GetFamilyMembersData.length==0?Container(
                                  height: size.height-200,child: Column(
                                mainAxisAlignment: MainAxisAlignment.center,



                                crossAxisAlignment: CrossAxisAlignment.center,
                                children: [
                                  Text("no_family_txt".tr,style: TextStyle(fontSize: 14.5,fontWeight: FontWeight.w600,
                                      color: Colors.grey.shade600,letterSpacing: 0.5
                                  ),),
                                  SizedBox(height: 20,),
                                  GestureDetector(
                                    onTap: (){
                                      Navigator.push(context,
                                          MaterialPageRoute(builder: (context) => AddFamilyMembers()));
                                    },
                                    child: Container(
                                      width: 160,
                                      height: 40,
                                      decoration: BoxDecoration(
                                        color: ContainerColor,
                                        border: Border.all(color: ContainerColor),
                                        borderRadius: BorderRadius.all(Radius.circular(8)),
                                      ),
                                      child: Center(
                                        child: Text("addfamily_txt".tr,
                                          textAlign: TextAlign.center,
                                          style: TextStyle(
                                            color: whiteColor,
                                            fontSize: 15,),),
                                      ),
                                    ),
                                  ),
                                ],
                              )):
                              Padding(
                                padding: EdgeInsets.only(top: 5, left: 10, right: 10),
                                child: ListView.builder(
                                    itemCount: getFamilyMembersController.GetFamilyMembersData.length,
                                    scrollDirection: Axis.vertical,
                                    shrinkWrap: true,
                                    physics: NeverScrollableScrollPhysics(),
                                    itemBuilder: (BuildContext context, index) {
                                      var familyMembersData = getFamilyMembersController.GetFamilyMembersData[index];
                                      return Card(
                                        elevation: 4,
                                        child: Column(
                                          children: [
                                            Row(
                                              mainAxisAlignment: MainAxisAlignment.end,
                                              children: [
                                                GestureDetector(
                                                  onTap:
                                                  activeItems[0]['familymember_delete_toggle']==0?
                                                      (){
                                                    ScaffoldMessenger.of(context).showSnackBar(
                                                      SnackBar(
                                                        content: Text("Your purchased plan doesn't support Family Member Delete !!"),
                                                        duration: Duration(seconds: 2),
                                                        behavior: SnackBarBehavior.floating,
                                                        backgroundColor: Red,
                                                      ),
                                                    );
                                                  }:
                                                      ()async{
                                                    showDialog(
                                                      context: context,
                                                      builder: (context) => new AlertDialog(
                                                        title:  Text('sure_title_txt'.tr),
                                                        content:  Text('delete'.tr),
                                                        actions: <Widget>[
                                                          ElevatedButton(
                                                            onPressed: () => Navigator.of(context).pop(false),
                                                            child:  Text('no'.tr),
                                                          ),
                                                          ElevatedButton(
                                                            onPressed: () async{
                                                              var item__id =   getFamilyMembersController.GetFamilyMembersData[index]["id"].toString();

                                                              // var indexs = getFamilyMembersController.GetFamilyMembersData.indexWhere((element)=> element['id']==item__id);
                                                              setState(() {

                                                                getFamilyMembersController.GetFamilyMembersData.removeAt(index);

                                                                var parameter = "";
                                                                getFamilyMembersController.DeleteFamilyMemberApiCalling(Delete_familyMember_url +item__id.toString(),parameter);

                                                              });
                                                              // deletefromCart(item__id);
                                                              Navigator.of(context).pop(true);
                                                            },
                                                            child:  Text('yes'.tr),
                                                          ),
                                                        ],
                                                      ),);
                                                  },
                                                  child: Padding(
                                                    padding: EdgeInsets.only(top: 5),
                                                    child: Container(
                                                        width: 40,
                                                        child: Icon(Icons.close,size: 25,
                                                          color: ContainerColor,)),
                                                  ),
                                                )
                                              ],
                                            ),
                                            Row(
                                              children: [
                                                Padding(
                                                  padding: EdgeInsets.only(left: 10),
                                                  child: Column(
                                                    mainAxisAlignment: MainAxisAlignment.center,
                                                    crossAxisAlignment: CrossAxisAlignment.start,
                                                    children: [
                                                      Container(
                                                        margin: EdgeInsets.symmetric(vertical: 10,),
                                                        height: 100,
                                                        width: 100,
                                                        decoration: BoxDecoration(
                                                          color: ContainerColor,
                                                          border: Border.all(width: 4,
                                                            color: buttonColor,
                                                          ),
                                                          borderRadius: BorderRadius.all(Radius.circular(90)),
                                                        ),
                                                        child: CachedNetworkImage(imageUrl: familyMembersData["image"].toString(),

                                                          height: 100,
                                                          width: 100,
                                                        ),
                                                      ),
                                                    ],
                                                  ),
                                                ),
                                                Padding(
                                                  padding: EdgeInsets.only(left: 10),
                                                  child: Column(
                                                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                                                    crossAxisAlignment: CrossAxisAlignment.start,
                                                    children: [
                                                      Padding(
                                                        padding:  EdgeInsets.only(bottom: 8),
                                                        child: Text(
                                                          familyMembersData["name"].toString(),
                                                          style: TextStyle(color: Namecolors, fontSize: 22),
                                                        ),
                                                      ),
                                                      Padding(
                                                        padding:  EdgeInsets.only(bottom: 8),
                                                        child: Container(
                                                          child: Row(
                                                            children: [
                                                              Container(
                                                                width: size.width*0.2,
                                                                child: Text(
                                                                  "Relations :",
                                                                  style:
                                                                  TextStyle(color: Namecolors, fontSize: 15),
                                                                ),
                                                              ),

                                                              Text(
                                                                familyMembersData["relation"].toString() != "null" ?
                                                                familyMembersData["relation"].toString() : "    -",
                                                                style:
                                                                TextStyle(color: Namecolors, fontSize: 15),
                                                              ),
                                                            ],
                                                          ),
                                                        ),
                                                      ),
                                                      Row(
                                                        children: [
                                                          Container(
                                                            // width: size.width*0.3,
                                                            child: Text(
                                                              "Categories : ",
                                                              style:
                                                              TextStyle(color: Namecolors, fontSize: 15),
                                                            ),
                                                          ),
                                                          Text(
                                                            familyMembersData["categories"].toString(),
                                                            style:
                                                            TextStyle(color: Namecolors, fontSize: 15),
                                                          ),
                                                        ],
                                                      ),

                                                      // Container(
                                                      //   width: size.width*0.3,
                                                      //   child: Text(
                                                      //     listShareAssets["assets no."].toString(),
                                                      //     style:
                                                      //     TextStyle(color: NameColors2, fontSize: 15),
                                                      //   ),
                                                      //   child:  Text(
                                                      //     familyMembersData["mobile"].toString(),
                                                      //     style:
                                                      //     TextStyle(color: Namecolors, fontSize: 15),
                                                      //   ),
                                                      // ),

                                                    ],
                                                  ),
                                                ),
                                              ],
                                            ),
                                            Padding(
                                              padding:  EdgeInsets.fromLTRB(10, 10, 10, 10),
                                              child: GestureDetector(
                                                onTap: (){
                                                  Navigator.push(context, MaterialPageRoute(
                                                    builder: (context) => manage_assets(
                                                      familyMemberID: familyMembersData["id"].toString(),
                                                      names: familyMembersData["name"].toString(),
                                                      phoneNo: familyMembersData["email"].toString(),
                                                      emailID: familyMembersData["mobile"].toString(),
                                                      images: familyMembersData["image"].toString(),
                                                    ),

                                                  )
                                                  );
                                                },
                                                child: Row(
                                                  mainAxisAlignment: MainAxisAlignment.end,
                                                  children: [
                                                    Container(
                                                      height: 40,
                                                      decoration: BoxDecoration(
                                                          color: whiteColor,
                                                          border:Border.all(color: appPrimaryColor),
                                                          borderRadius: BorderRadius.all(Radius.circular(5))
                                                      ),
                                                      child: Center(
                                                        child: Row(
                                                          children: [
                                                            sizebox_width_5,
                                                            Container(
                                                              child: Text("manageAss_tx".tr,
                                                                textAlign: TextAlign.center,
                                                                style: TextStyle(
                                                                  color: appPrimaryColor,
                                                                  fontSize: 15,),),
                                                            ),
                                                            VerticalDivider(
                                                              color: appPrimaryColor,
                                                              thickness: 1,
                                                            ),
                                                            GestureDetector(
                                                              onTap: activeItems[0]['familymember_edit_toggle']==0?
                                                              (){
                                                                ScaffoldMessenger.of(context).showSnackBar(
                                                                  SnackBar(
                                                                    content: Text("Your purchased plan doesn't support Family Member Edit !!"),
                                                                    duration: Duration(seconds: 2),
                                                                    behavior: SnackBarBehavior.floating,
                                                                    backgroundColor: Red,
                                                                  ),
                                                                );
                                                              }:
                                                                  () async {
                                                                var update_result = await Navigator.push(context,
                                                                    MaterialPageRoute(builder: (context) =>
                                                                        UpdateFamilyMember(
                                                                          id: familyMembersData["id"].toString(),)
                                                                    )
                                                                );
                                                                if(update_result == 'success'){
                                                                  setState(() {
                                                                    GetFamilyMembersController();
                                                                  });
                                                                }
                                                              },
                                                              child: Image.asset("assets/images/edit.png",
                                                                color: ContainerColor,
                                                                height: 25,
                                                                width: 25,),
                                                            ),
                                                            VerticalDivider(
                                                              color: appPrimaryColor,
                                                              thickness: 1,
                                                            ),

                                                            GetBuilder<GetFamilyMembersController>(
                                                                builder: (getFamilyMembersController) {
                                                                  if(getFamilyMembersController.ResetFamilyMembersLoading.value){
                                                                    return Center(child: CircularProgressIndicator());
                                                                  }
                                                                  else
                                                                    return IconButton(
                                                                      iconSize: 25,
                                                                      icon: Icon(
                                                                        Icons.lock_open,
                                                                      ),
                                                                      color: ContainerColor,
                                                                      onPressed: () {
                                                                        var item__id =   getFamilyMembersController.GetFamilyMembersData[index]["id"].toString();
                                                                        getFamilyMembersController.ResetFamilyMembersAPICalling(Rest_Family_Members_url+item__id.toString());
                                                                      },);
                                                                }
                                                            ),
                                                            sizebox_width_5,
                                                          ],
                                                        ),

                                                      ),
                                                    ),

                                                  ],
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                      );
                                    }),
                              );
                        }
                    ),
                    sizebox_height_10
                  ],
                ),
              );
            }

          }
        ),
      ),
    );
  }
}