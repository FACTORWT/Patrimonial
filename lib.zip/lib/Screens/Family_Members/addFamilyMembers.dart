import 'dart:async';
import 'dart:convert';
import 'dart:developer';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:fluttertoast/fluttertoast.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:urwealthpal/Constant/Api.dart';
import 'package:urwealthpal/Constant/ApiBaseHelper.dart';
import 'package:urwealthpal/Constant/colors.dart';
import 'package:urwealthpal/Screens/Family_Members/Controllers/familyMembersController.dart';

class AddFamilyMembers extends StatefulWidget {
  const AddFamilyMembers({Key? key}) : super(key: key);

  @override
  State<AddFamilyMembers> createState() => _AddFamilyMembersState();
}

class _AddFamilyMembersState extends State<AddFamilyMembers> {

  var _formKey = GlobalKey<FormState>();

  bool passToogle = true;
  bool passToogles = true;

  List country_list = [];
  List state_list = [];
  List city_list = [];
var selectCountryId;
  GetFamilyMembersController getFamilyMembersController =
  Get.put(GetFamilyMembersController());

  // Future<http.Response> multipartAPICall(url, parameter) async {
  //   print("post url : $url");
  //   print("post parameter : $parameter");
  //
  //   var jsondata = json.decode(sp!.getString("loginresponse").toString());
  //   print("data: "+jsondata.toString());
  //   var token =jsondata['data']['access_token'];
  //
  //   print("get token : $token");
  //   Map<String, String> mainHeaders = {
  //     Environment.appxapikey.toString(): Environment.appxapivalue.toString(),
  //     'Content-Type': 'application/json',
  //     'Authorization': 'Bearer $token'
  //   };
  //   try {
  //     final request = http.MultipartRequest('POST', Uri.parse(url));
  //     request.fields.addAll(parameter);
  //
  //     request.headers.addAll(mainHeaders);
  //
  //     // ignore: unnecessary_null_comparison
  //     if (getFamilyMembersController.pickfile1 != null) {
  //       request.files
  //           .add(await http.MultipartFile.fromPath('image',getFamilyMembersController.pickfile1!.path));
  //     } else {
  //
  //     }
  //
  //     http.StreamedResponse responses = await request.send();
  //
  //     var responsedata = await http.Response.fromStream(responses);
  //     print("add family member response body...."+responsedata.toString());
  //
  //     if(responsedata.statusCode == 200){
  //       getFamilyMembersController.userName.clear();
  //       getFamilyMembersController.email.clear();
  //       getFamilyMembersController.mobile.clear();
  //       getFamilyMembersController.country.clear();
  //       getFamilyMembersController.state.clear();
  //       getFamilyMembersController.city.clear();
  //       getFamilyMembersController.pincode.clear();
  //       getFamilyMembersController.address.clear();
  //       getFamilyMembersController.dateInput.clear();
  //       getFamilyMembersController.password.clear();
  //       getFamilyMembersController.confirmPassword.clear();
  //       getFamilyMembersController.SelectedCountryName="Select Country";
  //       getFamilyMembersController.SelectedStateName="Select State";
  //       getFamilyMembersController.SelectedCityName="Select City";
  //       Get.find<GetFamilyMembersController>().GetFamilyMembersAPICalling(Get_Family_Members_url);
  //       Get.back();
  //
  //       //     Map<String, String> queryParams = {
  //       //       que_search :"".toString(),
  //       //     };
  //       //     String queryString = Uri(queryParameters: queryParams).query;
  //       //     var Family_Members_url = Get_Family_Members_url + '?' + queryString;
  //       //     GetFamilyMembersAPICalling(Family_Members_url);
  //       //     // Get.back();
  //       //     Get.back(result: "success");
  //       //     update();
  //       //   }
  //     }
  //       // else if(responsedata.statusCode==403){
  //       // log("check : "+responsedata.toString());
  //       //   if(responsedata['error'] != null){
  //       //     responsedata['error'].forEach((k,v){
  //       //       log("Key :$k");
  //       //       log("Value :${v.join(" ")}");
  //       //       toastMsg("${v.join(" ")}", true);
  //       //     });
  //       //     getFamilyMembersController.AddFamilyMemberLoading.value = false;
  //       //     getFamilyMembersController.update();
  //       //   }
  //       // }
  //
  //     print("post statusCode : ${responsedata.statusCode.toString()}");
  //
  //     print("post response : ${responsedata.body.toString()}");
  //
  //     return responsedata;
  //   } on SocketException {
  //     throw FetchDataException('No Internet connection');
  //   } on TimeoutException {
  //     throw FetchDataException('Something went wrong, try again later');
  //   }
  // }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    fetchCountry();
    getFamilyMembersController.imagenull();
  }

  @override
  Widget build(BuildContext context) {
    return RefreshIndicator(
      onRefresh: () async {
        await getFamilyMembersController;
        await Future.delayed(Duration(milliseconds: 1500));
      },
      child: Scaffold(
        appBar: AppBar(
          titleSpacing: 0,
          title: Text("addfamily_txt".tr),
          elevation: 0,
          backgroundColor: ContainerColor,
        ),
        body: (SingleChildScrollView(
          physics: AlwaysScrollableScrollPhysics(),
          child: Form(
            key: _formKey,
            child: Column(children: [
              Stack(
                children: [
                  GetBuilder<GetFamilyMembersController>(
                    builder: (getFamilyMembersController) {
                      return Container(
                        margin: EdgeInsets.symmetric(vertical: 10,),
                        height: 100,
                        width: 100,
                        decoration: BoxDecoration(
                          color: ContainerColor,
                          image: DecorationImage(
                            image:  getFamilyMembersController.pickfile1!=null?
                            Image.file(
                              File( getFamilyMembersController.pickfile1!.path.toString()),
                              fit: BoxFit.contain,
                            ).image
                               // :NetworkImage(getFamilyMembersController.image.toString()),
                                :AssetImage("assets/images/user.png",),
                          ),
                          border: Border.all(width: 5,
                          color: buttonColor,
                          ),
                          borderRadius: BorderRadius.all(Radius.circular(90)),
                        ),
                        // child: profilePageImage,
                      );
                    }
                  ),
                  Positioned(
                    bottom: 5,
                    right: 2,
                    child: InkWell(
                      onTap: (){
                        getFamilyMembersController.getFromGallery();
                      },
                      child: Container(
                        height: 30,
                        width: 30,
                        decoration: BoxDecoration(
                            color: whiteColor,
                            border: Border.all(
                              color: whiteColor,
                            ),
                            borderRadius: BorderRadius.all(Radius.circular(20))
                        ),
                        child: Icon(Icons.edit,color: Color(0xFF939292),size: 18,
                        ),
                      ),
                    ),
                  ),
                ],
              ),

              Padding(
                padding: EdgeInsets.fromLTRB(10, 10, 10, 0),
                child: TextFormField(
                  controller: getFamilyMembersController.userName,
                  autovalidateMode: AutovalidateMode.onUserInteraction,
                  validator: (value) {
                    if (value == null) {
                      return "validUserName_txt".tr;
                    }
                    if (value.length < 3) {
                      return "validLength_UserName_txt".tr;
                    }
                    return null;
                  },
                  keyboardType: TextInputType.name,
                  textInputAction: TextInputAction.next,
                  decoration: InputDecoration(
                    filled: true,
                    fillColor: whiteColor,
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10),
                    ),
                    enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10),
                        borderSide:
                        BorderSide(width: 1, color: appPrimaryColor)),
                    focusedBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10),
                        borderSide:
                        BorderSide(width: 1, color: appPrimaryColor)),
                    // labelText: 'Your Name',
                    prefixIcon: Container(
                      // color: Colors.redAccent,
                      child: Image.asset(
                        "assets/images/user.png",
                        scale: 3,
                        width: 15,
                      ),
                    ),
                    hintText: "userName_txt".tr,
                  ),
                ),
              ),

              Padding(
                padding: EdgeInsets.fromLTRB(10, 10, 10, 0),
                child: TextFormField(
                  controller: getFamilyMembersController.email,
                  autovalidateMode: AutovalidateMode.onUserInteraction,
                  validator: (value) {
                    if (value == null) {
                      return "valid_Email_txt".tr;
                    }
                    if (value == null ||
                        value.isEmpty ||
                        !value.contains('@') ||
                        !value.contains('.')) {
                      return "validLength_Email_txt".tr;
                    }
                    return null;
                  },
                  keyboardType: TextInputType.emailAddress,
                  textInputAction: TextInputAction.next,
                  decoration: InputDecoration(
                    filled: true,
                    fillColor: whiteColor,
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10),
                    ),
                    enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10),
                        borderSide:
                        BorderSide(width: 1, color: appPrimaryColor)),
                    focusedBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10),
                        borderSide:
                        BorderSide(width: 1, color: appPrimaryColor)),
                    // labelText: 'Your Name',
                    prefixIcon: Container(
                      // color: Colors.redAccent,
                        child: Image.asset(
                          "assets/images/email (1).png",
                          scale: 3,
                          width: 15,
                        )),
                    hintText: "emailId_txt".tr,
                  ),
                ),
              ),

              Padding(
                padding: EdgeInsets.fromLTRB(10, 10, 10, 0),
                child: TextFormField(
                  controller: getFamilyMembersController.mobile,
                  inputFormatters: [
                    FilteringTextInputFormatter.allow(RegExp('[0-9]'))
                  ],
                  keyboardType: TextInputType.numberWithOptions(decimal: true),
                  autovalidateMode: AutovalidateMode.onUserInteraction,
                  validator: (value) {
                    if (value == null) {
                      return "valid_Mobile_No_txt".tr;
                    }
                    if (value.length == 0) {
                      return "valid_Mobile_No_txt".tr;
                    }
                    return null;
                  },
                  textInputAction: TextInputAction.next,
                  decoration: InputDecoration(
                    filled: true,
                    fillColor: whiteColor,
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10),
                    ),
                    enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10),
                        borderSide:
                        BorderSide(width: 1, color: appPrimaryColor)),
                    focusedBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10),
                        borderSide:
                        BorderSide(width: 1, color: appPrimaryColor)),
                    prefixIcon: Container(
                      // color: Colors.redAccent,
                      child: Image.asset(
                        "assets/images/phoneIcon.png",
                        scale: 3.5,
                        width: 15,
                      ),
                    ),
                    hintText: "mobileNo_txt".tr,
                  ),
                ),
              ),

              getFamilyMembersController.country.text.toString()=="null"?Container():
              Padding(
                padding: EdgeInsets.fromLTRB(10, 10, 10, 0),
                child: DropdownButtonFormField(
                  isExpanded: true,
                  validator: ((val) {
                    if (val == null) {
                      return "SelectCountry".tr;
                    }
                  }),
                  decoration: InputDecoration(
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10),
                    ),
                    enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10),
                        borderSide:
                        BorderSide(width: 1, color: appPrimaryColor)),
                    focusedBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10),
                        borderSide:
                        BorderSide(width: 1, color: appPrimaryColor)),
                    labelStyle: TextStyle(color: Colors.grey, fontSize: 16),
                    filled: true,
                    prefixIcon: Container(
                      // color: Colors.redAccent,
                      child:
                      Image.asset("assets/images/cityIcon.png",
                        color: Color(0xFF37BCF9),
                        scale: 2.6,width: 15,),
                    ),
                    hintStyle: TextStyle(color: Colors.black),
                    hintText:getFamilyMembersController.SelectedCountryName==null?"hintCountry_txt".tr:  getFamilyMembersController.SelectedCountryName
                        .toString(),
                    fillColor: Colors.transparent,
                  ),
                  // value: profileController.SelectedCountryName == null
                  //   ?"Select Country":profileController.SelectedCountryName,
                  items: country_list.map((explist) {
                    print("array " + explist.toString());
                    return DropdownMenuItem(
                      value: explist['name'],
                      child: Text(explist['name']),
                      onTap: () {
                        getFamilyMembersController.SelectedCountryId = explist['id'];
                        selectCountryId=explist['id'];
                        log('selectCountryId==>'+selectCountryId.toString());
                        setState(() {

                        });

                      },
                    );
                  }).toList(),
                  onChanged: (value) {
                    setState(() {
                      // SelectedStateNAme = value;
                      getFamilyMembersController.SelectedCountryName = value;
                      // profileController.SelectedCountryName = value;
                      print("countryId...." +
                          getFamilyMembersController.SelectedCountryId
                              .toString());

                      if (getFamilyMembersController.SelectedCountryId == 0) {
                        getFamilyMembersController.SelectedCountryId = null;
                      }
                    });
                    getFamilyMembersController.SelectedStateId = null;
                    getFamilyMembersController.SelectedStateName = null;
                    fetchState(getFamilyMembersController.SelectedCountryId.toString());
                  },
                ),
              ),

             // state_list
              getFamilyMembersController.state.text.toString()=="null"?Container():
              GestureDetector(
                onTap: (){

                  log('hh2222'+    getFamilyMembersController.SelectedCountryName .toString());
                  getFamilyMembersController.SelectedCountryName=="Select Country"?
                  Fluttertoast.showToast(msg:'Please select country. ',backgroundColor: Colors.red, ):
                  Container();
                  setState(() {

                  });
                },
                child: Padding(
                  padding: EdgeInsets.fromLTRB(10, 10, 10, 0),
                  child: DropdownButtonFormField(
                    isExpanded: true,
                    validator: ((val) {
                      if (val == null) {
                        return "SelectState".tr;
                      }
                    }),
                    decoration: InputDecoration(
                      //  labelText: "Select State",
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10),
                      ),
                      enabledBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10),
                          borderSide:
                          BorderSide(width: 1, color: appPrimaryColor)),
                      focusedBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10),
                          borderSide:
                          BorderSide(width: 1, color: appPrimaryColor)),
                      labelStyle: TextStyle(color: Colors.grey, fontSize: 16),
                      filled: true,
                      prefixIcon: Container(
                        // color: Colors.redAccent,
                        child:
                        Image.asset("assets/images/cityIcon.png",
                          color: Color(0xFF37BCF9),
                          scale: 2.6,width: 15,),
                      ),
                      hintStyle: TextStyle(color: Colors.black),
                      hintText:getFamilyMembersController.SelectedStateName==null?"hintState_txt".tr: getFamilyMembersController.SelectedStateName.toString(),
                      fillColor: Colors.transparent,
                    ),
                    value:  getFamilyMembersController.SelectedStateName,
                    items: state_list.map((explist) {
                      print("array==> " + explist.toString());
                      return DropdownMenuItem(
                        value: explist['name'],
                        child: Text(explist['name']),
                        onTap:  state_list.length==0?(){
                          print("true==>");
                        }:() {
                          print("true=22=>");
                          setState(() {

                            getFamilyMembersController.SelectedStateId = explist['id'];
                          });
                        },
                      );
                    }).toList(),


                    onChanged: (value) {
                      setState(() {
                        // SelectedStateNAme = value;
                        getFamilyMembersController.SelectedStateName = value;
                        log('SelectedStateName==>'+getFamilyMembersController.SelectedStateId.toString());
                        if (getFamilyMembersController.SelectedStateId == 0) {
                          getFamilyMembersController.SelectedStateId = null;
                        }
                      });
                      getFamilyMembersController.SelectedCityId = null;
                      getFamilyMembersController.SelectedCityName = null;
                      fetchCity(
                          getFamilyMembersController.SelectedStateId.toString());
                    },
                  ),
                ),
              ),

              getFamilyMembersController.city.text.toString()=="null"?Container():
              GestureDetector(
                onTap: (){

                  log('SelectedStateName==>'+    getFamilyMembersController.SelectedStateName.toString());
                  getFamilyMembersController.SelectedStateName=='Select State'?
                  Fluttertoast.showToast(msg:'Please select State. ',backgroundColor: Colors.red, ):
                  Container();
                  setState(() {

                  });
                },
                child: Padding(
                  padding: EdgeInsets.fromLTRB(10, 10, 10, 0),
                  child: DropdownButtonFormField(
                    isExpanded: true,
                    validator: ((val) {
                      if (val == null) {
                        return "SelectCity".tr;
                      }
                    }),
                    decoration: InputDecoration(
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10),
                      ),
                      enabledBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10),
                          borderSide:
                          BorderSide(width: 1, color: appPrimaryColor)),
                      focusedBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10),
                          borderSide:
                          BorderSide(width: 1, color: appPrimaryColor)),
                      labelStyle: TextStyle(color: Colors.black, fontSize: 16),
                      filled: true,
                      prefixIcon: Container(
                        // color: Colors.redAccent,
                        child:
                        Image.asset("assets/images/cityIcon.png",
                          color: Color(0xFF37BCF9),
                          scale: 2.6,width: 15,),
                      ),
                      hintStyle: TextStyle(color: Colors.black),
                      hintText:getFamilyMembersController.SelectedCityName==null?"hintCity_txt".tr: getFamilyMembersController.SelectedCityName.toString(),
                      fillColor: Colors.transparent,
                    ),
                    // value: getFamilyMembersController.SelectedCityName.toString(),
                    items: city_list.map((explist) {
                      print("array " + explist.toString());
                      return DropdownMenuItem(
                        value: explist['name'],
                        child: Text(explist['name']),
                        onTap: () {
                          setState(() {
                            getFamilyMembersController.SelectedCityId =
                            explist['id'];
                          });
                        },
                      );
                    }).toList(),
                    onChanged: (value) {
                      setState(() {
                        getFamilyMembersController.SelectedCityName = value;
                        if (getFamilyMembersController.SelectedCityId == 0) {
                          getFamilyMembersController.SelectedCityId = null;
                        }
                      });
                    },
                  ),
                ),
              ),


              Padding(
                padding: EdgeInsets.fromLTRB(10, 10, 10, 0),
                child: TextFormField(
                  controller: getFamilyMembersController.pincode,
                  autovalidateMode: AutovalidateMode.onUserInteraction,
                  validator: (value) {
                    if (value == null) {
                      return "pinCode_txt".tr;
                    }
                    if (value.length != 6) {
                      return "vaidPinCode".tr;
                    }
                    return null;
                  },
                  keyboardType: TextInputType.name,
                  textInputAction: TextInputAction.next,
                  decoration: InputDecoration(
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10),
                      ),
                      enabledBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10),
                          borderSide:
                          BorderSide(width: 1, color: appPrimaryColor)),
                      focusedBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10),
                          borderSide:
                          BorderSide(width: 1, color: appPrimaryColor)),
                      hintText: "hintpin_txt".tr,
                      prefixIcon: Container(
                        // color: Colors.redAccent,
                        child: Image.asset(
                          "assets/images/passIcon.png",
                          scale: 3.5,
                          width: 15,
                        ),
                      )),
                ),
              ),

              Padding(
                padding: EdgeInsets.fromLTRB(10, 10, 10, 0),
                child: TextFormField(
                  scrollPadding: EdgeInsets.only(
                      bottom: MediaQuery.of(context).viewInsets.bottom + 25*4),
                  controller: getFamilyMembersController.dateInput,
                  validator: (value) {
                    if (value!.isEmpty) {
                      return "dob_txt".tr;
                    } else
                      return null;
                  },
                  decoration: InputDecoration(
                    hintText: "hint_dob_txt".tr,
                    filled: true,
                    prefixIcon: Container(
                      child:
                        Icon(Icons.calendar_month_outlined,
                          color: Color(0xFF37BCF9),)
                    ),
                    fillColor: Colors.white,
                    // contentPadding: EdgeInsets.only(top: 5,left: 10),
                    // constraints: BoxConstraints(
                    //     minWidth: 30, maxHeight: 70),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10),
                    ),
                    enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10),
                        borderSide:
                        BorderSide(width: 1, color: appPrimaryColor)),
                    focusedBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10),
                        borderSide:
                        BorderSide(width: 1, color: appPrimaryColor)),
                  ),
                  onTap: () async {
                    DateTime? pickedDate = await showDatePicker(
                        context: context,
                        initialDate: DateTime.now(),
                        firstDate: DateTime(1950),
                        lastDate: DateTime(2100));
                    if (pickedDate != null) {
                      print(pickedDate);
                      String formattedDate =
                      DateFormat('yyyy-MM-dd').format(pickedDate);
                      print(formattedDate);
                      setState(() {
                        getFamilyMembersController.dateInput.text = formattedDate;
                      });
                    } else {
                      print('print_dob'.tr);
                    }
                  },
                ),
              ),

              Padding(
                padding: EdgeInsets.fromLTRB(10, 10, 10, 0),
                child: TextFormField(
                  controller: getFamilyMembersController.address,
                  autovalidateMode: AutovalidateMode.onUserInteraction,
                  validator: (value) {
                    if (value == null) {
                      return "address_txt".tr;
                    }
                    if (value.length < 6) {
                      return "valid_address_txt".tr;
                    }
                    return null;
                  },
                  keyboardType: TextInputType.streetAddress,

                  maxLines: 1,
                  textInputAction: TextInputAction.next,
                  decoration: InputDecoration(
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10),
                      ),
                      enabledBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10),
                          borderSide:
                          BorderSide(width: 1, color: appPrimaryColor)),
                      focusedBorder: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10),
                          borderSide:
                          BorderSide(width: 1, color: appPrimaryColor)),
                      hintText: "hint_address".tr,
                      prefixIcon: Container(
                        // color: Colors.redAccent,
                        child: Image.asset(
                          "assets/images/cityIcon.png",
                          color: Color(0xFF37BCF9),
                          scale: 2.6,
                          width: 15,
                        ),
                      )),
                ),
              ),

              Padding(
                padding: EdgeInsets.fromLTRB(10, 10, 10, 0),
                child: TextFormField(
                  controller: getFamilyMembersController.password,
                  autovalidateMode: AutovalidateMode.onUserInteraction,
                  scrollPadding: EdgeInsets.only(
                      bottom:
                      MediaQuery.of(context).viewInsets.bottom + 25 * 4),
                  validator: (value) {
                    if (value == null || value.isEmpty) {
                      return "validPassword".tr;
                    }
                    if (value.length < 6) {
                      return "correctPassword".tr;
                    }
                    return null; // Validation passed
                  },
                  obscureText: passToogle,
                  textInputAction: TextInputAction.next,
                  decoration: InputDecoration(
                    filled: true,
                    fillColor: whiteColor,
                    // contentPadding: EdgeInsets.only(top: 5),
                    // constraints: BoxConstraints(minWidth: 30, maxHeight: 70),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10),
                    ),
                    enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10),
                        borderSide:
                        BorderSide(width: 1, color: appPrimaryColor)),
                    focusedBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10),
                        borderSide:
                        BorderSide(width: 1, color: appPrimaryColor)),
                    prefixIcon: Container(
                      // color: Colors.redAccent,
                        child: Image.asset(
                          "assets/images/passIcon.png",
                          scale: 3,
                          width: 15,
                        )),
                    hintText: "hintPassword".tr,
                    suffixIcon: InkWell(
                      onTap: () {
                        setState(() {
                          passToogle = !passToogle;
                        });
                      },
                      child: Icon(
                          passToogle   ? Icons.visibility_off
                              : Icons.visibility),
                    ),
                  ),
                ),
              ),

              Padding(
                padding: EdgeInsets.fromLTRB(10, 10, 10, 0),
                child: TextFormField(
                  controller: getFamilyMembersController.confirmPassword,
                  autovalidateMode: AutovalidateMode.onUserInteraction,
                  scrollPadding: EdgeInsets.only(bottom: 40),
                  validator: (value) {
                    if (value!.isEmpty) {
                      return "reEnterPasswrod".tr;
                    } else if (getFamilyMembersController.password.text !=
                        getFamilyMembersController.confirmPassword.text) {
                      return "reEnterPasswrodNotMatch".tr;
                    } else
                      return null;
                  },
                  obscureText: passToogles,
                  textInputAction: TextInputAction.done,
                  decoration: InputDecoration(
                    filled: true,
                    fillColor: whiteColor,
                    // contentPadding: EdgeInsets.only(top: 5),
                    // constraints: BoxConstraints(minWidth: 30, maxHeight: 70),
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10),
                    ),
                    enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10),
                        borderSide:
                        BorderSide(width: 1, color: appPrimaryColor)),
                    focusedBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10),
                        borderSide:
                        BorderSide(width: 1, color: appPrimaryColor)),
                    prefixIcon: Container(
                      // color: Colors.redAccent,
                        child: Image.asset(
                          "assets/images/passIcon.png",
                          scale: 3,
                          width: 15,
                        )),
                    hintText: "hintConfirmPassword".tr,
                    suffixIcon: InkWell(
                      onTap: () {
                        setState(() {
                          passToogles = !passToogles;
                        });
                      },
                      child: Icon(passToogles
                          ? Icons.visibility_off
                          : Icons.visibility),
                    ),
                  ),
                ),
              ),
              Padding(
                padding: EdgeInsets.fromLTRB(10, 10, 10, 0),
                child: TextFormField(
                  controller: getFamilyMembersController.relationName,
                  autovalidateMode: AutovalidateMode.onUserInteraction,
                  validator: (value) {
                    if (value == null) {
                      return "relation_txt".tr;
                    }
                    if (value.length < 3) {
                      return "validrelation_txt".tr;
                    }
                    return null;
                  },
                  keyboardType: TextInputType.name,
                  textInputAction: TextInputAction.next,
                  decoration: InputDecoration(
                    filled: true,
                    fillColor: whiteColor,
                    border: OutlineInputBorder(
                      borderRadius: BorderRadius.circular(10),
                    ),
                    enabledBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10),
                        borderSide:
                        BorderSide(width: 1, color: appPrimaryColor)),
                    focusedBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10),
                        borderSide:
                        BorderSide(width: 1, color: appPrimaryColor)),
                    // labelText: 'Your Name',
                    prefixIcon: Container(
                      // color: Colors.redAccent,
                      child: Image.asset(
                        "assets/images/user.png",
                        scale: 3,
                        width: 15,
                      ),
                    ),
                    hintText: "relation_txt".tr,
                  ),
                ),
              ),


              Padding(
                padding: EdgeInsets.only(left: 10, right: 10, top: 40),
                child: GestureDetector(
                  onTap: () async {
                    if (_formKey.currentState!.validate()) {
                      var add_familyMemberUrl = Add_familyMember_url;
                      var body = ({
                        'name' : getFamilyMembersController.userName.text.toString(),
                        'email' : getFamilyMembersController.email.text.toString(),
                        'mobile' : getFamilyMembersController.mobile.text.toString(),
                        'country_id' : getFamilyMembersController.SelectedCountryId.toString(),
                        'state_id' : getFamilyMembersController.SelectedStateId.toString(),
                        'city_id' : getFamilyMembersController.SelectedCityId.toString(),
                        'pincode' : getFamilyMembersController.pincode.text.toString(),
                        'dob' : getFamilyMembersController.dateInput.text.toString(),
                        'address' : getFamilyMembersController.address.text.toString(),
                        'status' : getFamilyMembersController.MemberStatus.toString(),
                        'password' : getFamilyMembersController.password.text.toString(),
                        'password_confirmation' : getFamilyMembersController.confirmPassword.text.toString(),
                        'relation' : getFamilyMembersController.relationName.text.toString(),
                      });

                      print('AddFamily==>${body}'.toString());

                      getFamilyMembersController.AddFamilyMemberApiCalling(add_familyMemberUrl,
                          body);
                    }
                  },
                  child: Container(
                    width: 150,
                    height: 40,
                    decoration: BoxDecoration(
                      color: ContainerColor,
                      border: Border.all(color: ContainerColor),
                      borderRadius: BorderRadius.all(Radius.circular(8)),
                    ),
                    child: Center(
                      child: Text(
                        "save_txt".tr,
                        style: TextStyle(color: whiteColor, fontSize: 20),
                      ),
                    ),
                  ),
                ),
              ),
              SizedBox(
                height: 40,
              )
            ]),
          ),
        )),
      ),
    );
  }

  Future<void> fetchCountry() async {
    var countryUrl = Uri.parse(Country_url);
    print("countryUrl--> " + countryUrl.toString());
    var response = await ApiBaseHelper().getAPICall(countryUrl, true);
    var CountryData = jsonDecode(response.body);
    if (response.statusCode == 200) {
      setState(() {
        country_list.addAll(CountryData['data']);
        getFamilyMembersController.SelectedCountryName == null
            ? "hintCountry_txt".tr
            : getFamilyMembersController.SelectedCountryName;
        getFamilyMembersController.SelectedCountryId == null
            ? 0
            : getFamilyMembersController.SelectedCountryId;
        fetchState(getFamilyMembersController.SelectedCountryId.toString());
        getFamilyMembersController.SelectedStateId == null
            ? 0
            : getFamilyMembersController.SelectedStateId;
        fetchCity(getFamilyMembersController.SelectedStateId);
      });
    }
  }

  Future<void> fetchState(countryId) async {
    var stateUrl = Uri.parse(State_url + countryId);
    print("profileUrl--> " + stateUrl.toString());

    var response = await ApiBaseHelper().getAPICall(stateUrl, true);
    var StateData = jsonDecode(response.body);
    print("response.statusCode--> " + response.statusCode.toString());
    if (response.statusCode == 200) {
      state_list.clear();
      setState(() {
        state_list.addAll(StateData['data']);
        log('data==>'+state_list.toString());
      });
    } else if (response.statusCode == 404){
      log('data==>'+StateData.toString());
      Fluttertoast.showToast(msg:'No state found!!',backgroundColor: Colors.red,  );
    }
  }

  Future<void> fetchCity(state_id) async {
    var cityUrl = Uri.parse(City_url + state_id);
    print("cityurl : " + cityUrl.toString());
    var response = await ApiBaseHelper().getAPICall(cityUrl, true);
    var CityData = jsonDecode(response.body);
    if (response.statusCode == 200) {
      city_list.clear();
      setState(() {
        city_list.addAll(CityData['data']);
      });
    }
  }
}
