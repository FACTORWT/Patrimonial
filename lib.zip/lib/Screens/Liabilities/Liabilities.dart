import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'dart:async';
import 'package:urwealthpal/Constant/Api.dart';
import 'package:urwealthpal/Constant/Spacing.dart';
import 'package:urwealthpal/Constant/colors.dart';
import 'package:urwealthpal/Environment/Environment.dart';
import 'package:urwealthpal/Screens/Assets/Controllers/Get_Categories_Controller.dart';
import 'package:urwealthpal/Screens/Assets/assets_details.dart';
import 'package:urwealthpal/Screens/MPIN/AssetsMPIN.dart';
import '../../Constant/Images.dart';

class Libailitys extends StatefulWidget {
  const Libailitys({Key? key}) : super(key: key);

  @override
  State<Libailitys> createState() => _LibailitysState();
}

class _LibailitysState extends State<Libailitys> {
  List libailityList = [];

  var getcategoriesController = Get.put(Get_Categories_Controller());

  TextEditingController _searchController = TextEditingController();

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    _searchController.text;

    // if(sp!.getBool("paymentstatus")== false){
    //   Get.offAll(purchase_plan());
    //   sp!.setBool("paymentstatus", false);
    // }
    // else{
    //   sp!.setBool("paymentstatus", true);
    // }

    getcategoriesController.Get_CategoriesAPICalling(
        Category_url + "?type=${2}");

  }

  getliabilitie(search) async {
    Map<String, String> queryParams = {
      que_search: search.toString(),
      "type": "2",
    };
    String queryString = Uri(queryParameters: queryParams).query;
    var Get_Categories_url = Category_url + '?' + queryString;
    getcategoriesController.Get_CategoriesAPICalling(Get_Categories_url);
  }

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Scaffold(
      body: GetBuilder<Get_Categories_Controller>(
          builder: (getcategoriesController) {
        if (getcategoriesController.Get_Categories_Loading.value) {
          return Center(
            child: CircularProgressIndicator(),
          );
        } else {
          return RefreshIndicator(
            onRefresh: () async {
              _searchController.clear();
              await Get_Categories_Controller();
              await Future.delayed(Duration(milliseconds: 1500));
            },
            child: SingleChildScrollView(
              child: Column(
                children: [
                  Container(
                    height: 60,
                    decoration: BoxDecoration(
                      color: ContainerColor,
                      border: Border.all(color: ContainerColor),
                      borderRadius: BorderRadius.only(
                          bottomLeft: (Radius.circular(20)),
                          bottomRight: (Radius.circular(20))),
                    ),
                    child: Padding(
                      padding: EdgeInsets.only(left: 20, right: 20, bottom: 15),
                      child: TextFormField(
                        onTap: () {},
                        onChanged: (value) {
                          getliabilitie(_searchController.text.toString());
                        },
                        controller: _searchController,
                        decoration: InputDecoration(
                          filled: true,
                          fillColor: Colors.white,
                          border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(10),
                          ),
                          focusedBorder: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(10),
                              borderSide:
                                  BorderSide(width: 1, color: appPrimaryColor)),
                          suffixIcon: SearchIcon,
                          label: Text("search".tr),
                        ),
                      ),
                    ),
                  ),
                  ListView.builder(
                      itemCount:
                          getcategoriesController.Get_CategoriesData.length,
                      scrollDirection: Axis.vertical,
                      shrinkWrap: true,
                      physics: NeverScrollableScrollPhysics(),
                      itemBuilder: (BuildContext context, index1) {
                        var Categorieslistdata =
                            getcategoriesController.Get_CategoriesData[index1];
                        return Padding(
                          padding: EdgeInsets.only(left: 10, right: 10, top: 5),
                          child: Card(
                            elevation: 2,
                            child: ExpansionTile(
                              trailing:
                                  Categorieslistdata['sub_categories'].length == 0
                                      ? SizedBox(height: 0)
                                      : Icon(Icons.expand_more_outlined),
                              initiallyExpanded: index1 == 0,
                              key: Key(index1.toString()),
                              collapsedBackgroundColor: Colors.transparent,
                              onExpansionChanged: (bool expanded) {
                                setState(() {
                                  libailityList = getcategoriesController
                                          .Get_CategoriesData[index1]
                                      ['sub_categories'];
                                });
                              },
                              title: GestureDetector(
                                onTap: () {

                                  if (Environment.askMPIN == "1") {
                                    Get.to(AssetsMPIN(
                                        mainCategories_id:
                                            Categorieslistdata["id"].toString(),
                                        id: 3));
                                  } else {
                                    Navigator.push(
                                        context,
                                        MaterialPageRoute(
                                            builder: (context) =>
                                                assets_details(
                                                    mainCategories_id:
                                                        Categorieslistdata["id"]
                                                            .toString(),
                                                    assets: false)));
                                  }
                                  // Navigator.push(context,
                                  //     MaterialPageRoute(builder: (context)=>
                                  //         assets_details(
                                  //           mainCategories_id: Categorieslistdata["id"].toString(),assets:false)));
                                },
                                child: Row(
                                  children: [
                                    Image.network(
                                      Categorieslistdata["image"].toString(),
                                      height: 45,
                                      width: 45,
                                    ),
                                    sizebox_width_10,
                                    Expanded(
                                      flex: 25,
                                      child: Text(
                                        Categorieslistdata["name"].toString(),
                                        style: TextStyle(
                                            color: Darkgrey,
                                            fontSize: 17,
                                            letterSpacing: 0.5,
                                            height: 1.5,
                                            fontWeight: FontWeight.w600
                                        ),
                                      ),
                                    ),
                                    sizebox_width_10,
                                    Expanded(
                                      flex: 15,
                                      child: Container(
                                          padding: EdgeInsets.symmetric(
                                              horizontal: 10, vertical: 20),
                                          child: Center(
                                              child: Text(
                                            Categorieslistdata['sub_categories']
                                                .length
                                                .toString(),
                                            // Categorieslistdata["count"].toString(),
                                            style: TextStyle(
                                                color: whiteColor,
                                                fontSize: 18,
                                                fontWeight: FontWeight.bold),
                                          )),
                                          decoration: BoxDecoration(
                                              color: ContainerColor,
                                              border: Border.all(
                                                  color: ContainerColor),
                                              borderRadius: BorderRadius.all(
                                                  Radius.circular(8)))),
                                    ),
                                  ],
                                ),
                              ),
                              children: <Widget>[
                                ListView.builder(
                                    itemCount:
                                        Categorieslistdata['sub_categories']
                                            .length,
                                    scrollDirection: Axis.vertical,
                                    shrinkWrap: true,
                                    physics: NeverScrollableScrollPhysics(),
                                    itemBuilder:
                                        (BuildContext context, index2) {
                                      var SubCategorieslistdata =
                                          Categorieslistdata['sub_categories']
                                              [index2];
                                      print("SubCategorieslistdata-->" +
                                          SubCategorieslistdata.toString());
                                      return Padding(
                                        padding: EdgeInsets.only(left: 10, right: 10, top: 5),
                                        child: ExpansionTile(
                                          collapsedBackgroundColor:
                                              Colors.transparent,
                                          trailing: SubCategorieslistdata['sub_categories'].length == 0
                                              ? SizedBox(height: 0)
                                              : Icon(Icons.expand_more_outlined),
                                          onExpansionChanged:
                                              (bool isexpanded) {
                                        if (Environment.askMPIN == "1") {
                                        Get.to(AssetsMPIN(mainCategories_id: SubCategorieslistdata["id"].toString(), id: 4));
                                          } else {
                                          Navigator.push(
                                            context,
                                           MaterialPageRoute(builder: (context) =>
                                               assets_details(
                                                mainCategories_id: SubCategorieslistdata["id"].toString(),
                                                assets: false,
                                                  )));
                                        }
                                            // Navigator.push(context, MaterialPageRoute(builder: (context) =>
                                            //     assets_details(mainCategories_id: SubCategorieslistdata["id"].toString(), assets: false,
                                            //             )));
                                          },
                                          title: Row(
                                            children: [
                                              Image.network(
                                                SubCategorieslistdata["image"]
                                                    .toString(),
                                                height: 35,
                                                width: 35,
                                              ),
                                              sizebox_width_10,
                                              Container(
                                                width: size.width - 180,
                                                child: Text(
                                                  "${SubCategorieslistdata["name"].toString()}",
                                                  style: TextStyle(
                                                      color: greyColor,
                                                      fontSize: 16,
                                                      fontWeight:
                                                          FontWeight.w400),
                                                ),
                                              ),
                                            ],
                                          ),
                                          children: <Widget>[
                                            ListView.builder(
                                                itemCount:
                                                    SubCategorieslistdata['sub_categories'].length,
                                                scrollDirection: Axis.vertical,
                                                shrinkWrap: true,
                                                physics: NeverScrollableScrollPhysics(),
                                                itemBuilder:
                                                    (BuildContext context,
                                                        index3) {
                                                  var SubCategoriesdata =
                                                      SubCategorieslistdata[
                                                              'sub_categories']
                                                          [index3];
                                                  // print("subCategoryList${subcategoryList[index3]}");
                                                  return Padding(
                                                    padding:
                                                        EdgeInsets.all(8.0),
                                                    child: Container(
                                                      child: Row(
                                                        children: [
                                                          Image.network(
                                                            SubCategorieslistdata[
                                                                    "image"]
                                                                .toString(),
                                                            height: 60,
                                                            width: 60,
                                                          ),
                                                          Text(
                                                            "${SubCategoriesdata["name"].toString()}",
                                                            style: TextStyle(
                                                              color: Namecolors,
                                                            ),
                                                          ),
                                                        ],
                                                      ),
                                                    ),
                                                  );
                                                })
                                          ],
                                        ),
                                      );
                                    }),
                              ],
                            ),
                          ),
                        );
                      }),
                ],
              ),
            ),
          );
        }
        // ListView.builder(
        //   itemCount: getcategoriesController.Get_CategoriesData.length,
        //   scrollDirection: Axis.vertical,
        //   shrinkWrap: true,
        //   physics: NeverScrollableScrollPhysics(),
        //   itemBuilder:
        //       (BuildContext context, index) {
        //     var Categorieslistdata = getcategoriesController.Get_CategoriesData[index];
        //     return Padding(
        //       padding:  EdgeInsets.only(left: 10,right: 10,top: 5),
        //       child: Card(
        //         elevation: 2,
        //         child: Row(
        //           children: [
        //             Column(
        //               children: [
        //                 Container(
        //                     height: MediaQuery.of(context).size.height*0.1,
        //                     width: MediaQuery.of(context).size.width*0.2,
        //                     margin:  EdgeInsets.only(left: 10),
        //                     child:
        //                     FinancialAssets_Image       ),
        //               ],
        //             ),
        //
        //             Container(
        //               width: MediaQuery.of(context).size.width*0.5,
        //               margin: EdgeInsets.only(left: 10),
        //               child: Text(
        //                   Categorieslistdata["name"].toString(),
        //                   style: TextStyle(
        //                     // color: Colors.black,
        //                       fontSize: 18)),
        //             ),
        //           ],
        //         ),
        //       ),
        //     );
        //   });
      }),
    );
  }
}
