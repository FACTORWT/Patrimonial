import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:urwealthpal/Constant/Api.dart';
import 'package:urwealthpal/Constant/Images.dart';
import 'package:urwealthpal/Constant/Strings.dart';
import 'package:urwealthpal/Constant/colors.dart';
import 'package:urwealthpal/Screens/Change_Password/Controller/Change_password_Controller.dart';

class Change_Password extends StatefulWidget {
  const Change_Password({Key? key}) : super(key: key);

  @override
  State<Change_Password> createState() => _Change_PasswordState();
}

class _Change_PasswordState extends State<Change_Password> {

  var _formKey = GlobalKey<FormState>();

  ChangePasswordController changePasswordController = Get.put(ChangePasswordController());

  bool old_passToogle = true;
  bool new_passToogle = true;
  bool confrim_passToogles = true;

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Scaffold(
      resizeToAvoidBottomInset: false,
      appBar: AppBar(
        titleSpacing: 0,
        elevation: 0,
        title: Text("ChangePassword".tr),
        backgroundColor: ContainerColor,
      ),
      body: SingleChildScrollView(
        child: Column(
          children: [
            Form(
              key: _formKey,
              child: SingleChildScrollView(
                child: Column(
                  children: [
                    Container(
                        margin: EdgeInsets.only(top: 40),
                        alignment: Alignment.center,
                        width: size.width,
                        child: loginImage),
                    Container(
                      alignment: Alignment.center,
                      width: size.width,
                      child: Text(
                        "ChangePassword".tr,
                        style: TextStyle(
                            color: ContainerColor,
                            fontWeight: FontWeight.bold,
                            fontSize: 32),
                      ),
                    ),
                    Card(
                      clipBehavior: Clip.antiAlias,
                      margin: EdgeInsets.only(top: 30,left: 20,right: 20,bottom: 50),
                      elevation: 2,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(20),
                      ),
                      // padding: EdgeInsets.only(bottom: 50,),
                      child: Container(
                        decoration: BoxDecoration(
                          // color: whiteColor,
                          // border: Border.all(color: w),
                          borderRadius: BorderRadius.all(Radius.circular(20)),
                        ),
                        // // height: size.height,
                        // // height: 400,
                        margin: EdgeInsets.only(left: 15 ,right: 15),
                        padding: EdgeInsets.only(bottom: 50,),
                        child: Column(
                          children: [
                            Padding(
                              padding:  EdgeInsets.only(top: 50,left: 8,right: 8),
                              child: TextFormField(
                                controller: changePasswordController.old_password,
                                autovalidateMode:
                                AutovalidateMode.onUserInteraction,
                                scrollPadding: EdgeInsets.only(
                                    bottom: MediaQuery.of(context).viewInsets.bottom + 25*4),
                                validator: (value) {
                                  if (value == null || value.isEmpty) {
                                    return "valid_old_password_txt".tr;
                                  }
                                  if (value.length < 6) {
                                    return "old_password_txt".tr;
                                  }
                                  return null; // Validation passed
                                },
                                obscureText: old_passToogle,
                                textInputAction: TextInputAction.next,
                                decoration: InputDecoration(
                                  filled: true,
                                  fillColor: whiteColor,
                                  contentPadding: EdgeInsets.only(top: 5),
                                  constraints: BoxConstraints(
                                      minWidth: 30, maxHeight: 70),
                                  border: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(10),
                                  ),
                                  enabledBorder: OutlineInputBorder(
                                      borderRadius: BorderRadius.circular(10),
                                      borderSide: BorderSide(
                                          width: 1, color: Namecolors)),
                                  focusedBorder: OutlineInputBorder(
                                      borderRadius: BorderRadius.circular(10),
                                      borderSide: BorderSide(
                                          width: 1, color: appPrimaryColor)),
                                  focusedErrorBorder: OutlineInputBorder(
                                      borderRadius: BorderRadius.circular(10),
                                      borderSide: BorderSide(
                                          width: 1, color: Colors.redAccent)),
                                  prefixIcon: Container(
                                    // color: Colors.redAccent,
                                      child: Image.asset("assets/images/passIcon.png",
                                        scale: 3,width: 15,)
                                  ),
                                  hintText: "hintoldPassword".tr,
                                  suffixIcon: InkWell(
                                    onTap: () {
                                      setState(() {
                                        old_passToogle = !old_passToogle;
                                      });
                                    },
                                    child: Icon(old_passToogle
                                        ? Icons.visibility_off
                                        : Icons.visibility),
                                  ),
                                ),
                              ),
                            ),
                            SizedBox(
                              height: 15,
                            ),
                            Padding(
                              padding:  EdgeInsets.only(left: 8,right: 8),
                              child: TextFormField(
                                controller: changePasswordController.new_Password,
                                autovalidateMode:
                                AutovalidateMode.onUserInteraction,
                                scrollPadding: EdgeInsets.only(
                                    bottom: MediaQuery.of(context).viewInsets.bottom + 25*4),
                                validator: (value) {
                                  if (value == null || value.isEmpty) {
                                    return "valid_new_password_txt".tr;
                                  }
                                  if (value.length < 6) {
                                    return "old_password_tx".tr;
                                  }
                                  return null; // Validation passed
                                },
                                obscureText: new_passToogle,
                                textInputAction: TextInputAction.next,
                                decoration: InputDecoration(
                                  filled: true,
                                  fillColor: whiteColor,
                                  contentPadding: EdgeInsets.only(top: 5),
                                  constraints: BoxConstraints(
                                      minWidth: 30, maxHeight: 70),
                                  border: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(10),
                                  ),
                                  enabledBorder: OutlineInputBorder(
                                      borderRadius: BorderRadius.circular(10),
                                      borderSide: BorderSide(
                                          width: 1, color: Namecolors)),
                                  focusedBorder: OutlineInputBorder(
                                      borderRadius: BorderRadius.circular(10),
                                      borderSide: BorderSide(
                                          width: 1, color: appPrimaryColor)),
                                  focusedErrorBorder: OutlineInputBorder(
                                      borderRadius: BorderRadius.circular(10),
                                      borderSide: BorderSide(
                                          width: 1, color: Colors.redAccent)),
                                  prefixIcon: Container(
                                    // color: Colors.redAccent,
                                      child: Image.asset("assets/images/passIcon.png",
                                        scale: 3,width: 15,)
                                  ),
                                  hintText: "hintoldPass".tr,
                                  suffixIcon: InkWell(
                                    onTap: () {
                                      setState(() {
                                        new_passToogle = !new_passToogle;
                                      });
                                    },
                                    child: Icon(new_passToogle
                                        ? Icons.visibility_off
                                        : Icons.visibility),
                                  ),
                                ),
                              ),
                            ),

                            SizedBox(
                              height: 15,
                            ),

                            Padding(
                              padding:  EdgeInsets.only(left: 8,right: 8),
                              child: TextFormField(
                                controller: changePasswordController.confim_new_Password,
                                autovalidateMode:
                                AutovalidateMode.onUserInteraction,
                                scrollPadding: EdgeInsets.only(bottom:40),
                                validator: (value) {
                                  if (value!.isEmpty) {
                                    return "valid_cofirm_password_txt".tr;
                                  } else if (changePasswordController.new_Password.text !=
                                      changePasswordController.confim_new_Password.text) {
                                    return "confirm_password_tx".tr;
                                  } else
                                    return null;
                                },
                                obscureText: confrim_passToogles,
                                textInputAction: TextInputAction.done,
                                decoration: InputDecoration(
                                  filled: true,
                                  fillColor: whiteColor,
                                  contentPadding: EdgeInsets.only(top: 5),
                                  constraints: BoxConstraints(
                                      minWidth: 30, maxHeight: 70),
                                  border: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(10),
                                  ),
                                  enabledBorder: OutlineInputBorder(
                                      borderRadius: BorderRadius.circular(10),
                                      borderSide: BorderSide(
                                          width: 1, color: Namecolors)),
                                  focusedBorder: OutlineInputBorder(
                                      borderRadius: BorderRadius.circular(10),
                                      borderSide: BorderSide(
                                          width: 1, color: appPrimaryColor)),
                                  focusedErrorBorder: OutlineInputBorder(
                                      borderRadius: BorderRadius.circular(10),
                                      borderSide: BorderSide(
                                          width: 1, color: Colors.redAccent)),
                                  prefixIcon: Container(
                                    // color: Colors.redAccent,
                                      child: Image.asset("assets/images/passIcon.png",
                                        scale: 3,width: 15,)
                                  ),
                                  hintText: "hint_confrim_Password".tr,
                                  suffixIcon: InkWell(
                                    onTap: () {
                                      setState(() {
                                        confrim_passToogles = !confrim_passToogles;
                                      });
                                    },
                                    child: Icon(confrim_passToogles
                                        ? Icons.visibility_off
                                        : Icons.visibility),
                                  ),
                                ),
                              ),
                            ),

                            SizedBox(
                              height: 40,
                            ),
                            GestureDetector(
                              onTap: () {
                                if (_formKey.currentState!.validate()) {
                                  var changePassword_url = change_password_url;
                                  var body =
                                  {
                                    'old_password': changePasswordController
                                        .old_password.text,
                                    'password': changePasswordController
                                        .new_Password.text,
                                    'password_confirmation':
                                        changePasswordController
                                            .confim_new_Password.text
                                  };
                                  changePasswordController.ChangePasswordApiCalling(
                                      changePassword_url, body);
                                }
                              },
                              child: Container(
                                height: 40,
                                width: 150,
                                decoration: BoxDecoration(
                                    color: buttonColor,
                                    border: Border.all(
                                      color: buttonColor,
                                    ),
                                    borderRadius: BorderRadius.all(
                                        Radius.circular(12))),
                                child: Center(
                                  child: Text(
                                    "submitBtn".tr,
                                    style: TextStyle(
                                        color: whiteColor,
                                        fontSize: 16,
                                        fontWeight: FontWeight.bold),
                                  ),
                                ),
                              ),
                            ),

                          ],
                        ),
                      ),
                    )
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
