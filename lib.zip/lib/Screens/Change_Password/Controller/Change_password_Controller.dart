import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:urwealthpal/Constant/Api.dart';
import 'package:urwealthpal/Constant/ApiBaseHelper.dart';

class ChangePasswordController extends GetxController{
  var ChangePasswordLoading = false.obs;
  var ChangePasswordNData ;

  TextEditingController old_password = TextEditingController();
  TextEditingController new_Password = TextEditingController();
  TextEditingController confim_new_Password = TextEditingController();

  ChangePasswordApiCalling(url, parameter) async {
    ChangePasswordLoading.value =true;
    print("change password " + url.toString());
    var response = await ApiBaseHelper().postAPICall(Uri.parse(url), parameter, true);
    var responsedata = jsonDecode(response.body);
    if(response.statusCode==200){
      ChangePasswordNData = responsedata['message'];
      var msg = ChangePasswordNData.toString();
      toastMsg(msg, true);
      Get.back();
      old_password.clear();
      new_Password.clear();
      confim_new_Password.clear();
      ChangePasswordLoading.value =false;
      update();
    }else if(response.statusCode==422) {
        ChangePasswordNData = responsedata['message'];
        var msg = ChangePasswordNData.toString();
        toastMsg(msg, false);
        ChangePasswordLoading.value = false;
        update();
      } else
        ChangePasswordNData =[];
      ChangePasswordLoading.value =false;
      update();
    }
  }


