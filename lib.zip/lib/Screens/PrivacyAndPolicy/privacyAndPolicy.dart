import 'package:flutter/material.dart';
import 'package:flutter_html/flutter_html.dart';
import 'package:get/get.dart';
import 'package:urwealthpal/Constant/Api.dart';
import 'package:urwealthpal/Constant/Strings.dart';
import 'package:urwealthpal/Constant/colors.dart';
import 'package:urwealthpal/Screens/PrivacyAndPolicy/controller/privacyPolicyController.dart';

class privacyAndpolicy extends StatefulWidget {
  const privacyAndpolicy({Key? key}) : super(key: key);

  @override
  State<privacyAndpolicy> createState() => _privacyAndpolicyState();
}

class _privacyAndpolicyState extends State<privacyAndpolicy> {
  var privacypolicycontroller =Get.put(PrivacyPolicyController());
  List privacy = [
    {
      "text": "Lorem ipsum is simple dummy text.",
    },
    {
      "text": "Lorem ipsum is simple dummy text of the printing and typesetting industry.",
    },
    {
      "text": "Lorem ipsum is simple dummy text.",
    },
    {
      "text": "Lorem ipsum is simple dummy text.",
    },
    {
      "text": "Lorem ipsum is simple dummy text.",
    },
    {
      "text": "Lorem ipsum is simple dummy text.",
    },
    {
      "text": "Lorem ipsum is simple dummy text.",
    },
    {
      "text": "Lorem ipsum is simple dummy text.",
    },
    {
      "text": "Lorem ipsum is simple dummy text.",
    },
  ];

  @override
  void initState() {
    // TODO: implement initState
    privacypolicycontroller.Aboutfetch("${cms_url}2");
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return RefreshIndicator(
      onRefresh: ()async{
        await PrivacyPolicyController();
        await Future.delayed(Duration(milliseconds: 1500));
      },
      child: Scaffold(
        appBar: AppBar(
          elevation: 0,
          titleSpacing: 0,
          backgroundColor: ContainerColor,
          title: Text("privacy_policy_txt".tr),
        ),
        body: GetBuilder<PrivacyPolicyController>(
          builder: (privacypolicycontroller) {
            if(privacypolicycontroller.load.value){
              return Center(child: CircularProgressIndicator());
            }
            else
            return SingleChildScrollView(
              child: Column(children: [
                Padding(
                  padding:  EdgeInsets.only(left: 10,right: 10),
                  child: Html(data: privacypolicycontroller.privacyPolicydata['cms_contant'],),
                ),
                // ListView.builder(
                //     itemCount: privacy.length,
                //     scrollDirection: Axis.vertical,
                //     shrinkWrap: true,
                //     physics: NeverScrollableScrollPhysics(),
                //     itemBuilder: (BuildContext context, index) {
                //       var listdata = privacy[index];
                //       return Padding(
                //         padding: EdgeInsets.fromLTRB(10, 2, 10, 0),
                //         child: Column(
                //           children: [
                //             Row(
                //               children: [
                //                 Text(
                //                   '\u2022',
                //                   style: TextStyle(color: greyColor),
                //                 ),
                //                 SizedBox(
                //                   width: 10,
                //                 ),
                //                 Expanded(
                //                   child: Text(
                //                     listdata['text'].toString(),
                //                     textAlign: TextAlign.justify,
                //                     style: TextStyle(color: greyColor),
                //                   ),
                //                 )
                //               ],
                //             ),
                //           ],
                //         ),
                //       );
                //     }),
                // Padding(
                //   padding:  EdgeInsets.fromLTRB(10, 20, 10, 20),
                //   child: Text(bottom_text,
                //     textAlign: TextAlign.justify,
                //     style: TextStyle(color: greyColor),
                //   ),
                // ),
              ]),
            );
          }
        ),
      ),
    );
  }
}
