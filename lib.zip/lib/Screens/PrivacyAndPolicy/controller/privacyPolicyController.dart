import 'dart:convert';
import 'package:get/get.dart';
import 'package:urwealthpal/Constant/ApiBaseHelper.dart';

class PrivacyPolicyController extends GetxController{
  var load = false.obs;
  var privacyPolicydata ;
  Aboutfetch(url) async {
    load.value =true;

    print("cmsurl : " + url.toString());
    var response = await ApiBaseHelper().getAPICall(Uri.parse(url), true);
    var responsedata = jsonDecode(response.body);
    if(response.statusCode==200){
      privacyPolicydata = responsedata['data'];
      load.value =false;
      update();
    }else{
      privacyPolicydata =[];
      load.value =false;
      update();
    }
  }

}