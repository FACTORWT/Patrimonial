import 'dart:convert';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:urwealthpal/Constant/colors.dart';
import 'package:urwealthpal/main.dart';
import 'package:video_player/video_player.dart';

class VideoPlayerScreen extends StatefulWidget {
  var videourl;
  // double width;
  VideoPlayerScreen(this.videourl,
      // this.width
      );
  @override
  State<StatefulWidget> createState() {
    return _VideoPlayerState();
  }
}

class _VideoPlayerState extends State<VideoPlayerScreen> {
   VideoPlayerController? _controller;
  late Future<void> _initializeVideoPlayerFuture;
  Future<ClosedCaptionFile> _loadCaptions() async {
    final String fileContents = await DefaultAssetBundle.of(context)
        .loadString('assets/bumble_bee_captions.vtt');
    return WebVTTCaptionFile(
        fileContents); // For vtt files, use WebVTTCaptionFile
  }

   var setting_json_data;

  @override
  void initState() {
    super.initState();
    setting_json_data = jsonDecode(sp!.getString("setting").toString());
    print("setting data....." + setting_json_data['data']["welome_text"].toString());

    // _controller =  VideoPlayerController.networkUrl(
    //   Uri.parse('https://technolite.in/staging/urpayroll/public/uploads/setting/170030689847.mp4'),
    //   videoPlayerOptions: VideoPlayerOptions(mixWithOthers: true),
    // );
    // _controller!.addListener(() {
    //   setState(() {});
    // });
    // _controller!.setLooping(true);
    // _controller!.initialize();
    getvideo();

    // if (widget.boolvalue == true) {
    //   _controller.play();
    // } else {
    //   _controller.pause();
    // }
  }
getvideo()async{
  _controller =  VideoPlayerController.network(
    // widget.videourl,
    //   'https://flutter.github.io/assets-for-api-docs/assets/videos/bee.mp4',
    // Uri.parse(),
    //   'https://technolite.in/staging/urpayroll/public/uploads/setting/170030689847.mp4',
      "https://player.vimeo.com/external/464508537.sd.mp4?s=206f33573237e20f260d4474ec6ce2957ed9ae8e&profile_id=165&oauth2_token_id=57447761",

    videoPlayerOptions: VideoPlayerOptions(mixWithOthers: true),
  ) ..initialize().then((_) {
    setState(() {});
    _controller!.play();
  });
  // _initializeVideoPlayerFuture =
  //   _controller.initialize();
  _controller!.addListener(() {
    setState(() {});
  });
  _controller!.setLooping(true);
 await  _controller!.initialize();
  // _controller.play();
}
  @override
  void dispose() {
    _controller!.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Scaffold(
      body: Stack(
        clipBehavior: Clip.hardEdge,
        children: [
          Container(
              height: size.height,
              // height: 500,
              width: size.width,
              padding: EdgeInsets.all(0.0),
              color: Colors.white,
              alignment: Alignment.center,
              child: _controller!.value.isInitialized
                  ? Container(
                padding: EdgeInsets.all(0.0),
                child: SizedBox(
                  height: size.height,
                  width: size.width,
                  child: AspectRatio(

                      aspectRatio: _controller!.value.aspectRatio,
                      child: VideoPlayer(_controller!)),
                ),
              )
                  : Center(child: Container(),)
          ),


          Container(
            height: size.height,
            width: size.width,
            color: Colors.grey.withOpacity(0.6),
          ),

          Positioned(
            right: 0,
            child: Container(
              height: 100,
              width: 120,
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.bottomCenter,
                  end: Alignment.topLeft,
                  stops: [0.1, 0.5, 0.8, 0.9,],
                  colors: [
                    // ContainerColor.withOpacity(0.4),
                    // appBarColor.withOpacity(0.5),
                    // buttonColor.withOpacity(0.5),
                    // appPrimaryColor.withOpacity(0.4),

                    ContainerColor.withOpacity(0.9),
                    appBarColor.withOpacity(0.8),
                    blueColor.withOpacity(0.8),
                    appPrimaryColor.withOpacity(0.9)
                  ],
                ),
                borderRadius: BorderRadius.only(
                  bottomLeft: Radius.circular(120),
                ),
              ),
              child: Center(
                  child:
                  Text("Skip",
                    style: TextStyle(
                      color: whiteColor,
                      fontSize: 24,
                      // fontWeight: FontWeight.w600
                    ),)),
            ),
          ),

          Positioned(
              top: size.height*0.6,
              left: size.width*0.1,
              right: size.width*0.1,
            child: Container(
              decoration: BoxDecoration(
                color: Colors.transparent,
                ),
              child: Text(setting_json_data['data']['welome_text'].toString(),
                textAlign: TextAlign.justify,
                style: TextStyle(
                    color: whiteColor
                ),
              ),
            ),
          ),

          // Text("Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. ",
          //   textAlign: TextAlign.justify,
          //   style: TextStyle(
          //     color: whiteColor
          //   ),
          // ),

          // Positioned(
          //   top: size.height * 0.5,
          //   left: size.height * 0.2,
          //   right: size.height * 0.2,
          //   child: FloatingActionButton(
          //     backgroundColor: Colors.grey.withOpacity(0.5),
          //     onPressed: () {
          //       setState(() {
          //         // pause
          //         if (_controller!.value.isPlaying) {
          //           _controller!.pause();
          //         } else {
          //         //   // play
          //           _controller!.play();
          //         }
          //       });
          //     },
          //     // icon
          //     // child: Text("Lorem Ipsum is simply dummy text of the printing and \n\t typesetting industry. Lorem Ipsum has been the industry's\n\t standard dummy text ever since the 1500s, when an\n\t unknown printer took a galley of type and scrambled it\n\t to make a type specimen book. It has survived not only\n\t five centuries, but also the leap into electronic typesetting,\n\t remaining essentially unchanged. ")
          //
          //    child: Icon(
          //       _controller!.value.isPlaying ? Icons.pause : Icons.play_arrow,
          //     ),
          //   ),
          // ),

          Positioned(
            bottom:120,
            left: 20,
            right: 20,
            child: GestureDetector(
              onTap: (){
                // Navigator.push(context,
                //     MaterialPageRoute(builder: (context) => ImageScreen()
                //     ));
              },
              child: Container(
                height: 50,
                // width: 150,
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.bottomCenter,
                    end: Alignment.topLeft,
                    stops: [0.1, 0.5, 0.8, 0.9,],
                    colors: [
                      // ContainerColor.withOpacity(0.4),
                      // appBarColor.withOpacity(0.5),
                      // buttonColor.withOpacity(0.5),
                      // appPrimaryColor.withOpacity(0.4),

                      ContainerColor.withOpacity(0.9),
                      appBarColor.withOpacity(0.8),
                      blueColor.withOpacity(0.8),
                      appPrimaryColor.withOpacity(0.9)
                    ],
                  ),
                  borderRadius: BorderRadius.all(Radius.circular(5),
                  ),
                ),
                child: Center(
                    child:
                    Text("NEXT",
                      style: TextStyle(
                        color: whiteColor,
                        fontSize: 24,
                        // fontWeight: FontWeight.w600
                      ),)),
              ),
            ),
          ),
        ],
      ),
    );
  }
}