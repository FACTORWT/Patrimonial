import 'dart:convert';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:urwealthpal/BottomBar/bottombar.dart';
import 'package:urwealthpal/Constant/Api.dart';
import 'package:urwealthpal/Constant/ApiBaseHelper.dart';
import 'package:urwealthpal/Constant/colors.dart';
import 'package:urwealthpal/Environment/Environment.dart';
import 'package:urwealthpal/Screens/Login/login.dart';
import 'package:urwealthpal/Screens/WelcomeScreens/WelcomController.dart';
import 'package:urwealthpal/main.dart';
import 'package:video_player/video_player.dart';

class WelcomeImage extends StatefulWidget {
  var imageurl;
  WelcomeImage(this.imageurl);

  @override
  State<WelcomeImage> createState() => _WelcomeImageState();
}

class _WelcomeImageState extends State<WelcomeImage> {


  var setting_json_data;

  @override
  void initState() {
    super.initState();
    setting_json_data = jsonDecode(sp!.getString("setting").toString());
  }

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Scaffold(
      body: GetBuilder<WelcomeController>(
        builder: (welcomeController) {
          return Stack(
            children: [
              Positioned(
                right: 0,
                child: GestureDetector(
                  onTap: (){

                    ApiBaseHelper().manageroute();
                    welcomeController.stopVideo();


                  },
                  child: Container(
                    height: 100,
                    width: 120,
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.bottomCenter,
                        end: Alignment.topLeft,
                        stops: [0.1, 0.5, 0.8, 0.9,],
                        colors: [
                          ContainerColor.withOpacity(0.9),
                          appBarColor.withOpacity(0.8),
                          blueColor.withOpacity(0.8),
                          appPrimaryColor.withOpacity(0.9)
                        ],
                      ),
                      borderRadius: BorderRadius.only(
                        bottomLeft: Radius.circular(120),
                      ),
                    ),
                    child: Center(
                        child:
                        Text("NEXT",
                          style: TextStyle(
                            color: whiteColor,
                            fontSize: 18,
                            // fontWeight: FontWeight.w600
                          ),)),
                  ),
                ),
              ),

              Positioned(
                top: 100,
                right: 20,
                left: 20,
                child: Column(
                  children: [
                    Text("Welcome",textAlign: TextAlign.center,
                      style: TextStyle(
                          color: greyColor,
                          fontSize: 22,
                          fontWeight: FontWeight.w600
                      ),),
                    SizedBox(height: 25,),
                    Builder(
                      builder: (context) {
                        return setting_json_data['data']["welcome_video_show"].toString()=="1"?
                        Container(
                          height: 250,
                          width: size.width-10,
                          // child: Text("casds"),
                          child: AnimatedOpacity(
                            opacity:  1.0 ,
                            duration: Duration(milliseconds: 1000),
                            child: Container(

                                height: MediaQuery.of(context).size.height ,
                                width: MediaQuery.of(context).size.width,
                                // width: widget.width,
                                padding: EdgeInsets.all(0.0),
                                color: Colors.white,
                                alignment: Alignment.center,
                                child:welcomeController.controller!.value.isInitialized
                                    ? Container(
                                  padding: EdgeInsets.all(0.0),
                                  child: VideoPlayer(welcomeController.controller!),
                                )
                                    : Center(child: Container(),)
                            ),
                          ),
                        ) :

                        Container(
                          width: size.width-10,
                          height: 180.0,
                          color: Colors.white,
                          child: CachedNetworkImage(
                            imageUrl:  setting_json_data['data']["welcome_image"].toString(),
                            width: size.width,
                            height: size.height,
                            fit: BoxFit.cover,
                            progressIndicatorBuilder: (context, url, downloadProgress) =>
                                Center(child: CircularProgressIndicator(value: downloadProgress.progress,color: Colors.white,)),
                            errorWidget: (context, url, error) => Center(child: Icon(Icons.image_outlined,size: 60,color: Colors.grey,)),
                          ),
                        );
                      }
                    ),

                    // Container(
                    //   height: 250,
                    //   width: 250,
                    //   decoration: BoxDecoration(
                    //       color: Colors.grey.withOpacity(0.6),
                    //       image: DecorationImage(image: setting_json_data['data']["welcome_image"].toString() == "" ?
                    //           AssetImage("assets/image/splash_logo") as ImageProvider
                    //           : NetworkImage(setting_json_data['data']["welcome_video_show"].toString(),)
                    //       )
                    //       // image: DecorationImage(
                    //       //     image: setting_json_data['data']["welcome_video_show"].toString() == "0"
                    //       //         ? setting_json_data['data']["welcome_image"].toString() == ""
                    //       //         ?AssetImage("assets/images/welcome.png",) as ImageProvider
                    //       //         :NetworkImage(setting_json_data['data']["welcome_image"].toString(),):
                    //       //     AssetImage("assets/images/welcome.png",) as ImageProvider,
                    //       //     fit: BoxFit.fill
                    //       // )
                    //   ),
                    // ),
                    SizedBox(height: 25,),
                    Text(setting_json_data['data']['welome_title'].toString(),
                      textAlign: TextAlign.justify,
                      style: TextStyle(
                          color: greyColor,
                          fontSize: 22,
                          fontWeight: FontWeight.w600
                      ),
                    ),
                    SizedBox(height: 25,),
                    Text(setting_json_data['data']['welome_text'].toString(),
                      textAlign: TextAlign.justify,
                      style: TextStyle(
                          color: greyColor
                      ),
                    ),
                  ],
                ),
              ),
            ],
          );
        }
      ),
    );
  }
}
