import 'dart:developer';
import 'package:get/get.dart';
import 'package:video_player/video_player.dart';

class WelcomeController extends GetxController{
  var videourl ="".obs;
  VideoPlayerController? controller;
  Future<void> ?_initializeVideoPlayerFuture;

  callingvideo(){
    controller = VideoPlayerController.network(
      videourl.value ,
      //   'https://flutter.github.io/assets-for-api-docs/assets/videos/bee.mp4',
      //       'https://technolite.in/staging/urpayroll/public/uploads/setting/170030689847.mp4',
      // 'https://adiyogifintech.com/finserv/storage/tutorial/1701235101_4116.mp4'

      videoPlayerOptions: VideoPlayerOptions(mixWithOthers: true),
    ) ;
    _initializeVideoPlayerFuture = controller!.initialize();
    controller!.addListener(() {
     update();
    });
    controller!.setLooping(true);

    controller!.play();
    update();
  }
  setvideo(url) async {
    videourl.value =url;
    log("videourl.value : "+videourl.value.toString());
   await callingvideo();
    update();
  }
  stopVideo() async {
    controller!.pause();
    update();
  }
  playVideo() async {
    controller!.play();
    update();
  }
}