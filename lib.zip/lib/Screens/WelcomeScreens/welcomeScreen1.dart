import 'dart:convert';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:urwealthpal/Constant/colors.dart';
import 'package:urwealthpal/Screens/WelcomeScreens/WelcomController.dart';
import 'package:urwealthpal/Screens/WelcomeScreens/welcomeScreen2.dart';
import 'package:urwealthpal/main.dart';

class VideoScreen extends StatefulWidget {

  VideoScreen();
  @override
  State<StatefulWidget> createState() {
    return _VideoScreenState();
  }
}

class _VideoScreenState extends State<VideoScreen> {

  var setting_json_data;

  @override
  void initState() {
    super.initState();
    setting_json_data = jsonDecode(sp!.getString("setting").toString());
    print("setting data....." + setting_json_data['data']["welcome_video"].toString());

    // getvideo();
  }

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Scaffold(
      body: Stack(
        clipBehavior: Clip.hardEdge,
        children: [
          setting_json_data['data']["app_video"].toString()==""?
          Container():
          Container(

            child: CachedNetworkImage(
              imageUrl: setting_json_data['data']["app_video"].toString(),
              width: size.width,
              height: size.height,
              fit: BoxFit.fitHeight,
              progressIndicatorBuilder: (context, url, downloadProgress) =>
                  Center(child: CircularProgressIndicator(value: downloadProgress.progress,color: Colors.white,)),
              errorWidget: (context, url, error) => Center(child: Icon(Icons.image_outlined,size: 60,color: Colors.grey,)),
            ),
          ),
          // Container(
          //     height: size.height,
          //     // height: 500,
          //     width: size.width,
          //     padding: EdgeInsets.all(0.0),
          //     color: Colors.white,
          //     alignment: Alignment.center,
          //     child: CachedNetworkImage(imageUrl: setting_json_data['data']["app_video"].toString(),)
          //   // _controller!.value.isInitialized
          //   //     ? Container(
          //   //   padding: EdgeInsets.all(0.0),
          //   //   child: Image.network(setting_json_data['data']["app_video"].toString())
          //   //   // VideoPlayer(_controller!),
          //   // )
          //   //     : Center(child: Container(),)
          // ),

          // Container(
          //   height: size.height,
          //   width: size.width,
          //   color: Colors.grey.withOpacity(0.6),
          // ),

          Positioned(
            right: 0,
            child: GestureDetector(
              onTap: (){
                Get.find<WelcomeController>().playVideo();
                Get.to(WelcomeImage(""));
              },
              child: Container(
                height: 100,
                width: 120,
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.bottomCenter,
                    end: Alignment.topLeft,
                    stops: [0.1, 0.5, 0.8, 0.9,],
                    colors: [
                      ContainerColor.withOpacity(0.9),
                      appBarColor.withOpacity(0.8),
                      blueColor.withOpacity(0.8),
                      appPrimaryColor.withOpacity(0.9)
                    ],
                  ),
                  borderRadius: BorderRadius.only(
                    bottomLeft: Radius.circular(120),
                  ),
                ),
                child: Center(
                    child:
                    Text("NEXT",
                      style: TextStyle(
                        color: whiteColor,
                        fontSize: 18,
                        // fontWeight: FontWeight.w600
                      ),)),
              ),
            ),
          ),

        ],
      ),
    );
  }
}