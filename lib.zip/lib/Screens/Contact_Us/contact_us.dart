import 'dart:convert';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:maps_launcher/maps_launcher.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:urwealthpal/Constant/ApiBaseHelper.dart';
import 'package:urwealthpal/Constant/Images.dart';
import 'package:urwealthpal/Constant/colors.dart';
import 'package:urwealthpal/Environment/Environment.dart';
import 'package:urwealthpal/main.dart';

class contact_us extends StatefulWidget {
  const contact_us({Key? key}) : super(key: key);

  @override
  State<contact_us> createState() => _contact_usState();
}

class _contact_usState extends State<contact_us> {
  // var lat = 27.399728;
  // var long = 74.570188;
  // RequestFunction().launchMap(lat, long);

  var setting_json_data;

  Future<void> _makePhoneCall(String phoneNumber) async {
    final Uri launchUri = Uri(
      scheme: 'tel',
      path: phoneNumber,
    );
    await launchUrl(launchUri);
  }
var perentId;
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    setting_json_data = json.decode(sp!.getString("setting").toString());
    print("check data" + setting_json_data['data'].toString());
    perentId = Environment.parentID;
    print("perentId--->>"+perentId.toString());
  }

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return RefreshIndicator(
      onRefresh: () async {
        await setting_json_data();
        await Future.delayed(Duration(milliseconds: 1500));
      },
      child: Scaffold(
         appBar:  perentId.toString() == "0" ?AppBar(
          elevation: 0,
           titleSpacing: 0,
          backgroundColor: ContainerColor,
          title: Text("contactUs_txt".tr),

        ):PreferredSize(preferredSize: Size(0.0, 0.0),child: Container(),),

        body: (
            SingleChildScrollView(
          child: Container(
            // height: size.height,
            width: size.width,
            // color:  buttonColor,
            child: Column(
              children: [
                Center(
                    child: Container(
                      padding: EdgeInsets.all(25),
                      margin:EdgeInsets.all(10.0),
                        width: size.width,
                        decoration: BoxDecoration(
                            border: Border.all(
                              color: ContainerColor,
                            ),
                            borderRadius: BorderRadius.circular(5),
                            color: ContainerColor,
                            boxShadow: [
                              BoxShadow(
                                color: greyColor,
                                blurRadius: 3.0,
                              )
                            ]
                        ),
                        child: CachedNetworkImage(imageUrl: setting_json_data['data']['admin_logo'].toString(),))
                    // ContactUsLogo
                    ),
                // GestureDetector(
                //   onTap: () {
                //     _makePhoneCall(
                //         setting_json_data['data']['phone'].toString());
                //   },
                //   child: Padding(
                //     padding: EdgeInsets.all(10.0),
                //     child: Container(
                //       height: 130,
                //       width: size.width,
                //       decoration: BoxDecoration(
                //           border: Border.all(
                //             color: ContainerColor,
                //           ),
                //           borderRadius: BorderRadius.circular(5),
                //           color: ContainerColor,
                //           boxShadow: [
                //             BoxShadow(
                //               color: greyColor,
                //               blurRadius: 3.0,
                //             )
                //           ]),
                //       child: Column(
                //         mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                //         children: [
                //           Icon(
                //             Icons.call,
                //             size: 40,
                //             color: whiteColor,
                //           ),
                //           Text(
                //             phone,
                //             style: TextStyle(
                //                 color: whiteColor,
                //                 fontSize: 18,
                //                 fontWeight: FontWeight.bold),
                //           ),
                //           Text(
                //             (setting_json_data['data']['phone'].toString()),
                //             // phoneNo_txt,
                //             style: TextStyle(
                //               color: whiteColor,
                //               fontSize: 18,
                //             ),
                //           )
                //         ],
                //       ),
                //     ),
                //   ),
                // ),
                GestureDetector(
                  onTap: () {
                    launch(
                        'mailto:${setting_json_data['data']['email'].toString()}'
                        '?subject=This is Subject Title&body=This is Body of Email');
                  },
                  child: Container(
                    // height: 130,
                    padding: EdgeInsets.all(20),
                    margin:EdgeInsets.all(10.0),
                    width: size.width,
                    decoration: BoxDecoration(
                        border: Border.all(
                          color: ContainerColor,
                        ),
                        borderRadius: BorderRadius.circular(5),
                        color: ContainerColor,
                        boxShadow: [
                          BoxShadow(
                            color: greyColor,
                            blurRadius: 3.0,
                          )
                        ]),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        Icon(
                          Icons.email_outlined,
                          size: 40,
                          color: whiteColor,
                        ),
                        Text(
                          "Email".tr,
                          style: TextStyle(
                              color: whiteColor,
                              fontSize: 18,
                              fontWeight: FontWeight.bold),
                        ),
                        Text(
                          (setting_json_data['data']['email'].toString()),
                          // email_txt,
                          style: TextStyle(
                            color: whiteColor,
                            fontSize: 18,
                          ),
                        )
                      ],
                    ),
                  ),
                ),
                GestureDetector(
                  onTap: () {
                    MapsLauncher.launchQuery(setting_json_data['data']['address'].toString());
                  },
                  child: Container(
                    // height: 130,
                    padding: EdgeInsets.all(20),
                    margin:EdgeInsets.all(10.0),
                    width: size.width,
                    decoration: BoxDecoration(
                        border: Border.all(
                          color: ContainerColor,
                        ),
                        borderRadius: BorderRadius.circular(5),
                        color: ContainerColor,
                        boxShadow: [
                          BoxShadow(
                            color: greyColor,
                            blurRadius: 3.0,
                          )
                        ]),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      children: [
                        Icon(
                          Icons.location_on_outlined,
                          size: 40,
                          color: whiteColor,
                        ),
                        Text(
                          "address".tr,
                          style: TextStyle(
                              color: whiteColor,
                              fontSize: 18,
                              fontWeight: FontWeight.bold),
                        ),
                        Text(
                            (setting_json_data['data']['address'].toString()),
                          textAlign: TextAlign.center,
                          // "xxxxxxxxxxxxxx",
                          style: TextStyle(
                            color: whiteColor,
                            fontSize: 16,
                          ),
                        )
                      ],
                    ),
                  ),
                ),
                Padding(
                  padding: EdgeInsets.only(top: 20),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: [
                      GestureDetector(
                        onTap: () {
                          launch(
                              '${setting_json_data['data']['facebook_link'].toString()}');
                        },
                        child: FaceBookIcon,
                      ),
                      GestureDetector(
                          onTap: () {
                            launch(
                                '${setting_json_data['data']['linkedin_link'].toString()}');
                          },
                          child: LinkdInIcon),
                      GestureDetector(
                          onTap: () {
                            launch(
                                '${setting_json_data['data']['twitter_link'].toString()}');
                          },
                          child: TwitterIcon),
                      GestureDetector(
                        onTap: () {
                          // MapsLauncher.launchQuery(setting_json_data['data']['google_location'].toString());
                          launch('${setting_json_data['data']['google_location'].toString()}');

                        },
                        child: GoogleIcon,
                      ),
                      GestureDetector(
                        onTap: () {

                          launch('${setting_json_data['data']['instagram_link'].toString()}');

                        },
                        child: InstagramIcon,
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        )),
      ),
    );
  }
}
