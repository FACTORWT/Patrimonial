import 'dart:convert';
import 'dart:developer';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:image_cropper/image_cropper.dart';
import 'package:image_picker/image_picker.dart';
import 'package:urwealthpal/Constant/ApiBaseHelper.dart';
import 'package:urwealthpal/Constant/colors.dart';
import 'package:urwealthpal/main.dart';

class GetProfileController extends GetxController{
  var getProfile_loading = false.obs;
  List getProfiledata  = [] ;
  var image ;
  var toggleOn ;
  TextEditingController userName = TextEditingController();
  TextEditingController email = TextEditingController();
  TextEditingController mobile = TextEditingController();
  TextEditingController password = TextEditingController();
  TextEditingController change_password = TextEditingController();
  TextEditingController country = TextEditingController();
  // TextEditingController state = TextEditingController();
  // TextEditingController city = TextEditingController();
  TextEditingController pincode = TextEditingController();
  TextEditingController address = TextEditingController();

  var SelectedCountryName,
      SelectedCountryId;
      // SelectedStateName,
      // SelectedStateId,
      // SelectedCityName,
      // SelectedCityId;


  // XFile? file;
  //
  // imagenull(){
  //   file = null;
  // }
  //
  // dynamic pickImage(ImageSource) async {
  //
  //   XFile? pickedFile = await ImagePicker().pickImage(source: ImageSource.gallery);
  //
  //   if(pickedFile != null) {
  //     CroppedFile? cropFile = await ImageCropper().cropImage(
  //         sourcePath: pickedFile.path,
  //       aspectRatioPresets: [
  //         CropAspectRatioPreset.original,
  //         CropAspectRatioPreset.ratio5x4,
  //         CropAspectRatioPreset.ratio3x2,
  //       ],
  //       uiSettings: [
  //         AndroidUiSettings(
  //           backgroundColor: ContainerColor,
  //           initAspectRatio:  CropAspectRatioPreset.original,
  //         )
  //       ]
  //     );
  //
  //     file = XFile(cropFile!.path);
  //
  //   }
  //
  // }


  File ?pickfile;
  imagenull(){
    pickfile=null;
  }

  Future getFromGallery() async {
    XFile? pickedFile = await ImagePicker().pickImage(
        source: ImageSource.gallery,
        maxWidth: 1800,
        maxHeight: 1800,
        imageQuality: 100);
    if (pickedFile != null) {
      sp?.setString('imageselection','true');
      String? imageSelection = sp?.getString('imageselection');
      log('Image selection: $imageSelection');
        CroppedFile? cropFile = await ImageCropper().cropImage(
                sourcePath: pickedFile.path,
              aspectRatioPresets: [
                CropAspectRatioPreset.original,
                CropAspectRatioPreset.ratio3x2,
                CropAspectRatioPreset.ratio4x3,
                CropAspectRatioPreset.ratio5x3,
                CropAspectRatioPreset.ratio5x4,
                CropAspectRatioPreset.ratio7x5,
                CropAspectRatioPreset.ratio16x9,
                CropAspectRatioPreset.square
              ],
                uiSettings: [
                  AndroidUiSettings(
                    toolbarTitle: 'Crop Image',
                    toolbarColor: ContainerColor,
                    cropFrameColor: ContainerColor,
                    backgroundColor: ContainerColor,
                    activeControlsWidgetColor: ContainerColor,
                    cropGridColor: ContainerColor,
                    toolbarWidgetColor: Colors.white,
                    initAspectRatio: CropAspectRatioPreset.original,
                    lockAspectRatio: false,
                  ),
    ]
      );
      // pickfile = File(cropFile!.path);
      pickfile = File(cropFile!.path);
      update();
      refresh();
      print("pick file form gellary" + pickfile.toString());
    }else{
      sp?.setString('imageselection','false');
      String? imageSelection = sp?.getString('imageselection');
      log('Image selection: $imageSelection');
    }
  }

  GetProfileApiCalling(url) async {
    getProfile_loading.value =true;
    log("2");
    var response = await ApiBaseHelper().getAPICall(Uri.parse(url), true);

    var responsedata = jsonDecode(response.body);

    if(response.statusCode.toString()== "200"){
      getProfiledata.clear();
      getProfiledata.add(responsedata['data']);
      log("getProfiledata : " + getProfiledata[0]['name'].toString());
      userName.text= responsedata['data']['name'].toString();
      email.text= responsedata['data']['email'].toString();
      mobile.text= responsedata['data']['mobile'].toString();
      country.text= responsedata['data']['country_name'].toString();
      // state.text= responsedata['data']['state_name'].toString();
      // city.text= responsedata['data']['city_name'].toString();
      getProfile_loading.value =false;
print("object.......${responsedata['data']['name']}");

      pincode.text= responsedata['data']['pincode'].toString();
      address.text= responsedata['data']['address'] == null?"":responsedata['data']['address'].toString();
      image = responsedata['data']['image'].toString();
      toggleOn = responsedata['data']['mpin_status'].toString();
      sp!.setString("ask_mpin",toggleOn.toString());
      sp!.setString("imagee",  responsedata['data']['image']);
      sp!.setString("namee",  responsedata['data']['name']);
      sp!.setString("mobilenum",responsedata['data']['mobile']);
      sp!.setString("email", responsedata['data']['email']);
      log("3");
      print("profile responsecvxhnd : " + image.toString());
      update();
    }else{
      getProfiledata =[];
      getProfile_loading.value =false;
      update();
    }
  }
}

