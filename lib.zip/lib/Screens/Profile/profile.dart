import 'dart:developer';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:pinput/pinput.dart';
import 'package:urwealthpal/BottomBar/bottombar.dart';
import 'package:urwealthpal/Constant/Api.dart';
import 'package:urwealthpal/Constant/colors.dart';
import 'package:urwealthpal/Environment/Environment.dart';
import 'package:urwealthpal/Screens/Change_Password/Change_Password.dart';
import 'package:urwealthpal/Screens/EditProfile/editProfile.dart';
import 'package:urwealthpal/Screens/MPIN/Controllers/Toggle_MPIN_Controller.dart';
import 'package:urwealthpal/Screens/MPIN/Toggle_MPIN.dart';
import 'package:urwealthpal/Screens/Profile/ProfileControllers/Get_Profile_Controller.dart';
import 'package:urwealthpal/Screens/SecurityQuestions/Toggle_SecurityQuestion.dart';
import 'package:urwealthpal/main.dart';


class profile extends StatefulWidget {
  const profile({Key? key}) : super(key: key);

  @override
  State<profile> createState() => _profileState();
}

class _profileState extends State<profile> {
  var _formKey = GlobalKey<FormState>();
  bool passToogle = true;
  bool passToogles = true;

  var getProfileController =Get.put(GetProfileController());

  final focusNode = FocusNode();

  ToggleMPINController toggleMPINController = Get.put(ToggleMPINController());

  bool istoggelbol = false;

  final defaultPinTheme = PinTheme(
    width: 56,
    height: 56,
    textStyle: TextStyle(
      fontSize: 22,
      color: Color.fromRGBO(30, 60, 87, 1),
    ),
    decoration: BoxDecoration(
      borderRadius: BorderRadius.circular(10),
      border: Border.all(color: Colors.grey),
    ),
  );


  toggelMpin(){
    showDialog(context: context, builder: (context){

      return Container(
        // height: 100,
        child: Dialog(
          insetPadding: EdgeInsets.all(10),

          child: Container(
            height: 500,
            child: Pinput(
              controller: toggleMPINController.pinController,
              focusNode: focusNode,
              // androidSmsAutofillMethod:
              // AndroidSmsAutofillMethod
              //     .smsUserConsentApi,
              // listenForMultipleSmsOnAndroid: true,
              defaultPinTheme: defaultPinTheme,
              validator: (value) {
                return value!.length == 0
                    ? 'Please Fill Pin First'
                    : null;
              },
              // onClipboardFound: (value) {
              //   debugPrint('onClipboardFound: $value');
              //   pinController.setText(value);
              // },

              hapticFeedbackType:
              HapticFeedbackType.lightImpact,
              onCompleted: (pin) {
                debugPrint('onCompleted: $pin');
              },
              onChanged: (value) {
                debugPrint('onChanged: $value');
              },
              cursor: Column(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  Container(
                    margin: EdgeInsets.only(bottom: 9),
                    width: 22,
                    height: 1,
                    color: appPrimaryColor,
                  ),
                ],
              ),
              focusedPinTheme: defaultPinTheme.copyWith(
                decoration:
                defaultPinTheme.decoration!.copyWith(
                  borderRadius: BorderRadius.circular(8),
                  border:
                  Border.all(color: appPrimaryColor),
                ),
              ),
              submittedPinTheme: defaultPinTheme.copyWith(
                decoration:
                defaultPinTheme.decoration!.copyWith(
                  borderRadius: BorderRadius.circular(10),
                  border:
                  Border.all(color: appPrimaryColor),
                ),
              ),
              errorPinTheme: defaultPinTheme.copyBorderWith(
                border: Border.all(color: Colors.redAccent),
              ),
            ),
          ),
        ),
      );
    });
  }

  @override
  void initState() {
    // TODO: implement initState
    super.initState();

    // if(sp!.getBool("paymentstatus")== false){
    //   Get.offAll(purchase_plan());
    //   sp!.setBool("paymentstatus", false);
    // }
    // else{
    //   sp!.setBool("paymentstatus", true);
    // }

    getProfileController.GetProfileApiCalling(Get_profile_url);

    // isSwitched = getProfileController.toggleOn == '0'? false :true;
  }

  @override
  Widget build(BuildContext context) {
    return RefreshIndicator(
      onRefresh: () async {
        await GetProfileController();
        await Future.delayed(Duration(milliseconds: 1500));
      },
      child: Scaffold(
        body: GetBuilder<GetProfileController>(
          builder: (getProfileController) {

            if(getProfileController.getProfile_loading.value){
              return Center(child: CircularProgressIndicator(),);
            }
            else {
              return SingleChildScrollView(
              physics: AlwaysScrollableScrollPhysics(),
              child: Form(
                key: _formKey,
                child: Padding(
                  padding: EdgeInsets.fromLTRB(0, 10, 0, 10),
                  child: Column(
                      children: [
                        GestureDetector(
                          onTap: () {
                            Navigator.push(context,
                                MaterialPageRoute(
                                  builder: (context) => editProfile(),));
                          },
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.end,
                            children: [
                              Container(
                                alignment: Alignment.center,
                                width: 90,
                                height: 40,
                                margin: EdgeInsets.symmetric(horizontal: 10),
                                decoration: BoxDecoration(
                                    color: appPrimaryColor,
                                    border: Border.all(
                                      color: appPrimaryColor,
                                    ),
                                    borderRadius: BorderRadius.all(Radius.circular(8))
                                ),
                                child: Center(
                                  child: Text("edit_txt".tr,
                                    textAlign: TextAlign.center,
                                    style: TextStyle(
                                      color: whiteColor,
                                      fontSize: 18
                                  ),),
                                ),
                              ),
                            ],
                          ),
                        ),
                        Stack(
                          children: [
                            Container(
                              height: 100,
                              width: 100,
                              decoration: BoxDecoration(
                                  color: appPrimaryColor,
                                  border: Border.all(width: 5,
                                    color: buttonColor,
                                  ),
                                  borderRadius: BorderRadius.all(Radius.circular(90))
                              ),
                              child: ClipOval(
                                  child: Image.network(getProfileController.image.toString(),fit: BoxFit.contain),),
                            ),
                            // CircleAvatar(
                            //   backgroundColor: buttonColor,
                            //   radius: 50,
                            //   child: CircleAvatar(
                            //     radius: 50-5 ,
                            //     backgroundImage: NetworkImage(getProfileController.image.toString()),
                            //   ),
                            // ),
                            // Positioned(
                            //   bottom: 5,
                            //   right: 2,
                            //   child: InkWell(
                            //     onTap: (){
                            //       Navigator.push(
                            //         context,
                            //         MaterialPageRoute(
                            //           builder: (context) => editProfile(),
                            //         ),
                            //       );
                            //     },
                            //     child: Container(
                            //       height: 30,
                            //       width: 30,
                            //       decoration: BoxDecoration(
                            //           color: Colors.white,
                            //           border: Border.all(
                            //             color: Colors.white,
                            //           ),
                            //           borderRadius: BorderRadius.all(Radius.circular(20))
                            //       ),
                            //       child: Icon(Icons.edit,color: Color(0xFF939292),size: 18,
                            //       ),
                            //     ),
                            //   ),
                            // ),
                          ],
                        ),
                        Padding(
                          padding: EdgeInsets.fromLTRB(10, 20, 10, 0),
                          child: TextFormField(
                            controller: getProfileController.userName,
                            autovalidateMode:
                            AutovalidateMode.onUserInteraction,
                            validator: (value) {
                              if (value == null) {
                                return "validUserName_txt".tr;
                              }
                              if (value.length < 3) {
                                return "validLength_UserName_txt".tr;
                              }
                              return null;
                            },
                            keyboardType: TextInputType.name,
                            readOnly: true,
                            textInputAction: TextInputAction.next,
                            decoration: InputDecoration(
                              filled: true,
                              fillColor: whiteColor,
                              border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(10),
                              ),
                              enabledBorder: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(10),
                                  borderSide: BorderSide( width: 1, color: appPrimaryColor)
                              ),
                              focusedBorder: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(10),
                                  borderSide: BorderSide( width: 1, color: appPrimaryColor)
                              ),
                              // labelText: 'Your Name',
                              prefixIcon: Container(
                                // color: Colors.redAccent,
                                child: Image.asset("assets/images/user.png",scale: 3,width: 15,),
                              ),
                              hintText: "userName_txt".tr,
                            ),
                          ),
                        ),
                        Padding(
                          padding: EdgeInsets.fromLTRB(10, 10, 10, 0),
                          child: TextFormField(
                            controller: getProfileController.email,
                            autovalidateMode:
                            AutovalidateMode.onUserInteraction,
                            validator: (value) {
                              if (value == null) {
                                return "valid_Email_txt".tr;
                              }
                              if (value == null ||
                                  value.isEmpty ||
                                  !value.contains('@') ||
                                  !value.contains('.')) {
                                return "validLength_Email_txt".tr;
                              }
                              return null;
                            },
                            keyboardType: TextInputType.emailAddress,
                            readOnly: true,
                            textInputAction: TextInputAction.next,
                            decoration: InputDecoration(
                              filled: true,
                              fillColor: whiteColor,
                              border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(10),
                              ),
                              enabledBorder: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(10),
                                  borderSide: BorderSide( width: 1, color: appPrimaryColor)
                              ),
                              focusedBorder: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(10),
                                  borderSide: BorderSide( width: 1, color: appPrimaryColor)
                              ),
                              // labelText: 'Your Name',
                              prefixIcon: Container(
                                // color: Colors.redAccent,
                                  child: Image.asset("assets/images/email (1).png",scale: 3,width: 15,)),
                              hintText: "emailId_txt".tr,
                            ),
                          ),
                        ),
                        Padding(
                          padding: EdgeInsets.fromLTRB(10, 10, 10, 0),
                          child: TextFormField(
                            controller: getProfileController.mobile,
                            inputFormatters: [FilteringTextInputFormatter.allow(RegExp('[0-9]'))],
                            keyboardType: TextInputType.numberWithOptions(decimal: true),
                            autovalidateMode:
                            AutovalidateMode.onUserInteraction,
                            validator: (value) {
                              if (value == null) {
                                return "valid_Mobile_No_txt".tr;
                              }
                              // if (value.length != 10) {
                              //   return "validLengthMobile_No_txt".tr;
                              // }
                              return null;
                            },
                            readOnly: true,
                            textInputAction: TextInputAction.next,
                            decoration: InputDecoration(
                              filled: true,
                              fillColor: whiteColor,
                              border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(10),
                              ),
                              enabledBorder: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(10),
                                  borderSide: BorderSide( width: 1, color: appPrimaryColor)
                              ),
                              focusedBorder: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(10),
                                  borderSide: BorderSide( width: 1, color: appPrimaryColor)
                              ),
                              hintText: "mobileNo_txt".tr,
                              prefixIcon: Container(
                                // color: Colors.redAccent,
                                child: Image.asset("assets/images/phoneIcon.png",scale: 3.5,width: 15,),
                              )
                            ),
                          ),
                        ),

                        getProfileController.country.text.toString()=="null"?Container():
                        Padding(
                          padding: EdgeInsets.fromLTRB(10, 10, 10, 0),
                          child: TextFormField(
                            controller: getProfileController.country,
                            autovalidateMode:
                            AutovalidateMode.onUserInteraction,
                            validator: (value) {
                              if (value == null) {
                                return "SelectCountry".tr;
                              }
                              if (value.length < 3) {
                                return "ValidCountry".tr;
                              }
                              return null;
                            },
                            keyboardType: TextInputType.name,
                            readOnly: true,
                            textInputAction: TextInputAction.next,
                            decoration: InputDecoration(
                                filled: true,
                                fillColor: Colors.white,
                                border: OutlineInputBorder(
                                  borderRadius: BorderRadius.circular(10),
                                ),
                                enabledBorder: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(10),
                                    borderSide: BorderSide( width: 1, color: appPrimaryColor)
                                ),
                                focusedBorder: OutlineInputBorder(
                                    borderRadius: BorderRadius.circular(10),
                                    borderSide: BorderSide( width: 1, color: appPrimaryColor)
                                ),
                                hintText: ("hintCountry_txt".tr),
                                prefixIcon: Container(
                                  // color: Colors.redAccent,
                                  child:
                                  Image.asset("assets/images/cityIcon.png",
                                    color: Color(0xFF37BCF9),
                                    scale: 2.6,width: 15,),
                                )
                            ),
                          ),
                        ),


                        // getProfileController.state.text.toString()=="null"?Container():
                        // Padding(
                        //   padding: EdgeInsets.fromLTRB(10, 10, 10, 0),
                        //   child: TextFormField(
                        //     controller: getProfileController.state,
                        //     autovalidateMode:
                        //     AutovalidateMode.onUserInteraction,
                        //     validator: (value) {
                        //       if (value == null) {
                        //         return "SelectState".tr;
                        //       }
                        //       if (value.length < 3) {
                        //         return "ValidState".tr;
                        //       }
                        //       return null;
                        //     },
                        //     keyboardType: TextInputType.name,
                        //     readOnly: true,
                        //     textInputAction: TextInputAction.next,
                        //     decoration: InputDecoration(
                        //       filled: true,
                        //       fillColor: Colors.white,
                        //       border: OutlineInputBorder(
                        //         borderRadius: BorderRadius.circular(10),
                        //       ),
                        //       enabledBorder: OutlineInputBorder(
                        //           borderRadius: BorderRadius.circular(10),
                        //           borderSide: BorderSide( width: 1, color: appPrimaryColor)
                        //       ),
                        //       focusedBorder: OutlineInputBorder(
                        //           borderRadius: BorderRadius.circular(10),
                        //           borderSide: BorderSide( width: 1, color: appPrimaryColor)
                        //       ),
                        //         hintText: ("hintState_txt".tr),
                        //         prefixIcon: Container(
                        //           // color: Colors.redAccent,
                        //           child: Image.asset("assets/images/cityIcon.png",
                        //             color: Color(0xFF37BCF9),
                        //             scale: 2.6,width: 15,),
                        //         )
                        //     ),
                        //   ),
                        // ),
                        //
                        // getProfileController.city.text.toString()=="null"?Container():
                        // Padding(
                        //   padding: EdgeInsets.fromLTRB(10, 10, 10, 0),
                        //   child: TextFormField(
                        //     controller: getProfileController.city,
                        //     autovalidateMode:
                        //     AutovalidateMode.onUserInteraction,
                        //     validator: (value) {
                        //       if (value == null) {
                        //         return " Please enter city name";
                        //       }
                        //       if (value.length < 3) {
                        //         return "Please enter valid city name";
                        //       }
                        //       return null;
                        //     },
                        //     keyboardType: TextInputType.name,
                        //     readOnly: true,
                        //     textInputAction: TextInputAction.next,
                        //     decoration: InputDecoration(
                        //         filled: true,
                        //         fillColor: Colors.white,
                        //         border: OutlineInputBorder(
                        //           borderRadius: BorderRadius.circular(10),
                        //         ),
                        //         enabledBorder: OutlineInputBorder(
                        //             borderRadius: BorderRadius.circular(10),
                        //             borderSide: BorderSide( width: 1, color: appPrimaryColor)
                        //         ),
                        //         focusedBorder: OutlineInputBorder(
                        //             borderRadius: BorderRadius.circular(10),
                        //             borderSide: BorderSide( width: 1, color: appPrimaryColor)
                        //         ),
                        //         hintText: ("Select city"),
                        //         prefixIcon: Container(
                        //           // color: Colors.redAccent,
                        //           child:
                        //           Image.asset("assets/images/cityIcon.png",
                        //             color: Color(0xFF37BCF9),
                        //             scale: 2.6,width: 15,),
                        //         )
                        //     ),
                        //   ),
                        // ),

                        // getProfileController.pincode.text.toString()=="null"?Container():
                        // Padding(
                        //   padding: EdgeInsets.fromLTRB(10, 10, 10, 0),
                        //   child: TextFormField(
                        //     controller: getProfileController.pincode,
                        //     autovalidateMode: AutovalidateMode.onUserInteraction,
                        //     validator: (value){
                        //       if (value == null) {
                        //         return " Please enter your Pincode No.";
                        //       }if(value.length!=6) {
                        //         return "Please enter valid Pincode No.";
                        //       }
                        //       return null;
                        //     },
                        //     keyboardType: TextInputType.number,
                        //     textInputAction: TextInputAction.next,
                        //     readOnly: true,
                        //     decoration: InputDecoration(
                        //       border: OutlineInputBorder(
                        //         borderRadius: BorderRadius.circular(10),
                        //       ),
                        //       enabledBorder: OutlineInputBorder(
                        //           borderRadius: BorderRadius.circular(10),
                        //           borderSide: BorderSide( width: 1, color: appPrimaryColor)
                        //       ),
                        //       focusedBorder: OutlineInputBorder(
                        //           borderRadius: BorderRadius.circular(10),
                        //           borderSide: BorderSide( width: 1, color: appPrimaryColor)
                        //       ),
                        //         hintText: "Pincode",
                        //         prefixIcon: Container(
                        //           // color: Colors.redAccent,
                        //           child: Image.asset("assets/images/passIcon.png",scale: 3.5,width: 15,),
                        //         )
                        //     ),
                        //   ),
                        // ),
                        //
                        // getProfileController.address.toString()==""?Container():
                        // Padding(
                        //   padding: EdgeInsets.fromLTRB(10, 10, 10, 0),
                        //   child: TextFormField(
                        //     controller: getProfileController.address,
                        //     autovalidateMode: AutovalidateMode.onUserInteraction,
                        //     validator: (value){
                        //       if (value == null) {
                        //         return " Please enter your address";
                        //       }if(value.length<6) {
                        //         return "Please enter valid address";
                        //       }
                        //       return null;
                        //     },
                        //     keyboardType: TextInputType.streetAddress,
                        //     readOnly: true,
                        //     maxLines: 1,
                        //     textInputAction: TextInputAction.next,
                        //     decoration: InputDecoration(
                        //       border: OutlineInputBorder(
                        //         borderRadius: BorderRadius.circular(10),
                        //       ),
                        //       enabledBorder: OutlineInputBorder(
                        //           borderRadius: BorderRadius.circular(10),
                        //           borderSide: BorderSide( width: 1, color: appPrimaryColor)
                        //       ),
                        //       focusedBorder: OutlineInputBorder(
                        //           borderRadius: BorderRadius.circular(10),
                        //           borderSide: BorderSide( width: 1, color: appPrimaryColor)
                        //       ),
                        //         hintText: "address",
                        //         prefixIcon: Container(
                        //           // color: Colors.redAccent,
                        //           child:  Image.asset("assets/images/cityIcon.png",
                        //             color: Color(0xFF37BCF9),
                        //             scale: 2.6,width: 15,),
                        //         )
                        //     ),
                        //   ),
                        // ),

                        SizedBox(
                          height: 10,
                        ),
                        Padding(
                          padding: EdgeInsets.symmetric(horizontal: 10),
                          child: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text("mpin".tr,style: TextStyle(
                                  color: appBarColor,
                                  fontWeight: FontWeight.bold,
                                  fontSize: 18),),
                              Container(
                                width: 80,
                                child: Column(
                                  children: [
                                    Transform.scale(
                                        scale: 1.4,
                                        child: Switch(
                                          onChanged: (val) async {
                                            log('askMPIN==>'+Environment.askMPIN.toString());
                                            await Navigator.push(context,
                                                MaterialPageRoute(builder: (context)=> Toggle_MPIN()));

                                            setState(() {
                                            });
                                          },
                                          value: Environment.askMPIN=="1"?true:false,
                                          activeColor: whiteColor,
                                          activeTrackColor: appPrimaryColor,
                                          inactiveThumbColor: whiteColor,
                                          inactiveTrackColor: Red,
                                        )
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                        SizedBox(
                          height: 10,
                        ),
                        Padding(
                          padding:  EdgeInsets.symmetric(horizontal: 10),
                          child: Row(

                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Text("askQue".tr,style: TextStyle(
                                  color: appBarColor,
                                  fontWeight: FontWeight.bold,
                                  fontSize: 18),),

                              Container(
                                width: 80,
                                child: Column(
                                  children: [
                                    Transform.scale(
                                        scale: 1.4,
                                        child: Switch(
                                          onChanged: (val) async {
                                           log ('log>>>'+sp!.getString("askQuestion").toString());
                                            await Navigator.push(context,
                                                MaterialPageRoute(builder: (context)=> Toggle_SecurityQuestion()));
                                            setState(() {
                                            });
                                          },
                                          value: Environment.askQuestion=="1"?true:false,
                                          activeColor: whiteColor,
                                          activeTrackColor: appPrimaryColor,
                                          inactiveThumbColor: whiteColor,
                                          inactiveTrackColor: Red,
                                        )
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                        Row(
                     mainAxisAlignment: MainAxisAlignment.spaceBetween,
                     children: [
                       GestureDetector(
                         onTap: (){
                           Navigator.push(context, MaterialPageRoute(
                               builder: (context) => Change_Password()));
                         },
                         child: Container(
                           width: 150,
                           height: 40,
                           margin: EdgeInsets.symmetric(horizontal: 15),
                           decoration: BoxDecoration(
                               color: appPrimaryColor,
                               border: Border.all(
                                 color: appPrimaryColor,
                               ),
                               borderRadius: BorderRadius.all(Radius.circular(5))
                           ),
                           child: Center(
                             child: Text(
                               "ChangePassword".tr,
                               style: TextStyle(
                                   color: whiteColor,
                                   fontSize: 15
                               ),),
                           ),
                         ),
                       ),
                     ],
                   ),
                      ]
                  ),
                ),
              ),
            );
            }
          }
        ),
      ),
    );
  }


  Widget Calllmpaba(){
    return Container(
      height: 200,
      color: Colors.redAccent,
      child: Text("fasfaff"),
    );
  }


Widget Calllmpaba1(){
  return Container(
    height: 500,
    color: Colors.pink,
    child: AlertDialog(
      title: Text("conLogout_txt".tr),
      content: Text("sureToLogout_txt".tr),
      actions: [
        TextButton(onPressed: () {
          // prefs.setBool("login", false);
          // ApiBaseHelper(). AppLogout();
        },
            child: Text("logout_txt".tr,style: TextStyle(
                color: appPrimaryColor,
                fontWeight: FontWeight.bold
            ),)),

        TextButton(onPressed: (){
          Navigator.pushReplacement(context, MaterialPageRoute(
            builder: (context) => bottombar(bottom: 2),));
        },
            child: Text("cancel_txt".tr,style: TextStyle(
                color: appPrimaryColor,
                fontWeight: FontWeight.bold
            ),))
      ],
    ),
  );
}


}




