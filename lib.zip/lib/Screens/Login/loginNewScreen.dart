import 'dart:convert';
import 'dart:developer';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:urwealthpal/Constant/Api.dart';
import 'package:urwealthpal/Constant/ApiBaseHelper.dart';
import 'package:urwealthpal/Constant/Images.dart';
import 'package:urwealthpal/Constant/Spacing.dart';
import 'package:urwealthpal/Constant/colors.dart';
import 'package:urwealthpal/Environment/Environment.dart';
import 'package:urwealthpal/Screens/Login/Controllers/GetAccountsController.dart';
import 'package:urwealthpal/Screens/Login/Controllers/SendOtpController.dart';
import 'package:urwealthpal/Screens/Login/forgot_password.dart';
import 'package:urwealthpal/Screens/Register/register.dart';
import 'package:urwealthpal/main.dart';

class NewLoginScreen extends StatefulWidget {

  var accountId;

   NewLoginScreen({this.accountId});

  @override
  State<NewLoginScreen> createState() => _NewLoginScreenState();
}

class _NewLoginScreenState extends State<NewLoginScreen> {

  var _formKey = GlobalKey<FormState>();
  var _emailId = TextEditingController();

  var _pws = TextEditingController();
  bool passToogle = true;
  bool registered = true;

  ScrollController scrollController = ScrollController();

  bool type = true;
  int? selectedIndex ;
  var selectedRadio ;

  var tapp = 1;

  var setting_json_data;
  SendOTPController sendOTPcontroller =Get.put(SendOTPController());

  GetAccountController getAccountController = Get.put(GetAccountController());

  @override
  void initState()  {
    // TODO: implement initState
    super.initState();
    setting_json_data = json.decode(sp!.getString("setting").toString());


    getmsg();
  }
  getmsg(){
    log("check login type loginpage--->"+setting_json_data.toString());
  }

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Scaffold(
        resizeToAvoidBottomInset: false,
        body: Container(
            height: size.height,
            width: size.width,
            decoration: BoxDecoration(
              image: DecorationImage(
                  image: AssetImage("assets/images/full_background.png"),
                  fit: BoxFit.cover),
            ),
            child: Stack(
                children: [
                  Form(
                      key: _formKey,
                      child: SingleChildScrollView(
                        child: Column(
                          children: [
                            // SizedBox(
                            //   height: 50,
                            // ),
                            Container(
                                margin: EdgeInsets.only(top: 100),
                                alignment: Alignment.center,
                                width: size.width,
                                child: loginImage),
                            Container(
                              alignment: Alignment.center,
                              width: size.width,
                              child: Text(
                                "loginn".tr,
                                style: TextStyle(
                                    color: whiteColor,
                                    fontWeight: FontWeight.bold,
                                    fontSize: 32),
                              ),
                            ),

                            Container(
                              // width: size.width-30,
                              // color: whiteColor,
                                decoration: BoxDecoration(
                                  color: whiteColor,
                                  border: Border.all(color: whiteColor),
                                  borderRadius: BorderRadius.all(Radius.circular(30)),
                                ),
                                // height: size.height,
                                // height: 400,
                                margin: EdgeInsets.only(top: 30,left: 20,right: 20),
                                child: SingleChildScrollView(
                                  child: Column(
                                    children: [
                                      Padding(
                                        padding: EdgeInsets.only(top: 50,),
                                        child: Row(
                                          mainAxisAlignment: MainAxisAlignment.center,
                                          crossAxisAlignment: CrossAxisAlignment.center,
                                          children: [
                                            GestureDetector(
                                              onTap: (){
                                                setState(() {
                                                  type = true; // For Color changing
                                                  tapp = 1;
                                                });
                                              },
                                              child: Container(
                                                padding: EdgeInsets.only(top: 3,),
                                                height: 30,
                                                width: 150,
                                                decoration: BoxDecoration(
                                                  color: type == true ? buttonColor : whiteColor,
                                                  border: Border.all(color: buttonColor),
                                                  borderRadius: BorderRadius.all(Radius.circular(15)),
                                                ),
                                                child: Text("userlogin".tr,
                                                  textAlign: TextAlign.center,
                                                  style: TextStyle(
                                                    fontWeight: FontWeight.w600,
                                                      color: type == true ? whiteColor : buttonColor,
                                                    fontSize: 18
                                                  ),),
                                              ),
                                            ),
                                            sizebox_width_2,
                                            GestureDetector(
                                              onTap: (){
                                                setState(() {
                                                  type = false;
                                                  tapp = 2;
                                                });
                                              },
                                              child: Container(
                                                padding: EdgeInsets.only(top: 3,),
                                                height: 30,
                                                width: 150,
                                                decoration: BoxDecoration(
                                                  color:  type == false ? buttonColor : whiteColor,
                                                  border: Border.all(color: buttonColor),
                                                  borderRadius: BorderRadius.all(Radius.circular(15)),
                                                ),
                                                child: Text("family_txt".tr,
                                                textAlign: TextAlign.center,
                                                  style: TextStyle(
                                                    fontWeight: FontWeight.w600,
                                                    color: type == false ? whiteColor : buttonColor,
                                                    fontSize: 18
                                                  ),
                                                ),
                                              ),
                                            ),
                                          ],
                                        ),
                                      ),

                                        int.parse(setting_json_data['data']['login_type'].toString())==1?
                                        Padding(
                                          padding: EdgeInsets.fromLTRB(10, 60, 10, 0),
                                          child: TextFormField(
                                            controller: _emailId,
                                            autovalidateMode:
                                            AutovalidateMode.onUserInteraction,
                                            scrollPadding: EdgeInsets.only(
                                                bottom: MediaQuery.of(context).viewInsets.bottom + 25*4),
                                            validator: (value) {
                                              if (value == null || value.isEmpty) {
                                                return "email".tr;
                                              }
                                              if (!RegExp(
                                                  r'^[\w-]+(\.[\w-]+)*@[\w-]+(\.[\w-]+)+$')
                                                  .hasMatch(value)) {
                                                return "validEmail".tr;
                                              }
                                              return null; // Validation passed
                                            },
                                            keyboardType: TextInputType.emailAddress,
                                            textInputAction: TextInputAction.next,
                                            decoration: InputDecoration(
                                                filled: true,
                                                fillColor: whiteColor,
                                                contentPadding: EdgeInsets.only(top: 5),
                                                constraints: BoxConstraints(
                                                    minWidth: 30, maxHeight: 70),
                                                border: OutlineInputBorder(
                                                  borderRadius: BorderRadius.circular(10),
                                                ),
                                                enabledBorder: OutlineInputBorder(
                                                    borderRadius: BorderRadius.circular(10),
                                                    borderSide: BorderSide(
                                                        width: 1, color: Namecolors)),
                                                focusedBorder: OutlineInputBorder(
                                                    borderRadius: BorderRadius.circular(10),
                                                    borderSide: BorderSide(
                                                        width: 1, color: appPrimaryColor)),
                                                focusedErrorBorder: OutlineInputBorder(
                                                    borderRadius: BorderRadius.circular(10),
                                                    borderSide: BorderSide(
                                                        width: 1, color: Colors.redAccent)),
                                                prefixIcon: Container( child:
                                                Image.asset("assets/images/email (1).png",scale: 3,width: 15,)),
                                                hintText: "hintEmail".tr),
                                          ),

                                        ):
                                        Padding(
                                          padding: EdgeInsets.fromLTRB(10, 60, 10, 0),
                                          child: TextFormField(
                                            controller: sendOTPcontroller.mobileNo,
                                            scrollPadding: EdgeInsets.only(
                                                bottom: MediaQuery.of(context).viewInsets.bottom + 25*4),
                                            inputFormatters: [
                                              FilteringTextInputFormatter.allow(
                                                  RegExp('[0-9]'))
                                            ],
                                            keyboardType: TextInputType.numberWithOptions(
                                                decimal: true),
                                            autovalidateMode:
                                            AutovalidateMode.onUserInteraction,
                                            validator: (value) {
                                              if (value == null || value.isEmpty) {
                                                return "validMobileNo".tr;
                                              }
                                              if (value.length == 0) {
                                                return "valid_Mobile_No_txt".tr;
                                              }
                                              return null; // Validation passed
                                            },
                                            // maxLength: 10,
                                            textInputAction: TextInputAction.next,
                                            decoration: InputDecoration(
                                              filled: true,
                                              fillColor: whiteColor,
                                              contentPadding: EdgeInsets.only(top: 5),
                                              constraints: BoxConstraints(
                                                  minWidth: 30, maxHeight: 70),
                                              border: OutlineInputBorder(
                                                borderRadius: BorderRadius.circular(10),
                                              ),
                                              enabledBorder: OutlineInputBorder(
                                                  borderRadius: BorderRadius.circular(10),
                                                  borderSide: BorderSide(
                                                      width: 1, color: Namecolors)),
                                              focusedBorder: OutlineInputBorder(
                                                  borderRadius: BorderRadius.circular(10),
                                                  borderSide: BorderSide(
                                                      width: 1, color: appPrimaryColor)),
                                              focusedErrorBorder: OutlineInputBorder(
                                                  borderRadius: BorderRadius.circular(10),
                                                  borderSide: BorderSide(
                                                      width: 1, color: Colors.redAccent)),
                                              prefixIcon: PhoneIcon,
                                              hintText: "hintMobileNo".tr,
                                              counterText: "",
                                            ),
                                          ),
                                        ),
                                      GetBuilder<GetAccountController>(
                                          builder: (getAccountController) {
                                          return Column(
                                            children: [
                                              tapp == 2? GestureDetector(
                                                onTap: (){
                                                  FocusScope.of(context).requestFocus(new FocusNode());
                                                  FocusScope.of(context).unfocus();
                                                  if (_formKey.currentState!.validate()){
                                                    var GetAccountUrl = getAccountsList_url;
                                                  var body =  int.parse(setting_json_data['data']['login_type'].toString())==1?
                                                  ({
                                                    'mobile' : sendOTPcontroller.mobileNo.text,
                                                    'email' : _emailId.text.toString(),
                                                    'type' : '2',
                                                  }):({
                                                    'mobile' : sendOTPcontroller.mobileNo.text,
                                                    'email' : _emailId.text.toString(),
                                                    'type' : '2',

                                                  });
                                                  getAccountController.GetAccountApiCalling(GetAccountUrl, body);
                                                  log('GetAccount Response......${GetAccountUrl}'.toString());
                                                  log('GetAccount body......${body}'.toString());}

                                                },

                                                child: Padding(
                                                  padding: EdgeInsets.only(top: 10,left: 150),
                                                  child: Container(
                                                    height: 40,
                                                    width: 150,
                                                    decoration: BoxDecoration(
                                                        color: buttonColor,
                                                        border: Border.all(
                                                          color: buttonColor,
                                                        ),
                                                        borderRadius:
                                                        BorderRadius.all(Radius.circular(12))),
                                                    child: Center(
                                                      child: Text(
                                                        "getAccount".tr,
                                                        style: TextStyle(
                                                            color: whiteColor,
                                                            fontSize: 16,
                                                            fontWeight: FontWeight.bold),
                                                      ),
                                                    ),
                                                  ),
                                                ),
                                              ):Container(),


                                              getAccountController.accountTap == false ? Container(): tapp == 2? Container(
                                                  padding: EdgeInsets.only(top: 10,left: 5),
                                                  alignment: Alignment.topLeft,
                                                  child: Text("Select Account",
                                                    style: TextStyle(
                                                        fontSize: 18,
                                                        color: buttonColor,
                                                        fontWeight: FontWeight.w600
                                                    ),
                                                  )
                                              ):Container(),

                                              getAccountController.accountTap == false ?
                                              Container(): tapp == 2? Container(
                                                padding:  EdgeInsets.only(top: 4,left: 10,right: 10),
                                                height: 90,
                                                child: GetBuilder<GetAccountController>(
                                                    builder: (getAccountController) {
                                                      if(getAccountController.GetAccountLoading.value){
                                                        return Center(child: CircularProgressIndicator());
                                                      }
                                                      else
                                                        return
                                                          getAccountController.GetAccountList.length==0?Center(child: Text("DataFound".tr)):
                                                          ListView.builder(
                                                              itemCount: getAccountController.GetAccountList.length,
                                                              scrollDirection: Axis.horizontal,
                                                              shrinkWrap: true,
                                                              controller: scrollController,
                                                              // clipBehavior: Clip.none,
                                                              physics: AlwaysScrollableScrollPhysics(),
                                                              itemBuilder: (BuildContext context, index) {
                                                                var accountsListData = getAccountController.GetAccountList[index];
                                                                return Padding(
                                                                  padding: EdgeInsets.only(right: 5),
                                                                  child: Container(
                                                                    // padding:  EdgeInsets.only(left: 10,right: 10),
                                                                    decoration: BoxDecoration(
                                                                        color: whiteColor,
                                                                        border: Border.all(
                                                                          color: selectedIndex == index ? buttonColor : Namecolors,
                                                                        ),
                                                                        borderRadius: BorderRadius.all(Radius.circular(10))
                                                                    ),
                                                                    child: Padding(
                                                                      padding:  EdgeInsets.symmetric(horizontal: 10,vertical: 25),
                                                                      child: Row(
                                                                        mainAxisAlignment: MainAxisAlignment.start,
                                                                        crossAxisAlignment: CrossAxisAlignment.start,
                                                                        children: [
                                                                          GestureDetector(
                                                                            onTap: (){
                                                                              setState(() {

                                                                                selectedIndex = index;
                                                                                selectedRadio = accountsListData["id"];
                                                                                log("selectedIndex1---->$selectedRadio");
                                                                              });
                                                                            },

                                                                            child: Icon(selectedIndex == index ? Icons.radio_button_checked : Icons.radio_button_off,
                                                                              color: selectedIndex == index ? buttonColor : Namecolors,
                                                                            ),
                                                                          ),
                                                                          sizebox_width_5,
                                                                          VerticalDivider(
                                                                            color: selectedIndex == index ? buttonColor : Namecolors,
                                                                            thickness: 2,
                                                                          ),
                                                                          sizebox_width_5,
                                                                          Column(
                                                                            mainAxisAlignment: MainAxisAlignment.start,
                                                                            crossAxisAlignment: CrossAxisAlignment.start,
                                                                            children: [
                                                                              Text("Partner: ${accountsListData["name"].toString()}",
                                                                                maxLines: 2,
                                                                                overflow: TextOverflow.ellipsis,
                                                                                style: TextStyle(
                                                                                  fontSize: 14,
                                                                                  fontWeight: selectedIndex == index ? FontWeight.w600 : FontWeight.w100,
                                                                                  letterSpacing: 0.5,
                                                                                ),),
                                                                              sizebox_height_2,
                                                                              Text("Relation: ${accountsListData["relation"].toString()}",
                                                                                maxLines: 2,
                                                                                overflow: TextOverflow.ellipsis,
                                                                                style: TextStyle(
                                                                                    fontSize: 14,
                                                                                    fontWeight: selectedIndex == index ? FontWeight.w600 : FontWeight.w100,
                                                                                    letterSpacing: 0.5
                                                                                ),)
                                                                            ],
                                                                          )
                                                                        ],
                                                                      ),
                                                                    ),
                                                                  ),
                                                                );
                                                              });
                                                    }
                                                ),
                                              ):Container(),
                                            ],
                                          );
                                        }
                                      ),

                                        SizedBox(
                                          height: 30,
                                        ),

                                        int.parse(setting_json_data['data']['login_type'].toString())==1?
                                        Padding(
                                          padding: EdgeInsets.fromLTRB(10, 0, 10, 0),
                                          child: TextFormField(
                                            controller: _pws,
                                            autovalidateMode: AutovalidateMode.onUserInteraction,
                                            validator: (value) {
                                              if (value!.isEmpty) {
                                                return "validPassword".tr;
                                              } else if (value.length < 6) {
                                                return "correctPassword".tr;
                                              } else
                                                return null;
                                            },
                                            obscureText: passToogle,
                                            textInputAction: TextInputAction.next,
                                            decoration: InputDecoration(
                                              filled: true,
                                              fillColor: whiteColor,
                                              hintText: "hintPassword".tr,
                                              contentPadding: EdgeInsets.only(top: 5),
                                              constraints:
                                              BoxConstraints(minWidth: 30, maxHeight: 70),
                                              border: OutlineInputBorder(
                                                borderRadius: BorderRadius.circular(10),
                                              ),
                                              enabledBorder: OutlineInputBorder(
                                                  borderRadius: BorderRadius.circular(10),
                                                  borderSide:
                                                  BorderSide(width: 1, color: Namecolors)),
                                              focusedBorder: OutlineInputBorder(
                                                  borderRadius: BorderRadius.circular(10),
                                                  borderSide: BorderSide(
                                                      width: 1, color: appPrimaryColor)),
                                              focusedErrorBorder: OutlineInputBorder(
                                                  borderRadius: BorderRadius.circular(10),
                                                  borderSide: BorderSide(
                                                      width: 1, color: Colors.redAccent)),
                                              prefixIcon: Container(
                                                child: Image.asset("assets/images/passIcon.png",
                                                  scale: 3,width: 15,),
                                              ),
                                              suffixIcon: InkWell(
                                                onTap: () {
                                                  setState(() {
                                                    passToogle = !passToogle;
                                                  });
                                                },
                                                child: Icon(passToogle
                                                    ? Icons.visibility
                                                    : Icons.visibility_off),
                                              ),
                                            ),
                                          ),
                                        ):Container(),

                                        int.parse(setting_json_data['data']['login_type'].toString())==1?
                                        Align(
                                          alignment: Alignment.centerLeft,
                                          child: Padding(
                                            padding: EdgeInsets.only(top: 10,left: 10),
                                            child: GestureDetector(
                                              onTap: () {
                                                Navigator.push(
                                                    context,
                                                    MaterialPageRoute(
                                                        builder: (context) =>
                                                            forgot_password()));
                                              },
                                              child: Text("forgotPasstxt".tr,
                                                  style: TextStyle(
                                                    color: appPrimaryColor,
                                                    fontSize: 16,
                                                  )),
                                            ),
                                          ),
                                        ):
                                        Container(),
                                        int.parse(setting_json_data['data']['login_type'].toString())==1?
                                        Padding(
                                          padding: EdgeInsets.only(top: 15),
                                          child: GestureDetector(
                                            onTap: () async {
                                              var deviceid =await ApiBaseHelper().getId();
                                              var fcmid =await ApiBaseHelper().getToken();
                                              log("fcmid---->$fcmid");
                                              log("deviceid---->$deviceid");
                                              log("selectedIndex---->$selectedIndex");
                                              if (_formKey.currentState!.validate()) {
                                                var loginurl = Uri.parse(login_url);
                                                var body =  tapp == 1?({
                                                  'email': _emailId.text,
                                                  'password': _pws.text,
                                                  'fcm_id': fcmid.toString(),
                                                  'device_id': deviceid.toString(),
                                                  'type' : "1",
                                                }):
                                                ({ 'email': _emailId.text,
                                              'password': _pws.text,
                                              'fcm_id': fcmid.toString(),
                                              'device_id': deviceid.toString(),
                                              'type' : "2",
                                              'login_account' : selectedRadio.toString()});

                                                var response = await ApiBaseHelper().postAPICall(loginurl,body, false);
                                                var login = jsonDecode(response.body);
                                                log("body---->>>"+body.toString());
                                                log("login : "+response.statusCode.toString());
                                                if(response.statusCode==200){
                                                  log("login : "+login.toString());
                                                  sp!.setBool("loggedin",true) ;
                                                  ApiBaseHelper().logindata(login);
                                                  var   LoginOTPData = login['data'];
                                                  // var askmpin = LoginOTPData['ask_mpin'].toString();
                                                  // var setmpin = LoginOTPData['set_mpin'].toString();
                                                  sp!.setString("ask_mpin", LoginOTPData['ask_mpin'].toString());
                                                  sp!.setString("set_mpin", LoginOTPData['set_mpin'].toString());
                                                  sp!.setString("askQuestion", LoginOTPData['ask_question'].toString());

                                                  // sp!.setString("set_mpin", LoginOTPData['has_subscription'].toString());
                                                  if(LoginOTPData['has_subscription'].toString()=="1"){
                                                    sp!.setBool("paymentstatus", true);
                                                  }else{
                                                    sp!.setBool("paymentstatus", true);
                                                  }

                                                  _emailId.clear();
                                                  _pws.clear();
                                                  print("setMPIN...LoginEmail..."+Environment.setMPIN.toString());
                                                  print("askMPIN...LoginEmail..."+Environment.askMPIN.toString());
                                                  print("checkpaymentstatus...LoginEmail..."+Environment.checkpaymentstatus.toString());
                                                  ApiBaseHelper().manageroute();
                                                  toastMsg(login['message'], true);
                                                }
                                                else if(response.statusCode==422){
                                                  toastMsg(login['message'], false);
                                                }
                                              }
                                            },
                                            child: Container(
                                              height: 40,
                                              width: 150,
                                              decoration: BoxDecoration(
                                                  color: buttonColor,
                                                  border: Border.all(
                                                    color: buttonColor,
                                                  ),
                                                  borderRadius:
                                                  BorderRadius.all(Radius.circular(12))),
                                              child: Center(
                                                child: Text(
                                                  "signIn".tr,
                                                  style: TextStyle(
                                                      color: whiteColor,
                                                      fontSize: 16,
                                                      fontWeight: FontWeight.bold),
                                                ),
                                              ),
                                            ),
                                          ),
                                        ):
                                        Padding(
                                          padding: EdgeInsets.only(top: 15),
                                          child: GestureDetector(
                                            onTap: () async {
                                              if (_formKey.currentState!.validate()) {
                                                print('login type ...${ setting_json_data['data']['login_type'].toString()}');

                                               tapp==1? sp!.setString("type", "1"):
                                                   sp!.setString("type", "2");
                                                sp!.setString("radiotype", selectedRadio.toString());
                                                var sendOtp_url = sendOTP_url;
                                                var body=tapp == 1?
                                                ({
                                                  'mobile' : sendOTPcontroller.mobileNo.text,
                                                  'type' : '1'
                                                }):({
                                                  'mobile' : sendOTPcontroller.mobileNo.text,
                                                  'type' : '2'
                                                });
                                                sendOTPcontroller.SendOTPApiCalling(sendOtp_url, body);
                                                // print('send OTP Response......${body}'.toString());
                                                // print('send OTP Response......${sendOtp_url}'.toString());
                                                // sendOTPcontroller.mobileNo.clear();
                                              }
                                            },
                                            child: Container(
                                              height: 40,
                                              width: 150,
                                              decoration: BoxDecoration(
                                                  color: buttonColor,
                                                  border: Border.all(
                                                    color: buttonColor,
                                                  ),
                                                  borderRadius:
                                                  BorderRadius.all(Radius.circular(12))),
                                              child: Center(
                                                child: Text(
                                                  "send_OTP_txt".tr,
                                                  style: TextStyle(
                                                      color: whiteColor,
                                                      fontSize: 16,
                                                      fontWeight: FontWeight.bold),
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),

                                        SizedBox(
                                          height:30,
                                        ),
                                        RichText(
                                          text: TextSpan(
                                              text: "accounttxt".tr,
                                              style: TextStyle(
                                                color: Color(0xFF94A0AC),
                                                fontSize: 15,
                                              ),
                                              children: <TextSpan>[
                                                TextSpan(
                                                    text: "registertxt".tr,
                                                    style: TextStyle(
                                                      color: appPrimaryColor,
                                                      fontSize: 15,
                                                    ),
                                                    recognizer: TapGestureRecognizer()
                                                      ..onTap = () {
                                                        Navigator.push(
                                                            context,
                                                            MaterialPageRoute(
                                                              builder: (context) => register(),
                                                            ));
                                                      })
                                              ]),
                                        ),
                                      SizedBox(
                                        height:20,
                                      ),
                                      ]
                                  ),
                                ),

                            )
                          ],
                        ),
                      ))
                  ,
                ]
            )
        )
    );
  }
}
