import 'dart:convert';
import 'dart:developer';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:urwealthpal/Constant/Api.dart';
import 'package:urwealthpal/Constant/ApiBaseHelper.dart';
import 'package:urwealthpal/Constant/Images.dart';
import 'package:urwealthpal/Constant/Spacing.dart';
import 'package:urwealthpal/Constant/colors.dart';
import 'package:urwealthpal/Screens/Login/Controllers/GetAccountsController.dart';
import 'package:urwealthpal/Screens/Login/Controllers/LoginOtpController.dart';
import 'package:urwealthpal/Screens/Login/Controllers/SendOtpController.dart';
import 'package:urwealthpal/main.dart';

class loginOTP extends StatefulWidget {
  var mobileNo ;
   loginOTP({this.mobileNo});

  @override
  State<loginOTP> createState() => _loginOTPState();
}

class _loginOTPState extends State<loginOTP> {
  var _formKey = GlobalKey<FormState>();
  var _OTP = TextEditingController();

  bool type = true;
  int? selectedIndex ;
  var selectedRadio ;



  LoginOTPController loginOTPController =Get.put(LoginOTPController());

  GetAccountController getAccountController = Get.put(GetAccountController());

  var setting_json_data;
  SendOTPController sendOTPcontroller =Get.put(SendOTPController());

  var tapType;

  @override
  void initState()  {
    // TODO: implement initState
    super.initState();
    setting_json_data = json.decode(sp!.getString("setting").toString());
    tapType = sp!.getString("type");
    selectedRadio =  sp!.getString("radiotype");
    log("check tap type---->"+tapType);
    getmsg();
  }
  getmsg(){
    log("check login type loginpage--->"+setting_json_data.toString());
  }

  // String generateOTP() {
  //   Random random = Random();
  //   int otp = random.nextInt(9000) + 1000; // Generate a random number between 1000 and 9999
  //   return otp.toString();
  // }

  // var Generated_OTP;

  // @override
  // void initState() {
  //   // TODO: implement initState
  //   //   String otp = generateOTP();
  //     // setState((){
  //     //   Generated_OTP = otp.toString();
  //     // });
  //     // print('Generated OTP: $otp');
  //     // Fluttertoast.showToast(msg: 'Generated OTP: $otp',
  //     //     toastLength: Toast.LENGTH_SHORT,
  //     //     backgroundColor: appPrimaryColor,
  //     //     timeInSecForIosWeb: 1,
  //     //     textColor: Colors.white,
  //     //     fontSize: 15.0
  //     // );
  //   super.initState();
  // }

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Scaffold(
      resizeToAvoidBottomInset: false,
      body: Container(
        height: size.height,
        width: size.width,
        decoration: BoxDecoration(
          image: DecorationImage(
              image: AssetImage("assets/images/full_background.png"),
              fit: BoxFit.cover),),
        child: Column(
          children: [
           Stack(
                children: [
                  Form(
                      key: _formKey,
                      child:
                      SingleChildScrollView(
                        child: Column(
                          children: [
                            Container(
                                margin: EdgeInsets.only(top: 110),
                                alignment: Alignment.center,
                                width: size.width,
                                child: OTPImage),
                            Container(
                              alignment: Alignment.center,
                              width: size.width,
                              child: Text(
                                "otp".tr,
                                style: TextStyle(
                                    color: whiteColor,
                                    fontWeight: FontWeight.bold,
                                    fontSize: 32),
                              ),
                            ),
                            Container(
                              // height: 350,
                              margin: EdgeInsets.only(top:30, left: 20, right: 20),
                              decoration: BoxDecoration(
                                color: whiteColor,
                                border: Border.all(color: whiteColor),
                                borderRadius: BorderRadius.all(Radius.circular(30)),
                              ),
                              child: SingleChildScrollView(
                                child: Column(
                                  children: [
                                    Padding(
                                      padding: EdgeInsets.only(top: 40,),
                                      child: Row(
                                        mainAxisAlignment: MainAxisAlignment.center,
                                        crossAxisAlignment: CrossAxisAlignment.center,
                                        children: [
                                          GestureDetector(
                                            onTap: (){
                                              setState(() {
                                                type = true; // For Color changing

                                              });
                                            },
                                            child: Container(
                                              padding: EdgeInsets.only(top: 3,),
                                              height: 30,
                                              width: 150,
                                              decoration: BoxDecoration(
                                                color:tapType.toString() == "1"  ? buttonColor : whiteColor,
                                                border: Border.all(color: buttonColor),
                                                borderRadius: BorderRadius.all(Radius.circular(15)),
                                              ),
                                              child: Text("userlogin".tr,
                                                textAlign: TextAlign.center,
                                                style: TextStyle(
                                                    fontWeight: FontWeight.w600,
                                                    color: tapType.toString() == "1" ?whiteColor : buttonColor,
                                                    fontSize: 18
                                                ),),
                                            ),
                                          ),
                                          sizebox_width_2,
                                          GestureDetector(
                                            onTap: (){
                                              setState(() {
                                                type = false;

                                              });
                                            },
                                            child: Container(
                                              padding: EdgeInsets.only(top: 3,),
                                              height: 30,
                                              width: 150,
                                              decoration: BoxDecoration(
                                                color:  tapType.toString() == "2" ? buttonColor : whiteColor,
                                                border: Border.all(color: buttonColor),
                                                borderRadius: BorderRadius.all(Radius.circular(15)),
                                              ),
                                              child: Text("family_txt".tr,
                                                textAlign: TextAlign.center,
                                                style: TextStyle(
                                                    fontWeight: FontWeight.w600,
                                                    color: tapType.toString() == "2" ? whiteColor : buttonColor,
                                                    fontSize: 18
                                                ),
                                              ),
                                            ),
                                          ),
                                        ],
                                      ),
                                    ),

                                    // GetBuilder<GetAccountController>(
                                    //     builder: (getAccountController) {
                                    //
                                    //     return Column(
                                    //       children: [
                                    //         tapp == 2? GestureDetector(
                                    //           onTap: (){
                                    //             // FocusScope.of(context).requestFocus(new FocusNode());
                                    //             FocusScope.of(context).unfocus();
                                    //             var GetAccountUrl = getAccountsList_url;
                                    //             var body =  int.parse(setting_json_data['data']['login_type'].toString())==1? ({
                                    //               'mobile' : sendOTPcontroller.mobileNo.text,
                                    //               // 'email' : _emailId.text.toString(),
                                    //               'type' : '2',
                                    //             }):({
                                    //               'mobile' : sendOTPcontroller.mobileNo.text,
                                    //               // 'email' : _emailId.text.toString(),
                                    //               'type' : '2',
                                    //             });
                                    //             getAccountController.GetAccountApiCalling(GetAccountUrl, body);
                                    //             setState(() {
                                    //
                                    //             });
                                    //             log('GetAccount Response......${GetAccountUrl}'.toString());
                                    //             log('GetAccount body......${body}'.toString());
                                    //           },
                                    //
                                    //           child: Padding(
                                    //             padding: EdgeInsets.only(top: 10,left: 150),
                                    //             child: Container(
                                    //               height: 40,
                                    //               width: 150,
                                    //               decoration: BoxDecoration(
                                    //                   color: buttonColor,
                                    //                   border: Border.all(
                                    //                     color: buttonColor,
                                    //                   ),
                                    //                   borderRadius:
                                    //                   BorderRadius.all(Radius.circular(12))),
                                    //               child: Center(
                                    //                 child: getAccountController.GetAccountLoading.value?CircularProgressIndicator():Text(
                                    //                   "getAccount".tr,
                                    //                   style: TextStyle(
                                    //                       color: whiteColor,
                                    //                       fontSize: 16,
                                    //                       fontWeight: FontWeight.bold),
                                    //                 ),
                                    //               ),
                                    //             ),
                                    //           ),
                                    //         ):Container(),
                                    //
                                    //         getAccountController.accountTap == false ? Container(): tapp == 2? Container(
                                    //             padding: EdgeInsets.only(top: 10,left: 5),
                                    //             alignment: Alignment.topLeft,
                                    //             child: Text("Select Account",
                                    //               style: TextStyle(
                                    //                   fontSize: 18,
                                    //                   color: buttonColor,
                                    //                   fontWeight: FontWeight.w600
                                    //               ),
                                    //             )
                                    //         ):Container(),
                                    //
                                    //         getAccountController.accountTap == false ? Container(): tapp == 2? Container(
                                    //           padding:  EdgeInsets.only(top: 4,left: 10,right: 10),
                                    //           height: 90,
                                    //           child:   GetBuilder<GetAccountController>(
                                    //               builder: (getAccountController) {
                                    //                 if(getAccountController.GetAccountLoading.value){
                                    //                   return Center(child: CircularProgressIndicator());
                                    //                 }
                                    //                 else
                                    //                   return
                                    //                     getAccountController.GetAccountList.length==0?Center(child: Text("DataFound".tr)):
                                    //                     ListView.builder(
                                    //                         keyboardDismissBehavior: ScrollViewKeyboardDismissBehavior.onDrag,
                                    //                         itemCount: getAccountController.GetAccountList.length,
                                    //                         scrollDirection: Axis.horizontal,
                                    //                         shrinkWrap: true,
                                    //                         // clipBehavior: Clip.none,
                                    //                         physics: AlwaysScrollableScrollPhysics(),
                                    //                         itemBuilder: (BuildContext context, index) {
                                    //                           var accountsListData = getAccountController.GetAccountList[index];
                                    //                           return Padding(
                                    //                             padding: EdgeInsets.only(right: 5),
                                    //                             child: Container(
                                    //                               // padding:  EdgeInsets.only(left: 10,right: 10),
                                    //                               decoration: BoxDecoration(
                                    //                                   color: whiteColor,
                                    //                                   border: Border.all(
                                    //                                     color: selectedIndex == index ? buttonColor : Namecolors,
                                    //                                   ),
                                    //                                   borderRadius: BorderRadius.all(Radius.circular(10))
                                    //                               ),
                                    //                               child: Padding(
                                    //                                 padding:  EdgeInsets.symmetric(horizontal: 10,vertical: 25),
                                    //                                 child: Row(
                                    //                                   mainAxisAlignment: MainAxisAlignment.start,
                                    //                                   crossAxisAlignment: CrossAxisAlignment.start,
                                    //                                   children: [
                                    //                                     GestureDetector(
                                    //                                       onTap: (){
                                    //                                         setState(() {
                                    //
                                    //                                           selectedIndex = index;
                                    //                                           selectedRadio = accountsListData["id"];
                                    //                                           log("selectedIndex1---->$selectedRadio");
                                    //
                                    //                                         });
                                    //                                       },
                                    //
                                    //                                       child: Icon(selectedIndex == index ? Icons.radio_button_checked : Icons.radio_button_off,
                                    //                                         color: selectedIndex == index ? buttonColor : Namecolors,
                                    //                                       ),
                                    //                                     ),
                                    //                                     sizebox_width_5,
                                    //                                     VerticalDivider(
                                    //                                       color: selectedIndex == index ? buttonColor : Namecolors,
                                    //                                       thickness: 2,
                                    //                                     ),
                                    //                                     sizebox_width_5,
                                    //                                     Column(
                                    //                                       mainAxisAlignment: MainAxisAlignment.start,
                                    //                                       crossAxisAlignment: CrossAxisAlignment.start,
                                    //                                       children: [
                                    //                                         Text("Partner: ${accountsListData["name"].toString()}",
                                    //                                           maxLines: 2,
                                    //                                           overflow: TextOverflow.ellipsis,
                                    //                                           style: TextStyle(
                                    //                                             fontSize: 14,
                                    //                                             fontWeight: selectedIndex == index ? FontWeight.w600 : FontWeight.w100,
                                    //                                             letterSpacing: 0.5,
                                    //                                           ),),
                                    //                                         sizebox_height_2,
                                    //                                         Text("Relation: ${accountsListData["relation"].toString()}",
                                    //                                           maxLines: 2,
                                    //                                           overflow: TextOverflow.ellipsis,
                                    //                                           style: TextStyle(
                                    //                                               fontSize: 14,
                                    //                                               fontWeight: selectedIndex == index ? FontWeight.w600 : FontWeight.w100,
                                    //                                               letterSpacing: 0.5
                                    //                                           ),)
                                    //                                       ],
                                    //                                     )
                                    //                                   ],
                                    //                                 ),
                                    //                               ),
                                    //                             ),
                                    //                           );
                                    //                         });
                                    //               }
                                    //           ),
                                    //         ):Container(),
                                    //       ],
                                    //     );
                                    //   }
                                    // ),


                                    Padding(
                                      padding:  EdgeInsets.fromLTRB(10, 50, 10, 0),
                                      child: TextFormField(
                                        controller: _OTP,
                                        inputFormatters: [FilteringTextInputFormatter.allow(RegExp('[0-9]'))],
                                        keyboardType: TextInputType.numberWithOptions(decimal: true),
                                        autovalidateMode:
                                        AutovalidateMode.onUserInteraction,
                                        validator: (value) {
                                          if (value == null) {
                                            return "otptxt".tr;
                                          }
                                          else if (value.length != 4) {
                                            return "validotptxt".tr;
                                          }
                                          else
                                            return null;
                                        },
                                        maxLength: 4,
                                        textInputAction: TextInputAction.next,
                                        decoration: InputDecoration(
                                          filled: true,
                                          fillColor: whiteColor,
                                          contentPadding: EdgeInsets.only(top: 5),
                                          constraints :BoxConstraints(minWidth: 30, maxHeight:70),
                                          border: OutlineInputBorder(
                                            borderRadius: BorderRadius.circular(10),
                                          ),
                                          enabledBorder: OutlineInputBorder(
                                              borderRadius: BorderRadius.circular(10),
                                              borderSide: BorderSide( width: 1, color: Namecolors)
                                          ),
                                          focusedBorder: OutlineInputBorder(
                                              borderRadius: BorderRadius.circular(10),
                                              borderSide: BorderSide( width: 1, color: appPrimaryColor)
                                          ),
                                          focusedErrorBorder: OutlineInputBorder(
                                              borderRadius: BorderRadius.circular(10),
                                              borderSide: BorderSide(
                                                  width: 1, color: Colors.redAccent)),
                                          prefixIcon: PasswordIcon,
                                          hintText: "hintOTP".tr,
                                          counterText: "",
                                        ),
                                      ),
                                    ),
                                    Padding(
                                      padding:  EdgeInsets.only(top: 50,left: 80,right: 80),
                                      child: GestureDetector(
                                        onTap: () async {
                                          print("deviceid......");
                                          if (_formKey.currentState!.validate()) {
                                            var deviceid =await ApiBaseHelper().getId();
                                            var fcmid =await ApiBaseHelper().getToken();
                                            var loginOtp_url = login_OTP_url;
                                            print("deviceid......${deviceid.toString()}");
                                            print("fcmid......${fcmid.toString()}");
                                            print("otp......${_OTP.text}");
                                            var body =  tapType == "1"?({
                                              'mobile' : widget.mobileNo.toString(),
                                              'otp' : _OTP.text.toString(),
                                              'fcm_id': fcmid.toString(),
                                              'device_id': deviceid.toString(),
                                              'type' : "1",
                                            }):
                                            ({  'mobile' : widget.mobileNo.toString(),
                                              'otp' : _OTP.text.toString(),
                                              'fcm_id': fcmid.toString(),
                                              'device_id': deviceid.toString(),
                                              'type' : "2",
                                              'login_account' : selectedRadio.toString()});
                                            print("category---->"+body.toString());

                                            loginOTPController.LoginOTPApiCalling(loginOtp_url, body);
                                          }
                                        },
                                        child: Container(
                                          height: 40,
                                          // width: 150,
                                          decoration: BoxDecoration(
                                              color: buttonColor,
                                              border: Border.all(
                                                color: buttonColor,
                                              ),
                                              borderRadius:
                                              BorderRadius.all(Radius.circular(12))),
                                          child: Center(
                                            child: Text(
                                              "submitBtn".tr,
                                              style: TextStyle(
                                                  color: whiteColor,
                                                  fontSize: 16,
                                                  fontWeight: FontWeight.bold),
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                    sizebox_height_20
                                  ],
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),

                      ),
              ]),

              ],
            ),
      )
    );
  }
}


// if (_formKey.currentState!.validate()) {
// print('login type ...${ setting_json_data['data']['login_type'].toString()}');
// var sendOtp_url = sendOTP_url;
// var body=
// ({
// 'mobile' : _mobileNo.text
// });
// sendOTPcontroller.SendOTPApiCalling(sendOtp_url, body);
// print('send OTP Response......${sendOtp_u                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                               rl}'.toString());
// _mobileNo.clear();
// }