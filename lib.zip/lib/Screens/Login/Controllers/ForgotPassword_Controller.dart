import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:urwealthpal/Constant/Api.dart';
import 'package:urwealthpal/Constant/ApiBaseHelper.dart';
import 'package:urwealthpal/Screens/Login/loginNewScreen.dart';
import 'package:urwealthpal/Screens/Login/reset_password.dart';

class ForgotPasswordController extends GetxController{
  var ForgotPasswordDataLoading = false.obs;
  var Forgot_Password_Data ;
  var ResetPasswordDataLoading = false.obs;
  var Reset_Password_Data ;
  var email = TextEditingController();
  ForgotPasswordApiCalling(url, parameter) async {
    ForgotPasswordDataLoading.value =true;
    print("forgot response : " + url.toString());
    var response = await ApiBaseHelper().postAPICall(Uri.parse(url), parameter, false);
    var responsedata = jsonDecode(response.body);
    if(response.statusCode==200){
      Forgot_Password_Data = responsedata['data'];
      var otp = Forgot_Password_Data['token'].toString();
      toastMsg(otp, true);
      Get.to(reset_password());
      ForgotPasswordDataLoading.value =false;
      update();
    }
    else if(response.statusCode==422) {
      Forgot_Password_Data = responsedata['message'];
      var msg = Forgot_Password_Data.toString();
      toastMsg(msg, false);
      ForgotPasswordDataLoading.value = false;
      update();
    }
    else{
      Forgot_Password_Data =[];
      ForgotPasswordDataLoading.value =false;
      update();
    }
  }
  ResetPasswordApiCalling(url, parameter) async {
    ResetPasswordDataLoading.value =true;
    print("Reset Password response : " + url.toString());
    var response = await ApiBaseHelper().postAPICall(Uri.parse(url), parameter, false);
    var responsedata = jsonDecode(response.body);
    if(response.statusCode==200){
      toastMsg(responsedata['message'], true);
      Get.offAll(NewLoginScreen());
      email.clear();
      ResetPasswordDataLoading.value =false;
      update();
    }
    else if(response.statusCode==422) {
      Reset_Password_Data = responsedata['message'];
      var msg = Reset_Password_Data.toString();
      toastMsg(msg, false);
      ResetPasswordDataLoading.value = false;
      update();
    }
    else{
      Reset_Password_Data =[];
      ResetPasswordDataLoading.value =false;
      update();
    }
  }
}
