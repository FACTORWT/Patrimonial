import 'dart:convert';
import 'dart:developer';
import 'package:get/get.dart';
import 'package:urwealthpal/Constant/Api.dart';
import 'package:urwealthpal/Constant/ApiBaseHelper.dart';
import 'package:urwealthpal/Environment/Environment.dart';
import 'package:urwealthpal/main.dart';

class LoginOTPController extends GetxController{
  var LoginOTPDataLoading = false.obs;
  var LoginOTPData ;

  LoginOTPApiCalling(url, parameter) async {
    LoginOTPDataLoading.value =true;
    print("login OTP : " + url.toString());
    var response = await ApiBaseHelper().postAPICall(Uri.parse(url), parameter, false);
    var responsedata = jsonDecode(response.body);
    log("responsedata ======>> "+responsedata.toString());
    if(response.statusCode==200){
      ApiBaseHelper().logindata(responsedata);
      LoginOTPData = responsedata['data'];
      log("LoginOTPData>> "+LoginOTPData.toString());
      var askmpin = LoginOTPData['ask_mpin'];
      var setmpin = LoginOTPData['set_mpin'];
      sp!.setString("ask_mpin", LoginOTPData['ask_mpin'].toString());
      sp!.setString("set_mpin", LoginOTPData['set_mpin'].toString());
      sp!.setString("askQuestion", LoginOTPData['ask_question'].toString());
      sp!.setString("imagee",  LoginOTPData['user']['image']);
      sp!.setString("namee",  LoginOTPData['user']['name']);
      sp!.setString("mobilenum",LoginOTPData['user']['mobile']);
      sp!.setString("email", LoginOTPData['user']['email']);

      sp!.setBool("loggedin",true) ;
      if(LoginOTPData['has_subscription'].toString()=="1"){
        sp!.setBool("paymentstatus", true);
      }else{
        sp!.setBool("paymentstatus", true);
      }
      print("setMPIN...LoginOTP..."+Environment.setMPIN.toString());
      print("askMPIN...LoginOTP..."+Environment.askMPIN.toString());
      print("checkpaymentstatus...LoginOTP..."+Environment.checkpaymentstatus.toString());
      ApiBaseHelper().manageroute();
      LoginOTPData = responsedata['message'];
      var msg = LoginOTPData.toString();
      toastMsg(msg, true);
      // mpin.toString()== "0"?Get.offAll(bottombar(bottom: 2,)):
      // setmpin.toString()== "0"?Get.to(CreateMpinScreen()):Get.to(MPIN());
      LoginOTPDataLoading.value =false;
      update();
    } else if(response.statusCode==422) {
      // LoginOTPData = [];
      LoginOTPData = responsedata['message'];
      var msg = LoginOTPData.toString();
      toastMsg(msg, false);
      LoginOTPDataLoading.value = false;
      update();
    }
    else{
      LoginOTPData =[];
      LoginOTPDataLoading.value =false;
      update();
    }
  }
}

