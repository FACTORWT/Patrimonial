import 'dart:convert';
import 'package:get/get.dart';
import 'package:urwealthpal/Constant/Api.dart';
import 'package:urwealthpal/Constant/ApiBaseHelper.dart';

class GetAccountController extends GetxController {

  var GetAccountLoading = false.obs;
  List GetAccountList = [];

  // bool accountTap = false;

  var _accountTap =false;
  get accountTap => _accountTap;

  GetAccountApiCalling(url, parameter) async {
    GetAccountLoading.value =true;
    update();
    print("GetAccount " + url.toString());
    var response = await ApiBaseHelper().postAPICall(Uri.parse(url), parameter, true);
    var responsedata = jsonDecode(response.body);
    print("GetAccount responsedata : " + responsedata.toString());
    if(response.statusCode==200){

      // refresh();

      GetAccountList.clear();
      GetAccountList.addAll(responsedata['data']);
      GetAccountLoading.value =false;
      _accountTap = true;
      update();
    }
    else if(response.statusCode == 422){
      var msg = responsedata['message'];
      toastMsg(msg, false);
      _accountTap = false;
      GetAccountLoading.value = false;
      update();
    }
    else{
      var msg = responsedata['message'];
      toastMsg(msg, false);
      GetAccountList =[];
      _accountTap = false;
      GetAccountLoading.value =false;
      update();
    }

  }
}
