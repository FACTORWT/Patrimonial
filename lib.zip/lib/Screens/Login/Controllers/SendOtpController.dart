import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:urwealthpal/Constant/Api.dart';
import 'package:urwealthpal/Constant/ApiBaseHelper.dart';
import 'package:urwealthpal/Screens/Login/loginOTP.dart';

class SendOTPController extends GetxController{
  var SendOTPDataLoading = false.obs;
  var SendOTPData ;

  TextEditingController mobileNo = TextEditingController();

  SendOTPApiCalling(url, parameter) async {
    SendOTPDataLoading.value =true;
    print("send OTP : " + url.toString());
    var response = await ApiBaseHelper().postAPICall(Uri.parse(url), parameter, false);
    var responsedata = jsonDecode(response.body);
    if(response.statusCode==200){
      SendOTPData = responsedata['data'];
      // var otp = SendOTPData['message'].toString();
      // toastMsg(otp, true);
      print('moile3 no.... ${mobileNo.text}'.toString());
      Get.to(loginOTP(mobileNo: mobileNo.text,));
      mobileNo.clear();
      SendOTPDataLoading.value =false;
      update();
    }
    else if(response.statusCode==422) {
      SendOTPData = responsedata['message'];
      var msg = SendOTPData.toString();
      toastMsg(msg, false);
      SendOTPDataLoading.value = false;
      update();
    }
    else{
      SendOTPData =[];
      SendOTPDataLoading.value =false;
      update();
    }
  }

}
