import 'dart:convert';
import 'dart:developer';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:pinput/pinput.dart';
import 'package:urwealthpal/BottomBar/bottombar.dart';
import 'package:urwealthpal/Constant/Api.dart';
import 'package:urwealthpal/Constant/Images.dart';
import 'package:urwealthpal/Constant/Spacing.dart';
import 'package:urwealthpal/Constant/Strings.dart';
import 'package:urwealthpal/Constant/colors.dart';
import 'package:urwealthpal/Screens/Login/Controllers/ForgotPassword_Controller.dart';
import 'package:urwealthpal/Screens/Login/Controllers/GetAccountsController.dart';
import 'package:urwealthpal/main.dart';

class reset_password extends StatefulWidget {
  const reset_password({Key? key}) : super(key: key);

  @override
  State<reset_password> createState() => _reset_passwordState();
}

class _reset_passwordState extends State<reset_password> {
  var _formKey = GlobalKey<FormState>();
  var pinController = TextEditingController();
  final focusNode = FocusNode();
  var password = TextEditingController();
  var confirmPassword = TextEditingController();
  bool passToogle = true;
  bool passToogles = true;

  bool type = true;
  int? selectedIndex ;
  var selectedRadio ;

  var tapp = 1;

  var setting_json_data;

  ForgotPasswordController forgotPasswordController =Get.put(ForgotPasswordController());

  GetAccountController getAccountController = Get.put(GetAccountController());

  @override
  void initState()  {
    // TODO: implement initState
    super.initState();
    setting_json_data = json.decode(sp!.getString("setting").toString());

    getmsg();
  }
  getmsg(){
    log("check login type loginpage--->"+setting_json_data.toString());
  }

  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    final defaultPinTheme = PinTheme(
      width: 56,
      height: 56,
      textStyle:  TextStyle(
        fontSize: 22,
        color: Color.fromRGBO(30, 60, 87, 1),
      ),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: Colors.grey),
      ),
    );
    return Scaffold(
      resizeToAvoidBottomInset: false,
      body: Container(
        height: size.height,
          width: size.width,
          decoration: BoxDecoration(
            image: DecorationImage(
                image: AssetImage("assets/images/full_background.png"),
                fit: BoxFit.cover),
          ),
        child: Stack(
          children: [
            Form(
              key: _formKey,
                child: Column(
                  children: [
                    Container(
                        margin: EdgeInsets.only(top: 100),
                        alignment: Alignment.center,
                        width: size.width,
                        child: loginImage),
                    Container(
                      alignment: Alignment.center,
                      width: size.width,
                      child: Text(
                        "reset_txt".tr,
                        style: TextStyle(
                            color: whiteColor,
                            fontWeight: FontWeight.bold,
                            fontSize: 32),
                      ),
                    ),
                   Container(
                     decoration: BoxDecoration(
                       color: whiteColor,
                       border: Border.all(color: whiteColor),
                       borderRadius: BorderRadius.all(Radius.circular(30)),
                     ),
                     // height: size.height,
                     height: 500,
                     margin: EdgeInsets.only(top: 30,left: 20,right: 20),
                     child: SingleChildScrollView(
                       child: Column(
                         children: [
                           Padding(
                             padding: EdgeInsets.only(top: 30,),
                             child: Row(
                               mainAxisAlignment: MainAxisAlignment.center,
                               crossAxisAlignment: CrossAxisAlignment.center,
                               children: [
                                 GestureDetector(
                                   onTap: (){
                                     setState(() {
                                       type = true; // For Color changing
                                       tapp = 1;
                                     });
                                   },
                                   child: Container(
                                     padding: EdgeInsets.only(top: 3,),
                                     height: 30,
                                     width: 150,
                                     decoration: BoxDecoration(
                                       color: type == true ? buttonColor : whiteColor,
                                       border: Border.all(color: buttonColor),
                                       borderRadius: BorderRadius.all(Radius.circular(15)),
                                     ),
                                     child: Text("userlogin".tr,
                                       textAlign: TextAlign.center,
                                       style: TextStyle(
                                           fontWeight: FontWeight.w600,
                                           color: type == true ? whiteColor : buttonColor,
                                           fontSize: 18
                                       ),),
                                   ),
                                 ),
                                 sizebox_width_2,
                                 GestureDetector(
                                   onTap: (){
                                     setState(() {
                                       type = false;
                                       tapp = 2;
                                     });
                                   },
                                   child: Container(
                                     padding: EdgeInsets.only(top: 3,),
                                     height: 30,
                                     width: 150,
                                     decoration: BoxDecoration(
                                       color:  type == false ? buttonColor : whiteColor,
                                       border: Border.all(color: buttonColor),
                                       borderRadius: BorderRadius.all(Radius.circular(15)),
                                     ),
                                     child: Text("family_txt".tr,
                                       textAlign: TextAlign.center,
                                       style: TextStyle(
                                           fontWeight: FontWeight.w600,
                                           color: type == false ? whiteColor : buttonColor,
                                           fontSize: 18
                                       ),
                                     ),
                                   ),
                                 ),
                               ],
                             ),
                           ),

                           GetBuilder<GetAccountController>(
                               builder: (getAccountController) {
                              return Column(
                                children: [
                                  tapp == 2? GestureDetector(
                                    onTap: ()
                              {
                                FocusScope.of(context).requestFocus(
                                    new FocusNode());
                                if (_formKey.currentState!.validate()) {
                                  var GetAccountUrl = getAccountsList_url;
                                  var body = ({
                                    'email': forgotPasswordController.email.text
                                        .toString(),
                                    'type': '2',
                                  });
                                  getAccountController.GetAccountApiCalling(
                                      GetAccountUrl, body);
                                  log(
                                      'GetAccount Response......${GetAccountUrl}'
                                          .toString());
                                  log('GetAccount body......${body}'
                                      .toString());
                                }
                              },

                                    child: Padding(
                                      padding: EdgeInsets.only(top: 10,left: 150),
                                      child: Container(
                                        height: 40,
                                        width: 150,
                                        decoration: BoxDecoration(
                                            color: buttonColor,
                                            border: Border.all(
                                              color: buttonColor,
                                            ),
                                            borderRadius:
                                            BorderRadius.all(Radius.circular(12))),
                                        child: Center(
                                          child: Text(
                                            "getAccount".tr,
                                            style: TextStyle(
                                                color: whiteColor,
                                                fontSize: 16,
                                                fontWeight: FontWeight.bold),
                                          ),
                                        ),
                                      ),
                                    ),
                                  ):Container(),

                                  getAccountController.accountTap == false ? Container(): tapp == 2? Container(
                                      padding: EdgeInsets.only(top: 10,left: 5),
                                      alignment: Alignment.topLeft,
                                      child: Text("Select Account",
                                        style: TextStyle(
                                            fontSize: 18,
                                            color: buttonColor,
                                            fontWeight: FontWeight.w600
                                        ),
                                      )
                                  ):Container(),

                                  getAccountController.accountTap == false ? Container(): tapp == 2? Container(
                                    padding:  EdgeInsets.only(top: 4,left: 10,right: 10),
                                    height: 90,
                                    child:   GetBuilder<GetAccountController>(
                                        builder: (getAccountController) {
                                          if(getAccountController.GetAccountLoading.value){
                                            return Center(child: CircularProgressIndicator());
                                          }
                                          else
                                            return
                                              getAccountController.GetAccountList.length==0?Center(child: Text("DataFound".tr)): ListView.builder(
                                                  itemCount: getAccountController.GetAccountList.length,
                                                  scrollDirection: Axis.horizontal,
                                                  shrinkWrap: true,
                                                  // clipBehavior: Clip.none,
                                                  physics: AlwaysScrollableScrollPhysics(),
                                                  itemBuilder: (BuildContext context, index) {
                                                    var accountsListData = getAccountController.GetAccountList[index];
                                                    return Padding(
                                                      padding: EdgeInsets.only(right: 5),
                                                      child: Container(
                                                        // padding:  EdgeInsets.only(left: 10,right: 10),
                                                        decoration: BoxDecoration(
                                                            color: whiteColor,
                                                            border: Border.all(
                                                              color: selectedIndex == index ? buttonColor : Namecolors,
                                                            ),
                                                            borderRadius: BorderRadius.all(Radius.circular(10))
                                                        ),
                                                        child: Padding(
                                                          padding:  EdgeInsets.symmetric(horizontal: 10,vertical: 25),
                                                          child: Row(
                                                            mainAxisAlignment: MainAxisAlignment.start,
                                                            crossAxisAlignment: CrossAxisAlignment.start,
                                                            children: [
                                                              GestureDetector(
                                                                onTap: (){
                                                                  setState(() {

                                                                    selectedIndex = index;
                                                                    selectedRadio = accountsListData["id"];
                                                                    log("selectedIndex1---->$selectedRadio");

                                                                  });
                                                                },

                                                                child: Icon(selectedIndex == index ? Icons.radio_button_checked : Icons.radio_button_off,
                                                                  color: selectedIndex == index ? buttonColor : Namecolors,
                                                                ),
                                                              ),
                                                              sizebox_width_5,
                                                              VerticalDivider(
                                                                color: selectedIndex == index ? buttonColor : Namecolors,
                                                                thickness: 2,
                                                              ),
                                                              sizebox_width_5,
                                                              Column(
                                                                mainAxisAlignment: MainAxisAlignment.start,
                                                                crossAxisAlignment: CrossAxisAlignment.start,
                                                                children: [
                                                                  Text("Partner: ${accountsListData["name"].toString()}",
                                                                    maxLines: 2,
                                                                    overflow: TextOverflow.ellipsis,
                                                                    style: TextStyle(
                                                                      fontSize: 14,
                                                                      fontWeight: selectedIndex == index ? FontWeight.w600 : FontWeight.w100,
                                                                      letterSpacing: 0.5,
                                                                    ),),
                                                                  sizebox_height_2,
                                                                  Text("Relation: ${accountsListData["relation"].toString()}",
                                                                    maxLines: 2,
                                                                    overflow: TextOverflow.ellipsis,
                                                                    style: TextStyle(
                                                                        fontSize: 14,
                                                                        fontWeight: selectedIndex == index ? FontWeight.w600 : FontWeight.w100,
                                                                        letterSpacing: 0.5
                                                                    ),)
                                                                ],
                                                              )
                                                            ],
                                                          ),
                                                        ),
                                                      ),
                                                    );
                                                  });
                                        }
                                    ),
                                  ):Container(),
                                ],
                              );
                            }
                          ),


                           Padding(
                             padding: EdgeInsets.only(top: 20),
                             child: Pinput(
                               controller: pinController,
                               focusNode: focusNode,
                               // androidSmsAutofillMethod:
                               // AndroidSmsAutofillMethod.smsUserConsentApi,
                               // listenForMultipleSmsOnAndroid: true,
                               defaultPinTheme: defaultPinTheme,
                               validator: (value) {
                                 return value!.length == 0 ? "fillPin".tr : null;
                               },
                               // onClipboardFound: (value) {
                               //   debugPrint('onClipboardFound: $value');
                               //   pinController.setText(value);
                               // },

                               hapticFeedbackType: HapticFeedbackType.lightImpact,
                               onCompleted: (pin) {
                                 debugPrint('onCompleted: $pin');
                               },
                               onChanged: (value) {
                                 debugPrint('onChanged: $value');
                               },
                               cursor: Column(
                                 mainAxisAlignment: MainAxisAlignment.end,
                                 children: [
                                   Container(
                                     margin:  EdgeInsets.only(bottom: 9),
                                     width: 22,
                                     height: 1,
                                     color: appPrimaryColor,
                                   ),
                                 ],
                               ),
                               focusedPinTheme: defaultPinTheme.copyWith(
                                 decoration: defaultPinTheme.decoration!.copyWith(
                                   borderRadius: BorderRadius.circular(8),
                                   border: Border.all(color: appPrimaryColor),
                                 ),
                               ),
                               submittedPinTheme: defaultPinTheme.copyWith(
                                 decoration: defaultPinTheme.decoration!.copyWith(
                                   borderRadius: BorderRadius.circular(10),
                                   border: Border.all(color: appPrimaryColor),
                                 ),
                               ),
                               errorPinTheme: defaultPinTheme.copyBorderWith(
                                 border: Border.all(color: Colors.redAccent),
                               ),
                             ),
                           ),
                           SizedBox(
                             height: 20,
                           ),
                           Padding(
                             padding:  EdgeInsets.only(left: 10,right: 10),
                             child: TextFormField(
                               controller: password,
                               autovalidateMode:
                               AutovalidateMode.onUserInteraction,
                               scrollPadding: EdgeInsets.only(
                                   bottom: MediaQuery.of(context).viewInsets.bottom + 25*4),
                               validator: (value) {
                                 if (value == null || value.isEmpty) {
                                   return "valid_password_txt".tr;
                                 }
                                 if (value.length < 6) {
                                   return "new_password_correct_txt".tr;
                                 }
                                 return null; // Validation passed
                               },
                               obscureText: passToogle,
                               textInputAction: TextInputAction.next,
                               decoration: InputDecoration(
                                 filled: true,
                                 fillColor: whiteColor,
                                 contentPadding: EdgeInsets.only(top: 5),
                                 constraints: BoxConstraints(
                                     minWidth: 30, maxHeight: 70),
                                 border: OutlineInputBorder(
                                   borderRadius: BorderRadius.circular(10),
                                 ),
                                 enabledBorder: OutlineInputBorder(
                                     borderRadius: BorderRadius.circular(10),
                                     borderSide: BorderSide(
                                         width: 1, color: Namecolors)),
                                 focusedBorder: OutlineInputBorder(
                                     borderRadius: BorderRadius.circular(10),
                                     borderSide: BorderSide(
                                         width: 1, color: appPrimaryColor)),
                                 focusedErrorBorder: OutlineInputBorder(
                                     borderRadius: BorderRadius.circular(10),
                                     borderSide: BorderSide(
                                         width: 1, color: Colors.redAccent)),
                                 prefixIcon: PasswordIcon,
                                 hintText: "hint_newPassword".tr,
                                 suffixIcon: InkWell(
                                   onTap: () {
                                     setState(() {
                                       passToogle = !passToogle;
                                     });
                                   },
                                   child: Icon(passToogle
                                       ?  Icons.visibility_off
                                       : Icons.visibility),
                                 ),
                               ),
                             ),
                           ),
                           SizedBox(height: 15),
                           Padding(
                             padding:  EdgeInsets.only(left: 10,right: 10),
                             child: TextFormField(
                               controller: confirmPassword,
                               autovalidateMode:
                               AutovalidateMode.onUserInteraction,
                               scrollPadding: EdgeInsets.only(bottom:40),
                               validator: (value) {
                                 if (value!.isEmpty) {
                                   return "valid_confirm_txt".tr;
                                 } else if (password.text !=
                                     confirmPassword.text) {
                                   return "confirm_password_txt".tr;
                                 } else
                                   return null;
                               },
                               obscureText: passToogles,
                               textInputAction: TextInputAction.done,
                               decoration: InputDecoration(
                                 filled: true,
                                 fillColor: whiteColor,
                                 contentPadding: EdgeInsets.only(top: 5),
                                 constraints: BoxConstraints(
                                     minWidth: 30, maxHeight: 70),
                                 border: OutlineInputBorder(
                                   borderRadius: BorderRadius.circular(10),
                                 ),
                                 enabledBorder: OutlineInputBorder(
                                     borderRadius: BorderRadius.circular(10),
                                     borderSide: BorderSide(
                                         width: 1, color: Namecolors)),
                                 focusedBorder: OutlineInputBorder(
                                     borderRadius: BorderRadius.circular(10),
                                     borderSide: BorderSide(
                                         width: 1, color: appPrimaryColor)),
                                 focusedErrorBorder: OutlineInputBorder(
                                     borderRadius: BorderRadius.circular(10),
                                     borderSide: BorderSide(
                                         width: 1, color: Colors.redAccent)),
                                 prefixIcon: PasswordIcon,
                                 hintText: "hintConfimPassword".tr,
                                 suffixIcon: InkWell(
                                   onTap: () {
                                     setState(() {
                                       passToogles = !passToogles;
                                     });
                                   },
                                   child: Icon(passToogles
                                       ?  Icons.visibility_off
                                       : Icons.visibility
                                           ),
                                 ),
                               ),
                             ),
                           ),
                           Padding(
                             padding:  EdgeInsets.only(top: 30,left: 80,right: 80),
                             child: GestureDetector(
                               onTap: (){
                                 if (_formKey.currentState!.validate()){
                                  var resetpassword_url = reset_password_url;

                                  var body = tapp==1?({
                                    'email' : forgotPasswordController.email.text,
                                    'motp' : pinController.text,
                                    'password' : password.text,
                                    'password_confirmation' : confirmPassword.text,
                                    'type' : '1',
                                  }):({
                                    'email' : forgotPasswordController.email.text,
                                    'motp' : pinController.text,
                                    'password' : password.text,
                                    'password_confirmation' : confirmPassword.text,
                                    'type' : '2',
                                    'login_account' : selectedRadio.toString()
                                  });
                                  forgotPasswordController.ResetPasswordApiCalling(resetpassword_url, body);
                                 }
                               },
                               child: Container(
                                 height: 40,
                                 width: 150,
                                 decoration: BoxDecoration(
                                     color: buttonColor,
                                     border: Border.all(
                                       color: buttonColor,
                                     ),
                                     borderRadius:
                                     BorderRadius.all(Radius.circular(12))),
                                 child: Center(
                                   child: Text(
                                     "submitBtn".tr,
                                     style: TextStyle(
                                         color: whiteColor,
                                         fontSize: 16,
                                         fontWeight: FontWeight.bold),
                                   ),
                                 ),
                               ),
                             ),
                           ),
                           sizebox_height_20
                         ],
                       ),
                     ),
                   ),
                  ],
                ))
          ],
        ),
      ),
    );
  }
}
