import 'dart:convert';
import 'dart:developer';
import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:urwealthpal/Constant/Api.dart';
import 'package:urwealthpal/Constant/ApiBaseHelper.dart';
import 'package:urwealthpal/Constant/Images.dart';
import 'package:urwealthpal/Constant/colors.dart';
import 'package:urwealthpal/Environment/Environment.dart';
import 'package:urwealthpal/Screens/Login/Controllers/SendOtpController.dart';
import 'package:urwealthpal/Screens/Login/forgot_password.dart';
import 'package:urwealthpal/Screens/Register/register.dart';
import '../../main.dart';

class login extends StatefulWidget {
  const login({Key? key}) : super(key: key);

  @override
  State<login> createState() => _loginState();
}

class _loginState extends State<login> {
  var _formKey = GlobalKey<FormState>();
  var _emailId = TextEditingController();

  var _pws = TextEditingController();
  bool passToogle = true;
  bool registered = true;

  var setting_json_data;
  SendOTPController sendOTPcontroller =Get.put(SendOTPController());

  @override
  void initState()  {
    // TODO: implement initState
    super.initState();
    setting_json_data = json.decode(sp!.getString("setting").toString());

    getmsg();
  }
getmsg(){
  log("check login type loginpage--->"+setting_json_data.toString());
}
  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return Scaffold(
      resizeToAvoidBottomInset: false,
      body: Container(
          height: size.height,
          width: size.width,
          decoration: BoxDecoration(
            image: DecorationImage(
                image: AssetImage("assets/images/full_background.png"),
                fit: BoxFit.cover),
          ),
          child: Stack(
            children: [
              Form(
                  key: _formKey,
                  child: SingleChildScrollView(
                    child: Column(
                      children: [
                        // SizedBox(
                        //   height: 50,
                        // ),
                        Container(
                          margin: EdgeInsets.only(top: 100),
                            alignment: Alignment.center,
                            width: size.width,
                            child: loginImage),
                        Container(
                          alignment: Alignment.center,
                          width: size.width,
                          child: Text(
                            "loginn".tr,
                            style: TextStyle(
                                color: whiteColor,
                                fontWeight: FontWeight.bold,
                                fontSize: 32),
                          ),
                        ),
                        // SizedBox(
                        //   height: 50,
                        // ),

                        Container(
                          // width: size.width-30,
                          // color: whiteColor,
                          decoration: BoxDecoration(
                                    color: whiteColor,
                                    border: Border.all(color: whiteColor),
                                    borderRadius: BorderRadius.all(Radius.circular(30)),
                                  ),
                          // height: size.height,
                          height: 400,
                          margin: EdgeInsets.only(top: 30,left: 20,right: 20),
                          child: Column(
                                      children: [
                                        int.parse(setting_json_data['data']['login_type'].toString())==1?
                                        Padding(
                                          padding: EdgeInsets.fromLTRB(10, 60, 10, 0),
                                          child: TextFormField(
                                            controller: _emailId,
                                            autovalidateMode:
                                            AutovalidateMode.onUserInteraction,
                                            scrollPadding: EdgeInsets.only(
                                                bottom: MediaQuery.of(context).viewInsets.bottom + 25*4),
                                            validator: (value) {
                                              if (value == null || value.isEmpty) {
                                                return "email".tr;
                                              }
                                              if (!RegExp(
                                                  r'^[\w-]+(\.[\w-]+)*@[\w-]+(\.[\w-]+)+$')
                                                  .hasMatch(value)) {
                                                return "validEmail".tr;
                                              }
                                              return null; // Validation passed
                                            },
                                            keyboardType: TextInputType.emailAddress,
                                            textInputAction: TextInputAction.next,
                                            decoration: InputDecoration(
                                                filled: true,
                                                fillColor: whiteColor,
                                                contentPadding: EdgeInsets.only(top: 5),
                                                constraints: BoxConstraints(
                                                    minWidth: 30, maxHeight: 70),
                                                border: OutlineInputBorder(
                                                  borderRadius: BorderRadius.circular(10),
                                                ),
                                                enabledBorder: OutlineInputBorder(
                                                    borderRadius: BorderRadius.circular(10),
                                                    borderSide: BorderSide(
                                                        width: 1, color: Namecolors)),
                                                focusedBorder: OutlineInputBorder(
                                                    borderRadius: BorderRadius.circular(10),
                                                    borderSide: BorderSide(
                                                        width: 1, color: appPrimaryColor)),
                                                focusedErrorBorder: OutlineInputBorder(
                                                    borderRadius: BorderRadius.circular(10),
                                                    borderSide: BorderSide(
                                                        width: 1, color: Colors.redAccent)),
                                                prefixIcon: Container( child:
                                                Image.asset("assets/images/email (1).png",scale: 3,width: 15,)),
                                                hintText: "hintEmail".tr),
                                          ),

                                        ):
                                        Padding(
                                          padding: EdgeInsets.fromLTRB(10, 60, 10, 0),
                                          child: TextFormField(
                                            controller: sendOTPcontroller.mobileNo,
                                            scrollPadding: EdgeInsets.only(
                                                bottom: MediaQuery.of(context).viewInsets.bottom + 25*4),
                                            // inputFormatters: [
                                            //   FilteringTextInputFormatter.allow(
                                            //       RegExp('[0-9]'))
                                            // ],
                                            keyboardType: TextInputType.numberWithOptions(
                                                decimal: true),
                                            autovalidateMode:
                                            AutovalidateMode.onUserInteraction,
                                            validator: (value) {
                                              if (value == null || value.isEmpty) {
                                                return "validMobileNo".tr;
                                              }
                                              if (value.length == 0) {
                                                return "valid_Mobile_No_txt".tr;
                                              }
                                              return null; // Validation passed
                                            },
                                            // maxLength: 10,
                                            textInputAction: TextInputAction.next,
                                            decoration: InputDecoration(
                                              filled: true,
                                              fillColor: whiteColor,
                                              contentPadding: EdgeInsets.only(top: 5),
                                              constraints: BoxConstraints(
                                                  minWidth: 30, maxHeight: 70),
                                              border: OutlineInputBorder(
                                                borderRadius: BorderRadius.circular(10),
                                              ),
                                              enabledBorder: OutlineInputBorder(
                                                  borderRadius: BorderRadius.circular(10),
                                                  borderSide: BorderSide(
                                                      width: 1, color: Namecolors)),
                                              focusedBorder: OutlineInputBorder(
                                                  borderRadius: BorderRadius.circular(10),
                                                  borderSide: BorderSide(
                                                      width: 1, color: appPrimaryColor)),
                                              focusedErrorBorder: OutlineInputBorder(
                                                  borderRadius: BorderRadius.circular(10),
                                                  borderSide: BorderSide(
                                                      width: 1, color: Colors.redAccent)),
                                              prefixIcon: PhoneIcon,
                                              hintText: "hintMobileNo".tr,
                                              counterText: "",
                                            ),
                                          ),
                                        ),

                                        // TextFormField(
                                        //   controller: _mobileNo,
                                        //   // inputFormatters: [
                                        //   //   FilteringTextInputFormatter.allow(RegExp(r'^(([^<>()[]\.,;:\s@"]+(.[^<>()[]\.,;:\s@"]+)*)|(".+"))@(([[0-9]{1,3}.[0-9]{1,3}.[0-9]{1,3}.[0-9]{1,3}])|(([a-zA-Z-0-9]+.)+[a-zA-Z]{2,}))$|^(\+\d{1,2}\s)?\(?\d{3}\)?[\s.-]\d{3}[\s.-]\d{4}$'),)],
                                        //   // keyboardType:
                                        //   //     TextInputType.numberWithOptions(decimal: true),
                                        //   autovalidateMode: AutovalidateMode.onUserInteraction,
                                        //   validator: (value) {
                                        //     if(value!.contains('@')){
                                        //      if(value == null ||
                                        //         value.isEmpty || !value.contains('@') || !value.contains('.')) {
                                        //       return validEmail;
                                        //     }
                                        //     }else{
                                        //       if (value == null) {
                                        //         return validMobileNo;
                                        //       } else if (value.length != 10) {
                                        //         return correctMobileNo;
                                        //       }
                                        //     }
                                        //     return null;
                                        //   },
                                        //   // maxLength: 10,
                                        //   textInputAction: TextInputAction.next,
                                        //   decoration: InputDecoration(
                                        //       filled: true,
                                        //       fillColor: Colors.white,
                                        //       border: OutlineInputBorder(
                                        //         borderRadius: BorderRadius.circular(10),
                                        //       ),
                                        //       enabledBorder: OutlineInputBorder(
                                        //           borderRadius: BorderRadius.circular(10),
                                        //           borderSide: BorderSide( width: 1, color: appPrimaryColor)
                                        //       ),
                                        //       focusedBorder: OutlineInputBorder(
                                        //           borderRadius: BorderRadius.circular(10),
                                        //           borderSide: BorderSide( width: 1, color: appPrimaryColor)
                                        //       ),
                                        //       focusedErrorBorder: OutlineInputBorder(
                                        //           borderRadius: BorderRadius.circular(10),
                                        //           borderSide: BorderSide(
                                        //               width: 1, color: Colors.redAccent)),
                                        //       prefixIcon: PhoneIcon,
                                        //       label: Text(mobileNo_Emailtxt),
                                        //       counterText: ""),
                                        // ),
                                        SizedBox(
                                          height: 30,
                                        ),

                                        int.parse(setting_json_data['data']['login_type'].toString())==1?
                                        Padding(
                                          padding: EdgeInsets.fromLTRB(10, 0, 10, 0),
                                          child: TextFormField(
                                            controller: _pws,
                                            autovalidateMode: AutovalidateMode.onUserInteraction,
                                            validator: (value) {
                                              if (value!.isEmpty) {
                                                return "validPassword".tr;
                                              } else if (value.length < 6) {
                                                return "correctPassword".tr;
                                              } else
                                                return null;
                                            },
                                            obscureText: passToogle,
                                            textInputAction: TextInputAction.next,
                                            decoration: InputDecoration(
                                              filled: true,
                                              fillColor: whiteColor,
                                              hintText: "hintPassword".tr,
                                              contentPadding: EdgeInsets.only(top: 5),
                                              constraints:
                                                  BoxConstraints(minWidth: 30, maxHeight: 70),
                                              border: OutlineInputBorder(
                                                borderRadius: BorderRadius.circular(10),
                                              ),
                                              enabledBorder: OutlineInputBorder(
                                                  borderRadius: BorderRadius.circular(10),
                                                  borderSide:
                                                      BorderSide(width: 1, color: Namecolors)),
                                              focusedBorder: OutlineInputBorder(
                                                  borderRadius: BorderRadius.circular(10),
                                                  borderSide: BorderSide(
                                                      width: 1, color: appPrimaryColor)),
                                              focusedErrorBorder: OutlineInputBorder(
                                                  borderRadius: BorderRadius.circular(10),
                                                  borderSide: BorderSide(
                                                      width: 1, color: Colors.redAccent)),
                                              prefixIcon: Container(
                                                child: Image.asset("assets/images/passIcon.png",
                                                  scale: 3,width: 15,),
                                              ),
                                              suffixIcon: InkWell(
                                                onTap: () {
                                                  setState(() {
                                                    passToogle = !passToogle;
                                                  });
                                                },
                                                child: Icon(passToogle
                                                    ? Icons.visibility
                                                    : Icons.visibility_off),
                                              ),
                                            ),
                                          ),
                                        ):Container(),

                                        int.parse(setting_json_data['data']['login_type'].toString())==1?
                                        Align(
                                          alignment: Alignment.centerLeft,
                                          child: Padding(
                                            padding: EdgeInsets.only(top: 10,left: 10),
                                            child: GestureDetector(
                                              onTap: () {
                                                Navigator.push(
                                                    context,
                                                    MaterialPageRoute(
                                                        builder: (context) =>
                                                        forgot_password()));
                                              },
                                              child: Text("forgotPasstxt".tr,
                                                  style: TextStyle(
                                                    color: appPrimaryColor,
                                                    fontSize: 16,
                                                  )),
                                            ),
                                          ),
                                        ):
                                        Container(),
                                        int.parse(setting_json_data['data']['login_type'].toString())==1?
                                        Padding(
                                          padding: EdgeInsets.only(top: 15),
                                          child: GestureDetector(
                                            onTap: () async {
                                              var deviceid =await ApiBaseHelper().getId();
                                              var fcmid =await ApiBaseHelper().getToken();
                                              log("fcmid---->$fcmid");
                                              log("deviceid---->$deviceid");
                                              if (_formKey.currentState!.validate()) {
                                                var loginurl = Uri.parse(login_url);
                                                var body = ({
                                          'email': _emailId.text,
                                          'password': _pws.text,
                                          'fcm_id': fcmid.toString(),
                                          'device_id': deviceid.toString()
                                        });
                                                var response = await ApiBaseHelper().postAPICall(loginurl,body, false);
                                                var login = jsonDecode(response.body);
                                                log("login : "+response.statusCode.toString());
                                                if(response.statusCode==200){
                                                  log("login : "+login.toString());
                                                  sp!.setBool("loggedin",true) ;
                                                  ApiBaseHelper().logindata(login);
                                                  var   LoginOTPData = login['data'];
                                                  // var askmpin = LoginOTPData['ask_mpin'].toString();
                                                  // var setmpin = LoginOTPData['set_mpin'].toString();
                                                  sp!.setString("ask_mpin", LoginOTPData['ask_mpin'].toString());
                                                  sp!.setString("set_mpin", LoginOTPData['set_mpin'].toString());
                                                  sp!.setString("askQuestion", LoginOTPData['ask_question'].toString());

                                                  // sp!.setString("set_mpin", LoginOTPData['has_subscription'].toString());
                                                  if(LoginOTPData['has_subscription'].toString()=="1"){
                                                    sp!.setBool("paymentstatus", true);
                                                  }else{
                                                    sp!.setBool("paymentstatus", true);
                                                  }
                                                  _emailId.clear();
                                                  _pws.clear();
                                                  print("setMPIN...LoginEmail..."+Environment.setMPIN.toString());
                                                  print("askMPIN...LoginEmail..."+Environment.askMPIN.toString());
                                                  print("checkpaymentstatus...LoginEmail..."+Environment.checkpaymentstatus.toString());
                                                  ApiBaseHelper().manageroute();
                                                  toastMsg(login['message'], true);
                                                }
                                                else if(response.statusCode==422){
                                                  toastMsg(login['message'], false);
                                                }
                                              }
                                            },
                                            child: Container(
                                              height: 40,
                                              width: 150,
                                              decoration: BoxDecoration(
                                                  color: buttonColor,
                                                  border: Border.all(
                                                    color: buttonColor,
                                                  ),
                                                  borderRadius:
                                                      BorderRadius.all(Radius.circular(12))),
                                              child: Center(
                                                child: Text(
                                                  "signIn".tr,
                                                  style: TextStyle(
                                                      color: whiteColor,
                                                      fontSize: 16,
                                                      fontWeight: FontWeight.bold),
                                                ),
                                              ),
                                            ),
                                          ),
                                        ):
                                        Padding(
                                          padding: EdgeInsets.only(top: 15),
                                          child: GestureDetector(
                                            onTap: () async {
                                              if (_formKey.currentState!.validate()) {
                                                print('login type ...${ setting_json_data['data']['login_type'].toString()}');
                                                var sendOtp_url = sendOTP_url;
                                                var body=
                                                ({
                                                  'mobile' : sendOTPcontroller.mobileNo.text
                                                });
                                                sendOTPcontroller.SendOTPApiCalling(sendOtp_url, body);
                                                print('send OTP Response......${sendOtp_url}'.toString());
                                                // sendOTPcontroller.mobileNo.clear();
                                              }
                                            },
                                            child: Container(
                                              height: 40,
                                              width: 150,
                                              decoration: BoxDecoration(
                                                  color: buttonColor,
                                                  border: Border.all(
                                                    color: buttonColor,
                                                  ),
                                                  borderRadius:
                                                  BorderRadius.all(Radius.circular(12))),
                                              child: Center(
                                                child: Text(
                                                  "send_OTP_txt".tr,
                                                  style: TextStyle(
                                                      color: whiteColor,
                                                      fontSize: 16,
                                                      fontWeight: FontWeight.bold),
                                                ),
                                              ),
                                            ),
                                          ),
                                        ),

                                        SizedBox(
                                          height:40,
                                        ),
                                        RichText(
                                          text: TextSpan(
                                              text: "accounttxt".tr,
                                              style: TextStyle(
                                                color: Color(0xFF94A0AC),
                                                fontSize: 15,
                                              ),
                                              children: <TextSpan>[
                                                TextSpan(
                                                    text: "registertxt".tr,
                                                    style: TextStyle(
                                                      color: appPrimaryColor,
                                                      fontSize: 15,
                                                    ),
                                                    recognizer: TapGestureRecognizer()
                                                      ..onTap = () {
                                                        Navigator.push(
                                                            context,
                                                            MaterialPageRoute(
                                                              builder: (context) => register(),
                                                            ));
                                                      })
                                              ]),
                        )
                      ],
                    )
                        )
            ],
          ),
                  ))
              ,
        ]
      )
      )
    );
  }
}
