// import 'package:flutter/material.dart';
// import 'package:get/get.dart';
// import 'package:urwealthpal/Constant/Images.dart';
// import 'package:urwealthpal/Constant/colors.dart';
//
// class SearchBars extends StatefulWidget {
//   const SearchBars({Key? key}) : super(key: key);
//
//   @override
//   State<SearchBars> createState() => _SearchBarState();
// }
//
// class _SearchBarState extends State<SearchBars> {
//
//   TextEditingController _searchController = TextEditingController();
//
//
//   List searchList = [
//     {
//       "texts": "Credit Card",
//       "image": "assets/images/Financial_Assets.png"
//     },
//     {
//       "texts": "Bank Credit",
//       "image": "assets/images/Fixed_Assets.png"
//     },
//     {
//       "texts": "Personal Credit",
//       "image": "assets/images/business.png"
//     },
//     {
//       "texts": "Auto Loan",
//       "image": "assets/images/Financial_Assets.png"
//     },
//     {
//       "texts": "House Mortgage",
//       "image": "assets/images/Fixed_Assets.png"
//     },
//     {
//       "texts": "Rent",
//       "image": "assets/images/business.png"
//     },
//     {
//       "texts": "Electricity",
//       "image": "assets/images/Financial_Assets.png"
//     },
//     {
//       "texts": "Others",
//       "image": "assets/images/Fixed_Assets.png"
//     },
//   ];
//
//   List<String> searchTerms = [
//     "Apple",
//     "Banana",
//     "Mango",
//     "Pear",
//     "Watermelons",
//     "Blueberries",
//     "Pineapples",
//     "Strawberries"
//   ];
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       body: Padding(
//         padding: EdgeInsets.only(top: 50,left: 10,right: 10),
//         child: TextFormField(
//           onTap: (){
//             // Navigator.push(context, MaterialPageRoute(builder:
//             //     (context)=> SearchBar()));
//             setState(() {
//               ListView.builder(
//                   itemCount: searchList.length,
//                   scrollDirection: Axis.vertical,
//                   shrinkWrap: true,
//                   physics: NeverScrollableScrollPhysics(),
//                   itemBuilder:
//                       (BuildContext context, index) {
//                     var listdata = searchList[index];
//                     return Padding(
//                       padding:  EdgeInsets.only(left: 10,right: 10,top: 5),
//                       child: Card(
//                         elevation: 2,
//                         child: Text(
//                             listdata["texts"]
//                                 .toString(),
//                             style: TextStyle(
//                               // color: Colors.black,
//                                 fontSize: 18)),
//                       ),
//                     );
//                   });
//             });
//           },
//           controller: _searchController,
//           decoration: InputDecoration(
//             filled: true,
//             fillColor: whiteColor,
//             border: OutlineInputBorder(
//               borderRadius: BorderRadius.circular(10),
//             ),
//             focusedBorder: OutlineInputBorder(
//                 borderRadius: BorderRadius.circular(10),
//                 borderSide:
//                 BorderSide(width: 1, color: appPrimaryColor)),
//             suffixIcon: SearchIcon,
//             label: Text("search".tr),
//           ),
//         ),
//       ),
//       // appBar: AppBar(
//       //   elevation: 0,
//       //   backgroundColor: Colors.transparent,
//       //   title: TextFormField(
//       //     onTap: (){
//       //       // Navigator.push(context, MaterialPageRoute(builder:
//       //       //     (context)=> SearchBar()));
//       //     },
//       //     controller: _searchController,
//       //     decoration: InputDecoration(
//       //       filled: true,
//       //       fillColor: ContainerColor,
//       //       border: OutlineInputBorder(
//       //         borderRadius: BorderRadius.circular(10),
//       //       ),
//       //       focusedBorder: OutlineInputBorder(
//       //           borderRadius: BorderRadius.circular(10),
//       //           borderSide:
//       //           BorderSide(width: 1, color: appPrimaryColor)),
//       //       suffixIcon: SearchIcon,
//       //       label: Text(search,style: TextStyle(color: whiteColor),),
//       //     ),
//       //   ),
//       // ),
//       // body: SizedBox(
//       //   width: double.infinity,
//       //   child: Column(
//       //     children: [
//       //        Text('Searchable list with divider'),
//       //       Expanded(
//       //         child: Padding(
//       //           padding: EdgeInsets.all(15),
//       //           child: renderAsynchSearchableListview(),
//       //         ),
//       //       ),
//       //       Align(
//       //         alignment: Alignment.center,
//       //         child: ElevatedButton(
//       //           onPressed: addActor,
//       //           child:  Text('Add actor'),
//       //         ),
//       //       )
//       //     ],
//       //   ),
//       // ),
//     );
//   }
//
// //   void addActor() {
// //     actors.add(Actor(
// //       age: 10,
// //       lastName: 'Ali',
// //       name: 'ALi',
// //     ));
// //     setState(() {});
// //   }
// //
// //   Widget renderSimpleSearchableList() {
// //     return SearchableList<Actor>(
// //       seperatorBuilder: (context, index) {
// //         return  Divider();
// //       },
// //       style:  TextStyle(fontSize: 25),
// //       builder: (list, index, item) {
// //         return ActorItem(actor: item);
// //       },
// //       errorWidget: Column(
// //         mainAxisAlignment: MainAxisAlignment.center,
// //         children: const [
// //           Icon(
// //             Icons.error,
// //             color: Colors.red,
// //           ),
// //           SizedBox(
// //             height: 20,
// //           ),
// //           Text('Error while fetching actors')
// //         ],
// //       ),
// //       initialList: actors,
// //       filter: (p0) {
// //         return actors.where((element) => element.name.contains(p0)).toList();
// //       },
// //       reverse: true,
// //       emptyWidget:  EmptyView(),
// //       onRefresh: () async {},
// //       onItemSelected: (Actor item) {},
// //       inputDecoration: InputDecoration(
// //         labelText: "Search Actor",
// //         fillColor: Colors.white,
// //         focusedBorder: OutlineInputBorder(
// //           borderSide:  BorderSide(
// //             color: Colors.blue,
// //             width: 1.0,
// //           ),
// //           borderRadius: BorderRadius.circular(10.0),
// //         ),
// //       ),
// //       secondaryWidget: Padding(
// //         padding:  EdgeInsets.symmetric(horizontal: 10),
// //         child: Container(
// //           color: Colors.grey[400],
// //           child:  Padding(
// //             padding: EdgeInsets.symmetric(
// //               vertical: 20,
// //               horizontal: 10,
// //             ),
// //             child: Center(
// //               child: Icon(Icons.sort),
// //             ),
// //           ),
// //         ),
// //       ),
// //     );
// //   }
// //
// //   Widget sliverListViewBuilder() {
// //     return SearchableList<Actor>.sliver(
// //       initialList: actors,
// //       filter: (query) {
// //         return actors.where((element) => element.name.contains(query)).toList();
// //       },
// //       builder: (list, index, item) {
// //         return ActorItem(actor: list[index]);
// //       },
// //     );
// //   }
// //
// //   Widget renderAsynchSearchableListview() {
// //     return SearchableList<Actor>.async(
// //       builder: (displayedList, itemIndex, item) {
// //         return ActorItem(actor: displayedList[itemIndex]);
// //       },
// //       asyncListCallback: () async {
// //         await Future.delayed( Duration(seconds: 5));
// //         return actors;
// //       },
// //       asyncListFilter: (query, list) {
// //         return actors
// //             .where((element) =>
// //         element.name.contains(query) ||
// //             element.lastName.contains(query))
// //             .toList();
// //       },
// //       seperatorBuilder: (context, index) {
// //         return const Divider();
// //       },
// //       style: TextStyle(fontSize: 25),
// //       emptyWidget: EmptyView(),
// //       inputDecoration: InputDecoration(
// //         labelText: "Search Actor",
// //         fillColor: Colors.white,
// //         focusedBorder: OutlineInputBorder(
// //           borderSide: BorderSide(
// //             color: Colors.blue,
// //             width: 1.0,
// //           ),
// //           borderRadius: BorderRadius.circular(10.0),
// //         ),
// //       ),
// //     );
// //   }
// //
//   // Widget expansionSearchableList() {
//   //   return SearchableList<Actor>.expansion(
//   //     expansionListData: mapOfActors,
//   //     expansionTitleBuilder: (p0) {
//   //       return Container(
//   //         color: Colors.grey[300],
//   //         width: MediaQuery.of(context).size.width * 0.8,
//   //         height: 30,
//   //         child: Center(
//   //           child: Text(p0.toString()),
//   //         ),
//   //       );
//   //     },
//   //     filterExpansionData: (p0) {
//   //       final filteredMap = {
//   //         for (final entry in mapOfActors.entries)
//   //           entry.key: (mapOfActors[entry.key] ?? [])
//   //               .where((element) => element.name.contains(p0))
//   //               .toList()
//   //       };
//   //       return filteredMap;
//   //     },
//   //     style: const TextStyle(fontSize: 25),
//   //     expansionListBuilder: (int index) => ActorItem(actor: actors[index]),
//   //     emptyWidget: const EmptyView(),
//   //     inputDecoration: InputDecoration(
//   //       labelText: "Search Actor",
//   //       fillColor: Colors.white,
//   //       focusedBorder: OutlineInputBorder(
//   //         borderSide: const BorderSide(
//   //           color: Colors.blue,
//   //           width: 1.0,
//   //         ),
//   //         borderRadius: BorderRadius.circular(10.0),
//   //       ),
//   //     ),
//   //   );
//   // }
// // }
// //
// // class ActorItem extends StatelessWidget {
// //   final Actor actor;
// //
// //   const ActorItem({
// //     Key? key,
// //     required this.actor,
// //   }) : super(key: key);
// //
// //   @override
// //   Widget build(BuildContext context) {
// //     return Padding(
// //       padding: EdgeInsets.all(8.0),
// //       child: Container(
// //         height: 60,
// //         decoration: BoxDecoration(
// //           color: Colors.grey[200],
// //           borderRadius: BorderRadius.circular(10),
// //         ),
// //         child: Row(
// //           children: [
// //              SizedBox(
// //               width: 10,
// //             ),
// //             Icon(
// //               Icons.star,
// //               color: Colors.yellow[700],
// //             ),
// //              SizedBox(
// //               width: 10,
// //             ),
// //             Column(
// //               crossAxisAlignment: CrossAxisAlignment.start,
// //               mainAxisAlignment: MainAxisAlignment.center,
// //               children: [
// //                 Text(
// //                   'Firstname: ${actor.name}',
// //                   style: TextStyle(
// //                     color: Colors.black,
// //                     fontWeight: FontWeight.bold,
// //                   ),
// //                 ),
// //                 Text(
// //                   'Lastname: ${actor.lastName}',
// //                   style: TextStyle(
// //                     color: Colors.black,
// //                     fontWeight: FontWeight.bold,
// //                   ),
// //                 ),
// //                 Text(
// //                   'Age: ${actor.age}',
// //                   style: TextStyle(
// //                     color: Colors.black,
// //                   ),
// //                 ),
// //               ],
// //             ),
// //           ],
// //         ),
// //       ),
// //     );
// //   }
// // }
// //
// // class EmptyView extends StatelessWidget {
// //   const EmptyView({Key? key}) : super(key: key);
// //
// //   @override
// //   Widget build(BuildContext context) {
// //     return Column(
// //       mainAxisAlignment: MainAxisAlignment.center,
// //       children: [
// //         Icon(
// //           Icons.error,
// //           color: Colors.red,
// //         ),
// //         Text('no actor is found with this name'),
// //       ],
// //     );
// //   }
// // }
// //
// // class Actor {
// //   int age;
// //   String name;
// //   String lastName;
// //
// //   Actor({
// //     required this.age,
// //     required this.name,
// //     required this.lastName,
// //   });
// }