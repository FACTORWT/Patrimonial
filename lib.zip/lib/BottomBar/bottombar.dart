import 'dart:developer';
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:urwealthpal/Constant/Images.dart';
import 'package:urwealthpal/Constant/colors.dart';
import 'package:urwealthpal/Environment/Environment.dart';
import 'package:urwealthpal/Screens/Assets/assets.dart';
import 'package:urwealthpal/Screens/Contact_Us/contact_us.dart';
import 'package:urwealthpal/Screens/Family_Members/family_members.dart';
import 'package:urwealthpal/Screens/Home/homescreen.dart';
import 'package:urwealthpal/Screens/Languages/languageView.dart';
import 'package:urwealthpal/Screens/Liabilities/Liabilities.dart';
import 'package:urwealthpal/Screens/MPIN/MPIN.dart';
import 'package:urwealthpal/Screens/Notification/notification.dart';
import 'package:urwealthpal/Screens/Profile/profile.dart';
import 'package:urwealthpal/Screens/PurchasePlan/purchasecontroller.dart';
import 'package:urwealthpal/SideBar/drawer.dart';
import 'package:urwealthpal/main.dart';

import '../Constant/Api.dart';
import '../Constant/ApiBaseHelper.dart';

class bottombar extends StatefulWidget {
  var bottom;
  bottombar({this.bottom});

  @override
  State<bottombar> createState() => _bottombarState();
}

// LanguageController languageController =Get.put(LanguageController());

class _bottombarState extends State<bottombar> with WidgetsBindingObserver{


  PurchaseController _purchaseController = Get.put(PurchaseController());

  setBottomBarIndex(index) {
    setState(() {
      pagesIndex = index;
    });
  }

  int _itemCount = 1;

var perentId ;

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    perentId = Environment.parentID;
    pagesIndex = widget.bottom == null ? 0 : widget.bottom;
    getpagesid( "idss",  perentId.toString());
log("message--->"+perentId.toString());
    WidgetsBinding.instance.addObserver(this);
    //ApiBaseHelper().getPlandetails();
    getPurchaseHistoryPlanData();
  }

  @override
  void dispose() {
    // Remove the observer
    WidgetsBinding.instance.removeObserver(this);
    super.dispose();
  }

  List<Map<String, dynamic>> activeItems = [];

  getPurchaseHistoryPlanData() async {
    await _purchaseController.callpurchaseplanHistory_list(Get_MySubscriptionPlan_url);
    print("PurchaseplanHistoryData==>${_purchaseController.PurchaseplanHistoryData}");

    // _purchaseController.PurchaseplanHistoryData.where((item) => item['is_active'] == 1)
    //     .map((item) => Text('Edit Toggle: ${item['familymember_edit_toggle']}'))
    //     .toList();

    for (var item in _purchaseController.PurchaseplanHistoryData) {
      if (item['is_active'] == 1) {
        activeItems.add(item);

      }
    }
    print("activeItems==>${activeItems}");


  }

  AppLifecycleState? _appLifecycleState;

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    super.didChangeAppLifecycleState(state);
    _appLifecycleState = state;
    // These are the callbacks
    switch (state) {
      case AppLifecycleState.resumed:
        log("resumed case----->>>>>"+AppLifecycleState.resumed.toString());
        if(sp?.getString('imageselection') == true){
        if (Environment.askMPIN.toString()== "1"){
          Get.off(MPIN());
          String? imageSelection = sp?.getString('imageselection');
          log('Image selection: $imageSelection');
        }}
      // widget is resumed
        //mpin working
        break;
      case AppLifecycleState.inactive:
        log("inactive case------>>>>>"+AppLifecycleState.inactive.toString());
      // widget is inactive
        //working in background of the app
        break;
      case AppLifecycleState.paused:
        log("paused case------->>>>>"+AppLifecycleState.paused.toString());
      // widget is paused
        // working for lost connection of app
        break;
      case AppLifecycleState.detached:
        log("detached case------>>>>>>"+AppLifecycleState.detached.toString());
      // widget is detached
        break;
    }
  }


  void getpagesid(String idss, String salarytype) {

    salarytype.toString() == "0" || salarytype.toString() == "0" ?
    pages = [
      assets(),
      Libailitys(),
      homescreen(),
      Family_Members(),
      profile()
    ] : pages = [
      assets(),
      Libailitys(),
      homescreen(),
      contact_us(),
      profile()
    ];
  }

  int pagesIndex = 0;

  late List pages ;
  final GlobalKey<ScaffoldState> _scaffoldKey = new GlobalKey<ScaffoldState>();
  late DateTime _lastQuitTime;
  @override
  Widget build(BuildContext context) {
    Size size = MediaQuery.of(context).size;
    return WillPopScope(

      onWillPop: () async {
        if (pagesIndex != 2) {
          Navigator.pushReplacement(context,
              MaterialPageRoute(builder: (context) => bottombar(bottom: 2)));
          return false;
        } else {
          showDialog(
            context: context,
            builder: (BuildContext context) {
              return Dialog(
                child: Wrap(
                  children: [
                    Padding(
                      padding: EdgeInsets.all(4.0),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Padding(
                            padding: EdgeInsets.symmetric(vertical: 15),
                            child: Text(
                              'Do you want to exit?',
                              style: TextStyle(color: Colors.black, fontSize: 18)
                            ),
                          ),
                        ],
                      ),
                    ),
                    Padding(
                      padding: EdgeInsets.all(5.0),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                        children: [
                          ElevatedButton(
                            child: Text('Yes',
                                style: TextStyle(
                                    color: appPrimaryColor,
                                    fontWeight: FontWeight.bold)),
                            onPressed: () {
                              exit(0); // Close the dialog and exit
                            },
                            style: ElevatedButton.styleFrom(
                              backgroundColor: whiteColor,
                              elevation: 0,
                              side: BorderSide(width: 1, color: appPrimaryColor)
                            ),
                          ),
                          ElevatedButton(
                            child: Text('No',
                                style: TextStyle(
                                    color: appPrimaryColor,
                                    fontWeight: FontWeight.bold)),
                            onPressed: () {
                              Navigator.of(context).pop(
                                  false); // Close the dialog and don't exit
                            },
                            style: ElevatedButton.styleFrom(
                              backgroundColor: whiteColor,
                              elevation: 0,
                              side: BorderSide(width: 1, color: appPrimaryColor)
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              );
            },
          );
          return false;
        } // Prevent the default back button behavior
      },
      child: Scaffold(
        body: pages[pagesIndex],
        key: _scaffoldKey,
        drawer: drawer(),
        appBar: pagesIndex == 2
            ? AppBar(
                elevation: 0,
                backgroundColor: ContainerColor,
                leading: GestureDetector(
                    onTap: () {
                      _scaffoldKey.currentState!.openDrawer();
                    },
                    child: Icon(Icons.menu)),
                title: homeLogo,
          titleSpacing: 0,
                actions: [
                  // GestureDetector(
                  //   onTap: () {
                  //     // Navigator.push(context,
                  //     //     MaterialPageRoute(builder: (context)=> SearchBar()));
                  //   },
                  //   child: Icon(
                  //     Icons.search_rounded,
                  //     color: whiteColor,
                  //   ),
                  // ),
                  GestureDetector(
                    onTap: () {
                      Navigator.push(context,
                          MaterialPageRoute(builder: (context)=> notification()));

                      // Badge(
                      //   badgeContent: Text(
                      //     '$_itemCount',
                      //     style: TextStyle(color: Colors.white),
                      //   ),
                      //   position: BadgePosition.topEnd(),
                      //   badgeStyle: BadgeStyle(
                      //     shape: BadgeShape.circle,
                      //     badgeColor: ContainerColor,
                      //     padding: EdgeInsets.all(5.0),
                      //     borderRadius: BorderRadius.circular(4),
                      //     borderSide: BorderSide(width: 3),
                      //     borderGradient: BadgeGradient.linear(
                      //         colors: [ContainerColor, ContainerColor]),
                      //     badgeGradient: BadgeGradient.linear(
                      //       colors: [ContainerColor, ContainerColor],
                      //       begin: Alignment.topCenter,
                      //       end: Alignment.bottomCenter,
                      //     ),
                      //     elevation: 0,
                      //   ),
                      //   child: IconButton(
                      //     icon: Icon(
                      //       Icons.shopping_cart_outlined,
                      //       color: Colors.black,
                      //       size: 30,
                      //     ),
                      //     onPressed: () {},
                      //   ),
                      // );
                    },
                    child:
                    Padding(
                      padding:  EdgeInsets.only(right: 5),
                      child: Image.asset("assets/images/notification.png",
                      height: 15,
                        width: 18,
                      ),
                    )
                  ),
                  // GestureDetector(
                  //   onTap: () {
                  //     Navigator.push(
                  //         context,
                  //         MaterialPageRoute(
                  //             builder: (context) => notification()));
                  //   },
                  //   child: Padding(
                  //     padding: EdgeInsets.only(left: 4),
                  //     child: Icon(
                  //       Icons.notifications_active_outlined,
                  //       color: whiteColor,
                  //     ),
                  //   ),
                  // ),

                  GestureDetector(
                    onTap: () {
                      showDialog(
                          context: context,
                          builder: (builder) {
                            return LanguageView(index: pagesIndex,);
                          });
                    },
                    child:
                        Padding(
                          padding:  EdgeInsets.only(left: 5,right: 10),
                          child: Container(
                              // width: size.width * 0.12,
                              child:  sp!.getString("languagetype" )=="Spanish"?
                              ClipRRect(
                                clipBehavior: Clip.none,
                                  borderRadius: BorderRadius.circular(20),
                                  child: Image.asset("assets/images/spanish_flag.png",
                                    height: 30,
                                    width: 30,
                                    scale: 1.8,
                                  ))
                              :ClipRRect(
                                  clipBehavior: Clip.none,
                                  borderRadius: BorderRadius.circular(20),
                                  child: Image.asset("assets/images/english falg.png",
                                    height: 30,
                                    width: 30,
                                  scale: 1.8,
                                  ))

                          ),
                        ),
                  ),
                ],
              )
            : AppBar(
                elevation: 0,
          titleSpacing: 0,
                backgroundColor: ContainerColor,
                // toolbarHeight: 100,
                // shape: RoundedRectangleBorder(
                //   borderRadius: BorderRadius.only(
                //       bottomLeft: (Radius.circular(20)),
                //       bottomRight: (Radius.circular(20))),
                // ),
                title: Text(
                  pagesIndex == 0
                      ? "assetstxt".tr
                      : pagesIndex == 1
                          ? "Liabilities_txt".tr
                          : pagesIndex == 3
                              ?perentId.toString()== "0" ? "family_member_txt".tr:"contactUstxt".tr
                              : pagesIndex == 4
                                  ? "profiletext".tr
                                  : "",
                  style: TextStyle(color: whiteColor),
                ),
          actions: [
            GestureDetector(
              onTap: () {
                showDialog(
                    context: context,
                    builder: (builder) {
                      return LanguageView(index: pagesIndex,);
                    });
              },
              child:
              Padding(
                padding:  EdgeInsets.only(left: 5,right: 10),
                child: Container(
                  // width: size.width * 0.12,
                    child:  sp!.getString("languagetype" )=="Spanish"?
                    ClipRRect(
                        clipBehavior: Clip.none,
                        borderRadius: BorderRadius.circular(20),
                        child: Image.asset("assets/images/english falg.png",
                          height: 30,
                          width: 30,
                          scale: 1.8,
                        ))
                        :ClipRRect(
                        clipBehavior: Clip.none,
                        borderRadius: BorderRadius.circular(20),
                        child: Image.asset("assets/images/maxico_flag.png",
                          height: 30,
                          width: 30,
                          scale: 1.8,
                        ))

                ),
              ),
            ),
          ],
              ),
        bottomNavigationBar: Container(
          decoration: BoxDecoration(
            color: sidebarcontainerColor,
            borderRadius: BorderRadius.only(
                topLeft: (Radius.circular(18)),
                topRight: (Radius.circular(18))),
          ),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              GestureDetector(
                onTap: () {
                  if(activeItems[0]['assets_toggle']==0){
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(
                        content: Text("Your purchased plan doesn't support Assets !!"),
                        duration: Duration(seconds: 2),
                        behavior: SnackBarBehavior.floating,
                        backgroundColor: Red,
                      ),
                    );

                  }else{
                      pagesIndex = 0;
                      setState(() {

                      });
                    }

                },
                child: Container(
                  width: MediaQuery.of(context).size.width / 5,
                  height: 60,
                  decoration: BoxDecoration(
                    color: sidebarcontainerColor,
                    borderRadius: BorderRadius.only(
                      topLeft: (Radius.circular(18)),
                      // topRight: (Radius.circular(18))
                    ),
                  ),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Container(
                        child: AssetsImage,
                        height: 20,
                      ),
                      SizedBox(
                        height: 10,
                      ),
                      Text(
                        "assetstxt".tr,
                        style: TextStyle(color: whiteColor, fontSize: 10),
                      ),
                    ],
                  ),
                ),
              ),
              GestureDetector(
                onTap: () {
                  if(activeItems[0]['libilities_toggle']==0){
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(
                        content: Text("Your purchased plan doesn't support Liabilities !!"),
                        duration: Duration(seconds: 2),
                        behavior: SnackBarBehavior.floating,
                        backgroundColor: Red,
                      ),
                    );

                  }else{
                    pagesIndex = 1;
                    setState(() {});
                  }

                },
                child: Container(
                  width: MediaQuery.of(context).size.width / 5,
                  height: 60,
                  decoration: BoxDecoration(
                    color: sidebarcontainerColor,
                    // borderRadius: BorderRadius.only(
                    //     topLeft: (Radius.circular(18)),
                    //     topRight: (Radius.circular(18))),
                  ),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Container(
                        child: LibailityImage,
                        height: 20,
                      ),
                      SizedBox(
                        height: 10,
                      ),
                      Text(
                        "Liabilities_txt".tr,
                        style: TextStyle(color: whiteColor, fontSize: 10),
                      ),
                    ],
                  ),
                ),
              ),
              Padding(
                padding: EdgeInsets.only(bottom: 10),
                child: Container(
                  width: 70,
                  decoration: BoxDecoration(
                      color: whiteColor,
                      border: Border.all(color: whiteColor),
                      borderRadius: BorderRadius.only(
                          bottomRight: (Radius.circular(50)),
                          bottomLeft: (Radius.circular(50)))),
                  child: IconButton(
                      enableFeedback: false,
                      onPressed: () {
                        setState(() {
                          pagesIndex = 2;
                        });
                      },
                      icon: Padding(
                        padding: EdgeInsets.only(bottom: 10),
                        child: HomeImage,
                      )),
                ),
              ),

              perentId.toString() == "0"   ?
              GestureDetector(
                onTap: () {
                  if(activeItems[0]['familymember_toggle']==0){
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(
                        content: Text("Your purchased plan doesn't support Family Member !!"),
                        duration: Duration(seconds: 2),
                        behavior: SnackBarBehavior.floating,
                        backgroundColor: Red,
                      ),
                    );

                  }else{
                    pagesIndex = 3;
                    setState(() {

                    });
                  }
                },
                child: Container(
                  width: MediaQuery.of(context).size.width / 5,
                  height: 60,
                  decoration: BoxDecoration(
                    color: sidebarcontainerColor,
                  ),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Container(
                        child: AssetsShareImage,
                        height: 20,
                      ),
                      SizedBox(
                        height: 10,
                      ),
                      Text(
                        "family_txt".tr,
                        style: TextStyle(color: whiteColor, fontSize: 10),
                      ),
                    ],
                  ),
                ),
              ):

              GestureDetector(
                onTap: () {
                  // Navigator.push(context, MaterialPageRoute(
                  //     builder: (context) => bottombar(bottom: 3,)));
                  setState(() {
                    pagesIndex = 3;
                  });
                },
                child: Container(
                  width: MediaQuery.of(context).size.width / 5,
                  height: 60,
                  decoration: BoxDecoration(
                    color: sidebarcontainerColor,
                  ),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Container(
                        child: ContactUsbottom_Icon,
                        height: 20,
                      ),
                      SizedBox(
                        height: 10,
                      ),
                      Text(
                        "contactUstxt".tr,
                        style: TextStyle(color: whiteColor, fontSize: 10),
                      ),
                    ],
                  ),
                ),
              ),
              GestureDetector(
                onTap: () {
                  setState(() {
                    pagesIndex = 4;
                  });
                },
                child: Container(
                  width: MediaQuery.of(context).size.width / 5,
                  height: 60,
                  decoration: BoxDecoration(
                    color: sidebarcontainerColor,
                    borderRadius: BorderRadius.only(
                        // topLeft: (Radius.circular(18)),
                        topRight: (Radius.circular(18))),
                  ),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Container(
                        child: ProfileImage,
                        height: 20,
                      ),
                      SizedBox(
                        height: 10,
                      ),
                      Text(
                        "profiletext".tr,
                        style: TextStyle(color: whiteColor, fontSize: 10),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
