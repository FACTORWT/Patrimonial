import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:urwealthpal/main.dart';

class Environment {

  static String get filename {
    if (kReleaseMode) {
      return '.env.prod';
    }
    return '.env.dev';
  }
  // static String? get apibaseurl{
  //
  //
  //   return  dotenv.env['baseurl'];
  // }
  static String?  get apibaseurl{
  return  dotenv.env['baseurl'];
}

  static String get userid{
    var loginresponse = json.decode(sp!.getString("login_response")!);
    var userid =loginresponse['employeeId'].toString();

    return  userid;
  }

  static String? get appname{
    return dotenv.env['appname'];
  }

  static String? get appversion{
    return dotenv.env['appversion'];
  }

  static String? get appstatus{
    return dotenv.env['appstatus'];
  }
  static bool get appuserlog{
    var userlog = sp!.getBool("loggedin")??false;
    return userlog;
  }


  static String? get askMPIN{
    var askmpin = sp!.getString("ask_mpin")??"0";

    return  askmpin;
  }
  static String? get askQuestion{
    var askQuestion = sp!.getString("askQuestion")??"0";

    return  askQuestion;
  }
  static String? get setMPIN{
    var setmpin = sp!.getString("set_mpin")??"0";

    return  setmpin;
  }
  static bool? get checkpaymentstatus{
    var paymentstatus =sp!.getBool("paymentstatus")??false;

    return  paymentstatus;
  }

  static String? get parentID{
    var parent_ID = sp!.getString("parent_id");

    return  parent_ID;
  }

  static String? get apptimeout{
    return dotenv.env['apptimeout'];
  }
  static String? get appxapikey{
    return dotenv.env['header_xpi'];
  }
  static String? get appxapivalue{
    return dotenv.env['header_xpi_value'];
  }
}
